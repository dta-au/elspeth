# tests/unit/cicd: single Python 3.14 lane (report)

Worktree: /home/user/elspeth/.claude/worktrees/composer-0.8.12 (branch python-3.14-only).
Production files (scripts/ci_test_shards.py, .github/workflows/*) were read only, never edited. Nothing staged or committed.

## Result

- `PYTHONPATH=$PWD/src:$PWD/elspeth-lints/src .venv-314/bin/python -m pytest tests/unit/cicd -n 3 -p no:cacheprovider -q -rfE`
  wrote `.claude/lanes/py314/cicd-agent.log`. **exit=0**, `987 passed in 111.38s`.
- `ruff check tests/unit/cicd`: "All checks passed!" (exit 0). `ruff format --check tests/unit/cicd`: "14 files already formatted" (exit 0). Log: `.claude/lanes/py314/cicd-ruff.log`.
- Before my edits, against the new production code: exit=1, `691 failed, 587 passed` (`.claude/lanes/py314/cicd-agent-before.log`).
  That includes `test_partitioned_validator_consumes_real_successful_pytest_producers`, the known baseline failure. It now passes because the real 3.14 interpreter is the supported lane.
- The test count fell from 1278 to 987 because the `version` parametrisation went from two values to one. Most of the drop comes from the large mutation × producer grids.
- `.venv-314/bin/python -c "import elspeth"` works after the restart: Python 3.14.6, and `elspeth` resolves inside the worktree.
- A first rerun after the restart turned up 2 failures in `test_timing_real_no_pass_evidence_is_refused` (see below). They were fixed, and the full rerun above is green.

## Files changed

- tests/unit/cicd/test_ci_sharding.py
- tests/unit/cicd/test_ci_timing_sharding.py
- tests/unit/cicd/test_workflow_supply_chain_closure.py

No helper or fixture files were touched (`workflow_sources.py` did not need changes).

## test_ci_sharding.py

- Added a module constant `LANE = "3.14"`. It is a literal, deliberately not read from production, so a silent production retarget turns the tests red. Also imported `COVERAGE_PYTHON_VERSION` and `SUPPORTED_PYTHON_VERSIONS`.
- `_artifacts` fixture: `coverage-shard-3.13-*` became `coverage-shard-3.14-*`, and the manifest `python_version` became 3.14.
- `_long_run_artifacts(tmp_path, monkeypatch, count=4)`: the `version` parameter is gone (it is always LANE).
  - Removed the 3.12 branch that deleted the ordinary coverage DB and its hash.
  - Proof and timing producers now always carry coverage databases.
- Combine tests: all `coverage-shard-3.13` became 3.14. The `wrong_version` negative control now mutates to "3.13" (it was "3.12").
- Collapsed `version` parametrisation from ["3.12","3.13"] to the single lane:
  - `requires_eight_producers_and_all_case_coverage`
  - `rejects_selected_invalid_evidence`
  - `retains_newest_attempt_content_policy`
  - `refuses_invalid_native_namespace`
  - `bucket_check_is_independent_of_union_digest`
  - `rederives_unequal_weights_instead_of_equal_defaults`
  - `yaml_partition_validation_consumes_real_tiny_evidence_and_refuses_missing_proof`
  - All of their mutation sets are kept.
- `validates_each_real_database`, `requires_strict_shard_count` and `partitioned_cli_returns_selected_attempt_provenance` moved from 3.13/3.12 to LANE.
- `partitioned_validator_consumes_real_successful_pytest_producers`:
  - Now always runs producers with `--cov` and always checks coverage.
  - Now asserts up front that the real interpreter is LANE, with a clear message, so it does not fail deep inside the validator.
- `_assert_activation_contract` checks one lane:
  - three `Download Python 3.14 {ordinary,proof,timing} evidence` steps, with exact pattern and path;
  - the `Validate Python 3.14 selection and combine coverage` argv.
  - New strictness: the coverage job has exactly 3 download-artifact steps and exactly one `ci_test_shards.py` validation step.
  - New strictness: the `test` and `timing-sensitive` matrices are exactly `[3.14]`, with a single include row `(3.14, coverage: true)` and a `python:3.14-bookworm@sha256:` image.
  - Updated the "Both interpreters publish" comment.
- `activation_contract_refuses_disconnected_proof_paths`: all old mutations kept and retargeted at the 3.14 steps. `download` removes the 3.14 proof download. `version` rewrites `--python-version 3.14` to 3.13. New mutations, all confirmed red:
  - `download_retarget` (proof pattern points at 3.13)
  - `artifact_dir` (validation reads proof-evidence/3.13)
  - `retired_lane_download` (a 3.13 download step is re-added)
  - `retired_lane_validation` (a 3.13 validation step is re-added)
  - `matrix_lane` (3.13 added to the test matrix)
  - `matrix_coverage` (timing row gets coverage: false)
- `activation_contract_refuses_disconnected_timing_paths`: the `download` mutation now removes `Download Python 3.14 timing evidence`.

## test_ci_timing_sharding.py

- Imports `LANE`. All calls to `_long_run_artifacts` and `validate_long_run_shards` use the single lane.
- Collapsed the version parametrisation in `requires_complete_calls_and_a_pass` and `refuses_invalid_identity_collection_or_marker_evidence`.
  - Added a `retired-python` mutation to the second, which sets python_version to 3.13 and must be refused. The existing "3.99" mutation is kept.
- `requires_its_producer_and_includes_covered_lines`: the covered-lines assertion now always runs. I added a check that no `.coverage` is written when the producer is missing.
- `verifies_its_coverage_database` and `latest_attempt_supersedes_bad_older_evidence_without_falling_back` moved to LANE.
- `timing_real_no_pass_evidence_is_refused`: the old test ran on 3.12, which needed no coverage, so it never had to handle the coverage database. On the coverage lane, its positive control failed with "coverage database differs from its finalized test evidence".
  - The cause: the real subprocess manifest (run without `--cov`) has no `coverage_sha256`, while the fixture's coverage DB is still in the folder.
  - Fix: `coverage_sha256` is now copied along with the other fixture producer-envelope fields (commit, run, attempt, job, python, profile). Collection and call evidence still come from the real subprocess.
  - The negative assertion (`ValueError, match="timing call"`) is unchanged and still passes.

## test_workflow_supply_chain_closure.py

- The long-run matrix row count went from 6 to 3, and `rejects_mutable_image_in_every_row` from `range(6)` to `range(3)`. Each of the 3 rows still goes red with `python:latest`.
- The example image in the container-pin validator control went from python:3.13-bookworm to python:3.14-bookworm (both the digest-pinned positive and the mutable negative).

## Tests removed or converted

- **Removed — every 3.12 (non-coverage) case of the version-parametrised consumer tests**, in both files. They checked a lane that `validate_long_run_shards` now refuses outright. The coverage-lane cases are kept with all their mutations.
- **Removed — the `else` branch of `requires_eight_producers_and_all_case_coverage`** (no databases and no `.coverage` on 3.12). That branch can no longer be reached.
- **Removed — the 3.12 branch of `retains_newest_attempt_content_policy`** that wrote "[]" for the database-damage cases. On the coverage lane, the real database, hash and tamper damage paths are always exercised.
- **Converted — `partitioned_cli_returns_selected_attempt_provenance`**:
  - It used to run the 3.12 lane; it now runs 3.14 and also asserts `.coverage` is produced.
  - Added a negative control: `--python-version 3.13` exits 2 with "invalid choice" and writes no `.coverage`.
- **Converted — `requires_strict_shard_count`**: 3.12 became 3.14. Its control and negatives are unchanged.
- **Converted — `timing_latest_attempt_supersedes...` and `timing_real_no_pass_evidence_is_refused`**: 3.12 became 3.14. The second needed the `coverage_sha256` envelope fix described above.
- **Converted — `yaml_partition_validation...`**: now a single lane. It asserts `.coverage` exists exactly when the proof is present.
- **Added — `test_ci_lane_is_the_single_supported_coverage_interpreter`**: pins `COVERAGE_PYTHON_VERSION == "3.14"` and `SUPPORTED_PYTHON_VERSIONS == {"3.14"}`.
- **Added — `test_long_run_consumer_refuses_unsupported_interpreter_lane[3.12|3.13|3.15|unknown]`**:
  - Positive control first: the evidence validates on 3.14.
  - Then the artifact folders are renamed to the other version, and validation must raise "supported Python version" without writing `.coverage`.
  - This replaces the old "3.12 is valid but uncovered" coverage with a refusal proof.

## Concerns about production (none blocking; nothing edited)

1. **Two steps in ci.yaml can no longer run.**
   - The steps: "Run tests without coverage" (`if: ${{ !matrix.coverage }}`, line ~544) and the matching non-coverage step in timing-sensitive (line ~676).
   - With a single coverage: true row, neither can execute.
   - `_assert_activation_contract` still requires the "Run tests without coverage" step to exist and match the partition argv, so I left that assertion in place.
   - If you delete those steps, update the loop over `("Run tests with coverage", "Run tests without coverage")` in `_assert_activation_contract`.
2. **The real-producer test now needs a 3.14 interpreter.** `test_partitioned_validator_consumes_real_successful_pytest_producers` asserts the interpreter is 3.14, so it fails on any non-3.14 venv. That is consistent with a 3.14-only project. Other environments (for example the main checkout's `.venv`, if it is not 3.14) will see that failure.
3. `git status` earlier also showed modified `tests/unit/elspeth_lints/*` and `scripts/cicd/regen_fingerprint_baseline.py`. Those are not mine and were not touched.
