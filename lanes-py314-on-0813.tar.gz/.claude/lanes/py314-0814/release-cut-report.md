# 0.8.14 release cut — report

Worktree: `.claude/worktrees/py314-on-0813`, branch `python-3.14-on-0.8.13`.
Nothing committed or pushed. Template: `b2584269` (the 0.8.13 cut).

## Result

The cut is done and its release-surface tests pass. One test still fails
because of the cut: `tests/unit/test_version.py::test_version_matches_pyproject`
reads the installed package metadata, and this worktree's venv still has
`elspeth-0.8.13.dist-info`. Refreshing it needs
`uv pip install --python .venv/bin/python --no-deps -e .`; the permission
classifier denied that command, so it has not been run.

## Files changed (27, the same set as `b2584269`)

Token-only `0.8.13` -> `0.8.14` (every occurrence in the file):

- `pyproject.toml`, `src/elspeth/web/_acceptance_common/schema_facts.py`
- `uv.lock` via `uv lock`: "Updated elspeth v0.8.13 -> v0.8.14"; the diff is the one version line
- `docs/README.md`, `docs/release/README.md` (3), `docs/release/composer-guide.md`, `docs/release/platform-architecture.md`
- `docs/runbooks/aws-ecs-deployment.md`, `azure-container-apps-cold-install.md`, `azure-container-apps-deployment.md` (5), `azure-container-apps-existing-service-redeploy.md`, `index.md`
- `deploy/azure-container-apps/README.md`, `.agents/skills/operating-azure-container-apps/SKILL.md`
- `docs/guides/docker.md`, `docs/reference/deployment-platforms.md`
- `website/{index,authoring,assurance,use-cases,get-started}.html`
- `docs/architecture/dag/scenario-corpus/v1/manifest.yaml`: 8 `engine:0.8.13` values on 7 lines

Evidence path `docs/operator/evidence/azure-container-apps/0.8.13.json`: the
precedent only renamed the reference in prose (no such file is tracked), so
the references now read `0.8.14.json`.

Written by hand:

- `CHANGELOG.md`: new `## 0.8.14 - 2026-11-11` section above 0.8.13. From
  `## 0.8.13` to end of file is byte-identical to HEAD (sha256 `764d5fa9...` both sides).
- `README.md`: badge; new "What changed in 0.8.14"; the 0.8.13 text kept under
  "Previously in 0.8.13" with its "Package metadata is ..." sentence removed
  and "which also record earlier releases" dropped, as was done for 0.8.12.
- `tests/unit/docs/test_readme_release_surface.py`: current-release assertions
  now state 0.8.14 facts; new `test_readme_keeps_the_0_8_13_context_budget_as_a_historical_pin`.
- `tests/unit/website/test_release_site_contract.py`: current-release
  assertions now state 0.8.14 facts; the 0.8.13 statements (date, budget,
  960 KiB, #364, stores, tag sentence) are pinned against the 0.8.13 section.
- `tests/unit/architecture/test_dag_scenario_corpus_contract.py`: new pin and comment.

`tests/unit/docs/test_release_version_surfaces.py` needed no edit; it passes.

## Corpus pin

- Captured from the parity failure of
  `test_registered_cases_and_harness_references_have_exact_atomic_parity`
  after the manifest change (`corpus-capture.log`: 1 failed, 441 passed):
  new `d287953784cfb9bcd56f17f0be4b68c59df0a1e4c1b411cf1a3d0786409e091e`,
  previous `3338f07b09c11e79c487f9136bff55eef0c0f80aad4f25de32a07e67eab110d7`.
- Control (`corpus-control.log`): with the new pin in place, the eight values
  were put back to `engine:0.8.13` (manifest then equal to HEAD, `git diff --quiet`).
  The test failed reporting actual `3338f07b...110d7`, the previous pin. The
  0.8.14 manifest was then restored (sha256 `05ee2224...` before and after).

## Test runs (logs in this directory)

1. Requested set (`release-surface.log`), exit code 1:
   `1 failed, 991 passed, 62 skipped, 2 warnings in 222.97s`
   - `tests/unit/docs/test_adr_public_integrity.py::test_audited_adr_commit_citations_resolve_to_reachable_history`
     — pre-existing, not the cut: ADR-cited commits do not resolve in this clone.
   - The two `test_aws_ecs_terraform_package.py` tests named as known failures
     did not fail in this worktree (they passed in run 2 as well).
2. Other version-pinned tests (`version-pins.log`: the two AWS floor tests,
   `test_version.py`, `test_runtime_dependency_contract.py`,
   `web/acceptance_common`, `aws_ecs_acceptance/test_receipt_contracts.py`,
   `azure_container_apps_acceptance`, `test_azure_container_apps_runbook_contract.py`,
   `test_build_push_release_checks.py`), exit code 1:
   `1 failed, 944 passed, 5 warnings in 422.38s`
   - `tests/unit/test_version.py::test_version_matches_pyproject`
     (`'0.8.13' == '0.8.14'`) — caused by the cut, environmental: stale
     editable-install metadata, see Result.
3. `ruff check tests src`: exit 0. `ruff format --check tests src`: exit 0
   (3821 files already formatted).

Not run: the full suite, testcontainer suites, elspeth-lints, mypy.

## AWS minimum image revision

No re-point is needed for the cut. The floor test derives the revision from
which commit introduced the shipped `ELSPETH_WEB__` settings; the cut adds no
setting, and the test passes on this tree. It will need re-pointing only if a
later rebase rewrites the commit `deploy/aws-ecs/terraform/README.md` names.

## Unsure / to check

- Three changelog facts were taken from the brief and not measured here: the
  four drifting signed allowlist entries (no keyless scan run), the 169-file
  ruff figure (from commit `da6f4c4d`'s message), and "CI itself not run on
  the new lane". The rest were checked against the ten commits' messages and
  the source (JSON_LOGS refusal in `core/logging.py`, called from
  `configure_logging` and both MCP entry points; the approval record's
  `runtime_val_manifest_sha256`; Dockerfile bases and paths).
- The changelog's stores sentence reads "Existing 0.8.13 session and Landscape
  stores need no action beyond the drain above". The README keeps the
  test-pinned wording "existing session and Landscape stores need no action"
  in the epoch paragraph, directly after the paragraph that says to drain.
- The token replacement over the 21 single-token files and the manifest was
  done with a short Python `str.replace` over an explicit file list (no
  sed/awk), then checked against `git diff --stat`, which matches the
  precedent line for line. The manifest lines are too long for the Edit tool.
- The 0.8.14 section adds a `### Logging` heading beside `### Engine and runtime`.
- Remaining `0.8.13` mentions are historical: the changelog section, the
  README "Previously" section, design docs and briefs, a whitelist comment,
  the old pin comment, and the new historical-pin tests.
