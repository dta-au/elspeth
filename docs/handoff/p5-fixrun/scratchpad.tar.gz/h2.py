import codecs, io, encodings, pkgutil
def dec(exc):
    if isinstance(exc, UnicodeDecodeError):
        return "".join(chr(0xDC00 + b) for b in exc.object[exc.start:exc.end]), exc.end
    raise exc
codecs.register_error("x.dec", dec)
names = sorted({m.name for m in pkgutil.iter_modules(encodings.__path__)})
bad = []
for n in names:
    try: codecs.lookup(n)
    except Exception: continue
    for data in (bytes(range(256))*3, b"\xff\xfe\x00\xd8\x00\xdc\x00"*5, b"+\xff-\n\x80"):
        try:
            f = io.TextIOWrapper(io.BytesIO(data), encoding=n, errors="x.dec", newline="")
            list(f)
        except LookupError: break
        except Exception as e:
            bad.append((n, type(e).__name__, str(e)[:80])); break
for b in bad: print(b)
