from elspeth.plugins.infrastructure.manager import get_shared_plugin_manager
from elspeth.plugins.infrastructure.base import BaseSink
pm = get_shared_plugin_manager()
for cls in pm.get_sinks():
    print(cls.name, "supports_resume=", cls.supports_resume,
          "overrides validate_output_target=", cls.validate_output_target is not BaseSink.validate_output_target,
          "overrides configure_for_resume=", cls.configure_for_resume is not BaseSink.configure_for_resume)
