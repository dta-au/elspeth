import sys
sys.path.insert(0, "tests/unit/plugins")
import test_dataverse_p2_sweep as t
from unittest.mock import patch
with patch("elspeth.plugins.infrastructure.clients.dataverse.validate_url_for_ssrf", side_effect=lambda url, **k: t._ssrf_safe(url)):
    tr = t._FakeDataverse(lambda r: t._metadata_or(r, lambda q: {"value": [t._contact_row(q, "1")]}))
    rows, ctx = t._load_rows(t._odata_config(include_formatted_values=True), tr)
    for r in tr.requests: print(r.url, r.headers.get("prefer"))
    print([x.row for x in rows], [getattr(x,"is_quarantined",None) for x in rows])
