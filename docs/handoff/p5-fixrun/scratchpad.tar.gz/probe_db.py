import sys, tempfile
from pathlib import Path
from tests.integration.plugins.sinks.test_database_sink_effects import _provision, _config, _prepare, _CTX
from elspeth.plugins.sinks.database_sink import DatabaseSink
import elspeth; print(elspeth.__file__)
d = Path(tempfile.mkdtemp(dir=sys.argv[1]))
url = f"sqlite:///{d/'e.db'}"
_provision(url)
sink = DatabaseSink(_config(url))
for n in (10, 200):
    rows = tuple({"id": i, "name": "x"*500} for i in range(n))
    try:
        plan = _prepare(sink, rows, effect_id=("a" if n==10 else "b")*64)
        print(n, "ok")
    except Exception as e:
        print(n, type(e).__name__, str(e)[:200])
