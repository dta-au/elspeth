import re
def edit(p, pairs):
    s=open(p).read()
    for a,b in pairs:
        assert s.count(a)==1,(p,a)
        s=s.replace(a,b)
    open(p,"w").write(s)
edit("tests/unit/plugins/infrastructure/test_infrastructure_p3_sweep.py",[('''def test_truncate_header_spelling_key_of_a_declared_field_still_constructs() -> None:
    """Finding #0 caveat: a key whose canonical spelling IS declared is not refused.

    truncate resolves a header-spelled key through the row contract, so
    ``{'Value Text': 10}`` / ``{'Notes': 5}`` against fixed ``value_text`` /
    ``notes`` reach the declared field; only the canonical form is compared.
    """''','''def test_truncate_header_spelling_key_of_a_declared_field_still_constructs() -> None:
    """Finding #0 caveat: a key whose canonical spelling IS declared is not refused HERE.

    The fixed-schema read check compares canonical forms for every plugin, so
    ``{'Value Text': 10}`` / ``{'Notes': 5}`` against fixed ``value_text`` /
    ``notes`` construct. The header spelling is refused by the field-name
    spelling rule at build instead (truncate's keys are declared string
    inputs since plugin review #146; pinned in
    tests/integration/pipeline/test_field_name_spelling_rule.py), so the
    operator gets the rule's own verdict rather than "forbidden by schema".
    """''')])
edit("src/elspeth/plugins/infrastructure/base.py",[('''        # A header spelling whose canonical form is declared reaches that field
        # through the row contract at run time (``truncate`` resolves its keys
        # that way), so only a name whose canonical form is ALSO undeclared is
        # unsatisfiable. The spelling rule itself is the build's to enforce.''','''        # A header spelling whose canonical form is declared is not "forbidden
        # by the schema": it is a misspelling of a declared field, which the
        # field-name spelling rule refuses at build with its own verdict
        # (``validate_declared_field_spellings``). Only a name whose canonical
        # form is ALSO undeclared is this check's to reject.'''),
('''        - ``declared_string_input_fields``: the scan fields the text-scanning
          family (keyword_filter, the content-safety and prompt-shield
          guardrails, document intelligence's ``source_field``) requires
          present and string-valued. The string-type build validator compares
          them to the upstream schema as written, so a header spelling would
          walk past it.

        Deliberately NOT the column-option limb of ``consumed_input_fields``:
        an option that stays off those surfaces is a row LOOKUP, resolved
        through ``PipelineRow`` under either spelling (truncate's ``fields``,
        field_mapper's non-normalized mapping sources), and the ruling keeps lookups
        spelling-free.''','''        - ``declared_string_input_fields``: the fields a transform requires
          present and string-valued — keyword_filter's named ``fields``, the
          content-safety and prompt-shield guardrails' ``fields``, document
          intelligence's ``source_field`` and truncate's ``fields`` keys
          (plugin review #146). The string-type build validator compares them
          to the upstream schema as written, so a header spelling would walk
          past it.

        Deliberately NOT the column-option limb of ``consumed_input_fields``:
        an option that stays off those surfaces is a row LOOKUP, resolved
        through ``PipelineRow`` under either spelling (field_mapper's
        non-normalized mapping sources), and the ruling keeps lookups
        spelling-free.'''),
('''    # Column-naming config options whose value is a MAPPING keyed by the
    # input column it applies to (``truncate.fields: {column: max_len}``).
    # Their keys are read columns for the fixed-schema read check and for
    # demotion protection.''','''    # Column-naming config options whose value is a MAPPING keyed by the
    # input column it applies to (``truncate.fields: {column: max_len}``).
    # Their keys are read columns for the fixed-schema read check and for
    # demotion protection. This describes the option's shape only; it grants
    # no lookup semantics (a plugin that requires the columns declares them on
    # ``declared_input_fields`` / ``declared_string_input_fields``).''')])
edit("src/elspeth/core/dag/schema_validation.py",[('''    of the text-scanning family (Bedrock/Azure guardrails' ``fields``,
    keyword_filter's named ``fields``, document intelligence's
    ``source_field``), which quarantines the row otherwise.''','''    of the text-scanning family (Bedrock/Azure guardrails' ``fields``,
    keyword_filter's named ``fields``, document intelligence's
    ``source_field``) and of truncate's ``fields`` keys, which quarantines the
    row otherwise.''')])
