import re,sys
from pathlib import Path
from scripts.cicd.plugin_hash import compute_source_file_hash as h
for f in sys.argv[1:]:
    p=Path(f); src=p.read_text()
    old=re.search(r'source_file_hash: str \| None = "(sha256:[0-9a-f]+)"',src).group(1)
    new=h(p)
    print(f, old, new)
    if old!=new and "--write" in sys.argv[0:1]+[]: pass
