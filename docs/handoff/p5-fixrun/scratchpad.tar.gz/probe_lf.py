from elspeth.plugins.transforms.llm.langfuse import create_langfuse_tracer
from elspeth.plugins.transforms.llm.tracing import LangfuseTracingConfig
a = create_langfuse_tracer("t1", LangfuseTracingConfig(public_key="pk-x", secret_key="sk-a", host="https://lf-a.example.com"))
b = create_langfuse_tracer("t2", LangfuseTracingConfig(public_key="pk-x", secret_key="sk-b", host="https://lf-b.example.com"))
print("b client base_url:", b.client._base_url, " resources base_url:", b.client._resources.base_url, " same:", a.client._resources is b.client._resources)
