import chromadb
c = chromadb.EphemeralClient()
col = c.get_or_create_collection("tst", metadata={"hnsw:space":"cosine"})
col2 = c.get_or_create_collection("tst", metadata={"hnsw:space":"l2"})
print("space after second get_or_create:", col2.metadata, getattr(col2, "configuration_json", None) if hasattr(col2,"configuration_json") else "")
def tryit(label, **kw):
    try:
        col.upsert(**kw); print(label, "OK")
    except Exception as e:
        print(label, type(e).__mro__[:3], str(e)[:120])
class F:  # avoid embedding download
    pass
tryit("empty id", ids=[""], documents=["x"], embeddings=[[0.1,0.2]])
tryit("bigint", ids=["a"], documents=["x"], metadatas=[{"k": 2**70}], embeddings=[[0.1,0.2]])
tryit("reserved", ids=["b"], documents=["x"], metadatas=[{"chroma:document": "v"}], embeddings=[[0.1,0.2]])
tryit("none meta", ids=["c"], documents=["x"], metadatas=[{"k": None}], embeddings=[[0.1,0.2]])
print(col.get(ids=["c"], include=["metadatas"]))
