from elspeth.plugins.infrastructure.manager import get_shared_plugin_manager
pm = get_shared_plugin_manager()
hits=[]
for cls in pm.get_transforms():
    if cls.policy_capabilities:
        m = cls.get_config_model()
        print(cls.name, "detect_only in model:", m is not None and "detect_only" in m.model_fields, "extra:", None if m is None else m.model_config.get("extra"))
