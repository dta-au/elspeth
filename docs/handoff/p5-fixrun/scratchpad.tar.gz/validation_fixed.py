"""Plugin configuration validation subsystem.

Validates plugin configurations BEFORE instantiation, providing clear error
messages and enabling test fixtures to bypass validation when needed.

Design:
- Validation is separate from plugin construction
- Returns structured errors (not exceptions) for better error messages
- Validates against Pydantic config models (CSVSourceConfig, etc.)
- Does NOT instantiate plugins (just validates config)

Usage:
    from elspeth.plugins.infrastructure.validation import validate_source_config

    errors = validate_source_config("csv", config)
    if errors:
        raise ValueError(f"Invalid config: {errors}")
    source = CSVSource(config)  # Assumes config is valid
"""

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from pydantic import ValidationError as PydanticValidationError

from elspeth.contracts.plugin_protocols import PluginConfigProtocol, SinkProtocol, SourceProtocol, TransformProtocol
from elspeth.plugins.infrastructure.config_base import _SCHEMA_REQUIRED_GUIDANCE, PluginConfigError


class UnknownPluginTypeError(ValueError):
    """Raised when a plugin type string is not in the validator's mapping."""


@dataclass(frozen=True, slots=True)
class ValidationError:
    """Structured validation error.

    Frozen: error records are immutable evidence — once created, the
    captured field, message, and value must not be modified.

    Attributes:
        field: Field name that failed validation
        message: Human-readable error message
        value: None for configuration errors. Resolved inputs can contain
               credentials and are never diagnostic evidence.
    """

    field: str
    message: str
    value: Any

    def __post_init__(self) -> None:
        if not self.field:
            raise ValueError("ValidationError.field must not be empty")
        if not self.message:
            raise ValueError("ValidationError.message must not be empty")


def validate_source_config(
    source_type: str,
    config: dict[str, Any],
    *,
    plugin_cls: type[SourceProtocol] | None = None,
) -> list[ValidationError]:
    """Validate source plugin configuration.

    Args:
        source_type: Plugin type name (e.g., "csv", "json")
        config: Plugin configuration dict
        plugin_cls: The class that will be built from ``config``. A caller
            that resolved it from its own PluginManager passes it so the
            config is validated against the model of the class actually
            constructed; None resolves ``source_type`` through the shared
            manager.

    Returns:
        List of validation errors (empty if valid)
    """
    # Get config model for source type (config needed for provider dispatch).
    try:
        if plugin_cls is None:
            config_model = get_source_config_model(source_type, config)
        else:
            config_model = plugin_cls.get_config_model(dict(config))
    except UnknownPluginTypeError:
        raise
    except ValueError as exc:
        # Same contract as validate_transform_config: dispatch rejection is a
        # config error, reported rather than raised. Input values are omitted
        # from configuration diagnostics because they may contain credentials.
        return [ValidationError(field="provider", message=str(exc), value=None)]

    # Handle special case: null_source has no config class
    if config_model is None:
        return []  # No validation needed

    # Validate using Pydantic
    try:
        config_model.from_dict(config, plugin_name=source_type)
        return []  # Valid
    except PydanticValidationError as e:
        return _extract_errors(e)
    except PluginConfigError as e:
        return _extract_wrapped_plugin_config_error(e, config)


def get_source_config_model(
    source_type: str,
    config: Mapping[str, Any] | None = None,
) -> type[PluginConfigProtocol] | None:
    """Get Pydantic config model for source type.

    Resolves the plugin class via pluggy discovery (PluginManager), then
    calls get_config_model(config) on it. The config parameter enables
    provider dispatch for source plugins with discriminated variants.

    Args:
        source_type: Plugin type name
        config: Plugin configuration dict (needed for provider dispatch)

    Returns:
        Config model class, or None for sources with no config (e.g., null_source)

    Raises:
        UnknownPluginTypeError: If source_type is not a registered plugin.
    """
    from elspeth.plugins.infrastructure.manager import PluginNotFoundError, get_shared_plugin_manager

    try:
        plugin_cls = get_shared_plugin_manager().get_source_by_name(source_type)
    except PluginNotFoundError as exc:
        raise UnknownPluginTypeError(f"Unknown source type: {source_type}") from exc
    return plugin_cls.get_config_model(dict(config) if config is not None else None)


def validate_transform_config(
    transform_type: str,
    config: dict[str, Any],
    *,
    plugin_cls: type[TransformProtocol] | None = None,
) -> list[ValidationError]:
    """Validate transform plugin configuration.

    Args:
        transform_type: Plugin type name (e.g., "passthrough", "field_mapper")
        config: Plugin configuration dict
        plugin_cls: The class that will be built from ``config`` (see
            ``validate_source_config``); None resolves through the shared
            manager.

    Returns:
        List of validation errors (empty if valid)
    """
    # Get config model for transform type (config needed for provider dispatch)
    try:
        if plugin_cls is None:
            config_model = get_transform_config_model(transform_type, config)
        else:
            config_model = plugin_cls.get_config_model(config)
    except UnknownPluginTypeError:
        raise
    except ValueError as exc:
        # Provider dispatch rejected the config (unknown or non-string
        # ``provider``). That is a CONFIG error from authored input, not an
        # engine fault: report it through the same channel as a Pydantic
        # rejection so ``PluginManager`` raises the standard prefixed
        # ValueError and every composer probe abstains instead of crashing
        # ``CompositionState.validate()`` (elspeth-2ed41f0a4a census). Resolved
        # configuration values are excluded from the diagnostic projection.
        return [ValidationError(field="provider", message=str(exc), value=None)]

    if config_model is None:
        return []  # No validation needed

    # Validate using Pydantic
    try:
        config_model.from_dict(config, plugin_name=transform_type)
        return []  # Valid
    except PydanticValidationError as e:
        return _extract_errors(e)
    except PluginConfigError as e:
        return _extract_wrapped_plugin_config_error(e, config)


def validate_sink_config(
    sink_type: str,
    config: dict[str, Any],
    *,
    plugin_cls: type[SinkProtocol] | None = None,
) -> list[ValidationError]:
    """Validate sink plugin configuration.

    Args:
        sink_type: Plugin type name (e.g., "csv", "json")
        config: Plugin configuration dict
        plugin_cls: The class that will be built from ``config`` (see
            ``validate_source_config``); None resolves through the shared
            manager.

    Returns:
        List of validation errors (empty if valid)
    """
    # Get config model for sink type, passing config as the runtime factory
    # does (``get_config_model(options)``) so provider dispatch resolves the same model.
    sink_cls = _resolve_sink_class(sink_type) if plugin_cls is None else plugin_cls
    try:
        config_model = sink_cls.get_config_model(config)
    except ValueError as exc:
        # Same contract as validate_source_config / validate_transform_config:
        # a dispatch rejection is a config error, reported rather than raised.
        return [ValidationError(field="provider", message=str(exc), value=None)]

    if config_model is None:
        return []  # No validation needed

    # Validate using Pydantic
    try:
        config_model.from_dict(config, plugin_name=sink_type)
        return []  # Valid
    except PydanticValidationError as e:
        return _extract_errors(e)
    except PluginConfigError as e:
        return _extract_wrapped_plugin_config_error(e, config)


def validate_schema_config(
    schema_config: dict[str, Any],
) -> list[ValidationError]:
    """Validate schema configuration independently of plugin.

    Args:
        schema_config: Schema configuration dict (contents of 'schema' key)

    Returns:
        List of validation errors (empty if valid)
    """
    from elspeth.contracts.schema import SchemaConfig

    try:
        SchemaConfig.from_dict(schema_config)
        return []
    except ValueError as e:
        return [
            ValidationError(
                field="schema",
                message=str(e),
                value=None,
            )
        ]


def _extract_wrapped_plugin_config_error(
    error: PluginConfigError,
    config: dict[str, object],
) -> list[ValidationError]:
    """Convert wrapped PluginConfigError causes into structured errors.

    PluginConfig.from_dict() wraps:
    - PydanticValidationError for model-level validation failures
    - ValueError for schema parsing failures before model validation
    """
    cause = error.__cause__

    if cause is None:
        return [ValidationError(field="config", message=str(error), value=None)]

    if type(cause) is PydanticValidationError:
        return _extract_errors(cause)

    if type(cause) is ValueError:
        if "schema" in config:
            return [ValidationError(field="schema", message=str(cause), value=None)]
        return [ValidationError(field="config", message=str(cause), value=None)]

    raise error from cause


def get_transform_config_model(
    transform_type: str,
    config: dict[str, Any] | None = None,
) -> type[PluginConfigProtocol] | None:
    """Get Pydantic config model for transform type.

    Resolves the plugin class via pluggy discovery (PluginManager), then
    calls get_config_model(config) on it. The config parameter enables
    provider dispatch (e.g. LLMTransform selects provider-specific model).

    Args:
        transform_type: Plugin type name
        config: Plugin configuration dict (needed for provider dispatch on "llm")

    Returns:
        Config model class for the transform type

    Raises:
        UnknownPluginTypeError: If transform_type is not a registered plugin.
    """
    from elspeth.plugins.infrastructure.manager import PluginNotFoundError, get_shared_plugin_manager

    try:
        plugin_cls = get_shared_plugin_manager().get_transform_by_name(transform_type)
    except PluginNotFoundError as exc:
        raise UnknownPluginTypeError(f"Unknown transform type: {transform_type}") from exc
    return plugin_cls.get_config_model(config)


def get_sink_config_model(sink_type: str) -> type[PluginConfigProtocol] | None:
    """Get Pydantic config model for sink type.

    Resolves the plugin class via pluggy discovery (PluginManager), then
    calls get_config_model() on it.

    Returns:
        Config model class for the sink type

    Raises:
        UnknownPluginTypeError: If sink_type is not a registered plugin.
    """
    return _resolve_sink_class(sink_type).get_config_model()


def _resolve_sink_class(sink_type: str) -> type[SinkProtocol]:
    """Resolve a sink plugin class through the shared PluginManager.

    Raises:
        UnknownPluginTypeError: If sink_type is not a registered plugin.
    """
    from elspeth.plugins.infrastructure.manager import PluginNotFoundError, get_shared_plugin_manager

    try:
        return get_shared_plugin_manager().get_sink_by_name(sink_type)
    except PluginNotFoundError as exc:
        raise UnknownPluginTypeError(f"Unknown sink type: {sink_type}") from exc


def _extract_errors(
    pydantic_error: PydanticValidationError,
) -> list[ValidationError]:
    """Convert Pydantic errors to structured ValidationError list.

    The schema-required-on-DataPluginConfig case is enriched with mode
    guidance (observed/fixed/flexible) so consumers — particularly the
    LLM-composer — receive an actionable message rather than the bare
    ``"Field required"`` (cf. elspeth-861b0c58f5). The enrichment mirrors
    ``config_base._format_validation_error_cause`` so the structured
    extraction path and the joined-string path stay in sync. Resolved config
    inputs never enter the diagnostic projection, even for outer-model errors.
    """
    errors: list[ValidationError] = []

    for err in pydantic_error.errors(include_input=False):
        # Pydantic error dict has: loc, msg, type, ctx
        # Model-level validators (@model_validator) produce loc=() — empty tuple.
        # Use "__model__" sentinel so the field is never empty.
        field_path = ".".join(str(loc) for loc in err["loc"]) or "__model__"
        message = err["msg"]

        if tuple(err["loc"]) == ("schema",) and err["type"] == "missing":
            message = _SCHEMA_REQUIRED_GUIDANCE

        errors.append(
            ValidationError(
                field=field_path,
                message=message,
                value=None,
            )
        )

    return errors
