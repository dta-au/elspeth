def test_where():
    import elspeth
    print("ELSPETH_AT", elspeth.__file__)
