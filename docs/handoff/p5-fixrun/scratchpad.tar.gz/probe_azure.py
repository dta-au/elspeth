import sys
sys.path.insert(0, sys.argv[1])
from types import SimpleNamespace
from elspeth.plugins.sources.azure_blob_source import AzureBlobSource
import elspeth; print(elspeth.__file__)

class Rec:
    def __init__(self): self.calls=[]
    def __call__(self,*a,**k): self.calls.append(k)

def ctx():
    return SimpleNamespace(run_id="r", node_id="s", operation_id="op", call_mode_session=None, landscape=None,
        telemetry_emit=Rec(), record_call=Rec(), record_validation_error=Rec())

base = dict(connection_string="DefaultEndpointsProtocol=https;AccountName=fake;AccountKey=ZmFrZQ==;EndpointSuffix=core.windows.net",
    container="c", blob_path="b", schema={"mode":"observed"}, on_validation_failure="quarantine")

# 1 deep JSON array
for fmt, payload in [("json", b"["*100000 + b"]"*100000), ("jsonl", b'{"a":1}\n' + b'{"x":' + b"["*100000 + b"]"*100000 + b"}\n")]:
    s = AzureBlobSource(dict(base, format=fmt))
    c = ctx()
    try:
        out = list(s._load_json_array(payload, c) if fmt=="json" else s._load_jsonl(payload, c))
        print(fmt, "rows", [(r.is_quarantined if hasattr(r,'is_quarantined') else r) for r in out])
    except BaseException as e:
        print(fmt, "CRASH", type(e).__name__)

# 2 CSV one bad byte
s = AzureBlobSource(dict(base, format="csv"))
c = ctx()
out = list(s._load_csv(b"id,name\n1,a\n2,\xff\n3,c\n", c))
print("csv rows", len(out), [getattr(r,'is_quarantined',None) for r in out], len(c.record_validation_error.calls))

# 3 json data_key empty string
s = AzureBlobSource(dict(base, format="json", json_options={"data_key": ""}))
c=ctx()
out = list(s._load_json_array(b'{"": [{"a":1}]}', c))
print("data_key empty:", [getattr(r,'is_quarantined',None) for r in out], c.record_validation_error.calls[:1])
