p="src/elspeth/contracts/plugin_protocols.py"
s=open(p).read()
a='''    # arriving row, failing the row closed otherwise. Set at construction by
    # the text-scanning family from their own scan-field options; empty
    # frozenset for everything else.'''
assert s.count(a)==1
s=s.replace(a,'''    # arriving row, failing the row closed otherwise. Set at construction by
    # the text-scanning family from their own scan-field options and by
    # truncate from its ``fields`` keys; empty frozenset for everything else.''')
open(p,"w").write(s)
