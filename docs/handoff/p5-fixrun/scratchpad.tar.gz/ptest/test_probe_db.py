import sys, tempfile, os, pytest
from pathlib import Path
os.environ["ELSPETH_ALLOW_RAW_SECRETS"]="true"
from tests.e2e.pipelines.test_csv_to_database import _write_csv, _provision_database_effect_target, _EFFECT_LEDGER
from elspeth.core.config import SourceSettings
from elspeth.core.dag import ExecutionGraph
from elspeth.core.landscape.database import LandscapeDB
from elspeth.core.payload_store import FilesystemPayloadStore
from elspeth.engine.orchestrator import Orchestrator, PipelineConfig
from elspeth.plugins.sinks.database_sink import DatabaseSink
from elspeth.plugins.sources.csv_source import CSVSource
from tests.fixtures.base_classes import as_sink, as_source, as_transform
from tests.fixtures.factories import wire_transforms
from tests.fixtures.plugins import PassTransform

@pytest.mark.parametrize('n',[50,2000])
def test_probe(n, tmp_path):
    tmp=tmp_path
    csvp = tmp/"in.csv"; url=f"sqlite:///{tmp/'out.db'}"
    _write_csv(csvp, ["id","name","score"], [[str(i), f"name{i}", "50"] for i in range(n)])
    _provision_database_effect_target(url, table_name="o", columns=["id","name","score"])
    src = CSVSource({"path": str(csvp), "schema": {"mode":"observed"}, "on_validation_failure":"discard"}); src.on_success="csv_out"
    ss = SourceSettings(plugin=src.name, on_success="csv_out", options={})
    t = PassTransform(); wired = wire_transforms([t], source_connection="csv_out", final_sink="default")
    sink = DatabaseSink({"url":url,"table":"o","schema":{"mode":"observed"},"if_exists":"append","effect_ledger":_EFFECT_LEDGER})
    g = ExecutionGraph.from_plugin_instances(sources={"primary":src}, source_settings_map={"primary":ss}, transforms=wired, sinks={"default":sink}, aggregations={}, gates=[])
    o = Orchestrator(LandscapeDB(f"sqlite:///{tmp}/audit.db"))
    try:
        r = o.run(PipelineConfig(sources={"primary":as_source(src)}, transforms=[as_transform(t)], sinks={"default":as_sink(sink)}), graph=g, payload_store=FilesystemPayloadStore(tmp/"p"))
        print("status", r.status, r.rows_succeeded)
    except Exception as e:
        print("EXC", type(e).__name__, str(e)[:300]); c=e.__cause__
        while c: print(" cause", type(c).__name__, str(c)[:200]); c=c.__cause__