import sys, tempfile, json
from pathlib import Path
from unittest.mock import MagicMock
from elspeth.plugins.sources.json_source import JSONSource
d = Path(tempfile.mkdtemp(dir=sys.argv[1]))
for name, content, schema in [
  ("a.jsonl", '{"id": 1, "v": 1e400}\n', {"mode":"observed"}),
  ("b.jsonl", '{"id": 1, "v": 1e400}\n', {"mode":"fixed","fields":["id: int","v: float"]}),
  ("c.json", '[{"id": 1, "v": {"x": -1e999}}]', {"mode":"observed"}),
  ("d.jsonl", '﻿{"id": 1}\n{"id": 2}\n', {"mode":"observed"}),
  ("e.json", '﻿[{"id": 1}]', {"mode":"observed"}),
]:
    p = d/name; p.write_text(content, encoding="utf-8")
    src = JSONSource({"path": str(p), "schema": schema, "on_validation_failure": "quarantine"})
    ctx = MagicMock()
    for r in src.load(ctx):
        print(name, "quarantined" if r.is_quarantined else "valid", repr(r.row)[:120], (r.quarantine_error or "")[:100] if hasattr(r,'quarantine_error') else "")
