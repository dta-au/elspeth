"""Recompute and re-pin source_file_hash for the given plugin files (run from worktree root)."""
import re, sys
from pathlib import Path
sys.path.insert(0, ".")
from scripts.cicd.plugin_hash import compute_source_file_hash as h
for f in sys.argv[1:]:
    p = Path(f)
    for _ in range(3):
        new = h(p)
        s = p.read_text()
        s2 = re.sub(r'(source_file_hash: str \| None = ")sha256:[0-9a-f]+(")', rf'\g<1>{new}\g<2>', s, count=1)
        p.write_text(s2)
        if h(p) == new:
            break
    print(f, h(p), new == h(p))
