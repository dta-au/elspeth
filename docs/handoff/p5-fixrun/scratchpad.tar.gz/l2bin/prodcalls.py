"""Measure only the production-caller pin of the fencing gate for one tree."""
import json, sys, resource
from pathlib import Path
sys.path.insert(0, sys.argv[3])
from fencing_inventory import load_gate, row_fields
tree = Path(sys.argv[1])
gate = load_gate(tree)
units = gate._production_units()
production = gate.scan_production_calls(units)
out = {"count": len(production), "digest": gate._canonical_digest(production),
       "pinned_count": gate._EXPECTED_CALL_COUNT, "pinned_digest": gate._EXPECTED_PRODUCTION_CALLER_SHA256,
       "rows": [row_fields(r) for r in production]}
Path(sys.argv[2]).write_text(json.dumps(out, indent=1))
print(out["count"], out["digest"], out["pinned_count"], out["pinned_digest"], "maxrss_kb", resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
