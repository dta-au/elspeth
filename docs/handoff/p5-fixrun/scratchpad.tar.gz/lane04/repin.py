import re, sys
from pathlib import Path
from scripts.cicd.plugin_hash import compute_source_file_hash as h
for f in sys.argv[1:]:
    p = Path(f).resolve()
    new = h(p)
    s = p.read_text()
    old = re.search(r'source_file_hash: str \| None = "(sha256:[0-9a-f]+)"', s).group(1)
    if old != new:
        p.write_text(s.replace(old, new))
    print(f, old, "->", new, "verify:", h(p) == new)
