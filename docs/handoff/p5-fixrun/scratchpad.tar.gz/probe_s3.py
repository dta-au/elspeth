import sys
sys.path.insert(0, "tests/unit/plugins/sources")
import elspeth; print(elspeth.__file__)
from test_aws_s3_source import _source_for
cases = [
 ("json", b'[{"id":1},{"id":2}] garbage', {}),
 ("json", b'[{"id":1},{"id":2},{"id"', {}),
 ("json", b'{"r":[{"id":1},{"id":2}],"r":[{"id":3}]}', {"json_options":{"data_key":"r"}}),
 ("csv", b'\nid\n1\n', {}),
 ("csv", b'id,name\n1,a\n"bad\n2,b\n', {}),
]
for fmt, data, extra in cases:
    s, _, ctx = _source_for(data, format=fmt, **extra)
    try:
        rows = list(s.load(ctx))
        print(fmt, data[:40], [(r.is_quarantined, r.row, getattr(r,'source_row_index',None), getattr(r,'quarantine_error',None)) for r in rows])
    except Exception as e:
        print(fmt, data[:40], "EXC", type(e).__name__, e)
