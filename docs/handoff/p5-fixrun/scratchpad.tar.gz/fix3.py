p="tests/unit/contracts/transform_contracts/test_truncate_contract.py"
s=open(p).read()
def rep(a,b):
    global s
    assert s.count(a)==1,a
    s=s.replace(a,b)
rep('''class TestTruncateStrictContract(TransformErrorContractTestBase):
    """Contract tests for Truncate error handling in strict mode."""

    @pytest.fixture
    def transform(self) -> TransformProtocol:
        """Return a configured transform instance in strict mode."""
        return Truncate(
            {
                "fields": {"required_field": 100},
                "strict": True,
                "schema": {"mode": "observed"},
            }
        )''','''class TestTruncateRequiredFieldContract(TransformErrorContractTestBase):
    """Contract tests: every configured field is required and string-valued (plugin review #146)."""

    @pytest.fixture
    def transform(self) -> TransformProtocol:
        """Return a configured transform instance."""
        return Truncate(
            {
                "fields": {"required_field": 100},
                "schema": {"mode": "observed"},
            }
        )''')
rep('''        """Return input that triggers error (missing required field in strict mode)."""''','''        """Return input that triggers error (missing configured field)."""''')
rep('''    def test_strict_missing_field_returns_error(''','''    def test_missing_field_returns_error(''')
rep('''        """Contract: Strict mode MUST return error with missing_field reason."""''','''        """Contract: a missing configured field MUST return error with missing_field reason."""''')
rep('''    def test_strict_wrong_type_returns_error(''','''    def test_wrong_type_returns_error(''')
rep('''        """Contract: Strict mode MUST return error when field is not a string."""''','''        """Contract: MUST return error when field is not a string."""''')
rep('''    def test_strict_none_value_returns_error(''','''    def test_none_value_returns_error(''')
rep('''        """Contract: Strict mode MUST return error when field value is None."""''','''        """Contract: MUST return error when field value is None."""''')
rep('''        """Return a configured transform in lenient (non-strict) mode."""
        return Truncate(
            {
                "fields": {"value": 10},
                "strict": False,
                "schema": {"mode": "observed"},''','''        """Return a configured transform."""
        return Truncate(
            {
                "fields": {"value": 10},
                "schema": {"mode": "observed"},''')
rep('''    def test_configured_original_field_name_is_resolved(
        self,
        transform: TransformProtocol,
        ctx: Any,
    ) -> None:
        """Configured original names should resolve via PipelineRow contract."""''','''    def test_configured_original_field_name_is_not_resolved(
        self,
        transform: TransformProtocol,
        ctx: Any,
    ) -> None:
        """A header spelling is not a lookup (plugin review #146): process() reads the name rows carry.

        The engine's field-name spelling preflight refuses the header spelling
        before process(); called directly, the field is simply not on the row.
        """''')
rep('''                "fields": {"Value Text": 5},
                "strict": False,
                "schema": {"mode": "observed"},
            }
        )

        result = original_name_transform.process(mapped_row, ctx)

        assert result.status == "success"
        assert result.row is not None
        assert result.row["value"] == "abcde"''','''                "fields": {"Value Text": 5},
                "schema": {"mode": "observed"},
            }
        )

        result = original_name_transform.process(mapped_row, ctx)

        assert result.status == "error"
        assert result.reason is not None
        assert result.reason["reason"] == "missing_field"
        assert result.reason["field"] == "Value Text"''')
open(p,"w").write(s)
