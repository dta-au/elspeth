import csv, time, sys
from pathlib import Path
import elspeth.plugins.sources.csv_source as m
p = Path(sys.argv[1]); p.write_text("id,val,txt\n" + "".join(f"{i},row{i},some text é here\n" for i in range(1_000_000)), encoding="utf-8")
t=time.perf_counter(); n=sum(1 for _ in csv.reader(open(p, encoding="utf-8", newline=""))); a=time.perf_counter()-t
t=time.perf_counter()
with open(p,"rb") as f: n2=sum(1 for _ in csv.reader(m._iter_physical_lines(m._iter_decoded_text(f,"utf-8"))))
b=time.perf_counter()-t
print(p.stat().st_size, n, n2, f"text-mode {a:.2f}s new {b:.2f}s")
p.unlink()
