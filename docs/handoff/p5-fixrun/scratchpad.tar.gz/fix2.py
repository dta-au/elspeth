p="src/elspeth/plugins/transforms/truncate.py"
s=open(p).read()
a='''    # ``fields`` maps each input column to its max length: the KEYS are read columns.
    column_keyed_config_keys = frozenset({"fields"})'''
assert s.count(a)==1
s=s.replace(a,'''    # ``fields`` maps each input column to its max length: the KEYS are read
    # columns. This only describes the option's SHAPE (a mapping, where
    # keyword_filter's ``fields`` is a list) so the fixed-schema read check
    # and demotion protection see the keys; ``consumed_input_fields`` does not
    # read ``declared_string_input_fields``. It grants no lookup semantics.
    column_keyed_config_keys = frozenset({"fields"})''')
open(p,"w").write(s)
