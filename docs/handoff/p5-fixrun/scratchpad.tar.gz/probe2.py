import sys
sys.path.insert(0, "tests/unit/plugins/sources")
from test_aws_s3_source import _source_for
for data in [b"\n\n", b"\r\n", b" \nid\n1\n"]:
    s, _, ctx = _source_for(data, format="csv")
    rows = list(s.load(ctx))
    print(data, [(r.is_quarantined, r.row, r.quarantine_error) for r in rows], getattr(ctx, "validation_errors", None))
