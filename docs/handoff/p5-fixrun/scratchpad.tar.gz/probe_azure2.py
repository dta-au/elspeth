import sys, traceback
sys.path.insert(0, sys.argv[1])
from types import SimpleNamespace
from elspeth.plugins.sources.azure_blob_source import AzureBlobSource
class Rec:
    def __init__(self): self.calls=[]
    def __call__(self,*a,**k): self.calls.append(k)
def ctx():
    return SimpleNamespace(run_id="r", node_id="s", operation_id="op", call_mode_session=None, landscape=None,
        telemetry_emit=Rec(), record_call=Rec(), record_validation_error=Rec())
base = dict(connection_string="DefaultEndpointsProtocol=https;AccountName=fake;AccountKey=ZmFrZQ==;EndpointSuffix=core.windows.net",
    container="c", blob_path="b", schema={"mode":"observed"}, on_validation_failure="quarantine")
for payload in [b'{"x":' + b"["*100000 + b"]"*100000 + b"}\n", b'{"x":' + b"["*900 + b"]"*900 + b"}\n"]:
  s = AzureBlobSource(dict(base, format="jsonl"))
  c = ctx()
  try:
    out = list(s._load_jsonl(payload, c))
    print("ok", [r.is_quarantined for r in out])
  except BaseException as e:
    traceback.print_exc(limit=-3)
