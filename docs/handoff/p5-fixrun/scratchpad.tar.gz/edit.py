import sys
def remove_validator(s, field, occurrence_ok=None):
    """Remove every `@field_validator("<field>")` method block (4-space class indent)."""
    lines = s.split("\n")
    out=[]; i=0; removed=0
    while i < len(lines):
        if lines[i] == f'    @field_validator("{field}")':
            j=i+1
            while lines[j].startswith("    @"): j+=1
            assert lines[j].startswith("    def "), lines[j]
            j+=1
            while j < len(lines) and (lines[j]=="" or lines[j].startswith("        ")): j+=1
            # drop trailing blank lines from block but keep one separator
            removed+=1
            # strip preceding blank lines duplication
            while out and out[-1]=="" and (j>=len(lines) or True):
                out.pop()
            out.append("")
            if j < len(lines) and not lines[j].startswith("    "):
                out.append("")  # class end: two blanks before top-level
            i=j; continue
        out.append(lines[i]); i+=1
    return "\n".join(out), removed
def rep(s, old, new, n=1):
    c=s.count(old); assert c==n,(old,c); return s.replace(old,new)
