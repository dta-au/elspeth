import socket
from unittest.mock import patch
import httpx, respx
from tests.unit.plugins.transforms.test_web_scrape_pagination import _Recorder, _PayloadStore, _LimiterRegistry
from elspeth.contracts.plugin_context import PluginContext
from elspeth.plugins.transforms.web_scrape import WebScrapeTransform
from elspeth.testing import make_pipeline_row
from tests.fixtures.mock_audit import mock_item_audit_authority

def dns(h,p,*a,**k): return [(socket.AF_INET, socket.SOCK_STREAM, 6, '', ('93.184.216.34', 0))]
for loc in ["https://example.com:99999999/", "https://exa mple.com/", "https://example.com/a\x7fb", "//[::1"]:
    ctx = PluginContext(run_id="run-123", **mock_item_audit_authority("run-123"), config={}, landscape=_Recorder(),
                        payload_store=_PayloadStore(), rate_limit_registry=_LimiterRegistry(), state_id="state-123")
    t = WebScrapeTransform({"schema": {"mode": "observed"}, "url_field": "url", "content_field": "c", "fingerprint_field": "f",
                            "http": {"abuse_contact": "a@example.com", "scraping_reason": "test"}})
    t.on_start(ctx)
    with respx.mock(assert_all_called=False) as m, patch("socket.getaddrinfo", dns):
        try:
            m.route().mock(return_value=httpx.Response(302, headers={"location": loc}))
        except Exception as e:
            print(repr(loc), "cannot build header", type(e).__name__); continue
        try:
            r = t.process(make_pipeline_row({"url": "https://example.com/start"}), ctx)
            print(repr(loc), "result", r.status, r.reason)
        except Exception as e:
            print(repr(loc), "ESCAPED", type(e).__module__, type(e).__name__)
