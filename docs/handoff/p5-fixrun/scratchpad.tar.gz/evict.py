import sys, threading, time
sys.path.insert(0, sys.argv[1])
from types import SimpleNamespace
from elspeth.plugins.infrastructure.batching.mixin import BatchTransformMixin
from elspeth.contracts import TransformResult

class Port:
    def __init__(self): self.got=[]
    def emit(self, token, result, state_id): self.got.append((token.token_id, state_id, type(result).__name__, getattr(result,'exception',None)))

class T(BatchTransformMixin):
    pass
t=T(); port=Port()
t.init_batch_processing(max_pending=4, output=port, name="t")
gate=threading.Event()
def slow(row, ctx):
    gate.wait(); return TransformResult.success({"a":1} , success_reason={"action":"x"}) if False else "OK_A"
def fast(row, ctx): return "OK_B"
ctxA=SimpleNamespace(token=SimpleNamespace(token_id="A"), state_id="sA")
ctxB=SimpleNamespace(token=SimpleNamespace(token_id="B"), state_id="sB")
t.accept_row({}, ctxA, slow)
t.accept_row({}, ctxB, fast)
time.sleep(0.3)
print("evict B ->", t.evict_submission("B","sB"))
gate.set(); time.sleep(1.5)
print(port.got)
t.shutdown_batch_processing()
