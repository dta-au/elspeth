_MISSING = object()


def a(raw: object, name: str) -> object:
    try:
        return getattr(raw, name)
    except AttributeError:
        return _MISSING


def b(raw: object, name: str) -> object:
    try:
        return getattr(raw, name)
    except AttributeError:
        return None


def c(raw: object) -> object:
    missing = object()
    return getattr(raw, "read", missing)
