from elspeth.contracts.schema_contract import FieldContract, PipelineRow, SchemaContract
from elspeth.plugins.transforms.batch_replicate import BatchReplicate
import elspeth; print(elspeth.__file__)
def c(fields):
    return SchemaContract(mode="OBSERVED", fields=tuple(FieldContract(normalized_name=n, original_name=n, python_type=t, required=True, source="inferred") for n,t in fields), locked=True)
r0 = PipelineRow({"x": 1, "y": "a", "copies": 1}, c([("x", int), ("y", str), ("copies", int)]))
r1 = PipelineRow({"x": "hello", "copies": 1}, c([("x", str), ("copies", int)]))
t = BatchReplicate({"schema": {"mode": "observed"}})
res = t.process([r0, r1], None)
print(res.status if hasattr(res,'status') else res)
for row in res.rows:
    print(row.to_dict(), [(f.normalized_name, f.python_type.__name__, f.required) for f in row.contract.fields])
