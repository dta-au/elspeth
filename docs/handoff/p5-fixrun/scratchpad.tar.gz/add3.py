p="tests/unit/plugins/transforms/test_truncate.py"
s=open(p).read()
a='''        from elspeth.contracts.field_spelling import DeclaredSpellings

        transform = Truncate({"fields": {"Value Text": 5}, "schema": DYNAMIC_SCHEMA})
        row = _make_alias_mapped_row()

        spellings = DeclaredSpellings.of(reads=transform.declared_read_fields, creates=()).in_row(
            row_keys=frozenset(row.to_dict()),
            forwarded_keys=frozenset(),
            contract=row.contract,
        )
        assert spellings, "a header-spelled truncate field must be refused by the spelling rule"
'''
assert s.count(a)==1
s=s.replace(a,'''        transform = Truncate({"fields": {"Value Text": 5}, "schema": DYNAMIC_SCHEMA})

        assert "Value Text" in transform.declared_read_fields
''')
open(p,"w").write(s)
