import pytest
from elspeth.plugins.sources.json_source import JSONSource
from tests.fixtures.factories import make_operation_context

@pytest.mark.parametrize("depth", [100, 500, 1500])
def test_probe(tmp_path, depth):
    f = tmp_path / "in.jsonl"
    f.write_text('{"id":1}\n{"id":2,"x":' + "["*depth + "]"*depth + '}\n{"id":3}\n')
    src = JSONSource({"path": str(f), "format": "jsonl", "schema": {"mode": "observed"}, "on_validation_failure": "q"})
    ctx = make_operation_context(plugin_name="json")
    try:
        rows = list(src.load(ctx)); print(depth, [r.is_quarantined for r in rows])
    except Exception as e:
        print(depth, "RAISED", type(e).__name__)
