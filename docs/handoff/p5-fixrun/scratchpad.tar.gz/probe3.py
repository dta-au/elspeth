import sys
sys.path.insert(0, "tests/unit/plugins/sources")
from test_aws_s3_source import _source_for
s, _, ctx = _source_for(b'{"id":1}\n{"id":"' + b"x"*50 + b'"}\n{"id":3}\n{"id":4}\n', format="jsonl", max_record_chars=20)
rows = list(s.load(ctx))
print([(r.is_quarantined, r.row, r.quarantine_error) for r in rows])
s, _, ctx = _source_for(b'id\n1\n' + b"x"*50 + b'\n3\n4\n', format="csv", max_record_chars=20)
rows = list(s.load(ctx))
print([(r.is_quarantined, r.row, r.quarantine_error) for r in rows])
