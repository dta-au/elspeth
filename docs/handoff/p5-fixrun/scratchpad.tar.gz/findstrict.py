import os,re,sys
roots=["src","examples","docs","tests","config","scripts","elspeth-lints"]
pat=re.compile(r"truncate",re.I)
for r in roots:
  for dp,dn,fn in os.walk(r):
    if "frontend" in dp or "node_modules" in dp or "__pycache__" in dp: continue
    for f in fn:
      if not f.endswith((".py",".yaml",".yml",".md",".json",".txt")): continue
      p=os.path.join(dp,f)
      try: lines=open(p,encoding="utf-8").read().splitlines()
      except Exception: continue
      for i,l in enumerate(lines):
        if re.search(r"\bstrict\b['\"]?\s*[:=]",l) or "_strict" in l:
          win="\n".join(lines[max(0,i-25):i+1])
          if re.search(r"plugin:\s*truncate|['\"]truncate['\"]|Truncate\(|TruncateConfig",win):
            print(f"{p}:{i+1}: {l.strip()}")
