import sys
from pathlib import Path
from scripts.cicd.plugin_hash import compute_source_file_hash, extract_plugin_attributes, fix_source_file_hash
for f in sys.argv[1:]:
    p = Path(f)
    h = compute_source_file_hash(p)
    for attrs in extract_plugin_attributes(p):
        name = attrs.class_name
        fix_source_file_hash(p, name, h)
        print(f, name, h)
    assert compute_source_file_hash(p) == h
