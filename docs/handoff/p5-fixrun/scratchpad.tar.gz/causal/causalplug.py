import pytest
import elspeth.plugins.transforms.batch_stats as bs
@pytest.fixture(autouse=True)
def _no_guard(monkeypatch):
    monkeypatch.setattr(bs, "_SAFE_INTEGER_MAX", 2**4000)
