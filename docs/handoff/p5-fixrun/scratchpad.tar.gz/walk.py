import importlib, pkgutil, re
from pydantic import BaseModel, SecretStr
import elspeth.plugins
SECRETISH = re.compile(r"(api_key|apikey|secret|password|passwd|connection_string|sas_token|access_key|session_token|bearer|^token$|_token$|credential|private_key|trigger_url)", re.I)
NOTSECRET = re.compile(r"(_env$|_ref$|_name$|_field|max_|_fingerprint|_id$|auth_mode|_mode$|token_)", re.I)
mods=[]
for m in pkgutil.walk_packages(elspeth.plugins.__path__, "elspeth.plugins."):
    try: mods.append(importlib.import_module(m.name))
    except Exception as e: print("IMPORTFAIL", m.name, e)
seen=set()
for mod in mods:
    for o in list(vars(mod).values()):
        if isinstance(o,type) and issubclass(o,BaseModel) and o not in seen and o.__module__.startswith("elspeth"):
            seen.add(o)
            for n,f in o.model_fields.items():
                if SECRETISH.search(n) and not NOTSECRET.search(n):
                    print(f"{o.__module__}.{o.__qualname__}.{n} repr={f.repr} ann={f.annotation!r}")
