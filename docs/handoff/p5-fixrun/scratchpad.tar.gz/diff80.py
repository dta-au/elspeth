import io, random, csv
import elspeth.plugins.sources.csv_source as m
random.seed(7)
alphabet = ["a", "b", ",", '"', "\r", "\n", "\r\n", "é", "€", "𝄞", " "]
mism = 0
for trial in range(3000):
    text = "".join(random.choice(alphabet) for _ in range(random.randint(0, 60)))
    for enc in ("utf-8", "utf-16", "utf-8-sig", "cp1252" if all(c not in text for c in "𝄞") else "utf-8"):
        try:
            data = text.encode(enc)
        except UnicodeEncodeError:
            continue
        expected = list(io.TextIOWrapper(io.BytesIO(data), encoding=enc, newline=""))
        for size in (1, 2, 3, 7, 65536):
            m._DECODE_CHUNK_BYTES = size
            got = list(m._iter_physical_lines(m._iter_decoded_text(io.BytesIO(data), enc)))
            if got != expected:
                mism += 1
                if mism < 5: print("MISMATCH", enc, size, repr(text), expected, got)
print("mismatches", mism)
# negative control: a wrong splitter must be caught
orig = m._LINE_TERMINATOR
import re
m._LINE_TERMINATOR = re.compile(r"\n")
m._DECODE_CHUNK_BYTES = 65536
bad = sum(list(m._iter_physical_lines(m._iter_decoded_text(io.BytesIO(t.encode()), "utf-8"))) != list(io.TextIOWrapper(io.BytesIO(t.encode()), encoding="utf-8", newline="")) for t in ["a\rb\n", "x\r", "q\r\nz"])
print("negative-control detections", bad)
