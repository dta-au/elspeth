from tests.unit.plugins.transforms.test_web_scrape_pagination import _Recorder, _PayloadStore, _LimiterRegistry
from elspeth.contracts.plugin_context import PluginContext
from elspeth.plugins.transforms.web_scrape import WebScrapeTransform
from elspeth.testing import make_pipeline_row
from tests.fixtures.mock_audit import mock_item_audit_authority

ctx = PluginContext(run_id="run-123", **mock_item_audit_authority("run-123"), config={}, landscape=_Recorder(),
                    payload_store=_PayloadStore(), rate_limit_registry=_LimiterRegistry(), state_id="state-123")
for query in ({"q": "x"}, {}):
    t = WebScrapeTransform({"schema": {"mode": "observed"}, "url_field": "url", "content_field": "c", "fingerprint_field": "f",
                            "query": query,
                            "http": {"abuse_contact": "a@example.com", "scraping_reason": "test"}})
    t.on_start(ctx)
    try:
        r = t.process(make_pipeline_row({"url": "http://example.com/\x00"}), ctx)
        print(query, "result", r.status, r.reason)
    except Exception as e:
        import traceback; traceback.print_exc(limit=-4); print(query, "ESCAPED", type(e).__module__, type(e).__name__, e)
