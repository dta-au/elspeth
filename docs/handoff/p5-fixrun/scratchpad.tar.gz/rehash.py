"""Recompute source_file_hash for changed plugin files; rewrite pins tree-wide. Prints old->new."""
import re, subprocess, sys
from pathlib import Path
sys.path.insert(0, ".")
from scripts.cicd.plugin_hash import compute_source_file_hash
files = subprocess.run(["git","diff","--name-only","HEAD","--","src/elspeth/plugins"],capture_output=True,text=True,check=True).stdout.split()
files += subprocess.run(["git","ls-files","--others","--exclude-standard","src/elspeth/plugins"],capture_output=True,text=True,check=True).stdout.split()
for _ in range(3):  # hash excludes its own literal? iterate until stable
    changed=False
    for f in files:
        p=Path(f); s=p.read_text()
        m=re.findall(r'source_file_hash[^=\n]*= "(sha256:[0-9a-f]+)"', s)
        if not m: continue
        new=compute_source_file_hash(p)
        for old in set(m):
            if old==new: continue
            changed=True
            print(f, old, "->", new)
            hits=subprocess.run(["git","grep","-l",old],capture_output=True,text=True).stdout.split()
            for h in hits:
                hp=Path(h); hp.write_text(hp.read_text().replace(old,new))
                if h!=f: print("   pin updated:", h)
    if not changed: break
