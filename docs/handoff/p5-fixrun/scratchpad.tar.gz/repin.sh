#!/bin/bash
# usage: repin.sh <plugin path>  (run from worktree root)
set -e
f=$1
old=$(grep -oE 'source_file_hash: str \| None = "sha256:[0-9a-f]+"' "$f" | grep -oE '[0-9a-f]{16}"' | tr -d '"')
new=$(.venv/bin/python -c "from pathlib import Path; from scripts.cicd.plugin_hash import compute_source_file_hash as h; print(h(Path('$f')).split(':')[1])")
echo "old=$old new=$new"
[ "$old" = "$new" ] && exit 0
for g in $(git grep -l "$old"); do sed -i "s/$old/$new/g" "$g"; echo "repinned $g"; done
