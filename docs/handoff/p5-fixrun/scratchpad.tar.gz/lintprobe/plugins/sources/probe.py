def a(raw: object) -> object:
    missing = object()
    value = getattr(raw, "read", missing)
    return value


def b(raw: object) -> object:
    try:
        value = raw.read  # type: ignore[attr-defined]
    except AttributeError:
        return None
    return value
