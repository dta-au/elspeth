import sys, tempfile
from pathlib import Path
from unittest.mock import MagicMock
from elspeth.plugins.sources.json_source import JSONSource
d = Path(tempfile.mkdtemp(dir=sys.argv[1])); p = d/"x.jsonl"
good = lambda i: ('{"id": %d}\n' % i).encode("utf-16-le")
data = b"\xff\xfe" + good(1) + b"\x00\xdc" + good(2) + good(3) + good(4)  # lone low surrogate mid-file
p.write_bytes(data)
src = JSONSource({"path": str(p), "encoding": "utf-16", "schema": {"mode":"observed"}, "on_validation_failure": "quarantine"})
for r in src.load(MagicMock()):
    print("Q" if r.is_quarantined else "V", r.row)
