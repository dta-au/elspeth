import sys
sys.path.insert(0, sys.argv[1])
from elspeth.plugins.transforms.web_scrape_extraction import extract_content, extract_css_records, CSSRecordsConfig
html = "<div>"*20000 + "x" + "</div>"*20000
for fmt in ("text","markdown"):
    try:
        r = extract_content(html, fmt, ["script"])
        print(fmt, "ok", len(r))
    except Exception as e:
        print(fmt, type(e).__name__, str(e)[:100])
cfg = CSSRecordsConfig(field="r", selector="div", columns=[{"field":"t"}], max_records=1000)
try:
    print(len(extract_css_records(html, cfg, [])))
except Exception as e:
    print("css", type(e).__name__, str(e)[:100])
