import sys, os
W = sys.argv[1]
sys.path[:0] = [W + "/src", W]
from elspeth.plugins.infrastructure.runtime_factory import validate_sink_effect_eligibility_from_raw_config as v
from elspeth.contracts.sink_effects import SinkEffectExecutionPurpose as P
sinks = {"out": {"plugin": "json", "options": {"path": "o.jsonl", "schema": {"mode": "observed"}, "collision_policy": "auto_increment"}},
         "audit": {"plugin": "json", "options": {"path": "a.json", "format": "json", "schema": {"mode": "observed"}}}}
BASE={"compartment_id":"c","signing_mode":"unsigned","total_record_limit":1000,"total_byte_limit":1000000,"chunk_limit":10,"per_chunk_record_limit":100,"per_chunk_byte_limit":100000,"spool_root":".elspeth/audit-export-spool/x","content_store":{"content_store_id":"s-v1","namespace":"audit/export","root":".elspeth/audit-export-content-store/x","policy_version":"v1","retention_days":30,"durability":"fsync"}}
for label, exp in [("typo sink", {"enabled": True, "sink": "audti", "format": "json"}),
                   ("env sink", {"enabled": True, "sink": "${AUDIT_SINK}", "format": "json"}),
                   ("env enabled", {"enabled": "${EXPORT_ON:-true}", "sink": "audit", "format": "json"})]:
    os.environ["AUDIT_SINK"] = "audit"
    for purpose in (P.FRESH, P.AUDIT_EXPORT):
        try:
            r = v({"sinks": sinks, "landscape": {"export": {**BASE, **exp}}}, purpose=purpose, expand_env_placeholders=True)
            print(label, purpose.name, "OK", dict(r))
        except Exception as e:
            print(label, purpose.name, type(e).__name__, str(e)[:120])
