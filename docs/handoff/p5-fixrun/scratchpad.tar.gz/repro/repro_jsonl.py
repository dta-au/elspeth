import sys, tempfile
from pathlib import Path
W = sys.argv[1]
sys.path[:0] = [W + "/src", W]
import elspeth; print("elspeth from", elspeth.__file__)
from tests.unit.plugins.sinks.test_local_file_sink_effects import _prepare, _CTX
from elspeth.plugins.sinks.json_sink import JSONSink
d = Path(tempfile.mkdtemp(dir=str(Path(__file__).parent)))
t = d / "a.jsonl"
t.write_text('{"id": 0}')  # no trailing newline
s = JSONSink({"path": str(t), "format": "jsonl", "schema": {"mode": "observed"}, "mode": "append", "collision_policy": "append_or_create"})
s.commit_effect(_prepare(s, effect_id="ab"*32, rows=[{"id": 1}]), _CTX)
print(repr(t.read_text()))
