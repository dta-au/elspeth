from elspeth.contracts.schema_contract import PipelineRow, SchemaContract
from elspeth.testing import make_field
from elspeth.plugins.transforms.field_mapper import FieldMapper
from tests.fixtures.factories import make_context
import elspeth; print(elspeth.__file__)
t = FieldMapper({"schema": {"mode": "observed"}, "mapping": {"First Name": "first", "meta.origin": "status"}})
print("forwards", t.forwards_input_fields, "passes", t.passes_through_input, "declared_out", t.declared_output_fields)
contract = SchemaContract(mode="OBSERVED", fields=(
    make_field("first_name", str, original_name="First Name", required=False, source="inferred"),
    make_field("meta", object, original_name="meta", required=False, source="inferred"),
    make_field("status", str, original_name="status", required=False, source="inferred"),
), locked=True)
row = PipelineRow({"first_name": "A", "meta": {"origin": "X"}, "status": "ORIGINAL"}, contract)
r = t.process(row, make_context())
print(r.status, r.row.to_dict() if r.row is not None else r.reason)
