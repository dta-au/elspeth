import sys
from pathlib import Path
from tests.fixtures.factories import make_context
from elspeth.plugins.sources.text_source import TextSource
import elspeth; print(elspeth.__file__)
p = Path(sys.argv[1]) / "u16.txt"
data = "a\nb\n".encode("utf-16-le") + b"\x00\xd8" + "c\nd\ne\n".encode("utf-16-le")
p.write_bytes(data)
src = TextSource({"path": str(p), "column": "value", "encoding": "utf-16-le", "schema": {"mode": "observed"}, "on_validation_failure": "quarantine"})
rows = list(src.load(make_context(node_id="source")))
for r in rows: print(r.is_quarantined, r.source_row_index, r.row)
