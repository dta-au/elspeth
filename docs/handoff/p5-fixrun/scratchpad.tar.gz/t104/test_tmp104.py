from __future__ import annotations

from pathlib import Path

import pytest


# ---------------------------------------------------------------------------
# Finding #104: raw sink-effect eligibility and the landscape.export section
# ---------------------------------------------------------------------------


def _raw_export_config(*, enabled: object = True, sink: str = "audit") -> dict[str, object]:
    """A valid enabled-export raw config (shape from tests/unit/cli/test_cli_preflight.py)."""
    return {
        "sinks": {
            "pipeline": {"plugin": "csv", "options": {"path": "out.csv", "schema": {"mode": "observed"}}},
            "audit": {"plugin": "json", "options": {"path": "audit.json", "schema": {"mode": "observed"}}},
        },
        "landscape": {
            "export": {
                "enabled": enabled,
                "compartment_id": "test-compartment",
                "sink": sink,
                "format": "json",
                "signing_mode": "unsigned",
                "total_record_limit": 1_000,
                "total_byte_limit": 1_000_000,
                "chunk_limit": 10,
                "per_chunk_record_limit": 100,
                "per_chunk_byte_limit": 100_000,
                "spool_root": ".elspeth/audit-export-spool/p3-sweep",
                "content_store": {
                    "content_store_id": "p3-sweep-store-v1",
                    "namespace": "audit/export",
                    "root": ".elspeth/audit-export-content-store/p3-sweep",
                    "policy_version": "v1",
                    "retention_days": 30,
                    "durability": "fsync",
                },
            }
        },
    }


@pytest.mark.parametrize("purpose_name", ["FRESH", "AUDIT_EXPORT"])
def test_export_sink_missing_from_sinks_is_a_value_error(purpose_name: str, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Finding #104: a typo'd landscape.export.sink must be a ValueError, not a KeyError.

    The CLI run path reports ValueError as a configuration error; a bare
    KeyError escaped it as a raw traceback (AUDIT_EXPORT), and FRESH accepted
    the config silently.
    """
    from elspeth.engine.orchestrator.preflight import SinkEffectExecutionPurpose
    from elspeth.plugins.infrastructure.runtime_factory import validate_sink_effect_eligibility_from_raw_config

    monkeypatch.chdir(tmp_path)
    raw = _raw_export_config(sink="audti")
    try:
        validate_sink_effect_eligibility_from_raw_config(
            raw, purpose=SinkEffectExecutionPurpose[purpose_name], expand_env_placeholders=True
        )
    except KeyError as exc:
        raise AssertionError(f"missing export sink escaped as KeyError: {exc!r}") from exc
    except ValueError as exc:
        assert "audti" in str(exc)
    else:
        raise AssertionError("an export sink name absent from 'sinks' must be refused")


def test_export_sink_placeholder_is_expanded_like_the_loader(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Finding #104: landscape.export.sink=${AUDIT_SINK} names the real export sink.

    Unexpanded, FRESH validated the export sink as an ordinary pipeline sink
    and AUDIT_EXPORT raised KeyError('${AUDIT_SINK}').
    """
    from elspeth.engine.orchestrator.preflight import SinkEffectExecutionPurpose
    from elspeth.plugins.infrastructure.runtime_factory import validate_sink_effect_eligibility_from_raw_config

    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("AUDIT_SINK", "audit")
    raw = _raw_export_config(sink="${AUDIT_SINK}")

    fresh = validate_sink_effect_eligibility_from_raw_config(raw, purpose=SinkEffectExecutionPurpose.FRESH, expand_env_placeholders=True)
    assert sorted(fresh) == ["pipeline"]
    try:
        export = validate_sink_effect_eligibility_from_raw_config(
            raw, purpose=SinkEffectExecutionPurpose.AUDIT_EXPORT, expand_env_placeholders=True
        )
    except KeyError as exc:
        raise AssertionError(f"export sink placeholder was not expanded: {exc!r}") from exc
    assert sorted(export) == ["audit"]


@pytest.mark.parametrize("purpose_name", ["FRESH", "AUDIT_EXPORT"])
def test_export_enabled_placeholder_is_expanded_like_the_loader(purpose_name: str, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Finding #104: enabled=${EXPORT_ON:-true} is accepted by the loader, so the preflight must accept it."""
    from pydantic import ValidationError

    from elspeth.engine.orchestrator.preflight import SinkEffectExecutionPurpose
    from elspeth.plugins.infrastructure.runtime_factory import validate_sink_effect_eligibility_from_raw_config

    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("EXPORT_ON", raising=False)
    raw = _raw_export_config(enabled="${EXPORT_ON:-true}")
    try:
        modes = validate_sink_effect_eligibility_from_raw_config(
            raw, purpose=SinkEffectExecutionPurpose[purpose_name], expand_env_placeholders=True
        )
    except ValidationError as exc:
        raise AssertionError(f"landscape.export was validated unexpanded: {exc}") from exc
    assert sorted(modes) == (["audit"] if purpose_name == "AUDIT_EXPORT" else ["pipeline"])


def test_landscape_export_settings_reader_expands_placeholders_for_the_cli(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Finding #104: the CLI decides whether to run the AUDIT_EXPORT pass from this reader."""
    import inspect

    from elspeth.plugins.infrastructure.runtime_factory import validate_landscape_export_settings_from_raw_config

    parameters = inspect.signature(validate_landscape_export_settings_from_raw_config).parameters
    assert "expand_env_placeholders" in parameters
    assert "deferrable_env_vars" in parameters

    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("EXPORT_ON", "true")
    monkeypatch.setenv("AUDIT_SINK", "audit")
    settings = validate_landscape_export_settings_from_raw_config(
        _raw_export_config(enabled="${EXPORT_ON}", sink="${AUDIT_SINK}"),
        expand_env_placeholders=True,
        deferrable_env_vars=frozenset(),
    )
    assert settings.enabled is True
    assert settings.sink == "audit"


def test_export_sink_naming_a_deferred_secret_defers_the_raw_gate(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Finding #104: a Key Vault-deferred export sink name cannot be resolved yet.

    Like a sink whose options reference a deferred secret, the raw gate must
    defer (the post-expansion gates are authoritative) rather than validate
    the export sink as a pipeline member or refuse a config the loader accepts.
    """
    from elspeth.engine.orchestrator.preflight import SinkEffectExecutionPurpose
    from elspeth.plugins.infrastructure.runtime_factory import validate_sink_effect_eligibility_from_raw_config

    monkeypatch.chdir(tmp_path)
    raw = _raw_export_config(sink="${AUDIT_SINK}")
    for purpose in (SinkEffectExecutionPurpose.FRESH, SinkEffectExecutionPurpose.AUDIT_EXPORT):
        try:
            modes = validate_sink_effect_eligibility_from_raw_config(
                raw,
                purpose=purpose,
                expand_env_placeholders=True,
                deferrable_env_vars=frozenset({"AUDIT_SINK"}),
            )
        except KeyError as exc:
            raise AssertionError(f"deferred export sink escaped as KeyError: {exc!r}") from exc
        assert "audit" not in modes
        assert "${AUDIT_SINK}" not in modes
