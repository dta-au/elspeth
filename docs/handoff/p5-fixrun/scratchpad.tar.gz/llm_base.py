"""Unified LLM transform with strategy pattern.

LLMTransform dispatches to SingleQueryStrategy or MultiQueryStrategy
based on whether queries are configured. Provider dispatch (Azure,
OpenRouter, Bedrock, Gateway) is handled via _PROVIDERS registry.

Architecture:
    LLMTransform (BatchTransformMixin)
        ├── SingleQueryStrategy — direct template render, raw content output
        └── MultiQueryStrategy — mapped context, JSON parsing, field extraction

    Provider instantiation is deferred to on_start() when recorder/telemetry
    become available. __init__ stores provider_cls + config for later use.
"""

from __future__ import annotations

import threading
import time
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from functools import reduce
from operator import or_
from types import MappingProxyType
from typing import TYPE_CHECKING, Annotated, Any, Protocol, cast

import structlog
from pydantic import BaseModel, TypeAdapter
from pydantic import Field as PydanticField

from elspeth.contracts import Determinism, RunMode, TransformErrorReason, TransformResult, propagate_contract
from elspeth.contracts.audit_protocols import PluginAuditWriter
from elspeth.contracts.call_governance import LLMCallGovernance
from elspeth.contracts.chat_parts import ChatMessage, ContentPart, ImagePart, TextPart, parts_hash
from elspeth.contracts.contexts import LifecycleContext, TransformContext
from elspeth.contracts.coordination import CoordinationToken
from elspeth.contracts.errors import FrameworkBugError, RuntimePreflightFailedError
from elspeth.contracts.events import TelemetryEvent
from elspeth.contracts.freeze import freeze_fields
from elspeth.contracts.plugin_assistance import PluginAssistance, PluginAssistanceExample
from elspeth.contracts.plugin_capabilities import CapabilityDeclaration, ContentTrust, PluginCapability, WebConfigAuthority
from elspeth.contracts.schema import FieldDefinition
from elspeth.contracts.schema_contract import FieldContract, PipelineRow, SchemaContract
from elspeth.contracts.token_usage import TokenUsage
from elspeth.contracts.trust_boundary import trust_boundary
from elspeth.contracts.value_source import register_value_source_plugin
from elspeth.core.llm_profiles import require_lowered_llm_profile_alias
from elspeth.core.llm_provider_validation import LLM_PROVIDER_NAMES
from elspeth.plugins.infrastructure.base import BaseTransform
from elspeth.plugins.infrastructure.batching import BatchTransformMixin, OutputPort
from elspeth.plugins.infrastructure.clients.llm import ContextLengthError, LLMClientError
from elspeth.plugins.infrastructure.pooling import PooledExecutor, RowContext
from elspeth.plugins.infrastructure.schema_factory import create_schema_from_config
from elspeth.plugins.infrastructure.telemetry import make_warn_telemetry_before_start
from elspeth.plugins.infrastructure.templates import RowProjection, TemplateError, TemplateRow, declared_row_projection
from elspeth.plugins.transforms.llm import (
    _OUTPUT_FIELD_TYPE_TO_SCHEMA,
    _build_augmented_output_schema,
    _build_llm_output_schema_config,
    _build_multi_query_output_schema,
    _FieldType,
    _llm_created_output_fields,
    _llm_generated_output_fields,
    build_llm_audit_metadata,
    get_llm_guaranteed_fields,
    populate_llm_operational_fields,
)
from elspeth.plugins.transforms.llm.base import LLMConfig
from elspeth.plugins.transforms.llm.image_inputs import ImageInputConfig, resolve_image_parts
from elspeth.plugins.transforms.llm.langfuse import LangfuseTracer, create_langfuse_tracer
from elspeth.plugins.transforms.llm.multi_query import OrderedQueryPlan, OutputFieldConfig, QueryInputMode, QuerySpec, ResponseFormat
from elspeth.plugins.transforms.llm.provider import (
    FinishReason,
    LLMAuditParent,
    LLMProvider,
    LLMQueryResult,
    ParsedFinishReason,
    UnrecognizedFinishReason,
    classify_finish_reason_failure,
)
from elspeth.plugins.transforms.llm.providers.azure import AzureLLMProvider, AzureOpenAIConfig, _configure_azure_monitor
from elspeth.plugins.transforms.llm.providers.bedrock import BedrockConfig, BedrockLLMProvider
from elspeth.plugins.transforms.llm.providers.gateway import GatewayConfig, GatewayLLMProvider
from elspeth.plugins.transforms.llm.providers.openrouter import OpenRouterConfig, OpenRouterLLMProvider
from elspeth.plugins.transforms.llm.templates import PromptTemplate
from elspeth.plugins.transforms.llm.tracing import AzureAITracingConfig, TracingConfig, parse_tracing_config
from elspeth.plugins.transforms.llm.validation import (
    build_structured_response_directive,
    extract_structured_fields,
    strip_markdown_fences,
)

logger = structlog.get_logger(__name__)

if TYPE_CHECKING:
    from elspeth.contracts.call_mode import CallModeSession
    from elspeth.contracts.payload_store import PayloadStore
    from elspeth.contracts.plugin_semantics import OutputSemanticDeclaration


_warn_telemetry_before_start = make_warn_telemetry_before_start(logger)


# Bounded local retry constants for sequential multi-query transient errors.
# Mirrors transforms/azure/base.py _CAPACITY_RETRY_* constants.
_SEQUENTIAL_RETRY_INITIAL_DELAY_SECONDS: float = 0.05
_SEQUENTIAL_RETRY_MAX_DELAY_SECONDS: float = 1.0

# Engine batch-wait sizing. The engine's waiter starts at accept, but the
# plugin's retry budget (max_capacity_retry_seconds) starts inside the worker
# and is checked only between provider attempts, so the structured
# retry_timeout result arrives at budget + one in-flight request per query.
# Providers whose config carries no request timeout run on their SDK's
# default, mirrored here (tests pin both against the installed SDK).
_AZURE_OPENAI_SDK_REQUEST_TIMEOUT_SECONDS: float = 600.0  # openai.DEFAULT_TIMEOUT.read
_BEDROCK_LITELLM_REQUEST_TIMEOUT_SECONDS: float = 6000.0  # litellm.request_timeout
_BATCH_WAIT_HEADROOM_SECONDS: float = 30.0


@dataclass(frozen=True, slots=True)
class _FinishReasonError:
    """Bundles the transform result and tracer message for a terminal finish reason."""

    result: TransformResult
    error_message: str


def _serialize_finish_reason(finish_reason: ParsedFinishReason) -> str | None:
    """Serialize finish_reason for audit metadata and error reporting.

    Single source of truth for converting ParsedFinishReason to its string
    representation. Used by both _finish_reason_error (error path) and
    success metadata recording (audit path) to eliminate parallel isinstance
    dispatch chains that would need synchronized updates.

    Returns a string for known enum values, the raw string for unrecognized
    values, and None when the provider couldn't extract it. The audit trail
    must distinguish these three cases.
    """
    if finish_reason is None:
        return None
    if isinstance(finish_reason, FinishReason):
        return finish_reason.value
    if isinstance(finish_reason, UnrecognizedFinishReason):
        return finish_reason.raw
    return str(finish_reason)  # type: ignore[unreachable]  # pragma: no cover — exhaustive, but future-proof


def _shutdown_event_is_set(shutdown_event: threading.Event | None) -> bool:
    """Return whether the declared cancellation signal has been set."""
    return shutdown_event is not None and shutdown_event.is_set()


def _shutdown_requested_result(
    *,
    error: str = "Run cancellation requested before LLM provider call",
    query_name: str | None = None,
    query_index: int | None = None,
) -> TransformResult:
    reason: dict[str, Any] = {"reason": "shutdown_requested", "error": error}
    if query_name is not None:
        reason["query_name"] = query_name
    if query_index is not None:
        reason["query_index"] = query_index
    return TransformResult.error(cast(TransformErrorReason, reason), retryable=False)


def _blank_required_input_result(
    row: PipelineRow, required_fields: frozenset[str], allow_blank_fields: frozenset[str] = frozenset()
) -> TransformResult | None:
    """Refuse blanks except explicitly permitted strings and nullable nulls."""
    for field_name in sorted(required_fields):
        if field_name not in row:
            continue
        value = row[field_name]
        if field_name in allow_blank_fields and type(value) is str:
            continue
        if value is None:
            canonical_name = row.contract.find_name(field_name)
            if canonical_name is not None and row.contract.get_field(canonical_name).nullable:
                continue
        if value is None or (type(value) is str and not value.strip()):
            return TransformResult.error(
                {
                    "reason": "required_input_field_blank",
                    "field": field_name,
                    "message": "Declared required_input_fields must contain non-blank row content before LLM dispatch.",
                },
                retryable=False,
            )
    return None


def _finish_reason_error(
    finish_reason: ParsedFinishReason,
    *,
    query_name: str | None = None,
    query_index: int | None = None,
    content_length: int | None = None,
) -> _FinishReasonError | None:
    """Fail closed on non-STOP finish reasons.

    Only explicit STOP is allowlisted.  Absent finish_reason (None) is
    accepted with a structured warning (Drifting Goals intervention — see
    below). Known-bad reasons get specific error messages, unknown/unrecognized
    reasons get a generic rejection. This ensures new provider finish reasons
    are never silently treated as success.
    """

    def _build_reason(**base_fields: str) -> dict[str, Any]:
        reason: dict[str, Any] = dict(base_fields)
        if query_name is not None:
            reason["query_name"] = query_name
        if query_index is not None:
            reason["query_index"] = query_index
        if content_length is not None:
            reason["content_length"] = content_length
        return reason

    failure = classify_finish_reason_failure(finish_reason)
    if failure is None:
        return None
    return _FinishReasonError(
        result=TransformResult.error(
            cast(
                TransformErrorReason,
                _build_reason(reason=failure.reason, finish_reason=failure.finish_reason),
            ),
            retryable=False,
        ),
        error_message=failure.error_message,
    )


# ---------------------------------------------------------------------------
# Provider registry — single source of truth for both config parsing and
# provider instantiation. Eliminates the sync failure mode of two dispatch tables.
# ---------------------------------------------------------------------------

# NOTE: type[LLMProvider] won't work here — mypy doesn't support type[Protocol]
# for structural subtyping. The concrete classes (AzureLLMProvider,
# OpenRouterLLMProvider, BedrockLLMProvider, GatewayLLMProvider) are verified
# against LLMProvider by mypy at their definition sites. The provider class is
# stored here for documentation only — actual construction uses isinstance
# narrowing in _create_provider().
_PROVIDERS: dict[str, tuple[type[LLMConfig], type]] = {
    "azure": (AzureOpenAIConfig, AzureLLMProvider),
    "openrouter": (OpenRouterConfig, OpenRouterLLMProvider),
    "bedrock": (BedrockConfig, BedrockLLMProvider),
    "gateway": (GatewayConfig, GatewayLLMProvider),
}

if _PROVIDERS.keys() != LLM_PROVIDER_NAMES:
    raise FrameworkBugError("LLM provider implementations must exactly implement the core provider binding contract")


# ---------------------------------------------------------------------------
# Strategy protocol and implementations
# ---------------------------------------------------------------------------


class QueryStrategy(Protocol):
    """What LLMTransform._process_row delegates to."""

    def execute(
        self,
        row: PipelineRow,
        ctx: TransformContext,
        *,
        provider: LLMProvider,
        tracer: LangfuseTracer,
        payload_store: PayloadStore | None = None,
    ) -> TransformResult: ...


@dataclass(frozen=True, slots=True)
class SingleQueryStrategy:
    """Direct template render → LLM call → raw content output."""

    template: PromptTemplate
    # What the template's ``row`` holds: the node's declaration (ADR-051).
    row_projection: RowProjection
    system_prompt: str | None
    system_prompt_source: str | None
    model: str
    temperature: float | None
    max_tokens: int | None
    response_field: str
    align_output_contract: Callable[[SchemaContract], SchemaContract]
    apply_declared_output_field_contracts: Callable[[SchemaContract], SchemaContract]
    image_specs: tuple[ImageInputConfig, ...] = ()
    max_image_bytes: int = 0
    max_images_per_call: int = 0
    # Top-level structured output (single-prompt lift of the per-query pair).
    # Extracted fields land UNPREFIXED — no query name exists to prefix with.
    output_fields: tuple[OutputFieldConfig, ...] = ()
    response_format: ResponseFormat = ResponseFormat.STANDARD

    def execute(
        self,
        row: PipelineRow,
        ctx: TransformContext,
        *,
        provider: LLMProvider,
        tracer: LangfuseTracer,
        payload_store: PayloadStore | None = None,
    ) -> TransformResult:
        """Execute single LLM query and build output row."""
        state_id = ctx.state_id
        if state_id is None:
            raise RuntimeError("LLMTransform requires state_id")
        if ctx.token is None:
            raise RuntimeError("LLMTransform requires ctx.token")
        token_id = ctx.token.token_id
        shutdown_event = ctx.shutdown_event

        # 1. Render template (THEIR DATA — wrap)
        try:
            rendered = self.template.render_with_metadata(TemplateRow.project(row, self.row_projection), contract=row.contract)
        except TemplateError as e:
            error_reason: TransformErrorReason = {
                "reason": "template_rendering_failed",
                "error": str(e),
                "template_hash": self.template.template_hash,
            }
            if self.template.template_source:
                error_reason["template_file_path"] = self.template.template_source
            return TransformResult.error(error_reason)

        # 1b. Resolve config-declared image inputs (THEIR DATA — wrap). A
        # resolve failure is a row-level error result; the provider must
        # never be called on it.
        image_parts: tuple[ImagePart, ...] = ()
        if self.image_specs:
            resolved = resolve_image_parts(
                row,
                payload_store=payload_store,
                specs=self.image_specs,
                max_image_bytes=self.max_image_bytes,
                max_images_per_call=self.max_images_per_call,
            )
            if isinstance(resolved, TransformResult):
                return resolved
            image_parts = resolved
        tracer_extra_metadata: dict[str, Any] | None = {"image_parts": [p.audit_view() for p in image_parts]} if image_parts else None

        # 1c. Build the provider response constraint and exact prompt sent
        # (shared with multi-query mode and the LLM source). No output_fields
        # → (None, unchanged prompt), exactly the pre-structured behavior.
        response_format, provider_prompt = build_structured_response_directive(
            schema_name="single_output",
            output_fields=self.output_fields,
            response_format=self.response_format,
            prompt=rendered.prompt,
        )

        # 2. Build messages. Images append AFTER the standard-mode schema
        # suffix, so the schema text and the images travel in the same user
        # message (multi-query parity).
        messages: list[ChatMessage] = []
        if self.system_prompt:
            messages.append(ChatMessage(role="system", content=self.system_prompt))
        user_content: str | tuple[ContentPart, ...] = provider_prompt
        content_hash: str | None = None
        if image_parts:
            user_content = (TextPart(text=provider_prompt), *image_parts)
            content_hash = parts_hash(user_content)
        messages.append(ChatMessage(role="user", content=user_content))

        if _shutdown_event_is_set(shutdown_event):
            return _shutdown_requested_result()

        # 3. Call provider (EXTERNAL — errors classified by provider)
        trace_parent = LLMAuditParent.for_row(
            state_id=state_id, token_id=token_id, member_token=ctx.require_member_token(), work_item=ctx.require_work_item()
        )
        start_time = time.monotonic()
        try:
            result = provider.execute_query(
                messages,
                model=self.model,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                audit_parent=trace_parent,
                response_format=response_format,
            )
        except ContextLengthError as e:
            latency_ms = (time.monotonic() - start_time) * 1000
            tracer.record_error(
                parent=trace_parent,
                query_name="single",
                prompt=provider_prompt,
                error_message=str(e),
                model=self.model,
                latency_ms=latency_ms,
                extra_metadata=tracer_extra_metadata,
                system_prompt=self.system_prompt,
            )
            return TransformResult.error(
                {"reason": "context_length_exceeded", "error": str(e)},
                retryable=False,
            )
        except LLMClientError as e:
            latency_ms = (time.monotonic() - start_time) * 1000
            tracer.record_error(
                parent=trace_parent,
                query_name="single",
                prompt=provider_prompt,
                error_message=str(e),
                model=self.model,
                latency_ms=latency_ms,
                extra_metadata=tracer_extra_metadata,
                system_prompt=self.system_prompt,
            )
            if e.retryable:
                raise
            return TransformResult.error(
                {"reason": "llm_call_failed", "error": str(e)},
                retryable=False,
            )

        latency_ms = (time.monotonic() - start_time) * 1000

        # 4. Fail closed on provider-signaled terminal finish reasons.
        finish_reason_error = _finish_reason_error(
            result.finish_reason,
            content_length=len(result.content),
        )
        if finish_reason_error is not None:
            tracer.record_error(
                parent=trace_parent,
                query_name="single",
                prompt=provider_prompt,
                error_message=finish_reason_error.error_message,
                model=self.model,
                latency_ms=latency_ms,
                extra_metadata=tracer_extra_metadata,
                system_prompt=self.system_prompt,
            )
            return finish_reason_error.result

        # 5. Strip markdown fences
        content = strip_markdown_fences(result.content)

        # Record success in tracer
        tracer.record_success(
            parent=trace_parent,
            query_name="single",
            prompt=provider_prompt,
            response_content=content,
            model=result.model,
            usage=result.usage,
            latency_ms=latency_ms,
            extra_metadata=tracer_extra_metadata,
            system_prompt=self.system_prompt,
        )

        # 6. Build output row — operational fields plus any declared
        # structured fields. LLM response content is Tier 3 — parse and
        # validate immediately (shared with multi-query mode); extracted
        # fields land unprefixed, raw content stays in response_field for
        # audit traceability.
        output = row.to_dict()
        if self.output_fields:
            extracted, extraction_error = extract_structured_fields(content, self.output_fields)
            if extraction_error is not None:
                return TransformResult.error(extraction_error, retryable=False)
            output.update(extracted)
        output[self.response_field] = content
        populate_llm_operational_fields(
            output,
            self.response_field,
            usage=result.usage,
            model=result.model,
        )

        # 7. Build audit metadata (goes to success_reason, not the row)
        audit_metadata = build_llm_audit_metadata(
            self.response_field,
            template_hash=rendered.template_hash,
            variables_hash=rendered.variables_hash,
            template_source=rendered.template_source,
            lookup_hash=rendered.lookup_hash,
            lookup_source=rendered.lookup_source,
            system_prompt_source=self.system_prompt_source,
            parts_hash=content_hash,
        )

        # 8. Propagate contract
        output_contract = propagate_contract(
            input_contract=row.contract,
            output_row=output,
            transform_adds_fields=True,
        )
        output_contract = self.apply_declared_output_field_contracts(output_contract)
        output_contract = self.align_output_contract(output_contract)

        return TransformResult.success(
            PipelineRow(output, output_contract),
            success_reason={
                "action": "enriched",
                "fields_added": [self.response_field, *(field.suffix for field in self.output_fields)],
                "metadata": {
                    "model": result.model,
                    "finish_reason": _serialize_finish_reason(result.finish_reason),
                    **result.usage.to_dict(),
                    **audit_metadata,
                },
            },
        )


@dataclass(frozen=True, slots=True)
class MultiQueryStrategy:
    """Execute multiple queries per row with atomic failure semantics.

    Supports two execution modes:
    - Sequential (executor=None, pool_size=1): queries run one-by-one
    - Parallel (executor set, pool_size>1): queries run via PooledExecutor
      with AIMD throttle backoff on rate limits

    In parallel mode, the PooledExecutor retries individual queries with
    adaptive backoff, avoiding wasteful full-row retries that discard
    successful query results.
    """

    query_specs: Sequence[QuerySpec]
    template: PromptTemplate
    # What each query's ``row.source_row`` holds: the node's declaration (ADR-051).
    row_projection: RowProjection
    system_prompt: str | None
    system_prompt_source: str | None
    model: str
    temperature: float | None
    max_tokens: int | None
    response_field: str
    align_output_contract: Callable[[SchemaContract], SchemaContract]
    align_output_row_contract: Callable[[PipelineRow], PipelineRow]
    apply_declared_output_field_contracts: Callable[[SchemaContract], SchemaContract]
    image_specs: tuple[ImageInputConfig, ...] = ()
    max_image_bytes: int = 0
    max_images_per_call: int = 0
    executor: PooledExecutor | None = None
    max_capacity_retry_seconds: int = 3600
    ordered_plan: OrderedQueryPlan | None = None
    verify_intermediate: Callable[[PipelineRow, PipelineRow], None] | None = None
    _query_templates: Mapping[str, PromptTemplate] = field(init=False, default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.query_specs, tuple):
            object.__setattr__(self, "query_specs", tuple(self.query_specs))

        # Pre-compile per-query template overrides — structural validation at
        # init time.  Templates are Tier 2 data: validated once at load, trusted
        # thereafter.  A TemplateSyntaxError here is a structural failure that
        # propagates up through LLMTransform.__init__ and stops the run at setup.
        query_templates: dict[str, PromptTemplate] = {}
        for spec in self.query_specs:
            if spec.template is not None:
                query_templates[spec.name] = self.template.with_template_override(spec.template)
        object.__setattr__(self, "_query_templates", query_templates)
        freeze_fields(self, "_query_templates")

    def execute(
        self,
        row: PipelineRow,
        ctx: TransformContext,
        *,
        provider: LLMProvider,
        tracer: LangfuseTracer,
        payload_store: PayloadStore | None = None,
    ) -> TransformResult:
        """Execute all queries, returning atomic success or failure."""
        state_id = ctx.state_id
        if state_id is None:
            raise RuntimeError("LLMTransform requires state_id")
        if ctx.token is None:
            raise RuntimeError("LLMTransform requires ctx.token")
        token_id = ctx.token.token_id
        shutdown_event = ctx.shutdown_event

        audit_parent = LLMAuditParent.for_row(
            state_id=state_id, token_id=token_id, member_token=ctx.require_member_token(), work_item=ctx.require_work_item()
        )

        if self.executor is not None:
            return self._execute_parallel(
                row, state_id, token_id, provider, tracer, shutdown_event, payload_store, audit_parent=audit_parent
            )
        return self._execute_sequential(row, state_id, token_id, provider, tracer, shutdown_event, payload_store, audit_parent=audit_parent)

    @dataclass(frozen=True, slots=True)
    class _QuerySuccess:
        """Partial output fields from a successful single-query execution.

        Tagged success type replacing bare ``dict`` in the union return of
        ``_execute_one_query``, so callers can exhaustively match on
        ``_QuerySuccess | TransformResult`` instead of ``dict | TransformResult``.
        """

        # ``Mapping`` (not ``dict``): ``freeze_fields`` replaces both
        # fields with ``MappingProxyType``; the annotation must describe
        # the read-only runtime type callers observe. Consumers needing
        # a writable dict must ``dict(result.fields)`` (see the
        # ``PipelineRow(dict(result.fields), ...)`` call below).
        fields: Mapping[str, Any]
        audit_metadata: Mapping[str, str | None]

        def __post_init__(self) -> None:
            freeze_fields(self, "fields", "audit_metadata")

    def _execute_one_query(
        self,
        query_idx: int,
        spec: QuerySpec,
        row: PipelineRow,
        state_id: str,
        token_id: str,
        provider: LLMProvider,
        tracer: LangfuseTracer,
        shutdown_event: threading.Event | None = None,
        payload_store: PayloadStore | None = None,
        *,
        audit_parent: LLMAuditParent,
        binding_row: PipelineRow | None = None,
    ) -> _QuerySuccess | TransformResult:
        """Execute a single query within a multi-query row.

        Returns:
            _QuerySuccess: Partial output fields on success
            TransformResult: Error result on failure

        Raises:
            LLMClientError: Retryable errors propagate to caller for retry
                handling (PooledExecutor AIMD or sequential error capture).
        """
        if _shutdown_event_is_set(shutdown_event):
            return _shutdown_requested_result(query_name=spec.name, query_index=query_idx)

        # Build template context from named input_fields
        try:
            template_ctx = spec.build_template_context(row if binding_row is None else binding_row, self.row_projection, original_row=row)
        except KeyError as e:
            return TransformResult.error(
                {
                    "reason": "template_context_failed",
                    "query_name": spec.name,
                    "query_index": query_idx,
                    "error": str(e),
                },
                retryable=False,
            )

        # Use pre-compiled per-query template (already structurally validated
        # in __post_init__), falling back to config-level template.
        if spec.template is not None:
            query_template = self._query_templates[spec.name]
        else:
            query_template = self.template

        # Render template — contract=None because template_ctx is a synthetic
        # dict (keys are template variable names from input_fields, not source
        # column names); its source_row is already the projected row.
        try:
            rendered = query_template.render_with_metadata(
                template_ctx,
                contract=None,
            )
        except TemplateError as e:
            return TransformResult.error(
                {
                    "reason": "template_rendering_failed",
                    "query_name": spec.name,
                    "query_index": query_idx,
                    "error": str(e),
                    "template_hash": query_template.template_hash,
                },
                retryable=False,
            )

        # Resolve config-declared image inputs (THEIR DATA — wrap). Resolved
        # from the full row, not the synthetic template_ctx above — image
        # fields are never template variables. A resolve failure is a
        # row-level error result; the provider must never be called on it.
        image_parts: tuple[ImagePart, ...] = ()
        if self.image_specs:
            resolved = resolve_image_parts(
                row,
                payload_store=payload_store,
                specs=self.image_specs,
                max_image_bytes=self.max_image_bytes,
                max_images_per_call=self.max_images_per_call,
            )
            if isinstance(resolved, TransformResult):
                return resolved
            image_parts = resolved
        tracer_extra_metadata: dict[str, Any] | None = {"image_parts": [p.audit_view() for p in image_parts]} if image_parts else None

        # Build the provider response constraint and exact prompt sent for
        # this query (shared with single-prompt mode and the LLM source).
        response_format, provider_prompt = build_structured_response_directive(
            schema_name=f"{spec.name}_output",
            output_fields=spec.output_fields or (),
            response_format=spec.response_format,
            prompt=rendered.prompt,
        )

        # Build messages. Images append AFTER the standard-mode schema suffix
        # above, so the schema text and the images travel in the same user
        # message.
        messages: list[ChatMessage] = []
        if self.system_prompt:
            messages.append(ChatMessage(role="system", content=self.system_prompt))
        user_content: str | tuple[ContentPart, ...] = provider_prompt
        content_hash: str | None = None
        if image_parts:
            user_content = (TextPart(text=provider_prompt), *image_parts)
            content_hash = parts_hash(user_content)
        messages.append(ChatMessage(role="user", content=user_content))
        # Langfuse reconstructs the outbound messages from these separate
        # values. Match the provider's truthy inclusion rule so an explicitly
        # empty system prompt is omitted from both records.
        tracer_system_prompt = self.system_prompt or None

        if _shutdown_event_is_set(shutdown_event):
            return _shutdown_requested_result(query_name=spec.name, query_index=query_idx)

        # Execute query
        query_max_tokens = spec.max_tokens or self.max_tokens

        trace_parent = audit_parent
        start_time = time.monotonic()
        try:
            result = provider.execute_query(
                messages,
                model=self.model,
                temperature=self.temperature,
                max_tokens=query_max_tokens,
                audit_parent=trace_parent,
                response_format=response_format,
            )
        except ContextLengthError as e:
            latency_ms = (time.monotonic() - start_time) * 1000
            tracer.record_error(
                parent=trace_parent,
                query_name=spec.name,
                prompt=provider_prompt,
                error_message=str(e),
                model=self.model,
                latency_ms=latency_ms,
                extra_metadata=tracer_extra_metadata,
                system_prompt=tracer_system_prompt,
            )
            return TransformResult.error(
                {
                    "reason": "context_length_exceeded",
                    "failed_query_name": spec.name,
                    "failed_query_index": query_idx,
                    "error": str(e),
                },
                retryable=False,
            )
        except LLMClientError as e:
            latency_ms = (time.monotonic() - start_time) * 1000
            tracer.record_error(
                parent=trace_parent,
                query_name=spec.name,
                prompt=provider_prompt,
                error_message=str(e),
                model=self.model,
                latency_ms=latency_ms,
                extra_metadata=tracer_extra_metadata,
                system_prompt=tracer_system_prompt,
            )
            if e.retryable:
                raise  # Pool catches with AIMD; sequential catches and returns error
            return TransformResult.error(
                {
                    "reason": "multi_query_failed",
                    "failed_query_name": spec.name,
                    "failed_query_index": query_idx,
                    "error": str(e),
                },
                retryable=False,
            )

        latency_ms = (time.monotonic() - start_time) * 1000

        # Fail closed on provider-signaled terminal finish reasons.
        finish_reason_error = _finish_reason_error(
            result.finish_reason,
            query_name=spec.name,
            query_index=query_idx,
        )
        if finish_reason_error is not None:
            tracer.record_error(
                parent=trace_parent,
                query_name=spec.name,
                prompt=provider_prompt,
                error_message=finish_reason_error.error_message,
                model=self.model,
                latency_ms=latency_ms,
                extra_metadata=tracer_extra_metadata,
                system_prompt=tracer_system_prompt,
            )
            return finish_reason_error.result

        # Strip fences and store content
        content = strip_markdown_fences(result.content)

        tracer.record_success(
            parent=trace_parent,
            query_name=spec.name,
            prompt=provider_prompt,
            response_content=content,
            model=result.model,
            usage=result.usage,
            latency_ms=latency_ms,
            extra_metadata=tracer_extra_metadata,
            system_prompt=tracer_system_prompt,
        )

        # Build partial output for this query
        partial: dict[str, Any] = {}

        # JSON parsing + field extraction when output_fields configured.
        # LLM response content is Tier 3 — parse and validate immediately
        # (shared with single-prompt mode and the LLM source).
        if spec.output_fields:
            extracted, extraction_error = extract_structured_fields(content, spec.output_fields)
            if extraction_error is not None:
                extraction_error["query_name"] = spec.name
                extraction_error["query_index"] = query_idx
                return TransformResult.error(extraction_error, retryable=False)
            # Publish typed fields under the spec's resolved row names.
            for suffix, value in extracted.items():
                partial[spec.structured_field_name(suffix)] = value
            # Also store raw content for audit traceability
            partial[f"{spec.name}_{self.response_field}"] = content
        else:
            # Unstructured: store raw content only
            partial[f"{spec.name}_{self.response_field}"] = content

        populate_llm_operational_fields(
            partial,
            f"{spec.name}_{self.response_field}",
            usage=result.usage,
            model=result.model,
        )

        audit_metadata = build_llm_audit_metadata(
            f"{spec.name}_{self.response_field}",
            template_hash=rendered.template_hash,
            variables_hash=rendered.variables_hash,
            template_source=rendered.template_source,
            lookup_hash=rendered.lookup_hash,
            lookup_source=rendered.lookup_source,
            system_prompt_source=self.system_prompt_source,
            parts_hash=content_hash,
        )
        # Record finish_reason so audit trail distinguishes None (absent) from
        # STOP (confirmed completion). See Bug elspeth-393d2459aa.
        audit_metadata[f"{spec.name}_finish_reason"] = _serialize_finish_reason(result.finish_reason)

        return self._QuerySuccess(fields=partial, audit_metadata=audit_metadata)

    def _sequential_retry_timeout_result(
        self,
        last_error: LLMClientError,
        query_idx: int,
        query_name: str,
        started_at: float,
        discarded_successful_queries: int,
    ) -> TransformResult:
        """Build the bounded-retry-exhausted row result for sequential mode.

        Mirrors Azure _capacity_retry_timeout_result shape so the engine and
        downstream audit code see the same reason/elapsed_seconds/max_seconds
        fields regardless of provider.
        """
        elapsed = time.monotonic() - started_at
        return TransformResult.error(
            {
                "reason": "retry_timeout",
                "failed_query_name": query_name,
                "failed_query_index": query_idx,
                "error": str(last_error),
                "elapsed_seconds": elapsed,
                "max_seconds": self.max_capacity_retry_seconds,
                "discarded_successful_queries": discarded_successful_queries,
            },
            retryable=False,
        )

    def _sequential_retry_shutdown_result(
        self,
        query_idx: int,
        query_name: str,
        started_at: float,
    ) -> TransformResult:
        """Build the shutdown-during-retry row result for sequential mode."""
        elapsed = time.monotonic() - started_at
        return TransformResult.error(
            {
                "reason": "shutdown_requested",
                "error": "Run cancellation requested during sequential query retry backoff",
                "failed_query_name": query_name,
                "failed_query_index": query_idx,
                "elapsed_seconds": elapsed,
            },
            retryable=False,
        )

    def _execute_sequential(
        self,
        row: PipelineRow,
        state_id: str,
        token_id: str,
        provider: LLMProvider,
        tracer: LangfuseTracer,
        shutdown_event: threading.Event | None = None,
        payload_store: PayloadStore | None = None,
        *,
        audit_parent: LLMAuditParent,
    ) -> TransformResult:
        """Execute queries sequentially (pool_size=1 fallback).

        Short-circuits on first non-retryable error. Retryable LLMClientErrors
        (429/5xx/network) are retried locally with exponential backoff bounded
        by max_capacity_retry_seconds, mirroring the Azure
        _analyze_field_with_capacity_retry pattern. Earlier succeeded queries
        are NOT re-executed on retry of a later query.
        """
        accumulated_outputs: dict[str, Any] = {}
        accumulated_audit: dict[str, object] = {}

        retry_budget_started_at = time.monotonic()
        retry_deadline = retry_budget_started_at + float(self.max_capacity_retry_seconds)

        for query_idx, spec in enumerate(self.query_specs):
            retry_delay = _SEQUENTIAL_RETRY_INITIAL_DELAY_SECONDS
            prior_view = row
            if self.ordered_plan is not None:
                prior_output = {**row.to_dict(), **accumulated_outputs}
                prior_contract = propagate_contract(input_contract=row.contract, output_row=prior_output, transform_adds_fields=True)
                prior_contract = self.apply_declared_output_field_contracts(prior_contract)
                prior_view = PipelineRow(prior_output, prior_contract)

            while True:
                try:
                    result = self._execute_one_query(
                        query_idx,
                        spec,
                        row,
                        state_id,
                        token_id,
                        provider,
                        tracer,
                        shutdown_event,
                        payload_store,
                        audit_parent=audit_parent,
                        binding_row=prior_view if self.ordered_plan is not None else None,
                    )
                    break  # success or non-retryable error result - exit retry loop
                except LLMClientError as e:
                    if not e.retryable:
                        # Non-retryable (ContextLength, ContentPolicy) - fail immediately
                        return TransformResult.error(
                            {
                                "reason": "multi_query_failed",
                                "failed_query_name": spec.name,
                                "failed_query_index": query_idx,
                                "error": str(e),
                                "discarded_successful_queries": query_idx,
                            },
                            retryable=False,
                        )

                    # Retryable (RateLimit/Server/Network) - apply bounded local retry
                    if _shutdown_event_is_set(shutdown_event):
                        return self._sequential_retry_shutdown_result(query_idx, spec.name, retry_budget_started_at)

                    now = time.monotonic()
                    if now >= retry_deadline:
                        return self._sequential_retry_timeout_result(e, query_idx, spec.name, retry_budget_started_at, query_idx)

                    sleep_seconds = min(retry_delay, retry_deadline - now)
                    if sleep_seconds > 0:
                        if isinstance(shutdown_event, threading.Event):
                            if shutdown_event.wait(timeout=sleep_seconds):
                                return self._sequential_retry_shutdown_result(query_idx, spec.name, retry_budget_started_at)
                        else:
                            time.sleep(sleep_seconds)

                    if time.monotonic() >= retry_deadline:
                        return self._sequential_retry_timeout_result(e, query_idx, spec.name, retry_budget_started_at, query_idx)

                    retry_delay = min(retry_delay * 2.0, _SEQUENTIAL_RETRY_MAX_DELAY_SECONDS)

            # Error from template/JSON/validation/non-retryable LLM
            if isinstance(result, TransformResult):
                # A TransformResult with status="error" and reason=None is a bug
                # in our code — mirrors the same guard in _execute_parallel.
                if result.reason is None:
                    raise FrameworkBugError(
                        f"Multi-query sequential execution produced TransformResult with "
                        f"status='error' but reason=None for query index {query_idx} "
                        f"(query_name={spec.name!r}). Every error path must set a reason dict."
                    )
                # Add discarded count for error reporting — copy first to avoid
                # mutating the original dict (which may be shared with audit records)
                augmented_reason = cast(TransformErrorReason, dict(result.reason))
                augmented_reason["discarded_successful_queries"] = query_idx
                return TransformResult.error(
                    augmented_reason,
                    retryable=result.retryable,
                    context_after=result.context_after,
                )

            if self.ordered_plan is not None:
                expected = self.ordered_plan.generated_by_query[query_idx]
                if frozenset(result.fields) != expected:
                    raise FrameworkBugError(f"Ordered query '{spec.name}' produced a field set different from its compiled plan")
                if set(result.fields) & set(prior_view.to_dict()):
                    raise FrameworkBugError(f"Ordered query '{spec.name}' overwrote an existing field")
                candidate_output = {**prior_view.to_dict(), **result.fields}
                candidate_contract = propagate_contract(
                    input_contract=prior_view.contract, output_row=candidate_output, transform_adds_fields=True
                )
                candidate_contract = self.apply_declared_output_field_contracts(candidate_contract)
                if self.verify_intermediate is None:
                    raise FrameworkBugError("Ordered query strategy has no intermediate verifier")
                self.verify_intermediate(prior_view, PipelineRow(candidate_output, candidate_contract))
            accumulated_outputs.update(result.fields)
            accumulated_audit.update(result.audit_metadata)

        # All queries succeeded — build output row
        output = {**row.to_dict(), **accumulated_outputs}
        output_contract = propagate_contract(
            input_contract=row.contract,
            output_row=output,
            transform_adds_fields=True,
        )
        output_contract = self.apply_declared_output_field_contracts(output_contract)
        output_contract = self.align_output_contract(output_contract)

        return TransformResult.success(
            PipelineRow(output, output_contract),
            success_reason={
                "action": "multi_query_enriched",
                "queries_completed": len(self.query_specs),
                "fields_added": list(accumulated_outputs.keys()),
                "metadata": {"model": self.model, **accumulated_audit},
            },
        )

    def _execute_parallel(
        self,
        row: PipelineRow,
        state_id: str,
        token_id: str,
        provider: LLMProvider,
        tracer: LangfuseTracer,
        shutdown_event: threading.Event | None = None,
        payload_store: PayloadStore | None = None,
        *,
        audit_parent: LLMAuditParent,
    ) -> TransformResult:
        """Execute queries in parallel via PooledExecutor with AIMD retry.

        All queries run concurrently. The pool retries individual queries with
        AIMD backoff on retryable errors — only the failing query retries, not
        the entire row. Results are collected in submission order.
        """
        if self.executor is None:
            raise RuntimeError("_execute_parallel called without executor")

        # Side channel for audit metadata — _process_fn writes here, outer scope reads after pool.
        # Protected by lock: PooledExecutor runs _process_fn across ThreadPoolExecutor
        # workers, so concurrent dict writes require synchronization.
        # ``Mapping`` value type (not ``dict``): ``_QuerySuccess.audit_metadata``
        # is frozen via ``freeze_fields`` and surfaces as ``MappingProxyType``.
        # Declaring the slot as ``dict`` would make the assignment below a
        # silent type lie (see IM-2: ``dict[str, Any]`` after ``freeze_fields``).
        audit_metadata_by_index: dict[int, Mapping[str, str | None]] = {}
        audit_metadata_lock = threading.Lock()

        # Build RowContext for each query — the pool treats each as a "row"
        contexts = [
            RowContext(
                row={
                    "original_row": row,
                    "spec": spec,
                    "query_idx": i,
                    "provider": provider,
                    "tracer": tracer,
                    "token_id": token_id,
                    "state_id": state_id,
                    "payload_store": payload_store,
                },
                state_id=state_id,
                row_index=i,
            )
            for i, spec in enumerate(self.query_specs)
        ]

        def _process_fn(work: Mapping[str, Any], _work_state_id: str) -> TransformResult:
            """Pool process function — wraps _execute_one_query for pool interface."""
            result = self._execute_one_query(
                work["query_idx"],
                work["spec"],
                work["original_row"],
                work["state_id"],
                work["token_id"],
                work["provider"],
                work["tracer"],
                shutdown_event,
                work["payload_store"],
                audit_parent=audit_parent,
            )
            if isinstance(result, TransformResult):
                return result  # Error passthrough
            # Stash audit metadata in side channel before wrapping in TransformResult.
            # Lock required: multiple pool workers write concurrently.
            with audit_metadata_lock:
                audit_metadata_by_index[work["query_idx"]] = result.audit_metadata
            # Success: wrap partial fields in TransformResult for pool interface
            observed = SchemaContract(
                mode="OBSERVED",
                fields=tuple(
                    FieldContract(
                        normalized_name=k,
                        original_name=k,
                        python_type=type(v) if type(v) in (int, str, float, bool) else object,
                        required=False,
                        source="inferred",
                    )
                    for k, v in result.fields.items()
                ),
                locked=True,
            )
            # result.fields is a MappingProxyType (deep-frozen in
            # _QuerySuccess.__post_init__). PipelineRow enforces
            # ``type(data) is dict`` as a Tier 1 guard against silently coercing
            # audit/replay data — so materialize a fresh dict here. PipelineRow
            # re-deep-freezes internally, preserving immutability across the handoff.
            return TransformResult.success(
                self.align_output_row_contract(PipelineRow(dict(result.fields), observed)),
                success_reason={"action": "query_completed", "metadata": {"query_name": work["spec"].name}},
            )

        if shutdown_event is None:
            entries = self.executor.execute_batch(contexts=contexts, process_fn=_process_fn)
        else:
            entries = self.executor.execute_batch(contexts=contexts, process_fn=_process_fn, shutdown_event=shutdown_event)
        query_results = [entry.result for entry in entries]

        # Check for failures — atomic: any failure fails the row
        failed = [(i, r) for i, r in enumerate(query_results) if r.status == "error"]
        if failed:
            first_idx, first_result = failed[0]
            spec = self.query_specs[first_idx]
            # A TransformResult with status="error" and reason=None is a bug in
            # our code — every error path in _execute_one_query sets a reason dict.
            # Fabricating a reason here would hide the bug. Crash per offensive
            # programming policy.
            if first_result.reason is None:
                raise FrameworkBugError(
                    f"Multi-query parallel execution produced TransformResult with "
                    f"status='error' but reason=None for query index {first_idx} "
                    f"(query_name={spec.name!r}). Every error path must set a reason dict."
                )
            error_reason: TransformErrorReason = cast(
                TransformErrorReason,
                dict(first_result.reason),
            )
            error_reason["failed_query_name"] = spec.name
            error_reason["failed_query_index"] = first_idx
            error_reason["discarded_successful_queries"] = len(query_results) - len(failed)
            error_reason["failed_queries"] = [self.query_specs[i].name for i, _ in failed]
            error_reason["total_count"] = len(query_results)
            return TransformResult.error(error_reason, retryable=first_result.retryable)

        # Merge all successful partial outputs
        accumulated_outputs: dict[str, Any] = {}
        for result in query_results:
            if result.row is not None:
                accumulated_outputs.update(result.row.to_dict())

        # Merge audit metadata from side channel (written by _process_fn).
        # Validate that every successful query contributed its audit metadata —
        # a missing entry means incomplete provenance in the audit trail.
        success_indices = {i for i, r in enumerate(query_results) if r.status == "success"}
        missing_audit = success_indices - set(audit_metadata_by_index.keys())
        if missing_audit:
            raise FrameworkBugError(
                f"Multi-query parallel execution lost audit metadata for query indices "
                f"{sorted(missing_audit)}. Side-channel write in _process_fn did not "
                f"execute for these successful queries."
            )
        accumulated_audit: dict[str, object] = {}
        for idx in sorted(audit_metadata_by_index):
            accumulated_audit.update(audit_metadata_by_index[idx])

        output = {**row.to_dict(), **accumulated_outputs}
        output_contract = propagate_contract(
            input_contract=row.contract,
            output_row=output,
            transform_adds_fields=True,
        )
        output_contract = self.apply_declared_output_field_contracts(output_contract)
        output_contract = self.align_output_contract(output_contract)

        return TransformResult.success(
            PipelineRow(output, output_contract),
            success_reason={
                "action": "multi_query_enriched",
                "queries_completed": len(self.query_specs),
                "fields_added": list(accumulated_outputs.keys()),
                "metadata": {"model": self.model, **accumulated_audit},
            },
        )


# ---------------------------------------------------------------------------
# LLMTransform — the unified plugin class
# ---------------------------------------------------------------------------


class LLMTransform(BaseTransform, BatchTransformMixin):
    """Unified LLM transform with provider dispatch and strategy selection.

    Registered as plugin name="llm". Uses BatchTransformMixin for concurrent
    row processing with FIFO output ordering and backpressure.

    Provider dispatch:
        "azure"      → AzureOpenAIConfig + AzureLLMProvider
        "openrouter" → OpenRouterConfig  + OpenRouterLLMProvider
        "bedrock"    → BedrockConfig     + BedrockLLMProvider
        "gateway"    → GatewayConfig     + GatewayLLMProvider

    Strategy selection:
        queries is not None → MultiQueryStrategy
        queries is None     → SingleQueryStrategy
    """

    # response_field names the row field the LLM response is WRITTEN to
    # ("Field name for LLM response in output"), not a column that is read.
    output_naming_config_keys = frozenset({"response_field"})
    name = "llm"
    web_config_authority = WebConfigAuthority.OPERATOR_PROFILED
    policy_capabilities = frozenset({CapabilityDeclaration(PluginCapability.LLM)})
    requires_runtime_preflight = True
    plugin_version = "1.0.0"
    source_file_hash: str | None = "sha256:0e12f0bdebf60583"
    determinism: Determinism = Determinism.NON_DETERMINISTIC
    config_model = LLMConfig  # Base; get_config_model dispatches to provider-specific
    passes_through_input = True
    content_trust = ContentTrust.UNTRUSTED
    # elspeth-e6e552ce34: the LLM ADDS response fields and never rewrites an
    # input field's value in place. A response field colliding with a
    # guaranteed input is rejected at build by
    # validate_transform_output_field_collisions, which is what keeps this
    # promise sound for the type-resolution walk; a stray undeclared column a
    # response could overwrite is never resolvable (no ancestor vouches for
    # it), so no build verdict rests on its value.
    preserves_input_values = True
    _provider: LLMProvider | None
    capability_tags: tuple[str, ...] = ("llm", "generation", "structured-output")

    usage_when_to_use = (
        "Use an operator-approved profile for text generation or structured-output workflows. "
        "ELSPETH records prompts, responses, the returned model, and input/output tokens when reported by the provider "
        "in the audit trail. "
        "Returned provider content is untrusted before LLM reuse or tool routing."
    )
    usage_when_not_to_use = (
        "Do not put provider credentials or endpoints in web-authored options; the operator profile "
        "owns those bindings. Do not use this non-deterministic transform where replay must reproduce "
        "the same generated value without a recorded provider response."
    )
    example_use = (
        "transform:\n"
        "  plugin: llm\n"
        "  options:\n"
        "    profile: approved-structured-generation\n"
        "    prompt_template: 'Summarise {{ row.document_text }} in one sentence.'\n"
        "    required_input_fields: [document_text]\n"
        "    response_field: generated_summary\n"
        "    schema: {mode: observed}"
    )

    @classmethod
    def get_config_model(cls, config: dict[str, Any] | None = None) -> type[LLMConfig]:
        """Dispatch to provider-specific config class based on config["provider"]."""
        provider = config["provider"] if config is not None and "provider" in config else None
        if provider is not None and not isinstance(provider, str):
            # ``provider in _PROVIDERS`` on an unhashable value (a mapping from
            # a free-form ``upsert_node`` options payload) raised TypeError and
            # crashed the composer's Stage-1 validator; a wrong-typed provider
            # is a config error like an unknown one (elspeth-2ed41f0a4a).
            raise ValueError(f"LLM 'provider' must be a string naming one of: {sorted(_PROVIDERS)}")
        if provider is not None and provider in _PROVIDERS:
            config_cls, _ = _PROVIDERS[provider]
            return config_cls
        elif provider is not None:
            raise ValueError(f"Unknown LLM provider '{provider}'. Valid providers: {sorted(_PROVIDERS)}")
        # provider missing — return base LLMConfig so Pydantic catches it with Literal validation
        return LLMConfig

    @classmethod
    def get_config_schema(cls) -> dict[str, Any]:
        """Publish the full LLM config contract as a Pydantic discriminated union.

        The runtime dispatches ``get_config_model(config)`` on ``config["provider"]``
        to select the provider-specific config class registered in
        :data:`_PROVIDERS`. The catalog needs to advertise the complete
        contract at schema-discovery time — before any provider has been
        chosen — so this returns ``oneOf`` + a ``provider`` discriminator
        over every variant in ``_PROVIDERS``. The variant list is derived
        from the same registry that drives runtime provider instantiation;
        the two cannot drift.

        Requires ``len(_PROVIDERS) >= 2`` because a discriminated union with
        one branch degenerates — Pydantic's ``TypeAdapter`` would emit a
        non-``oneOf`` schema and downstream consumers (catalog flattener,
        frontend PluginCard) rely on the ``oneOf`` + ``$defs`` shape to route
        rendering. The guard here surfaces the contract explicitly instead of
        letting the shape silently change under a single-provider build.
        """
        variants = tuple(cfg for cfg, _ in _PROVIDERS.values())
        if len(variants) < 2:
            raise RuntimeError(
                "LLMTransform.get_config_schema requires at least two providers "
                f"registered in _PROVIDERS; found {len(variants)}. Discriminated "
                "union shape requires multiple branches."
            )
        # Fold with ``|`` to a single types.UnionType — the form Pydantic's
        # Annotated[..., Field(discriminator=...)] requires. typing.Union[*variants]
        # and tuple-of-types do not produce the same schema shape.
        union_type = reduce(or_, variants[1:], variants[0])
        adapter: TypeAdapter[Any] = TypeAdapter(Annotated[union_type, PydanticField(discriminator="provider")])
        schema: dict[str, Any] = adapter.json_schema(ref_template="#/$defs/{model}")
        # Pydantic emits ``provider`` as ``{const, default}`` on each variant and,
        # because the field has a default, omits it from the variant's ``required``
        # set. That disagrees with the runtime contract: ``LLMTransform.__init__``
        # raises ``ValueError`` when config lacks ``provider`` because the registry
        # cannot dispatch without it. A JSON-Schema preflight consumer (MCP composer,
        # PluginCard form generation) must see the same requirement the runtime
        # enforces — otherwise it accepts configs the pipeline will reject.
        # Republish ``provider`` as required on every variant defined by ``_PROVIDERS``.
        # Targeting variants by class name (not by "has a provider property") keeps
        # the injection scoped to the discriminated union; unrelated nested ``$defs``
        # (e.g. ``SchemaConfig``) are untouched.
        provider_variant_names = {cfg.__name__ for cfg, _ in _PROVIDERS.values()}
        for variant_name in provider_variant_names:
            variant_schema = schema["$defs"][variant_name]
            # Each provider variant inherits non-empty required fields from
            # LLMConfig (``schema``, ``template``, ...) so Pydantic always
            # emits a ``required`` key on the variant $defs. Access it directly
            # — a missing key would signal a schema-emission regression worth
            # crashing on, not silently papering over with setdefault().
            required = variant_schema["required"]
            if "provider" not in required:
                required.append("provider")
        return schema

    @classmethod
    def discriminated_variants(cls) -> tuple[str, dict[str, type[BaseModel]]]:
        """Expose provider variants to composer knob-schema lowering."""
        return ("provider", {provider: config_cls for provider, (config_cls, _) in _PROVIDERS.items()})

    @classmethod
    def probe_config(cls) -> dict[str, Any]:
        """Minimal no-network config for the ADR-009 forward invariant.

        Uses ``openai/gpt-5`` because it's a stable presence in
        ``litellm.model_list``'s OpenRouter slice — the probe never
        actually makes a network call (preflight mode defers all
        external client setup), but the value-source compliance walker
        runs at construction time, so the model identifier MUST satisfy
        the OpenRouter catalog declaration. Pick a family's BASE id: a
        point-version or dated variant that drops in/out across litellm
        versions (e.g. ``gpt-4o-2024-05-13``) would make probes flaky
        against the catalog snapshot, and the web service primes this
        catalog LIVE at boot, so a provider-retired id (``gpt-4o``,
        EOL'd upstream 2026-09) starts failing construction in
        deployments even while the bundled snapshot still lists it.
        """
        return {
            "provider": "openrouter",
            "api_key": "probe-key",
            "model": "openai/gpt-5",
            "prompt_template": "{{ row.llm_probe_text }}",
            "schema": {"mode": "observed"},
            "required_input_fields": [],
        }

    def forward_invariant_probe_rows(self, probe: PipelineRow) -> list[PipelineRow]:
        """Inject a deterministic prompt field for invariant probing."""
        return [
            self._augment_invariant_probe_row(
                probe,
                field_name="llm_probe_text",
                value="probe request",
            )
        ]

    def execute_forward_invariant_probe(
        self,
        probe_rows: list[PipelineRow],
        ctx: Any,
    ) -> TransformResult:
        """Exercise the real LLM row path with a lifecycle-safe fake provider."""
        if len(probe_rows) != 1:
            raise FrameworkBugError(
                f"{self.__class__.__name__}.execute_forward_invariant_probe() "
                f"received {len(probe_rows)} rows; LLM invariant probes require exactly 1 row."
            )

        class _InvariantProvider:
            def execute_query(
                self,
                messages: Sequence[ChatMessage],
                *,
                model: str,
                temperature: float | None,
                max_tokens: int | None,
                audit_parent: LLMAuditParent,
                response_format: object | None = None,
            ) -> LLMQueryResult:
                del messages, model, temperature, max_tokens, audit_parent, response_format
                return LLMQueryResult(
                    content="probe response",
                    usage=TokenUsage.known(1, 1),
                    model="probe-model",
                    finish_reason=FinishReason.STOP,
                )

            def runtime_preflight(
                self, *, operation_id: str, model: str, temperature: float | None, coordination_token: CoordinationToken
            ) -> None:
                del operation_id, model, temperature, coordination_token

            def close(self) -> None:
                return None

        original_provider = self._provider
        probe_provider = _InvariantProvider()
        try:
            self._provider = probe_provider
            return self._process_row(probe_rows[0], ctx)
        finally:
            self._provider = original_provider
            probe_provider.close()

    def __init__(self, config: dict[str, Any]) -> None:
        profile_alias = require_lowered_llm_profile_alias(config)
        if profile_alias is None:
            base_config = config
        else:
            # Consume the nominal admission proof at the plugin boundary and
            # retain only the opaque plain-string alias in audit config.
            base_config = dict(config)
            base_config["profile_alias"] = profile_alias
        super().__init__(base_config)

        # Provider dispatch from single registry.
        # config is user YAML (Tier 3 boundary) — distinguish missing key from unknown value.
        if "provider" not in base_config:
            raise ValueError(f"LLM config missing required 'provider' key. Valid providers: {sorted(_PROVIDERS)}")
        provider_name = base_config["provider"]
        if provider_name not in _PROVIDERS:
            raise ValueError(f"Unknown LLM provider '{provider_name}'. Valid providers: {sorted(_PROVIDERS)}")
        config_cls, _ = _PROVIDERS[provider_name]

        # `profile_alias` is a provenance-only marker the batch/CLI operator
        # profile catalog lowering pass (core.config._lower_llm_profile_nodes)
        # leaves in `self.config` (converted from its nominal admission marker
        # to an ordinary string before BaseTransform.__init__ above) purely so
        # the DAG's per-node audit config and the run's settings_json snapshot
        # can answer "which llm_profiles alias did this node use" — no provider
        # config model declares this field, and every provider config class
        # forbids extra fields, so it must be excluded before validation rather
        # than declared on LLMConfig itself. Named distinctly from the authored
        # `profile` selector key on purpose: keying the retained alias as
        # `profile` here would put a lowered node right back into the exact shape
        # _lower_llm_profile_nodes's own ambiguity check rejects (`profile`
        # + `provider` both present), making that pass unsafe to run twice
        # over its own output.
        provider_config = (
            {key: value for key, value in base_config.items() if key != "profile_alias"} if "profile_alias" in base_config else base_config
        )

        # Parse config with provider-specific model.
        # config_cls is one of the registered provider config classes at runtime;
        # from_dict() returns Self on the subclass, but mypy sees type[LLMConfig].
        self._config = cast(
            "AzureOpenAIConfig | OpenRouterConfig | BedrockConfig | GatewayConfig",
            config_cls.from_dict(provider_config, plugin_name=self.name),
        )
        self._initialize_declared_input_fields(self._config)
        self._result_checks = tuple(self._config.result_checks or ())
        self._input_checks = tuple(self._config.input_checks or ())
        self.header_spelled_lookups = MappingProxyType(self._config.header_spelled_row_lookups())

        # Store common LLM settings.
        # AzureOpenAIConfig._set_model_from_deployment ensures model is populated;
        # OpenRouterConfig requires model. So self._config.model is always non-empty.
        self._model = self._config.model
        # What a template may see of each row: exactly the declared fields
        # (the whole row under the ``[]`` opt-out; nothing when omitted). ADR-051.
        self._row_projection: RowProjection = declared_row_projection(self._config.required_input_fields)
        self._allow_blank_input_fields = frozenset(self._config.allow_blank_input_fields)
        self._template = PromptTemplate(
            self._config.effective_template(
                self._config.resolved_queries()[0].template
                if self._config.prompt_template is None and self._config.queries is not None
                else None
            ),
            template_source=self._config.prompt_template_source,
            lookup_data=self._config.lookup,
            lookup_source=self._config.lookup_source,
        )
        self._system_prompt = self._config.system_prompt
        self._system_prompt_source = self._config.system_prompt_source
        self._temperature = self._config.temperature
        self._max_tokens = self._config.max_tokens
        self._response_field = self._config.response_field
        self._max_capacity_retry_seconds = self._config.max_capacity_retry_seconds
        self._pool_size = self._config.pool_size
        # Phase 5b Task 9 — cross-DB hash anchor. ``None`` when this LLM
        # transform was not staged via an interpretation event; populated
        # by the session service's ``resolve_interpretation_event`` writer
        # when the transform's prompt template carried a
        # ``{{interpretation:<term>}}`` placeholder the user resolved.
        # Forwarded to every audited LLM call so the Landscape
        # ``calls.approved_prompt_artifact_hash`` column populates.
        self._approved_prompt_artifact_hash = self._config.approved_prompt_artifact_hash

        # Schema (input — same for both single and multi-query)
        schema_config = self._config.schema_config
        self.input_schema = create_schema_from_config(
            schema_config,
            f"{self.name}Schema",
            allow_coercion=False,
        )
        # output_schema and _output_schema_config are set in the strategy
        # dispatch below — multi-query uses prefixed fields, single-query
        # uses unprefixed fields.

        # Tracer — factory returns frozen ActiveLangfuseTracer or NoOpLangfuseTracer.
        # Tracing lives on every provider-specific config, each of which
        # defines tracing: dict[str, Any] | None.
        tracing_config = parse_tracing_config(self._config.tracing) if self._config.tracing else None
        self._tracing_config: TracingConfig | None = tracing_config

        # Validate provider/tracing compatibility — azure_ai tracing auto-instruments
        # the OpenAI SDK, which only the Azure provider uses. Fail loud, not silent.
        if isinstance(tracing_config, AzureAITracingConfig) and not isinstance(self._config, AzureOpenAIConfig):
            raise ValueError(
                "azure_ai tracing requires the azure provider. "
                "Azure Monitor auto-instruments the OpenAI SDK, which is only used by provider='azure'. "
                f"Current provider: '{self._config.provider}'"
            )

        self._tracer = create_langfuse_tracer(
            transform_name=self.name,
            tracing_config=tracing_config,
        )

        # Query-level executor for parallel multi-query execution with AIMD backoff.
        # Created here (not in on_start) because it doesn't depend on recorder/telemetry.
        pool_config = self._config.pool_config
        self._query_executor: PooledExecutor | None = PooledExecutor(pool_config) if pool_config is not None else None

        # Config-declared image inputs — empty tuple (text-only) when unset,
        # same shape both strategies expect.
        image_specs: tuple[ImageInputConfig, ...] = tuple(self._config.image_inputs or ())
        max_image_bytes = self._config.max_image_bytes
        max_images_per_call = self._config.max_images_per_call

        # Strategy dispatch: queries is not None → multi-query
        self._strict_generated_fields: frozenset[str] = frozenset()
        if self._config.queries is not None:
            query_specs = self._config.resolved_queries()
            self._strategy: SingleQueryStrategy | MultiQueryStrategy = MultiQueryStrategy(
                query_specs=query_specs,
                template=self._template,
                row_projection=self._row_projection,
                system_prompt=self._system_prompt,
                system_prompt_source=self._system_prompt_source,
                model=self._model,
                temperature=self._temperature,
                max_tokens=self._max_tokens,
                response_field=self._response_field,
                align_output_contract=self._align_output_contract,
                align_output_row_contract=self._align_output_row_contract,
                apply_declared_output_field_contracts=self._apply_declared_output_field_contracts,
                image_specs=image_specs,
                max_image_bytes=max_image_bytes,
                max_images_per_call=max_images_per_call,
                executor=self._query_executor,
                max_capacity_retry_seconds=self._max_capacity_retry_seconds,
                ordered_plan=self._config.ordered_query_plan() if self._config.query_input_mode == QueryInputMode.ORDERED else None,
                verify_intermediate=self._verify_intermediate_output,
            )

            # Multi-query emits prefixed fields — compute guaranteed field sets
            # (audit fields now travel via success_reason, not the row)
            prefixed_guaranteed: set[str] = set()
            for spec in query_specs:
                prefix = f"{spec.name}_{self._response_field}"
                prefixed_guaranteed.add(prefix)
                prefixed_guaranteed.update(get_llm_guaranteed_fields(prefix))
                if spec.output_fields:
                    for field in spec.output_fields:
                        prefixed_guaranteed.add(spec.structured_field_name(field.suffix))
            self.declared_output_fields = frozenset(prefixed_guaranteed)
            if self._config.query_input_mode == QueryInputMode.ORDERED or any(
                spec.structured_output_prefix is not None for spec in query_specs
            ):
                self._strict_generated_fields = self.declared_output_fields

            # Output schema config with prefixed fields for DAG contract propagation.
            # INVARIANT: guaranteed_fields must be a superset of declared_output_fields.
            # See: docs/specs/2026-03-20-output-schema-contract-enforcement-design.md
            self._created_output_fields: tuple[FieldDefinition, ...] = tuple(
                definition
                for spec in query_specs
                for definition in _llm_created_output_fields(
                    f"{spec.name}_{self._response_field}", spec.structured_field_prefix, spec.output_fields or ()
                )
            )

            # Pydantic output schema with prefixed LLM fields
            # Build extracted_fields mapping: query_name → (field_name, schema_type) tuples
            extracted: dict[str, tuple[tuple[str, _FieldType], ...]] = {}
            nullable_fields = frozenset(
                spec.structured_field_name(field.suffix) for spec in query_specs for field in spec.output_fields or () if field.nullable
            )
            for spec in query_specs:
                if spec.output_fields:
                    extracted[spec.name] = tuple(
                        (spec.structured_field_name(f.suffix), _OUTPUT_FIELD_TYPE_TO_SCHEMA[f.type.value]) for f in spec.output_fields
                    )
            generated_fields = tuple(
                field
                for spec in query_specs
                for field in _llm_generated_output_fields(
                    f"{spec.name}_{self._response_field}",
                    extracted[spec.name] if spec.name in extracted else (),
                    nullable_fields=nullable_fields,
                )
            )
            self._output_schema_config = _build_llm_output_schema_config(
                schema_config, prefixed_guaranteed, generated_fields=generated_fields
            )
            self.output_schema = _build_multi_query_output_schema(
                base_schema_config=schema_config,
                response_field=self._response_field,
                query_names=tuple(spec.name for spec in query_specs),
                schema_name=f"{self.name}OutputSchema",
                extracted_fields=extracted if extracted else None,
                nullable_fields=nullable_fields,
            )
        else:
            single_output_fields = tuple(self._config.output_fields or ())
            self._strategy = SingleQueryStrategy(
                template=self._template,
                row_projection=self._row_projection,
                system_prompt=self._system_prompt,
                system_prompt_source=self._system_prompt_source,
                model=self._model,
                temperature=self._temperature,
                max_tokens=self._max_tokens,
                response_field=self._response_field,
                align_output_contract=self._align_output_contract,
                apply_declared_output_field_contracts=self._apply_declared_output_field_contracts,
                image_specs=image_specs,
                max_image_bytes=max_image_bytes,
                max_images_per_call=max_images_per_call,
                output_fields=single_output_fields,
                response_format=self._config.response_format,
            )

            # Single-query emits unprefixed fields: operational side fields
            # plus any declared structured fields (audit goes to success_reason).
            # Structured fields are guaranteed on success — extraction fails
            # the row when one is missing.
            guaranteed = (
                *get_llm_guaranteed_fields(self._response_field),
                *(field.suffix for field in single_output_fields),
            )
            self.declared_output_fields = frozenset(guaranteed)

            # Output schema config with LLM output fields for DAG contract propagation.
            # INVARIANT: guaranteed_fields must be a superset of declared_output_fields.
            # See: docs/specs/2026-03-20-output-schema-contract-enforcement-design.md
            extracted_single = tuple((field.suffix, _OUTPUT_FIELD_TYPE_TO_SCHEMA[field.type.value]) for field in single_output_fields)
            nullable_fields = frozenset(field.suffix for field in single_output_fields if field.nullable)
            generated_fields = _llm_generated_output_fields(self._response_field, extracted_single, nullable_fields=nullable_fields)
            self._output_schema_config = _build_llm_output_schema_config(schema_config, guaranteed, generated_fields=generated_fields)
            self._created_output_fields = _llm_created_output_fields(self._response_field, "", single_output_fields)

            # Pydantic output schema with unprefixed LLM fields (structured
            # fields carry their declared runtime types)
            self.output_schema = _build_augmented_output_schema(
                base_schema_config=schema_config,
                response_field=self._response_field,
                schema_name=f"{self.name}OutputSchema",
                extracted_fields=extracted_single or None,
                nullable_fields=nullable_fields,
            )

        # Provider instance — deferred to on_start() when recorder/telemetry available
        self._provider: LLMProvider | None = None

        # Recorder, telemetry, rate limit, payload store (set in on_start)
        self._recorder: PluginAuditWriter | None = None
        self._run_id: str = ""
        self._telemetry_emit: Callable[[TelemetryEvent], None] = _warn_telemetry_before_start
        self._limiter: Any = None
        self._shutdown_event: threading.Event | None = None
        self._payload_store: PayloadStore | None = None
        self._call_mode_session: CallModeSession | None = None

        # Batch processing state
        self._batch_initialized = False

    @property
    def provider_config(self) -> AzureOpenAIConfig | OpenRouterConfig | BedrockConfig | GatewayConfig:
        """Read-only accessor for the typed provider config.

        Exposes the post-validation ``LLMConfig`` subclass so cross-cutting
        validators (notably the value-source compliance walker) can inspect
        ``VALUE_SOURCES`` declarations and field values without reaching for
        ``self._config`` private attribute access.

        Named ``provider_config`` (not ``config``) to avoid colliding with
        :class:`BaseTransform.config` (the raw ``dict[str, Any]`` configuration
        passed to ``__init__``) — distinct meanings, distinct names.
        """
        return self._config

    @property
    def consumed_input_fields(self) -> frozenset[str]:
        """The base set plus every ``image_inputs`` column, the optional ones included.

        An image marked ``required: false`` is not a declared input
        (``LLMConfig.declared_input_fields``) because its absence is a valid
        row, but the transform reads it whenever it is present. The base
        class's column-option limb cannot see it (``image_inputs`` is not a
        ``*_field`` option), so the plugin surfaces it here, as the base
        contract asks of a plugin that reads a column it does not declare:
        demotion must never treat a read column as created-only.
        """
        return super().consumed_input_fields | self._config.image_input_fields

    def output_semantics(self) -> OutputSemanticDeclaration:
        """Declare that raw LLM response fields are unconstrained strings.

        Single-query mode emits ``response_field`` directly. Multi-query mode
        emits one raw response field per query using ``<query>_<response_field>``.
        Structured multi-query extracted fields have their own schema types, but
        this semantic contract only claims the raw response-content fields whose
        runtime value is mechanically known here.

        ``text_framing=UNCONSTRAINED`` is a positive claim, not an abstention:
        the value is free text and whether the model emits a newline is not
        decidable before the run, under any configuration. Declaring UNKNOWN
        instead would be an abstention, and ``compare_semantic`` can never
        raise a CONFLICT against an abstention — which left a generative
        producer ungateable and every wrong composition merely advisory
        (ADR-039).

        ``content_kind`` stays UNKNOWN deliberately. Prose or markdown is a
        genuine unknown per response, and claiming either would manufacture
        false conflicts against consumers that constrain that dimension.
        """
        from elspeth.contracts.plugin_semantics import (
            ContentKind,
            FieldSemanticFacts,
            OutputSemanticDeclaration,
            SemanticValueType,
            TextFraming,
        )

        if isinstance(self._strategy, MultiQueryStrategy):
            return OutputSemanticDeclaration(
                fields=tuple(
                    FieldSemanticFacts(
                        field_name=f"{spec.name}_{self._response_field}",
                        content_kind=ContentKind.UNKNOWN,
                        text_framing=TextFraming.UNCONSTRAINED,
                        value_type=SemanticValueType.STR,
                        fact_code="llm.response_field.string",
                        configured_by=("queries", "response_field"),
                    )
                    for spec in self._strategy.query_specs
                ),
            )

        return OutputSemanticDeclaration(
            fields=(
                FieldSemanticFacts(
                    field_name=self._response_field,
                    content_kind=ContentKind.UNKNOWN,
                    text_framing=TextFraming.UNCONSTRAINED,
                    value_type=SemanticValueType.STR,
                    fact_code="llm.response_field.string",
                    configured_by=("response_field", "queries"),
                ),
            ),
        )

    def connect_output(self, output: OutputPort, max_pending: int = 30) -> None:
        """Connect output port and initialize batch processing."""
        if self._batch_initialized:
            raise RuntimeError("connect_output() already called")

        self.init_batch_processing(
            max_pending=max_pending,
            output=output,
            name=self.name,
            max_workers=max_pending,
            batch_wait_timeout=self._effective_batch_wait_timeout_seconds(),
        )
        self._batch_initialized = True

    def _provider_request_timeout_seconds(self) -> float:
        """Upper bound of one provider request for this transform's provider."""
        if isinstance(self._config, (OpenRouterConfig, GatewayConfig)):
            return float(self._config.timeout_seconds)
        if isinstance(self._config, AzureOpenAIConfig):
            return _AZURE_OPENAI_SDK_REQUEST_TIMEOUT_SECONDS
        if isinstance(self._config, BedrockConfig):
            return _BEDROCK_LITELLM_REQUEST_TIMEOUT_SECONDS
        raise RuntimeError(f"Unknown config type: {type(self._config).__name__}")

    def _effective_batch_wait_timeout_seconds(self) -> float:
        """Engine wait that the plugin's structured retry_timeout result always beats.

        After the retry deadline each query gets at most one further provider
        attempt (the one in flight, or the single attempt of a later
        sequential query), so the wait covers the budget plus one request per
        query plus headroom.
        """
        query_count = len(self._strategy.query_specs) if isinstance(self._strategy, MultiQueryStrategy) else 1
        return (
            float(self._max_capacity_retry_seconds) + query_count * self._provider_request_timeout_seconds() + _BATCH_WAIT_HEADROOM_SECONDS
        )

    def created_output_fields(self) -> tuple[FieldDefinition, ...]:
        """Every field this transform creates, typed by the code that writes it (ADR-050).

        The operational fields follow ``_SUFFIX_SCHEMA_TYPES`` (the response
        content and the served model are ``str``; the usage is a mapping the
        schema DSL has no scalar type for). Each structured ``output_fields``
        entry is BOUND to the row type of its ``OutputFieldConfig.type`` through
        ``_OUTPUT_FIELD_TYPE_TO_SCHEMA``, and the Tier-3 parse
        (``validation.parse_field_value``, reached through
        ``extract_structured_fields``) returns every nonnull value it admits in
        exactly that type (``integer`` admits an integral float as an int,
        ``number`` an int as a float), and admits None only when that field's
        explicit nullable flag declares it. A value the parse admits satisfies the
        declaration the engine enforces. The binding and the parse landed
        together and a test pins that they agree for every ``OutputFieldType``
        (operator ruling 2026-09-25: never one without the other).
        """
        return self._created_output_fields

    def on_start(self, ctx: LifecycleContext) -> None:
        """Capture recorder/telemetry and create provider instance."""
        if ctx.call_mode_session is None:
            if ctx.run_mode is not RunMode.LIVE:
                raise RuntimeError("LLM replay/verify requires a matching call-mode session")
        elif ctx.call_mode_session.mode is not ctx.run_mode:
            raise RuntimeError("LLM run mode and call-mode session disagree")
        if (
            ctx.run_mode in (RunMode.REPLAY, RunMode.VERIFY)
            and self._tracing_config is not None
            and self._tracing_config.provider != "none"
        ):
            raise RuntimeError("LLM tracing is not supported in replay or verify mode")
        super().on_start(ctx)
        self._recorder = ctx.landscape
        self._run_id = ctx.run_id
        self._telemetry_emit = ctx.telemetry_emit
        self._shutdown_event = ctx.shutdown_event
        self._payload_store = ctx.payload_store
        self._call_mode_session = ctx.call_mode_session
        limiter_name = (
            "azure_openai"
            if isinstance(self._config, AzureOpenAIConfig)
            else "bedrock"
            if isinstance(self._config, BedrockConfig)
            else "gateway"
            if isinstance(self._config, GatewayConfig)
            else "openrouter"
        )
        self._limiter = ctx.rate_limit_registry.get_limiter(limiter_name) if ctx.rate_limit_registry is not None else None

        # Create provider now that recorder/telemetry are available
        self._provider = self._create_provider(llm_call_governance=ctx.llm_call_governance)

        # Initialize Azure AI tracing (process-level OpenTelemetry auto-instrumentation).
        # Must happen after provider creation — the OpenAI SDK must be available.
        if isinstance(self._tracing_config, AzureAITracingConfig):
            _configure_azure_monitor(self._tracing_config)

    def runtime_preflight(self, ctx: LifecycleContext) -> None:
        """Fail fast if the configured LLM provider/model cannot be reached."""
        if self._provider is None:
            raise FrameworkBugError("LLMTransform runtime_preflight called before provider initialization")
        if ctx.operation_id is None:
            raise FrameworkBugError("LLMTransform runtime_preflight requires an operation audit parent")

        try:
            self._provider.runtime_preflight(
                operation_id=ctx.operation_id,
                model=self._model,
                temperature=self._temperature,
                coordination_token=ctx.require_coordination_token(),
            )
        except LLMClientError as exc:
            raise RuntimePreflightFailedError(
                plugin_name=self.name,
                provider=self._config.provider,
                cause=exc,
            ) from exc

    def _create_provider(self, *, llm_call_governance: LLMCallGovernance | None = None) -> LLMProvider:
        """Instantiate the provider with all required dependencies.

        Uses isinstance narrowing on self._config to safely access
        provider-specific attributes (endpoint, deployment_name, base_url, etc.).
        """
        if self._recorder is None:
            raise RuntimeError("_recorder not initialized — _create_provider called before on_start()")

        if isinstance(self._config, AzureOpenAIConfig):
            return AzureLLMProvider(
                pricing_model=self._config.pricing_model,
                endpoint=self._config.endpoint,
                api_key=self._config.api_key,
                api_version=self._config.api_version,
                deployment_name=self._config.deployment_name,
                recorder=self._recorder,
                run_id=self._run_id,
                telemetry_emit=self._telemetry_emit,
                limiter=self._limiter,
                approved_prompt_artifact_hash=self._approved_prompt_artifact_hash,
                llm_call_governance=llm_call_governance,
                call_mode_session=self._call_mode_session,
            )
        elif isinstance(self._config, OpenRouterConfig):
            return OpenRouterLLMProvider(
                pricing_model=self._config.pricing_model,
                api_key=self._config.api_key,
                base_url=self._config.base_url,
                timeout_seconds=self._config.timeout_seconds,
                recorder=self._recorder,
                run_id=self._run_id,
                telemetry_emit=self._telemetry_emit,
                limiter=self._limiter,
                approved_prompt_artifact_hash=self._approved_prompt_artifact_hash,
                llm_call_governance=llm_call_governance,
                call_mode_session=self._call_mode_session,
            )
        elif isinstance(self._config, BedrockConfig):
            return BedrockLLMProvider(
                pricing_model=self._config.pricing_model,
                region_name=self._config.region_name,
                credentials=self._config.credentials(),
                recorder=self._recorder,
                run_id=self._run_id,
                telemetry_emit=self._telemetry_emit,
                limiter=self._limiter,
                approved_prompt_artifact_hash=self._approved_prompt_artifact_hash,
                llm_call_governance=llm_call_governance,
                call_mode_session=self._call_mode_session,
            )
        elif isinstance(self._config, GatewayConfig):
            # GatewayConfig.api_key already carries the resolved bearer value
            # — the same convention AzureOpenAIConfig.api_key and
            # OpenRouterConfig.api_key use. Resolution from an operator
            # secret reference happens upstream of config construction (the
            # web path's ``resolve_secret_refs`` walk, or ``${VAR}``
            # expansion for batch/CLI YAML), never here. See Phase 2 Task 4's
            # report for why an earlier direct ``EnvSecretLoader`` lookup at
            # this call site was replaced with this shared path.
            return GatewayLLMProvider(
                pricing_model=self._config.pricing_model,
                endpoint=self._config.endpoint,
                api_key=self._config.api_key,
                contract_major=self._config.contract_major,
                required_capabilities=self._config.required_capabilities,
                timeout_seconds=self._config.timeout_seconds,
                recorder=self._recorder,
                run_id=self._run_id,
                telemetry_emit=self._telemetry_emit,
                limiter=self._limiter,
                approved_prompt_artifact_hash=self._approved_prompt_artifact_hash,
                llm_call_governance=llm_call_governance,
                call_mode_session=self._call_mode_session,
            )
        else:
            raise RuntimeError(f"Unknown config type: {type(self._config).__name__}")

    def accept(self, row: PipelineRow, ctx: TransformContext) -> None:
        """Accept a row for processing (pipeline entry point)."""
        if not self._batch_initialized:
            raise RuntimeError("connect_output() must be called before accept()")
        self.accept_row(row, ctx, self._process_row)

    def process(self, row: PipelineRow, ctx: TransformContext) -> TransformResult:
        """Not supported — use accept() for row-level pipelining."""
        raise NotImplementedError(
            f"{self.__class__.__name__} uses row-level pipelining. Use accept() instead of process(). See class docstring for usage."
        )

    def _process_row(self, row: PipelineRow, ctx: TransformContext) -> TransformResult:
        """Process a single row via the selected strategy.

        Called by worker threads from BatchTransformMixin. Delegates to
        SingleQueryStrategy or MultiQueryStrategy.
        """
        if self._provider is None:
            raise RuntimeError("Provider not initialized — _process_row called before on_start()")
        self._shutdown_event = ctx.shutdown_event

        blank_required_input = _blank_required_input_result(row, self.declared_input_fields, self._allow_blank_input_fields)
        if blank_required_input is not None:
            return blank_required_input

        for row_field in row.contract.fields:
            if row_field.normalized_name in self._strict_generated_fields or row_field.original_name in self._strict_generated_fields:
                return TransformResult.error({"reason": "field_collision", "field": row_field.normalized_name}, retryable=False)

        for check in self._input_checks:
            failure = check.failure_for(row, phase="input")
            if failure is not None:
                return TransformResult.error(failure, retryable=False)

        result = self._strategy.execute(
            row,
            ctx,
            provider=self._provider,
            tracer=self._tracer,
            payload_store=self._payload_store,
        )
        if result.status == "error" or not self._result_checks:
            return result
        if result.row is None or result.rows is not None:
            raise FrameworkBugError("LLM result checks require a single successful output row")
        for check in self._result_checks:
            failure = check.failure_for(result.row)
            if failure is not None:
                return TransformResult.error(failure, retryable=False, context_after=result.context_after)
        return result

    def _verify_intermediate_output(self, prior: PipelineRow, candidate: PipelineRow) -> None:
        """Reuse ADR-050 value semantics before any dependent query is rendered."""
        from elspeth.contracts.plugin_protocols import TransformProtocol
        from elspeth.engine.executors.declared_output_types import verify_produced_output_types

        verify_produced_output_types(transform=cast(TransformProtocol, self), input_row=prior, emitted_rows=(candidate,))

    def close(self) -> None:
        """Release resources."""
        self._tracer.flush()
        shutdown_requested = _shutdown_event_is_set(self._shutdown_event)

        if shutdown_requested and self._provider is not None:
            self._provider.close()
            self._provider = None

        if self._query_executor is not None:
            self._query_executor.shutdown(wait=not shutdown_requested)

        if self._batch_initialized:
            self.shutdown_batch_processing(wait_for_workers=not shutdown_requested)

        if self._provider is not None:
            self._provider.close()
            self._provider = None

        self._recorder = None
        self._shutdown_event = None

    @classmethod
    def get_agent_assistance(cls, *, issue_code: str | None = None) -> PluginAssistance | None:
        if issue_code is None:
            return PluginAssistance(
                plugin_name="llm",
                issue_code=None,
                summary="Call an LLM provider (Azure OpenAI, OpenRouter, or AWS Bedrock) on each row and write the response into a field. Tracks model identity, token usage, and finish reason in the audit trail.",
                examples=(
                    PluginAssistanceExample(
                        title="Separate colour inputs from generated answers",
                        before={"required_input_fields": ["colour", "good_colour_pair_answer", "approximate_hex_answer"]},
                        after={
                            "schema": {"mode": "flexible", "fields": ["colour: str"]},
                            "required_input_fields": ["colour"],
                            "queries": {
                                "good_colour_pair": {
                                    "input_fields": {"shade": "colour"},
                                    "template": "Name a colour paired with {{ row.shade }} as answer.",
                                    "response_format": "structured",
                                    "output_fields": [{"suffix": "answer", "type": "string"}],
                                },
                                "approximate_hex": {
                                    "input_fields": {"shade": "colour"},
                                    "template": "Give an approximate hex code for {{ row.shade }} as answer.",
                                    "response_format": "structured",
                                    "output_fields": [{"suffix": "answer", "type": "string"}],
                                },
                            },
                        },
                    ),
                    PluginAssistanceExample(
                        # A minimal before/after option diff (the established example
                        # shape) showing the one load-bearing lesson: interpolate the
                        # per-row content, not just an identifier. A summarization task
                        # (not scoring) so the example carries no authored-judgment
                        # semantics that would oblige a vague_term review per the hints
                        # below. Illustrative placeholders only — no real URLs or data.
                        title="Interpolate the per-row content, not just an identifier",
                        # WRONG: summarizes each row from an identifier alone, so every
                        # row sends identical input and the model fabricates a summary
                        # instead of reading anything.
                        before={
                            "prompt_template": "Summarize the page at {{ row.url }} in one sentence.",
                            "response_field": "summary",
                            "required_input_fields": ["url"],
                        },
                        # RIGHT: interpolates the per-row content, so the model reads each
                        # row and the summaries differ. required_input_fields must declare
                        # every row field the template references, or the LLM config
                        # validator rejects the node.
                        after={
                            "prompt_template": "Summarize this page in one sentence, based on its content: {{ row.content }}.",
                            "response_field": "summary",
                            "required_input_fields": ["content"],
                        },
                    ),
                    PluginAssistanceExample(
                        # Structured multi-query discovery: several typed queries per
                        # row, each with named input_fields and typed output_fields.
                        # Output columns are "{query_name}_{suffix}" plus the
                        # automatic per-query usage/model fields; do not hand-add them.
                        title="Ask several typed structured queries per row with the queries map",
                        # WRONG: a single free-text response gives no typed columns
                        # downstream transforms can consume by name.
                        before={
                            "prompt_template": "Assess this content: {{ row.content }}.",
                            "response_field": "llm_response",
                            "required_input_fields": ["content"],
                        },
                        # RIGHT: queries is a mapping keyed by query name (the value
                        # omits name); each query binds template variables to row
                        # columns via input_fields and declares typed output_fields
                        # (suffix + type; enum types also carry values). The list form
                        # is equivalent — an array whose entries each carry a name.
                        after={
                            "prompt_template": "Assess this content: {{ row.content }}.",
                            "response_field": "llm_response",
                            "required_input_fields": ["content"],
                            "queries": {
                                "clarity": {
                                    "input_fields": {"content": "content"},
                                    "response_format": "structured",
                                    "output_fields": [
                                        {"suffix": "score", "type": "integer"},
                                        {"suffix": "band", "type": "enum", "values": ["low", "medium", "high"]},
                                        {"suffix": "rationale", "type": "string"},
                                    ],
                                },
                            },
                        },
                    ),
                ),
                composer_hints=(
                    "Call list_models before pinning 'model:' — deployments don't all ship the same providers.",
                    "Interpolate every row field your prompt needs with `{{ row.<field> }}`. A template naming no varying field sends identical input to every row and identical output; to score, classify, or summarize content, inject the content field (e.g. `{{ row.content }}`), not an identifier.",
                    "Never ask the model to judge a page or record from its URL or identifier alone — with no content interpolated it fabricates a plausible answer instead of reading anything. When the judgement needs fetched text, interpolate the fetch/scrape field into the prompt_template.",
                    "Identical answers across rows are only wrong when the inputs genuinely differ. A discriminating prompt injects the per-row data; do not pad prompts for artificial variety. The defect to avoid is one that CANNOT discriminate because it never interpolated the per-row field.",
                    "The backend automatically stages and surfaces llm_prompt_template reviews; do not author or request that review. Keep the authored prompt exact for user review.",
                    "When you author LLM judgment semantics — a scoring scale, rubric, category meaning, threshold, signal weighting, cutoff, comparison set, or subjective criterion definition — stage a vague_term review on the LLM node before set_pipeline.",
                    "Measurable adjectives are not exempt: if the user gives the metric/cutoff, use it; if you choose a cutoff such as 'over 6 ft' or a ranking rule such as 'top quartile', review that authored threshold semantics.",
                    "Prompt-template review is not enough for authored judgment semantics: put the vague_term requirement in interpretation_requirements before set_pipeline for the rubric, definition, threshold, or category semantics; the backend owns the raw-prompt review.",
                    "Use a stable user_term preserving the user's criterion phrase, not the whole task phrase; for an adjective embedded in prose, use the adjective or noun phrase that names the criterion.",
                    "llm_draft must equal the semantics you wrote; only an llm_prompt_template review is incomplete.",
                    "When repairing or upserting an LLM node, repeat the review preflight; carry forward existing pending LLM interpretation requirements and add missing vague_term or prompt shield requirements before stopping.",
                    "Do not stop by saying the rubric is part of the reviewed prompt. If you wrote the scale, label meanings, thresholds, cutoff, comparison rule, tie break, or signals, add the separate vague_term requirement and request its review.",
                    "If the prompt asks the model to return a score, rating, rank, class, or pass/fail result, that output shape is authored judgement semantics when you chose the scale, class meaning, threshold, or ranking rule.",
                    "Objective extraction such as identifying primary colours used does not by itself need a vague_term review unless you add subjective scoring, ranking, thresholds, or category semantics.",
                    "For how <adjective> phrasing, use the adjective itself as user_term unless the user supplied a more specific criterion phrase; do not use the whole how-phrase.",
                    "Token-usage and model-ID fields are appended automatically as <response_field>_usage / _model — don't hand-add them.",
                    "required_input_fields names upstream columns and bounds template visibility (ADR-051). Never require this node's generated fields as upstream inputs. options.schema.fields may declare output types (ADR-050); it does not extract fields from the reply.",
                    "Declared inputs reject empty/whitespace strings before provider dispatch by default. For a prompt that must classify unavailable text, set allow_blank_input_fields to only the relevant required_input_fields.",
                    "allow_blank_input_fields preserves the original string, declared visibility, field presence and types; non-nullable nulls and other blank fields still fail. It does not generate an unavailable result or waive input/result checks.",
                    "The plugin derives generated outputs from response_field and output_fields; pass-through guarantees come from upstream.",
                    "Optional input_checks are named strict-Boolean expressions on the entry row, before any per-row model request. False/non-Boolean/evaluation errors route a nonretryable failure via on_error without widening prompt visibility.",
                    "input_checks do not replace operation startup preflight. Keep detailed admission causes in the incoming row for error-sink row_json retention.",
                    "Multi-query input_fields maps variables to upstream columns by default. Explicit query_input_mode=ordered needs list-form named queries and pool_size=1; exact bindings may name earlier validated generated fields, never self/forward.",
                    "Per-query output_fields default to <queryname>_<suffix>.",
                    "Per-query structured_output_prefix: null/omitted retains the query-name stem; empty string emits bare suffixes; a nonempty ASCII identifier (at most 64 characters) emits <stem>_<suffix>.",
                    "structured_output_prefix leaves JSON response keys and raw/usage/model names unchanged. Any non-null override requires unique final generated names across every query; ordered mode always rejects collisions.",
                    "A separate semantic reviewer query must bind the actual earlier generated fields and relevant original evidence explicitly. A Boolean verdict plus result_checks can reject before downstream release.",
                    "Separate model calls are not a certification of semantic correctness; both prompts and authored judgment semantics still need ordinary review.",
                    "Ordered mode preserves original-only source_row/images and atomic final output. Later failure routes the original entry row; prior calls/charges remain. Node-level restart may repeat calls; no durable mid-node resume or exactly-once guarantee.",
                    "Optional chain compaction is an operator choice. Inspect all consumers, exact output names/types, rendered prompts, effective provider/profile/settings, intermediate shields/gates/mappers/branches and failure policies.",
                    "For optional chain compaction, independent entry-row queries can qualify; dependent queries require ordered mode. Never promise fewer calls/tokens. Disclose changed quarantine/audit/checkpoint boundaries.",
                    "Before optional chain compaction, obtain the operator's choice before ordinary provider-authored node/edge mutations; decline changes nothing. Preserve interpretation tokens and prompt/semantics review.",
                    "For the colour example, require colour on the LLM and good_colour_pair_answer / approximate_hex_answer downstream.",
                    "Single-query LLM output is written to response_field as raw text. Prompt wording alone does not create separate JSON fields; preserve response_field through cleanup when no output_fields are configured.",
                    "Configure single-query output_fields to parse JSON into typed, unprefixed row fields within the LLM transform; no downstream parser is needed. The raw response_field and automatic usage/model fields remain available.",
                    "Each output_fields type is the row type downstream nodes receive: integer -> int (5.0 arrives as 5; 5.5 fails the row), number -> float (7 arrives as 7.0), boolean -> bool, string and enum -> str.",
                    "An authored node schema output type must admit the bound model type; number cannot narrow to int. If you declare <response_field>_usage, type it any.",
                    "Keep downstream requirements for every field the consumer uses. Do not erase them or widen to any/flexible to silence a contradictory plugin output contract; report that contradiction.",
                    "Read declared template fields by carried name; use get, row | list for names, row | items for pairs, and dict(row) or row | tojson for the whole row. Read a method-named column with row['keys']. Source header aliases resolve only when that header reaches the node.",
                    "The LLM transform preserves upstream row fields while adding response_field; it does not remove raw scrape fields. If a web_scrape-to-LLM workflow must save results without raw HTML or fingerprints, put a field_mapper cleanup node between the LLM and the sink.",
                    "The prompt-injection shield advisory covers LLM nodes consuming externally-fetched remote content (a web_scrape-family producer upstream) without an authorized shield between them; it is always advisory (never blocking).",
                    "Recommend an available authorized prompt-injection shield before the LLM; use azure_prompt_shield only when discovery lists it.",
                    "Use the deployment's equivalent when available; recommendation is not permission to add a node, so do not insert it automatically unless requested, policy-required, or explicitly high-risk.",
                    "Stage a pipeline_decision review on the LLM node with user_term prompt_injection_shield_recommendation whenever no authorized shield is upstream (State B/C). Skip it only when an authorized shield is already wired upstream (State A).",
                    "Pick the state-appropriate draft: State B (an authorized shield is available in this deployment) recommends wiring it in; State C (no shield available) is the high-risk reconsider advisory. Default to the State-C draft when availability is unknown.",
                    "LLM-node reviews stack: an authored web-content scoring prompt can need llm_prompt_template, vague_term, and prompt_injection_shield_recommendation requirements on the same LLM node.",
                    "Interpretation reviews are not transform stages. Do not create passthrough, review, recommendation, or placeholder nodes for LLM reviews; put caller-owned review objects in this LLM node's interpretation_requirements list.",
                    "For prompt-injection shielding recommendations, do not add passthrough, placeholder, no-op, or renamed utility nodes to imply protection; recommendation prose is not a graph step.",
                    "This is prompt-injection defense; do not substitute azure_content_safety. Use azure_content_safety only for harmful-content moderation or safety classification.",
                    "Concurrency is pool_size (1 = sequential, no pooling). Tune dispatch pacing with min_dispatch_delay_ms / max_dispatch_delay_ms and bound capacity retries with max_capacity_retry_seconds; there is no max_concurrency or per_minute_rate_limit field.",
                ),
            )
        return None

    # ``@classmethod`` must stay OUTERMOST: ``trust_boundary`` reads the wrapped
    # function's signature to resolve ``source_param``.
    @classmethod
    @trust_boundary(
        tier=3,
        source="composer node options snapshot as the planner authored it (post-call hint input)",
        source_param="config_snapshot",
        suppresses=("R1", "R5"),
        invariant=(
            "returns advisory hint strings only; every member of config_snapshot is read by presence and "
            "shape-checked before use, an absent or wrong-shaped member yields no hint, and nothing is raised, "
            "coerced, or defaulted on malformed input"
        ),
        non_raising=True,
    )
    def get_post_call_hints(
        cls,
        *,
        tool_name: str,
        config_snapshot: Mapping[str, object],
    ) -> tuple[str, ...]:
        # Manual _usage / _model field declared by hand → tell them it's automatic.
        if "response_field" not in config_snapshot:
            return ()
        response_field = config_snapshot["response_field"]
        if type(response_field) is not str:
            return ()
        manual_appendix = {f"{response_field}_usage", f"{response_field}_model"}
        # The first schema alias that carries a `fields` member is the one the
        # author wrote; every read stays inside this loop body so the snapshot
        # is parsed where it is still the boundary's own input.
        for schema_key, fields_location in (("schema", "schema.fields"), ("output_schema", "output_schema.fields")):
            if schema_key not in config_snapshot:
                continue
            schema_snapshot = config_snapshot[schema_key]
            if not isinstance(schema_snapshot, Mapping) or "fields" not in schema_snapshot:
                continue
            fields = schema_snapshot["fields"]
            if isinstance(fields, Sequence) and not isinstance(fields, (str, bytes)):
                declared = {field.split(":", 1)[0].strip() if isinstance(field, str) else "" for field in fields}
                if manual_appendix & declared:
                    return (
                        f"You declared {sorted(manual_appendix & declared)!r} in the schema, but token-usage and model-ID fields are appended automatically. Remove them from {fields_location}.",
                    )
            return ()
        return ()


# Register opt-in for value-source compliance: the typed Pydantic config
# (OpenRouterConfig | AzureOpenAIConfig | BedrockConfig) is exposed via the public
# ``provider_config`` property. The walker (engine/orchestrator/preflight.py)
# uses this registration to find the typed config without resorting to
# duck-typing or getattr.
register_value_source_plugin(LLMTransform, config_attr="provider_config")
