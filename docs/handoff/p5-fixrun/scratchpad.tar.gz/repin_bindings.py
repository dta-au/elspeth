"""Check / re-pin a module-bindings entry in reviewed-writer-recipes.json.

usage: repin_bindings.py ROOT SRC_REL_PATH [--write] [--source-ref REF]
"""
import ast, json, subprocess, sys
from pathlib import Path
from elspeth_lints.core.ast_dump import stable_ast_dump

root = Path(sys.argv[1]); rel = sys.argv[2]; write = "--write" in sys.argv
ref = sys.argv[sys.argv.index("--source-ref") + 1] if "--source-ref" in sys.argv else None
src = subprocess.check_output(["git", "-C", str(root), "show", f"{ref}:{rel}"], text=True) if ref else (root / rel).read_text()
tree = ast.parse(src)
node = ast.Module(body=[n for n in tree.body if not isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))], type_ignores=[])
dump = stable_ast_dump(node)
pin = root / "tests/helpers/required_work_reserve_recipes/reviewed-writer-recipes.json"
text = pin.read_text()
data = json.loads(text)
key = rel + ":module-bindings"
print("matches:", data[key] == dump)
if write and data[key] != dump:
    old_line = "  " + json.dumps(key) + ": " + json.dumps(data[key])
    assert text.count(old_line) == 1, "serialization differs"
    new_line = "  " + json.dumps(key) + ": " + json.dumps(dump)
    pin.write_text(text.replace(old_line, new_line))
    data2 = json.loads(pin.read_text())
    assert data2[key] == dump and {k: v for k, v in data2.items() if k != key} == {k: v for k, v in data.items() if k != key}
    print("re-pinned one line")
