import sys, tempfile
from pathlib import Path
from elspeth.contracts.plugin_context import PluginContext
from elspeth.plugins.sources.json_source import JSONSource
from tests.fixtures.landscape import make_recorder_with_run
d = Path(tempfile.mkdtemp(dir=sys.argv[1]))
for name, content, extra in [("a.json", '{"wrong_key": [1]}', {"data_key":"results"}), ("b.json", '{"x": 1}', {}), ("c.json", '[{"id": 1}, 5]', {})]:
    setup = make_recorder_with_run(source_plugin_name="json")
    ctx = PluginContext(run_id=setup.run_id, coordination_token=setup.coordination_token, node_id=setup.source_node_id, config={}, landscape=setup.factory.plugin_audit_writer())
    p = d/name; p.write_text(content)
    src = JSONSource({"path": str(p), "format": "json", **extra, "on_validation_failure": "quarantine", "schema": {"mode": "observed"}})
    for r in src.load(ctx):
        if r.is_quarantined:
            print(name, "error_id linked:", ctx.pop_pending_quarantine_validation_error_id(r.row))
