import typing
from elspeth.plugins.infrastructure.manager import get_shared_plugin_manager
from elspeth.plugins.infrastructure.base import is_column_naming_config_option
import elspeth.plugins.infrastructure.base as b
print("base file", b.__file__)
pm = get_shared_plugin_manager()
n=0
for cls in pm.get_transforms():
    model = cls.get_config_model()
    if model is None: continue
    n+=1
    for fname, f in model.model_fields.items():
        if not is_column_naming_config_option(fname): continue
        if fname in cls.output_naming_config_keys: continue
        ann = str(f.annotation)
        if any(t in ann for t in ("dict", "Mapping", "set", "frozenset")) or not any(t in ann for t in ("str","list","tuple")):
            print(cls.name, fname, ann)
print("transforms with config:", n)
