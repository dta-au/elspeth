def main():
    from elspeth.plugins.transforms.llm.transform import LLMTransform
    for prov in (["azure"], {"a": 1}):
        try:
            LLMTransform({"provider": prov, "model": "m", "prompt_template": "x", "schema": {"mode": "observed"}, "required_input_fields": []})
        except Exception as e:
            print(type(prov).__name__, "->", type(e).__name__, str(e)[:120])
if __name__ == "__main__":
    main()
