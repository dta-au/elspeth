import socket
from unittest.mock import patch
import httpx, respx
from tests.unit.plugins.transforms.test_web_scrape_pagination import _transform, _Recorder, _PayloadStore, _LimiterRegistry, _dns, _IP
from elspeth.contracts.plugin_context import PluginContext
from elspeth.testing import make_pipeline_row
from tests.fixtures.mock_audit import mock_item_audit_authority

ctx = PluginContext(run_id="run-123", **mock_item_audit_authority("run-123"), config={}, landscape=_Recorder(),
                    payload_store=_PayloadStore(), rate_limit_registry=_LimiterRegistry(), state_id="state-123")
with respx.mock:
    route = respx.get(url__regex=rf"https://{_IP}(:443)?/page-1.*").mock(
        return_value=httpx.Response(200, headers={"content-type": "text/html"},
                                    text='<p>first</p><a class="next" href="/page-1?sort=a:b">Next</a>'))
    t = _transform("next_link_css")
    t.on_start(ctx)
    with patch("socket.getaddrinfo", _dns):
        r = t.process(make_pipeline_row({"url": "https://example.com/page-1?sort=a:b"}), ctx)
print(r.status, route.call_count)
print(repr(r.row["content"]) if r.status=="success" else r.reason)
if r.status == "success":
    print(r.success_reason["metadata"]["pagination_stop_reason"], len(r.success_reason["metadata"]["pagination_pages"]))
