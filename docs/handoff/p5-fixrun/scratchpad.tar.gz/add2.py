p="tests/unit/plugins/transforms/test_truncate.py"
s=open(p).read()
def rep(a,b):
    global s
    assert s.count(a)==1,a
    s=s.replace(a,b)
rep('''    def test_defaults_strict_false(self) -> None:
        cfg = TruncateConfig(fields={"title": 10}, schema_config=OBSERVED_SCHEMA_CONFIG)
        assert cfg.strict is False
''','''    @pytest.mark.parametrize("strict", [True, False])
    def test_strict_is_not_an_option(self, strict: bool) -> None:
        """#146: a configured field is required, like every sibling's; there is no skip-if-missing mode."""
        with pytest.raises(PluginConfigError, match="strict"):
            Truncate({"fields": {"title": 10}, "strict": strict, "schema": DYNAMIC_SCHEMA})

    def test_configured_fields_are_declared_string_inputs(self) -> None:
        """#146: truncate requires strings and declares it exactly as keyword_filter and the guardrails do."""
        transform = Truncate({"fields": {"title": 10, "desc": 100}, "schema": DYNAMIC_SCHEMA})
        assert transform.declared_string_input_fields == frozenset({"title", "desc"})
''')
rep('''    def test_non_strict_skips_missing_fields(self, ctx: PluginContext) -> None:
        transform = Truncate({"fields": {"title": 5, "missing": 10}, "strict": False, "schema": DYNAMIC_SCHEMA})
        row = make_pipeline_row({"title": "Hello World"})
        result = transform.process(row, ctx)
        assert result.status == "success"
        assert result.row is not None
        assert result.row["title"] == "Hello"
''','''    def test_missing_configured_field_fails_the_row(self, ctx: PluginContext) -> None:
        """#146: a configured field the row does not carry fails the row; it is never silently skipped."""
        transform = Truncate({"fields": {"title": 5, "missing": 10}, "schema": DYNAMIC_SCHEMA})
        row = make_pipeline_row({"title": "Hello World"})
        result = transform.process(row, ctx)
        assert result.status == "error"
        assert result.reason is not None
        assert result.reason["reason"] == "missing_field"
        assert result.reason["field"] == "missing"
''')
rep('''    def test_success_reason_uses_normalized_field_name_for_original_header_config(
        self,
        ctx: PluginContext,
    ) -> None:
        transform = Truncate({"fields": {"Value Text": 5}, "schema": DYNAMIC_SCHEMA})

        result = transform.process(_make_alias_mapped_row(), ctx)

        assert result.status == "success"
        assert result.success_reason is not None
        assert result.success_reason["fields_modified"] == ["value"]
''','''    def test_header_spelled_field_is_a_declared_read_not_a_lookup(self) -> None:
        """#146: ``fields`` keys are declared reads, so the standard field-name spelling rule governs them.

        The build (``validate_declared_field_spellings``), the Web Composer
        mirror and the per-row preflight all read ``declared_read_fields``;
        the end-to-end refusal is pinned in
        tests/integration/pipeline/test_field_name_spelling_rule.py.
        """
        from elspeth.contracts.field_spelling import DeclaredSpellings

        transform = Truncate({"fields": {"Value Text": 5}, "schema": DYNAMIC_SCHEMA})
        row = _make_alias_mapped_row()

        spellings = DeclaredSpellings.of(reads=transform.declared_read_fields, creates=()).in_row(
            row_keys=frozenset(row.to_dict()),
            forwarded_keys=frozenset(),
            contract=row.contract,
        )
        assert spellings, "a header-spelled truncate field must be refused by the spelling rule"

    def test_header_spelled_field_is_not_resolved_through_the_contract(self, ctx: PluginContext) -> None:
        """#146: process() reads the configured name as rows carry it; it never rewrites a header alias."""
        transform = Truncate({"fields": {"Value Text": 5}, "schema": DYNAMIC_SCHEMA})

        result = transform.process(_make_alias_mapped_row(), ctx)

        assert result.status == "error"
        assert result.reason is not None
        assert result.reason["reason"] == "missing_field"
''')
open(p,"w").write(s)
