import json, sys
from pathlib import Path
from elspeth.plugins.infrastructure.manager import get_shared_plugin_manager
from elspeth.web.catalog.service import CatalogServiceImpl
d = Path("tests/golden/web/catalog/knob_schema")
svc = CatalogServiceImpl(get_shared_plugin_manager())
for kind, name in sorted(svc._schema_cache):
    if name not in sys.argv[1:]:
        continue
    info = svc._schema_cache[(kind, name)]
    p = d / f"{kind}__{name}.json"
    p.write_text(json.dumps({"plugin_kind": kind, "plugin_name": name, "knob_schema": info.knob_schema}, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print("wrote", p)
