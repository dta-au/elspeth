from elspeth.plugins.infrastructure.manager import get_shared_plugin_manager
pm = get_shared_plugin_manager()
def make(name, cfg):
    cls = pm.get_transform_by_name(name)
    try:
        t = cls(cfg)
        print(name, "CONSTRUCTED; consumed_input_fields=", sorted(t.consumed_input_fields), "declared_read_fields=", sorted(t.declared_read_fields))
        return t
    except Exception as e:
        print(name, "RAISED", type(e).__name__, str(e)[:200])
fixed = {"mode": "fixed", "fields": ["id: int"]}
# positive control: str-valued column option missing from fixed schema
make("keyword_filter", {"schema": fixed, "fields": ["notes"], "blocked_patterns": ["x"]})
make("truncate", {"schema": fixed, "fields": {"notes": 5}})
t = make("truncate", {"schema": {"mode":"fixed","fields":["id: int"]}, "fields": {"notes": 5}})
if t is not None:
    try:
        t.input_schema.model_validate({"id": 1, "notes": "hello world"}, strict=True)
        print("row with notes ACCEPTED")
    except Exception as e:
        print("row with notes REJECTED:", type(e).__name__, str(e).splitlines()[0])
