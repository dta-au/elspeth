import codecs, io
def dec(exc):
    if isinstance(exc, UnicodeDecodeError):
        bad = exc.object[exc.start:exc.end]
        return "".join(chr(0xDC00 + b) for b in bad), exc.end
    raise exc
def enc(exc):
    if isinstance(exc, UnicodeEncodeError):
        s = exc.object[exc.start:exc.end]
        if all(0xDC00 <= ord(c) <= 0xDCFF for c in s):
            return bytes(ord(c) - 0xDC00 for c in s), exc.end
    raise exc
codecs.register_error("x.dec", dec); codecs.register_error("x.enc", enc)
for enc_name, data in [
  ("utf-16-le", "a\nb\n".encode("utf-16-le")+b"\x00\xd8"+"c\nd\ne\n".encode("utf-16-le")),
  ("utf-16-le", "a\nb\n".encode("utf-16-le")+b"\x00\xdc"+"c\nd\ne\n".encode("utf-16-le")),
  ("utf-16", "a\nb\n".encode("utf-16")+b"\x00\xdc"+"c\nd\n".encode("utf-16-le")),
  ("utf-16-le", "a\nb\n".encode("utf-16-le")+b"\x41"),
  ("utf-32-le", "a\n".encode("utf-32-le")+b"\x00\x00\x11\x00"+"c\nd\n".encode("utf-32-le")),
  ("utf-8", b"a\n\xff\x41\nb\n"),
  ("utf-8-sig", b"\xef\xbb\xbfa\n\xff\nb\n"),
]:
    f = io.TextIOWrapper(io.BytesIO(data), encoding=enc_name, errors="x.dec", newline="")
    lines = list(f)
    print(enc_name, lines)
    for l in lines:
        if any(0xDC00<=ord(c)<=0xDCFF for c in l):
            for e2 in (enc_name,):
                try: print("  enc", l.encode(e2, errors="x.enc").hex())
                except Exception as ex: print("  encfail", type(ex).__name__, ex)
