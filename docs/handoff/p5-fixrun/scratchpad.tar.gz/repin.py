"""Re-pin a plugin's source_file_hash class attribute (run from worktree root)."""
import re, sys
from pathlib import Path
sys.path.insert(0, ".")
from scripts.cicd.plugin_hash import compute_source_file_hash as h
for f in sys.argv[1:]:
    p = Path(f)
    for _ in range(3):  # the hash line self-normalises; iterate to a fixed point
        new = h(p)
        s = p.read_text()
        old = re.search(r'source_file_hash: str \| None = "(sha256:[0-9a-f]+)"', s).group(1)
        if old == new:
            break
        p.write_text(s.replace(f'"{old}"', f'"{new}"', 1))
        print(f, old, "->", new)
    assert h(p) == re.search(r'source_file_hash: str \| None = "(sha256:[0-9a-f]+)"', p.read_text()).group(1)
    print(f, "pinned", h(p))
