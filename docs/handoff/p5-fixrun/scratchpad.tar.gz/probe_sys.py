import sys
from unittest.mock import Mock
def main():
    sys.path.insert(0, "tests/unit/plugins/llm")
    import test_transform as tt
    from elspeth.plugins.transforms.llm.transform import LLMTransform
    from elspeth.plugins.transforms.llm.langfuse import LangfuseTracer
    from elspeth.plugins.transforms.llm.provider import LLMProvider, LLMQueryResult, FinishReason
    from elspeth.contracts.token_usage import TokenUsage
    cfg = tt._make_config(prompt_template="Evaluate: {{ row.text }}", system_prompt="")
    t = LLMTransform(cfg)
    p = Mock(spec=LLMProvider)
    p.execute_query.return_value = LLMQueryResult(content="x", usage=TokenUsage.known(1,1), model="m", finish_reason=FinishReason.STOP)
    tr = Mock(spec=LangfuseTracer)
    t._provider = p; t._tracer = tr
    r = t._process_row(tt._make_row(), tt._make_ctx())
    print("status", r.status)
    print("sent", p.execute_query.call_args.args[0])
    print("traced system_prompt", repr(tr.record_success.call_args.kwargs["system_prompt"]))
    
if __name__ == '__main__':
    main()
def main2():
    import sys
    from unittest.mock import Mock
    sys.path.insert(0, "tests/unit/plugins/llm")
    import test_transform as tt
    from elspeth.plugins.transforms.llm.transform import LLMTransform
    from elspeth.plugins.transforms.llm.provider import LLMProvider, LLMQueryResult, FinishReason
    from elspeth.contracts.token_usage import TokenUsage
    for extra in ({}, {"queries": {"q1": {"input_fields": {"t": "text"}}}}):
        cfg = tt._make_config(prompt_template="Evaluate: {{ row.text }}" if not extra else "Evaluate: {{ row.t }}", model="configured-model", **extra)
        t = LLMTransform(cfg)
        p = Mock(spec=LLMProvider)
        p.execute_query.return_value = LLMQueryResult(content="x", usage=TokenUsage.known(1,1), model="served-model", finish_reason=FinishReason.STOP)
        t._provider = p
        r = t._process_row(tt._make_row(), tt._make_ctx())
        print(r.status, "row keys added:", sorted(set(r.row.to_dict()) - set(tt._make_row().to_dict())))
        print("  fields_added:", r.success_reason["fields_added"], "metadata.model:", r.success_reason["metadata"]["model"])
if __name__ == "__main__":
    main2()
