PARTIAL: lane-07-p3-llm-providers fixed #62, #63, #97, #125, #128, #133 fully and #123's classification half (14 commits, HEAD 00397278); #123's call-row-status half (AuditedLLMClient records SUCCESS for "" before provider rejects) needs a maintainer recording/replay decision.

(Written by orchestrator from the lane's hand-back; the subagent's report.md write was refused.)

## Fixes
- #62 gateway: required 'usage' capability rejects malformed usage (non-retryable LLMClientError) unless prompt_tokens and completion_tokens both parse.
- #63 gateway readyz: non-str capability elements and non-int contract_major (True, 1.0) rejected with fixed-text LLMClientError; no raw TypeError escapes.
- #97 openrouter: NetworkError has fixed text "Network error: OpenRouter request failed", original on __cause__ (no URL in audit/Langfuse).
- #125 bedrock runtime_preflight checks content and finish_reason like Azure (empty -> ContentPolicyError; non-stop finish -> LLMClientError). NOTE: preflight still max_tokens=32; reasoning models may now fail readiness.
- #123 (half) azure empty completion classified: content_filter -> ContentPolicyError; length -> token-budget LLMClientError; tool_calls unchanged; other -> non-retryable LLMClientError. test_provider_azure whitespace test renamed/re-asserted.
- #128 OpenRouter/Gateway source config api_key repr=False (transform-side configs left: listed "for dedup only").
- #133 normalize_openrouter_base_url rejects query/fragment (COMPAT: such base_urls now refused at config). test_provider_openrouter redaction test moved secret to a path segment.

## Not landed
- #123 call-row status: would reverse test_audited_llm_client::test_empty_string_content_is_valid and collide with _replay_completion rules. Bedrock execute_query has the same empty->ContentPolicyError pattern (outside slice).

## Evidence (lane-reported)
- RED on git archive of 10d56017: 34 failed (all AssertionError), 9 controls passed; HEAD 43 passed.
- ruff/format/check_contracts/mypy(6 files) 0; trust_boundary lints 0; keyless trust-tier diff empty (no signature churn); masquerade 243 passed; fencing_inventory exit 0, no movement.
- tests/unit/architecture -n 2: 5 OOM worker kills, the 8 ids passed serially. integration/core/dag not completed (no source_file_hash files touched).
