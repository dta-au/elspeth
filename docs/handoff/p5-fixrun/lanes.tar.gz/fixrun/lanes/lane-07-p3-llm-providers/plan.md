# lane-07-p3-llm-providers — #62 [P3 (raised as P2), bug] Gateway 'usage' required capability accepts malformed usage payloads (fail-open gate); #63 [P3, bug] readyz validator lets a raw TypeError escape the Tier-3 boundary and accepts a bool or float contract_major; #97 [P3, security] OpenRouter puts the raw httpx RequestError text into NetworkError, the audit row and Langfuse; the sibling providers use a fixed message; #123 [P3 (raised as P2), bug] Azure provider fails empty or whitespace completions after AuditedLLMClient has recorded the call as SUCCESS, and labels budget exhaustion (finish_reason=length) as content_policy; #125 [P3, enhancement] Bedrock runtime_preflight accepts an empty or unusable completion as proof of readiness; #128 [P3, security] OpenRouter and Gateway LLM source configs print the plaintext api_key in repr/str (Azure and Bedrock siblings hide it); #133 [P3, bug] OpenRouter base_url validator admits a query string or fragment, producing a request URL with the API path inside the query/fragment

Ticket `p3-llm-providers` · run `p3` · branch `lane/p3-llm-providers` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

This lane fixes 7 findings; fix each one (one test commit + one fix commit PER finding).
Every finding names the files where the sweep located it; touch only what each fix needs.

FINDING #62 [P3 (raised as P2), bug] Gateway 'usage' required capability accepts malformed usage payloads (fail-open gate)

`src/elspeth/plugins/transforms/llm/providers/gateway.py`

gateway.py:481-493. The `required_capabilities` contains 'usage' check is only `if usage_required and raw_usage is None`. Any present-but-malformed usage then goes through `TokenUsage.from_dict`, which quietly turns non-Mapping input and non-int values into `TokenUsage.unknown()`. So a profile that declares usage mandatory still accepts a response with no usable token counts and records it as SUCCESS with all-None usage. That defeats the point of the 'usage' capability: the trust boundary should fail closed when the gateway breaks a capability it advertised. Expected: when usage_required is set, raise a non-retryable LLMClientError unless the usage dict yields at least prompt_tokens and completion_tokens as ints (or whatever the capability contract names). Verification: I called `_validate_gateway_success_response(..., usage_required=True)` with usage = `{}`, `'junk'`, `{'prompt_tokens':'10'}` and `5`. All four were ACCEPTED and returned all-None TokenUsage. Coverage: tests/unit/plugins/llm/test_provider_gateway.py::TestUsageHandling covers only `usage=None` (test_usage_required_but_absent_is_non_retryable). No test covers malformed usage while it is required.

**Verifier (CONFIRMED):** Repro scratch-F/r62.py calls providers/gateway.py::_validate_gateway_success_response(httpx.Response, usage_required=True) with usage {} / 'junk' / {'prompt_tokens':'10'} / 5. All four are ACCEPTED and return an all-None TokenUsage. Only usage=None is REJECTED (gateway.py:481-486). TokenUsage.from_dict (contracts/token_usage.py:189-221) quietly coerces non-Mapping or non-int input to unknown. docs/reference/configuration.md:1799 describes required_capabilities as 'checked at startup against what the gateway declares', so a per-response usage requirement is the code's own intent, and the gate fails open on malformed input. Severity lowered: the consequence is missing token accounting recorded as SUCCESS with no usage, and no row data or routing is wrong.

FINDING #63 [P3, bug] readyz validator lets a raw TypeError escape the Tier-3 boundary and accepts a bool or float contract_major

`src/elspeth/plugins/transforms/llm/providers/gateway.py`

gateway.py:404-411 and 374. (1) `missing = set(required_capabilities) - set(declared_capabilities)` checks that `capabilities` is a list but never checks its elements. A readyz body such as `capabilities: [{"x":1}]` raises `TypeError: unhashable type: 'dict'` out of a `@trust_boundary(tier=3)` function whose declared invariant is 'raises LLMClientError unless...'. LLMTransform.runtime_preflight (transform.py:1886-1898) wraps only LLMClientError in RuntimePreflightFailedError, so malformed external data crashes preflight as an untyped error instead of the typed preflight failure. (2) `payload.get("contract_major") != contract_major` accepts `true` (when configured as 1) and `1.0`, because Python treats True == 1 == 1.0. The same function excludes bool explicitly for `adapter_api_major` (lines 391-394) and leaves contract_major unchecked. Expected: require `type(x) is str` for every capability element and `type(contract_major) is int` (not bool), each failing with a fixed-text LLMClientError. Verification: I called _validate_readyz_payload directly. `capabilities=[{'x':1}]` raised TypeError. `contract_major=True` and `contract_major=1.0` both returned the adapter identity, meaning the document was accepted. No test in tests/unit/plugins/llm/test_provider_gateway.py covers non-str capability elements or a non-int contract_major.

FINDING #97 [P3, security] OpenRouter puts the raw httpx RequestError text into NetworkError, the audit row and Langfuse; the sibling providers use a fixed message

`src/elspeth/plugins/transforms/llm/providers/openrouter.py`

openrouter.py:464 raises `NetworkError(f"Network error: {e}")` from any httpx.RequestError. That text then spreads in three directions. (a) It goes into the logical LLM audit row as LLMCallError.message (`_record_logical_llm_error`, line 605). (b) The transform persists it as transform error text: transform.py:963 sets `"error": str(e)`. (c) It is sent externally to the Langfuse tracer (transform.py:399/759, `error_message=str(e)`). httpx/h11 transport errors can carry URLs and bytes the server sent, for example RemoteProtocolError messages that quote illegal header lines. The rest of the codebase treats this text as unsafe. AuditedHTTPClient sanitizes URL candidates before HTTP error text reaches the audit (`_sanitize_http_error_message`, http.py:86). AuditedLLMClient uses `_AUDIT_SAFE_PROVIDER_ERROR` with the explicit rationale that raw SDK error text must not leave the boundary (llm.py:827-842). The gateway provider (`_STATIC_GATEWAY_ERROR`, gateway.py:721-723) and the bedrock provider (`_redacted_bedrock_error`) also use static text. This file already redacts HTTP error bodies (`_summarize_http_error_body`) and documents 'never echoes body content'. The transport path is the one gap. Expected: a fixed message such as 'OpenRouter network request failed', with the original kept in __cause__. Verification: I grepped every NetworkError( construction under providers/ and clients/llm.py. openrouter.py:464 is the only one that interpolates the exception. The tests at tests/unit/plugins/llm/test_provider_openrouter.py:1014/1030 only match the 'Network error' prefix.

FINDING #123 [P3 (raised as P2), bug] Azure provider fails empty or whitespace completions after AuditedLLMClient has recorded the call as SUCCESS, and labels budget exhaustion (finish_reason=length) as content_policy

`src/elspeth/plugins/transforms/llm/providers/azure.py`

At azure.py:251-262, empty or whitespace-only content raises ContentPolicyError, except when finish_reason is tool_calls. Two problems. (1) Audit mismatch: AuditedLLMClient.chat_completion (clients/llm.py) only treats content=None (and non-str content) as an error. A str '' or '   ' goes through the normal path and is recorded as CallStatus.SUCCESS with SUCCESS telemetry (llm.py ~1200-1225). I found no strip or empty check in llm.py before that record. So the Landscape shows a successful call for a row the provider then fails, with no error payload on the call. The comment at azure.py:251 ('AuditedLLMClient converts None->""') is stale: None now raises inside the client, so this branch only handles real empty strings. (2) Misclassification: a reasoning deployment that spends its max_completion_tokens budget on reasoning returns content '' with finish_reason=length. azure.py:54-60 itself describes this case for preflight. That response is reported as ContentPolicyError (category content_policy). The sibling OpenRouter provider (openrouter.py:186-196) separates explicit refusal or content_filter (ContentPolicyError), length (LLMClientError 'exhausted the output token budget'), tool_calls, and unexplained empty content (LLMClientError), and states 'Missing content alone does not establish a content-policy refusal.' Expected: classify the empty case by finish_reason the way OpenRouter does, and record the call as ERROR (or reject empty content inside AuditedLLMClient before the SUCCESS record) so the call row and the row outcome agree. tests/unit/plugins/llm/test_provider_azure.py:727-760 pins the ContentPolicyError behaviour, but only through a FakeLLMClient, so nothing checks the recorded call status. bedrock.py:312 has the same empty-to-ContentPolicyError pattern; it is outside my slice.

**Verifier (CONFIRMED):** providers/azure.py:251-262: empty or whitespace content with any finish_reason other than tool_calls raises ContentPolicyError (category 'content_policy', clients/llm.py:140-147), including finish_reason=length. azure.py:54-60 describes exactly that reasoning-budget case. OpenRouter separates these cases (openrouter.py:186-196). AuditedLLMClient.chat_completion records an ERROR call row only for content None (llm.py:1053-1150) and non-str content (1158+). A str ''/'   ' reaches the CallStatus.SUCCESS record at llm.py:1209-1220. So the LLM call row says SUCCESS while the provider rejects the row. OpenRouter instead records a logical LLM call as ERROR via _record_logical_llm_error (openrouter.py:483-495). The comment 'AuditedLLMClient converts None->""' is stale. Mitigation found: the transform maps the error to {reason: llm_call_failed, error: 'LLM returned empty content (finish_reason=length)'} (transform.py:405-410). The row still routes to on_error and the real finish_reason is visible in the message, so the harm is mislabelled category and call-level audit inconsistency, not data loss. Lowered to P3.

FINDING #125 [P3, enhancement] Bedrock runtime_preflight accepts an empty or unusable completion as proof of readiness

`src/elspeth/plugins/transforms/llm/providers/bedrock.py`

bedrock.py:354-368: runtime_preflight calls client.chat_completion(...) and throws away the response. It raises only if the call itself raises an LLMClientError. It never checks the response content or finish_reason. Its siblings do check. azure.py:320-324 raises ContentPolicyError('Azure preflight returned empty content') and LLMClientError('Azure preflight returned an unusable finish reason'), and tests/unit/plugins/llm/test_provider_azure.py:191 pins the content_filter case. openrouter.py:637-646 sends its preflight through execute_query, which applies the empty-content and tool_calls checks. Bedrock's own execute_query (bedrock.py:306-312) applies those checks too, but its preflight does not. Effect: a Bedrock model that answers the smoke test with empty text passes readiness, then fails every row at run time with ContentPolicyError. Causes include a guardrail intervention (content_filter), a length or max_tokens stop at max_tokens=32, or a tool_calls-only reply. Expected: apply the same empty-content and finish-reason checks as Azure, or route the preflight through execute_query the way OpenRouter does. Keep the static redacted messages. Verified: read all three providers' runtime_preflight. rg 'preflight returned empty|unusable finish reason' over src and tests matches only azure.py and its test. The Bedrock preflight tests in tests/unit/plugins/llm/test_provider_bedrock.py (lines 65-99, 147-184, 653-664) cover VERIFY refusal, governance and error redaction only. None of them tests an empty or unusable preflight response.

FINDING #128 [P3, security] OpenRouter and Gateway LLM source configs print the plaintext api_key in repr/str (Azure and Bedrock siblings hide it)

`src/elspeth/plugins/sources/llm/config.py`

At config.py:223 (OpenRouterLLMSourceConfig.api_key) and config.py:312 (GatewayLLMSourceConfig.api_key), the field is declared without repr=False. The Azure sibling in the same file (line 196) and the Bedrock credential fields (lines 253-280) do set repr=False. As a result, any repr()/str() of a resolved OpenRouter or Gateway source config, for example in an exception message, debugger output, a log line or an f-string, contains the live bearer credential. Expected: every credential field on these configs uses repr=False, like Azure and Bedrock. Verification: ran the worktree code (elspeth.__file__ resolved inside the worktree), built both configs with from_dict and the sentinel keys 'SENTINEL-OR-KEY' and 'SENTINEL-GW-KEY', and both printed 'leaked: True' for `sentinel in repr(config)`. The only existing repr test is tests/unit/plugins/sources/llm/test_source.py:172 (test_azure_source_config_hides_key_repr), which covers Azure only, so this gap has no test. The same omission exists on the transform side (src/elspeth/plugins/transforms/llm/providers/openrouter.py:242 and providers/gateway.py:154). Those files are not owned by this slice, so they are mentioned here for dedup only. Fix: add repr=False to both fields and extend the repr test to every provider.

FINDING #133 [P3, bug] OpenRouter base_url validator admits a query string or fragment, producing a request URL with the API path inside the query/fragment

`src/elspeth/plugins/llm/config_validation.py`

normalize_openrouter_base_url (config_validation.py:241-265) keeps parsed.query and parsed.fragment, and validate_credential_safe_https_url (core/url_validation.py:30-52) does not reject either. At runtime AuditedHTTPClient._resolve_url (plugins/infrastructure/clients/http.py:400-406) builds f"{base}/{path}". For base_url 'https://openrouter.ai/api/v1#frag', httpx parses that URL as raw_path b'/api/v1' with fragment 'frag/chat/completions'. For '...?token=x' it parses as raw_path b'/api/v1?token=x/chat/completions'. In both cases the POST goes to /api/v1, not /api/v1/chat/completions, so every call fails mid-run after rows have been read. Because the normalized value no longer equals OPENROUTER_BASE_URL, the catalogue applies_when gate is also silently off for such a config. Sibling validate_gateway_endpoint (core/llm_provider_validation.py:56-59) rejects both ('endpoint must not contain a query string' / 'a fragment'). The web policy (web/provider_config_policy.py:177-184) fails closed here; the CLI/YAML path does not. Expected: reject query and fragment in the base_url validator, as the gateway validator does. Verification: validate_openrouter_base_url returned both URLs unchanged, and httpx.URL parsing of the joined URL showed the paths above. tests/unit/plugins/llm/test_provider_openrouter.py:1502 even constructs a provider with a '?token=' base_url (for a redaction test), which shows the shape is admitted.

## Files a correct fix must change

- `src/elspeth/plugins/transforms/llm/providers/gateway.py`

## Test files the lane must add or change

- `tests/unit/plugins/llm/test_llm_providers_p3_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/llm/test_llm_providers_p3_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-07-p3-llm-providers/report.md`; the worker returns one line.
