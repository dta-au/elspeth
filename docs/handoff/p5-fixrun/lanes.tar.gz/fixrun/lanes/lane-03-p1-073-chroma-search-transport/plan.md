# lane-03-p1-073-chroma-search-transport — #73 Chroma search() does not catch the SDK's real transport and HTTP failures, so failed calls go unrecorded and are not retried

Ticket `p1-073-chroma-search-transport` · run `p1` · branch `lane/p1-073-chroma-search-transport` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

FINDING #73 [P1] Chroma search() does not catch the SDK's real transport and HTTP failures, so failed calls go unrecorded and are not retried
File: src/elspeth/plugins/infrastructure/clients/retrieval/chroma.py
Sweep evidence: Location: chroma.py:276-322 (count) and 389-439 (query). These handlers catch only chromadb.errors.* plus ConnectionError, TimeoutError and OSError. The installed chromadb FastAPI client (.venv/.../chromadb/api/fastapi.py:119-133 and base_http_client.py:106-136) behaves as follows. It calls `self._session.request(...)` directly, so a refused connection or timeout surfaces as httpx.ConnectError or httpx.ReadTimeout. The MRO, checked in the venv, is ConnectError -> NetworkError -> TransportError -> RequestError -> HTTPError -> Exception, so neither is an OSError or ConnectionError. A non-Chroma HTTP error, such as a 502 HTML page from a proxy, raises a bare `Exception(resp.text)`. A non-JSON body raises orjson.JSONDecodeError, which is a ValueError. The sibling _live_readiness (line 790) already catches `ValueError` and `httpx.HTTPError`, with comments saying the SDK raises exactly these. In search(), these exceptions escape after allocate_call_index (line 263) and, in VERIFY, after admit_verify_call. As a result: (a) no record_call row is written for an external call that was attempted, an audit gap that leaves an allocated call index with no call; (b) the error is not a RetrievalError, so the RAG transform (rag/core.py:527) neither retries the transient failure nor routes it through TransformResult.error, and the row crashes. rg for 'httpx' in tests/unit/plugins/infrastructure/clients/retrieval/test_chroma.py finds nothing; the tests inject only builtin ConnectionError (lines 1227, 1289), which the real SDK does not raise for transport failures. Expected behaviour: classify httpx.HTTPError as retryable and record it via _record_error. Handle the SDK's bare Exception and ValueError paths explicitly, so every failure after allocate_call_index produces an ERROR call record.
Independent verifier (CONFIRMED): chroma.py:276-312 (count) and 389-428 (query) catch chromadb.errors.* plus (ConnectionError, TimeoutError, OSError) only. Installed chromadb 1.5.5: fastapi.py:119-133 _make_request calls self._session.request (httpx) directly, then BaseHTTPClient._raise_chroma_error (base_http_client.py:106-136) raises a bare Exception(resp.text) for a non-Chroma HTTP error, and orjson.loads raises on a non-JSON body. httpx.ConnectError MRO = ConnectError, NetworkError, TransportError, RequestError, HTTPError, Exception, and issubclass(ConnectError, OSError) is False. Repro .claude/lanes/20261111-plugins-review/scratch-D/chroma_sdk.py + chroma_search.py: a real chromadb HttpClient Collection (httpx MockTransport injected below the SDK) attached to a ChromaSearchProvider with the test _FakeExecutionRecorder. ConnectError, ReadTimeout, 502 HTML (builtins.Exception) and non-JSON body (orjson.JSONDecodeError) each escape search() raw, with 'allocated {s1: 1} recorded 0'. rag/core.py:527-540 catches only RetrievalError, so the row crashes, a transient failure is not retried, and the allocated call index has no Call row. Applies to mode=client (HTTP) deployments. Side note: chromadb.HttpClient() itself raises ValueError on an unreachable server, which _initialize_client (chroma.py:206-212) does not wrap.
Verifier repro scripts (gitignored, read-only reference): .claude/lanes/20261111-plugins-review/scratch-*/ in /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta

## Files a correct fix must change

- `src/elspeth/plugins/infrastructure/clients/retrieval/chroma.py`

## Test files the lane must add or change

- `tests/unit/plugins/infrastructure/clients/retrieval/test_chroma_search_transport_errors.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/infrastructure/clients/retrieval/test_chroma_search_transport_errors.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-03-p1-073-chroma-search-transport/report.md`; the worker returns one line.
