DONE: #73 fixed. Chroma search() records an ERROR call and raises RetrievalError for the HTTP SDK's real failures: httpx transport errors are retryable; the SDK's bare HTTP-error Exception is identified by its httpx.HTTPStatusError context and classified by status (408/429/5xx retryable, other 4xx permanent, status_code recorded); non-JSON/ValueError is permanent; anything unidentified crashes. Lane commits bb43d9fe/8ae6dd46 + review follow-up 4066c5e7 (RED 12 assertion failures)/d762d048 (GREEN 21 passed), rebased onto 9131a99e.

(Written by the hub from lane-03's SubagentHandback; the harness refused the lane's own report file. The logs cited are in this lane dir.)

## Root cause
src/elspeth/plugins/infrastructure/clients/retrieval/chroma.py: the count() and query() handlers in search() caught only chromadb.errors.* and (ConnectionError, TimeoutError, OSError).

chromadb 1.5.5's HTTP client raises other types:
- httpx.ConnectError and httpx.ReadTimeout, which are not OSError.
- A bare Exception(resp.text) for non-Chroma HTTP errors.
- orjson.JSONDecodeError, a ValueError, for non-JSON 2xx bodies.

Each of these escaped after allocate_call_index. That left an allocated index with no Call row, and an error that rag/core.py:527 neither retried nor routed.

## Fix (f6d590dc)
Both handlers get the same three changes. Every path calls _record_error and then raises RetrievalError:
1. httpx.HTTPError is added to the transport tuple, as retryable.
2. ValueError is handled as permanent.
3. `except Exception` acts only on the exact type (`type(exc) is not Exception: raise`), as retryable. Subclasses, such as a TypeError from a code bug, still crash.

This mirrors `_live_readiness`. chroma.py has no source_file_hash pin.

The fix commit also adjusts the test module's httpx import and patch target so mypy passes; this does not change what the test checks.

Classification choices for the maintainer to confirm:
- A bare Exception is retryable. The SDK drops the status code, so a 4xx page from a proxy would also be retried, within the engine's bounded retry.
- A ValueError is permanent.

## Tests
tests/unit/plugins/infrastructure/clients/retrieval/test_chroma_search_transport_errors.py uses a real chromadb.HttpClient over httpx.MockTransport. It covers {count, query} × {ConnectError, ReadTimeout, 502 bare Exception, non-JSON}, plus a success control and TypeError crash-through cases.

- **RED (3.14):** exit 1, 8 failed, 3 passed. Each failure is the AssertionError "fault escaped search() as <Type>... allocated={'s1': 1} recorded=0" (red-final.log).
- **GREEN (3.14):** exit 0, 11 passed (green-final.log).
- **Mutation check:** removing the exact-type guard turns both crash-through tests red (mutant.log).

## Gates (gates-final.txt)
- ruff check 0, ruff format --check 0, check_contracts 0, mypy chroma.py 0.
- **retrieval + rag tests:** 963 passed, 1 failed. The failure is test_no_fd_leak_after_repeated_evaluations, a load flake that also appears in the hub baseline; it passes serially (flaky-serial.log).
- **keyless elspeth-lints:** exit 1, the existing corpus. chroma.py findings are unchanged: the same 2 R_TB_SUPPRESSED, at lines 137 and 151.
- **dag + architecture (-n 2):** 2206 passed, 10 failed. Nine were OOM worker kills and one was the partial_terminal 20s timeout. All pass when re-run serially file by file (arch-serial.exit).
- **masquerade gate:** exit 0.
- mypy on the new test file reports one arg-type error. It reuses the `_FakeExecutionRecorder` fake, which causes the same error about 20 times in test_chroma.py already. CI's mypy scope is `src/ elspeth-lints/src/`, so this is not a CI gate.

## Left alone
- **`_initialize_client` path:** it does not wrap construction-time ValueError, httpx errors or bare Exception. This is a preflight path with no allocated index, so it is a candidate follow-up rather than part of #73.


## Review follow-up (approved by the maintainer after the Fable review)
- The first fix's bare-Exception-is-retryable guess was wrong because the status is recoverable. `BaseHTTPClient._raise_chroma_error` raises inside `except httpx.HTTPStatusError`, so `__context__` carries the response.
- d762d048 adds two helpers:
  - `_sdk_http_error_status`, which returns the status only for an exact `Exception` whose `__context__` is an HTTPStatusError and None otherwise.
  - `_http_status_is_transient`, which is true for 408, 429 and 5xx.
- Both handlers re-raise when the status is None. Otherwise they record an ERROR call and raise RetrievalError(retryable=..., status_code=status).
- **RED:** against 8ae6dd46 the run fails with 12 failed / 9 passed (red-fu.log). The failing assertions are status mismatches, a 403 marked retryable, and a crash-through that was being classified instead of re-raised.
- **GREEN:** 21 passed (green-fu.log). The mutation check (mutant-fu.log) turns both crash-through tests red.
- **Gates at HEAD d762d048:** ruff 0, format 0, check_contracts 0, mypy src/ elspeth-lints/src/ 0, retrieval+rag at -n 2 0 (974 passed).
