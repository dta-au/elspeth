# lane-11-p3-clients — #13 [P3, architecture] CallVerifier is exported and documented as the verify-mode API but production verify uses a different, stricter comparator; #22 [P3, bug] request_ssrf_safe lets POST/JSON/form bodies follow redirects, and _follow_redirects_safe silently re-sends every hop as a body-less GET, including 307/308; #23 [P3, enhancement] HTTP replay cannot reproduce a recorded transport failure; it aborts with AuditIntegrityError, unlike LLM replay, which re-raises the recorded error; #86 [P3, bug] Azure Search provider copies every returned field, including the embedding vector, into chunk metadata and the row's sources output; #141 [P3, architecture] CallReplayer is an unused, publicly exported replay path with weaker integrity checks than the engine's real replay (it invents {} for a SUCCESS call with no stored response)

Ticket `p3-clients` · run `p3` · branch `lane/p3-clients` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

This lane fixes 5 findings; fix each one (one test commit + one fix commit PER finding).
Every finding names the files where the sweep located it; touch only what each fix needs.

FINDING #13 [P3, architecture] CallVerifier is exported and documented as the verify-mode API but production verify uses a different, stricter comparator

`src/elspeth/plugins/infrastructure/clients/verifier.py`

verifier.py:254-547 defines CallVerifier, which `clients/__init__.py:34-45` re-exports and documents with "For verify mode, use CallVerifier". No production code uses it: `rg 'CallVerifier' src` hits only verifier.py and the clients `__init__` re-export and docstring, and tests/unit/plugins/clients/test_verifier.py is its only caller. Real RunMode.VERIFY goes through `CallModeSession.verify_call` (src/elspeth/engine/orchestrator/call_mode_session.py:705-790), whose rules differ from CallVerifier's. (a) verify_call binds the source call to the current parent (state_id/operation_id/call_index) with pre-dispatch admission. CallVerifier matches on a per-process (call_type, request_hash) sequence counter. (b) verify_call compares call status and error_json hashes. CallVerifier never looks at call.status or call.error_json, so a recorded ERROR call whose response payload equals the live success payload reports `matched`. (c) verify_call compares exact stable_hash values. CallVerifier defaults to `ignore_order=True` (verifier.py:285) with DeepDiff, a looser equivalence that also turns off hash verification of purged payloads by default (line 406). (d) For CALL_NOT_FOUND, CallVerifier raises, while the replayer treats it as a missing payload. Expected: a single verify authority. Either delete CallVerifier and its re-export, or make it delegate to the session comparator, and correct the package docstring so nobody wires the looser, unaudited comparator into a new verify path. Verified by rg over src/ and reading call_mode_session.py:705-790.

FINDING #22 [P3, bug] request_ssrf_safe lets POST/JSON/form bodies follow redirects, and _follow_redirects_safe silently re-sends every hop as a body-less GET, including 307/308

`src/elspeth/plugins/infrastructure/clients/http.py`

_follow_redirects_safe hard-codes method='GET' and sends no body on every hop (http.py:2206-2296), whatever the redirect status. RFC 9110 requires 307/308 to keep the method and body, and httpx's own redirect handling does that.

request_ssrf_safe refuses redirects for multipart (http.py:1815-1816) and for POWER_AUTOMATE_V1 (http.py:1804-1805). It does not refuse them for json= or form= POST bodies (the form check at http.py:1806-1811 rejects only a non-POST method or a mixed body). So request_ssrf_safe('POST', ..., json=..., follow_redirects=True) is accepted. A 307 then makes the hop a GET with no body. The hop also inherits the merged Content-Type (for a form request, 'application/x-www-form-urlencoded', set at http.py:1844 and copied into hop_headers at http.py:2197). The final response is returned as the answer to the POST. This is a guard that is only partly enforced: the hazard was recognised for multipart but not for the other body kinds.

Expected: either refuse follow_redirects whenever a request body or a non-GET method is present (matching the multipart rule), or implement 307/308 method and body preservation.

Verification: all current callers avoid the path. web_scrape POST passes follow_redirects=False (web_scrape.py:1878-1891), and azure_search POST does not follow redirects (azure_search.py:458-463). So the defect is latent in the shared client API. rg for 307/308 and for POST with follow_redirects under tests/ finds no test of this branch.

FINDING #23 [P3, enhancement] HTTP replay cannot reproduce a recorded transport failure; it aborts with AuditIntegrityError, unlike LLM replay, which re-raises the recorded error

`src/elspeth/plugins/infrastructure/clients/http.py`

A live transport exception records an ERROR call with response_data=None:
- _execute_request records response_payload None for timeout or connect errors (http.py:1525-1555).
- request_ssrf_safe does the same when response is None (http.py:1971-2010).

CallModeSession.replay_call accepts such a call: an ERROR call with NEVER_STORED response is allowed (engine/orchestrator/call_mode_session.py:330-347). But _restore_replay_response raises AuditIntegrityError('... has no response payload') (http.py:528-529), and _replay_ssrf_request raises '... lacks transport' (http.py:701-703). As a result, replaying any source run in which one web_scrape, blob_fetch or provider row hit a timeout, connect error or SSRF-blocked redirect aborts the whole replay with an audit-integrity error. That labels a legitimate recorded failure as corrupt evidence.

The sibling AuditedLLMClient replay path rebuilds recorded errors and re-raises the categorized exception (RateLimitError, ServerError, NetworkError and so on) at llm.py:~466-498, so the row is routed the same way it was originally.

Expected: for an ERROR evidence with error_data and no response payload, re-raise a bounded httpx/NetworkError-class exception rebuilt from the recorded error type, so callers route the row as they did in the source run.

Verification: rg for 'no response payload' finds only the raise sites, in http.py and llm.py, and no test exercises HTTP replay of a recorded transport exception. tests/unit/plugins/clients/test_http.py replay tests cover only corrupt or legacy transports and successful or redirect restores.

FINDING #86 [P3, bug] Azure Search provider copies every returned field, including the embedding vector, into chunk metadata and the row's sources output

`src/elspeth/plugins/infrastructure/clients/retrieval/azure_search.py`

azure_search.py:607-611 builds `metadata` from every item key except the score, content and id fields. It does not exclude `self._config.vector_field`, and `select` defaults to None, so Azure returns all retrievable fields; vector fields are retrievable unless the index marks them otherwise. In hybrid or vector mode against a typical index, each chunk's metadata then carries the full embedding (for example 1536 floats). RAGRetrievalTransform serialises it into the row's `sources` field (transforms/rag/core.py:603-612), which bloats row data, payload storage and sinks. The sibling Chroma provider explicitly asks only for `include=["documents","distances","metadatas"]` (chroma.py:393), so embeddings never reach metadata. Expected: drop `vector_field` (and other `@search.*` internals) from metadata, or send a default `select` covering only the mapped and citation fields. Verification: read the metadata comprehension and the RAG envelope builder, and compared with Chroma's include list. The azure tests (test_azure_search.py:898-918) cover only small text metadata.

FINDING #141 [P3, architecture] CallReplayer is an unused, publicly exported replay path with weaker integrity checks than the engine's real replay (it invents {} for a SUCCESS call with no stored response)

`src/elspeth/plugins/infrastructure/clients/replayer.py`

rg finds no production construction of CallReplayer. Only the re-export and the 'For replay mode, use CallReplayer' docstring in clients/__init__.py:27-32 remain, plus tests/unit/plugins/clients/test_replayer.py. Real replay goes through engine/orchestrator/call_mode_session.py, which enforces Tier-1 invariants that replayer.py does not: (1) A SUCCESS call whose response is not AVAILABLE raises AuditIntegrityError (call_mode_session.py:327-330). replayer.py:260-262 returns response_data={} for NEVER_STORED regardless of call.status, so a successful call with no recorded response replays as an invented empty success. (2) error_json that parses to a non-dict raises in call_mode_session.py:334-337. replayer.py:233-242 accepts any JSON value and deep-freezes it into a field typed Mapping. (3) ERROR without error_json raises in call_mode_session.py:338-339; the replayer allows it. (4) The verifier treats CALL_NOT_FOUND after a successful lookup as AuditIntegrityError (verifier.py:480-486); the replayer reports it as ReplayPayloadMissingError. A contributor following the package docstring would wire in a divergent replay boundary that does not enforce these checks. Expected: delete the dead module and its export, or make it enforce the same invariants as call_mode_session (refuse SUCCESS+NEVER_STORED, require dict error evidence).

## Files a correct fix must change

- `src/elspeth/plugins/infrastructure/clients/http.py`

## Test files the lane must add or change

- `tests/unit/plugins/infrastructure/test_clients_p3_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/infrastructure/test_clients_p3_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-11-p3-clients/report.md`; the worker returns one line.
