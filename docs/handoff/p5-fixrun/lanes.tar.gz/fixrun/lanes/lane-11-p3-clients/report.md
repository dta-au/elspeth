DONE: lane-11-p3-clients fixed all 5 findings (#13, #141, #22, #23, #86) test-then-fix on lane/p3-clients (10 commits); lane file 26 passed; fencing gate unconfirmed (timed out at 900s on lane host) — verify suite must settle it.

(Written by orchestrator from the lane's hand-back; the subagent's report.md write was refused.)

## Fixes
- #13 DELETED clients/verifier.py (CallVerifier) + its tests and re-exports; CallModeSession.verify_call is the only verify authority. Contracts whitelist rows removed, census re-pinned, design note updated. COMPAT: public import elspeth.plugins.infrastructure.clients.CallVerifier removed.
- #141 DELETED clients/replayer.py (CallReplayer) + tests/re-exports; stale allowlist entries removed (tier_model R5 unsigned, freeze_guards FG2, contracts whitelist), fingerprint_baseline.json entry removed, census re-pinned, ReplayedCall freeze tests deleted, test_ordered_query_runtime expects AuditIntegrityError. COMPAT: CallReplayer import removed.
- #22 request_ssrf_safe refuses follow_redirects=True unless body-less GET (ValueError before network). Production callers already pass False for POST.
- #23 HTTP replay rebuilds recorded httpx.TransportError leaf failures (closed table) and re-raises, recording the replay call as ERROR; other error types (incl. SSRFBlockedError) still AuditIntegrityError. Limitation: transport failure on a later redirect hop leaves earlier HTTP_REDIRECT calls unconsumed.
- #86 Azure Search metadata excludes vector_field and @search.* keys.

## Evidence (lane-reported)
- RED per finding at assertions; GREEN 26 passed; adjacent 520/554/1410/1420/982 passed (one rag fd-leak load flake, passes -n 0).
- ruff/format/check_contracts/mypy(src) 0; masquerade baseline up to date; keyless tier_model same multiset (http.py fingerprints rotated -> signed http.py entries may need operator re-sign).
- Fencing file -n 0 killed at 900s (~46%, no failures). #23 adds two _record_and_emit calls (existing helper).

## Left in place
- deepdiff dependency (now unused in src; lockfile change).
- discovery.py EXCLUDED_FILES still lists replayer.py/verifier.py.
