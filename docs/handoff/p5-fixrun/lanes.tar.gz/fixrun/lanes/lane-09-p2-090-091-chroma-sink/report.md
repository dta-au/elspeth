DONE: #90 and #91 are fixed in chroma_sink.py in 4 commits: bba2b79f test#90, 7291817a fix#90, 0d2a2ce2 test#91, decac1f7 fix#91. An empty document ID, and every later duplicate ID within an effect group, are now diverted at prepare time, one row each. The valid rows next to them still publish.

(The hub wrote this report from lane-09's hand-back, because the harness refused the lane's own report write. The logs are in this lane dir.)

## #90: empty-string document ID
**Root cause.** The ID check in `_extract_effect_member` was type-only, so an empty-string ID passed it. chromadb then raised InvalidArgumentError at upsert. That is a ChromaError, not a ValueError, so the existing handler did not catch it. Reconcile then saw the row as "not applied" and recommitted, which failed the same way every time.

**Fix.** `_extract_effect_member` now raises ValueError "Chroma effect member id must not be empty". That error reaches the existing per-row diversion, which diverts the row.

**Test.** It runs the real SinkEffectCoordinator.
- RED: "empty ID escaped the effect instead of diverting".
- GREEN: 1 passed.

## #91: duplicate IDs in one effect group
**Root cause.** The uniqueness check ran after the per-row loop, so a single duplicate raised ValueError for the whole group.

**Fix.** The check now runs inside the loop. The first row with an ID is accepted, and later rows with the same ID are diverted with a "duplicates the document id" reason. Which row is diverted depends only on row order.

**Test.**
- RED: ValueError "require unique stable document IDs".
- GREEN: 2 passed.

## Re-pins
ChromaSink hash: 53866f704b91068f → e37f21d0c0038e1c → c08d757cf9512990. Nothing else pins it.

## Gates
| Check | Result |
|---|---|
| ruff | 0 |
| format | 0 |
| check_contracts | 0 |
| mypy on the src file | 0 |
| module tests + architecture hash tests | 698 passed, then 778 passed |
| branch-safety | 0 |

mypy on the test file reports 3 errors. They follow the existing pattern in test_chroma_member_effect_diversion.py.

## Left alone
- `_ChromaPayloadRejection` is not caught anywhere.
- Whitespace-only IDs are still accepted.
- Duplicates across batches still overwrite, as before.
