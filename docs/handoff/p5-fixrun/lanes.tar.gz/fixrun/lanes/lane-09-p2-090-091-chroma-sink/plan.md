# lane-09-p2-090-091-chroma-sink — #90 [P2, bug] Empty-string document ID passes per-member validation but Chroma rejects it at upsert, so the run fails instead of diverting the row; #91 [P2, bug] Duplicate document IDs within one effect group fail the whole batch instead of diverting rows

Ticket `p2-090-091-chroma-sink` · run `p2` · branch `lane/p2-090-091-chroma-sink` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

This lane fixes 2 findings; fix each one (one test commit + one fix commit PER finding).
The listed files are where the sweep located each defect; a finding may need no change in some of them.

FINDING #90 [P2, bug] Empty-string document ID passes per-member validation but Chroma rejects it at upsert, so the run fails instead of diverting the row

`src/elspeth/plugins/sinks/chroma_sink.py`

At chroma_sink.py:380, _extract_effect_member checks only `type(raw_id) is not str`, so an empty string "" is accepted and moves on to commit. I confirmed with an EphemeralClient probe that chromadb 1.5.5 rejects it: upsert(ids=[""]) raises chromadb.errors.InvalidArgumentError ('Empty ID, ID must have at least one character'). That class is a ChromaError, not a ValueError, so the `except ValueError` at line 622 does not catch it. It escapes commit_member_effect. sink_effects.py:1052-1057 marks the attempt response_lost and re-raises. On the next attempt, reconcile calls get(ids=[""]). If that call raises a ChromaError, the handler at line 648 returns UNKNOWN. If it returns ids==[""], the check at line 660 (`not item`) classes it 'malformed', which is also UNKNOWN. Either way the coordinator raises SinkEffectUnknownError (sink_effects.py:899). I did not run that reconcile get() call with an empty ID. Line 660 shows that reconcile already treats an empty ID as invalid, while preparation does not. Result: one row with an empty-string ID (a realistic Tier-2 data defect) blocks its whole effect group, when it should be diverted on its own during preparation like the other invalid-ID cases covered by elspeth-32bf1a9b63 (tests/unit/engine/test_chroma_member_effect_diversion.py). Expected: _extract_effect_member raises ValueError for an empty `raw_id` so the member is diverted at prepare time. No test covers an empty ID: rg for `"doc_id": ""` and empty-id patterns under the chroma tests found nothing.

**Verifier (CONFIRMED):** chroma_sink.py:380 only checks `type(raw_id) is not str`, so '' is accepted. Probe .claude/lanes/20261111-plugins-review/scratch-D/empty_id.py on a chromadb 1.5.5 EphemeralClient: upsert(ids=['']) -> InvalidArgumentError (a ChromaError, not a ValueError) 'Empty ID, ID must have at least one character'; get(ids=['']) returns ids=[] without raising. End-to-end repro .claude/lanes/20261111-plugins-review/scratch-D/sink_ids_body.py, run via pytest -p tests.conftest -n 0 with the harness from tests/unit/engine/test_chroma_member_effect_diversion.py, a real ephemeral collection, rows d0 and '': attempt 0 -> InvalidArgumentError, attempt 1 -> InvalidArgumentError; d0 landed and the group never finalizes. Correction to the mechanism: reconcile on retry does NOT return UNKNOWN. get(['']) gives ids=[], so reconcile returns not_applied('missing') (chroma_sink.py:666-667), the coordinator recommits, and the commit raises the same error again on every attempt. The outcome is the same: one bad row wedges the effect group instead of being diverted at prepare time. Also, _ChromaPayloadRejection (chroma_sink.py:68, raised at 623) is caught nowhere in src.

FINDING #91 [P2, bug] Duplicate document IDs within one effect group fail the whole batch instead of diverting rows

`src/elspeth/plugins/sinks/chroma_sink.py`

At chroma_sink.py:435-437, _member_effect_material raises ValueError('Chroma effect members require unique stable document IDs') when two members that would otherwise be accepted share an ID. This is outside the per-member try/except at lines 430-434, so it escapes prepare_effect (called at sink_effects.py:1501 with no handler). The whole group then fails on every attempt, and its valid siblings fail with it. elspeth-32bf1a9b63 fixed exactly this all-or-nothing behaviour for every other row-attributable defect. The ID values come from row data, so this is a per-row data condition and not an internal invariant. Rejecting duplicates is reasonable: with sequential per-member upserts, reconciling the earlier member would see the later document. But the members after the first occurrence of the ID should be diverted with a reason, not cause the plan to fail. There is also an inconsistency: under on_duplicate=overwrite (the only supported mode), the same ID arriving in a later batch silently overwrites, while the same ID within one batch fails the run. No test exercises this branch: rg for 'unique stable' finds only the raise site, and nothing under tests/ builds a chroma batch with repeated IDs.

**Verifier (CONFIRMED):** chroma_sink.py:435-437 raises ValueError('Chroma effect members require unique stable document IDs') outside the per-member try (430-434); prepare_effect is called with no handler at engine/executors/sink_effects.py:1501. Repro .claude/lanes/20261111-plugins-review/scratch-D/sink_ids_body.py (same coordinator harness, rows d0, d0, d2 with _RecordingCollection): 'DUP_ID attempt 0 -> ValueError Chroma effect members require unique stable document IDs', and the same on attempt 1, so the valid sibling d2 is blocked as well. `rg 'unique stable'` under tests/ finds no test. The IDs are row data, so this is a per-row condition and should be diverted rather than fail the plan.

## Files a correct fix must change

- `src/elspeth/plugins/sinks/chroma_sink.py`

## Test files the lane must add or change

- `tests/unit/plugins/sinks/test_chroma_sink_p2_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/sinks/test_chroma_sink_p2_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-09-p2-090-091-chroma-sink/report.md`; the worker returns one line.
