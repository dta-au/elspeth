DONE: #9 and #10 fixed on lane/p2-009-010-aws-s3-source (eab0a543 test#9, cdf194d6 fix#9, 65f3d0cf test#10, d34b4f0e fix#10). The aws_s3 JSON file error now takes the next unused source_row_index and says rows were already emitted. JSONL now resyncs past an oversized line. CSV and JSONL stops now state "processing stopped at row/line N and later records were not read". CAVEAT: the dag/architecture gate is not verified green (see Gates).

## #9 — the JSON mid-document file error reused source_row_index=0
- Root cause: `_file_error` (src/elspeth/plugins/sources/aws_s3_source.py, formerly :1118-1132) hardcoded `source_row_index=0`. `_load_json_array` (formerly :1309-1320) calls it after ijson has already yielded items, so the quarantine reused index 0. That index collides with UNIQUE(run_id, source_node_id, source_row_index) in the landscape rows table, and the run crashes.
- Fix: `_file_error` takes a keyword `source_row_index` (default 0, used by the CSV header paths). The JSON loader passes its next unused index. When the index is greater than 0, the message becomes "JSON object could not be parsed within configured bounds; N rows were already emitted from this document before it proved invalid". This is recorded in both quarantine and discard modes. Streaming partial admission is kept, because it is inherent to the bounded streaming parser, but the audit record now states it. A failure before the first row keeps index 0 and the original message.
- RED (on eab0a543): 7 failed, 1 passed. Example: `assert [(False, 0), ...1), (True, 0)] == [(False, 0), ...1), (True, 2)]`, and `AssertionError: assert '2 rows were already emitted' in 'JSON object could not be parsed within configured bounds'`.
- GREEN (on cdf194d6): 8 passed.

## #10 — JSONL and CSV dropped every record after an oversized or unparseable one
- Root cause: `_load_jsonl` (formerly :1247-1264) and `_load_csv` (formerly :1192-1209) quarantined the bad record and then `return`ed. The rest of the object was abandoned without any record of it.
- JSONL fix: the new `_BoundedDecodedLineIterator.skip_rest_of_line()` tracks whether the last bounded readline already consumed a line terminator. It then discards the rest of the oversized physical line in chunks bounded by max_record_chars + 1 and resets the record budget. On `_RecordLimitExceeded` the loader calls it and `continue`s. A test covers the edge case where the oversized line is exactly max+1 characters including its newline: the resync does not swallow the next line.
- CSV: there is deliberately no resync. A record can span lines, and after csv.Error the reader state is untrustworthy, which is the same reason csv_source stops. Both CSV stop messages now say "...; processing stopped at row N and later records were not read". The JSONL UnicodeDecodeError stop says the same thing with "line N".
- RED (on 65f3d0cf): 4 failed, 9 passed. Example: `assert [(False, 0), (True, 1)] == [(False, 0), ...), (False, 3)]`, and `AssertionError: assert 'stopped at row 2' in 'CSV record exceeds configured character limit'`.
- GREEN (on d34b4f0e): 13 passed.

## Re-pins
- Only `AWSS3Source.source_file_hash` pins this file. A grep of the whole tree found the old hash only at the class attribute; it is not in the scenario-corpus manifest. ecf90258957184af -> 9d252a163980b4ce (fix #9) -> c4126cd44880a771 (fix #10). After each edit, a strict equality check against compute_source_file_hash returned True.

## Gates (final tree d34b4f0e unless noted)
- ruff check src/ tests/: exit 0
- ruff format --check src/ tests/: exit 0
- scripts/check_contracts.py: exit 0
- mypy src/elspeth/plugins/sources/aws_s3_source.py: exit 0
- mypy on aws_s3_source.py plus the new test file: exit 1. All 26 errors are in tests/unit/plugins/sources/test_aws_s3_source.py, which mypy follows through the import. That file is unchanged since the base (`git diff --quiet` from HEAD~4 returned 0), and the errors are about its own fakes (_Client vs _S3Client, _SourceContext). None are in the files I touched.
- pytest test_aws_s3_source_p2_sweep.py + test_aws_s3_source.py -n 2: exit 0, 225 passed.
- scripts/branch-safety-check.sh --intent commit: FAIL=0 WARN=0.
- pytest tests/integration/core/dag tests/unit/architecture (+ test_source_field_renames, test_aws_ecs_terraform_package) -n 2: NOT VERIFIED.
  - First run: the harness killed it at 97% after a long run on a loaded host (load around 8.8, 15 GB RAM with 11 GB used). Two xdist workers reported "node down: Not properly terminated" at about 87%, which is likely OOM or contention; the crashed tests were not identified.
  - A -v rerun of dag+architecture was still running at handback. Its log is /tmp/claude-0/-home-user-elspeth/35e9058a-baa7-5887-beaa-b37b81fdf62f/scratchpad/arch2.log and its exit code goes to arch2.exit.
  - The hub should run this gate on the merged tree.

## Left alone and caveats
- "1 rows were already emitted" is not pluralised for the single-row case.
- JSONL resync edge case: if a bounded read of an oversized line ends exactly between "\r" and "\n" of a CRLF terminator, the stray "\n" is read as a blank line. That line is skipped as blank, but line_number advances by one more.
- No judge or trust-tier allowlist signatures were touched.
