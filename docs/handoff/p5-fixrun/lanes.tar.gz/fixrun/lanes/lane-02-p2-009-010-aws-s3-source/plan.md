# lane-02-p2-009-010-aws-s3-source — #9 [P2 (raised as P1), bug] aws_s3 JSON source: mid-document parse failure emits prefix rows as valid, then a file-error quarantine at source_row_index=0 that collides with the first valid row; #10 [P2, bug] aws_s3 JSONL/CSV source silently drops every record after the first oversized or unparseable record

Ticket `p2-009-010-aws-s3-source` · run `p2` · branch `lane/p2-009-010-aws-s3-source` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

This lane fixes 2 findings; fix each one (one test commit + one fix commit PER finding).
The listed files are where the sweep located each defect; a finding may need no change in some of them.

FINDING #9 [P2 (raised as P1), bug] aws_s3 JSON source: mid-document parse failure emits prefix rows as valid, then a file-error quarantine at source_row_index=0 that collides with the first valid row

`src/elspeth/plugins/sources/aws_s3_source.py`

_load_json_array (aws_s3_source.py:1309-1320) streams items through ijson. When the document fails after some items were already yielded (trailing garbage, truncated tail, a duplicate data_key found later), it catches the error and calls _file_error (1118-1132), which always quarantines with source_row_index=0. Item 0 was already yielded with source_row_index=0. Measured on 1a7ff0e6 with the test helper _source_for: b'[{"id":1},{"id":2}] garbage', b'[{"id":1},{"id":2},{"id"' and b'{"r":[{"id":1},{"id":2}],"r":[{"id":3}]}' with data_key=r. Each one produced valid(0), valid(1) and then quarantined(0). Two invariants break here. (a) The landscape rows table has UniqueConstraint("run_id","source_node_id","source_row_index") (core/landscape/schema.py:811), and encode_source_snapshot raises 'duplicate source row indexes' (engine/orchestrator/source_snapshot.py:101). With a quarantine sink configured, a truncated or malformed S3 JSON object therefore crashes on an integrity error and is not cleanly quarantined. (b) This is fail-open compared with the sibling sources. json_source (json.load at :376) and azure_blob_source parse the whole document before emitting anything, so a structurally invalid document produces zero rows plus one file-level quarantine. aws_s3 admits the prefix of an invalid document as valid rows, and with on_validation_failure=discard it does so with only a validation-error record. Expected: the file-error quarantine uses a source_row_index that has not been used yet (the next index), and the audit or quarantine reason states that rows were already emitted from a document that later proved invalid. Alternatively, document the streaming partial-admission semantics explicitly. No test covers this: rg for trailing/truncat/'within configured bounds' in tests/unit/plugins/sources/test_aws_s3_source.py found no mid-document failure case. The existing tests exercise only failures before the first item or per-item validation failures.

**Verifier (CONFIRMED):** Read aws_s3_source.py:1309-1326 (_load_json_array catches ijson/limit/boundary errors mid-stream and calls _file_error) and :1118-1132 (_file_error hardcodes source_row_index=0). Repro .claude/lanes/20261111-plugins-review/scratch-B/repro_s3.py (worktree elspeth.__file__ confirmed): all three payloads (trailing garbage, truncated tail, duplicate data_key) yield V(0), V(1), Q(0). No upstream guard: source_iteration.py:779 takes source_row_index verbatim from the source ('Source row identity must be source-authored') and passes it to quarantine_router.route -> processor.ingest_quarantined_row (quarantine_router.py:163-166). Demonstrated the consequence in .claude/lanes/20261111-plugins-review/scratch-B/test_scratch_dup.py (pytest -p tests.conftest -n 0): a third create_row_with_token with source_row_index=0 raises sqlite3.IntegrityError 'UNIQUE constraint failed: rows.run_id, rows.source_node_id, rows.source_row_index' (schema.py:811). source_iteration.py:986 re-raises, so the run crashes instead of quarantining. snapshot_for_resume path would instead hit source_snapshot.py:101 duplicate-index ValueError. Partial-admission of prefix rows is real but is arguably an inherent streaming trade-off; the index collision/crash is the defect. Downgraded P1->P2: the unique constraint prevents audit corruption, outcome is a crash on hostile/malformed Tier-3 input (same class as #18/#112).

FINDING #10 [P2, bug] aws_s3 JSONL/CSV source silently drops every record after the first oversized or unparseable record

`src/elspeth/plugins/sources/aws_s3_source.py`

In _load_jsonl (1247-1255) and _load_csv (1192-1209), a _RecordLimitExceeded or a csv.Error/UnicodeDecodeError quarantines one row and then `return`s. All remaining records in the object are abandoned. The quarantine reason does not say that processing stopped ('JSONL record exceeds configured character limit', 'CSV record could not be parsed safely'), and nothing else is recorded. Measured with max_record_chars=20: JSONL b'{"id":1}\n{"id":"xxx…50"}\n{"id":3}\n{"id":4}\n' gave [valid id=1, quarantined line 2]. Rows 3 and 4 vanished, the load ended normally, and the audit trail never shows they existed. CSV showed the same behaviour. JSONL is newline-framed, so resyncing at the next newline is possible: reading the rest of the oversized line in bounded chunks would let the following lines be processed. Even where stopping is deliberate (CSV after csv.Error), the sibling csv_source says so explicitly in its audit message ('Stopping file processing — csv.Error can corrupt parser state', csv_source.py:536). Expected: either continue past an oversized JSONL line, or record a file-level validation error stating that processing stopped at line N and later records were not read. No test exercises a row after an oversized or unparseable record: test_record_caps_reject_selected_and_ignored_oversized_tokens only asserts that rows[0] is quarantined.

**Verifier (CONFIRMED):** Read aws_s3_source.py:1192-1209 (CSV) and :1247-1264 (JSONL): _RecordLimitExceeded / csv.Error / UnicodeDecodeError quarantine one row then `return`. Repro .claude/lanes/20261111-plugins-review/scratch-B/repro_s3.py with max_record_chars=20: JSONL -> [V idx0, Q idx1 {'__line_number__': 2}], CSV -> [V idx0, Q idx1 {'__row_number__': '2'}]; rows 3 and 4 never emitted, only one validation error recorded ('... exceeds configured character limit'), message never says processing stopped. Contrast csv_source.py:534-537 whose message states 'Stopping file processing'. No test asserts post-oversize rows (test_aws_s3_source.py:923-929 checks only rows[0]). Silent audit gap for records after the failure point.

## Files a correct fix must change

- `src/elspeth/plugins/sources/aws_s3_source.py`

## Test files the lane must add or change

- `tests/unit/plugins/sources/test_aws_s3_source_p2_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/sources/test_aws_s3_source_p2_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-02-p2-009-010-aws-s3-source/report.md`; the worker returns one line.
