# lane-01-p3-file-sinks — #14 [P3, bug] Stale-scratch sweep can delete a live prepare's building tree, classified by directory mtime alone; #25 [P3, bug] CSVSinkConfig accepts delimiters that csv.writer rejects, so the failure surfaces at publication instead of at config validation; #26 [P3, bug] CSVSinkConfig encoding validator admits non-text codecs (base64, hex, rot13), which crash at publication; #27 [P3, enhancement] Pipeline-row CSV output does not guard against spreadsheet formula injection, although the same plugin's audit-export path does; #41 [P3 (raised as P2), bug] DatabaseSink composer guidance contradicts the runtime: it advertises table auto-creation, 'replace', and SQL Server, and never mentions the required effect_ledger; #79 [P3, enhancement] Local-file storage admission makes one durable DB reservation per streamed chunk (one per CSV row in web runs)

Ticket `p3-file-sinks` · run `p3` · branch `lane/p3-file-sinks` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

This lane fixes 6 findings; fix each one (one test commit + one fix commit PER finding).
Every finding names the files where the sweep located it; touch only what each fix needs.

FINDING #14 [P3, bug] Stale-scratch sweep can delete a live prepare's building tree, classified by directory mtime alone

`src/elspeth/plugins/sinks/_audit_export_bundle_effects.py`

`cleanup_stale_audit_export_bundle_scratch` (lines 1254-1298) runs inside every `preflight_audit_export_bundle` (line 1328, called per CSV audit export from csv_sink.py:289-291). It removes any parent entry that matches `_BUILDING_GLOB` (`.*.elspeth-*.building-*`, which covers every target and every effect_id in that parent) once `st_mtime` is more than 1h old. The sweep has no ownership or liveness check: no lock, pid, or flock. `_prepare_audit_export_bundle_with_portable_records` creates the building directory (line 888) BEFORE `_parse_verified_records` (line 894) streams the whole verified snapshot into TemporaryFile spools. During that pass the directory stays empty and its mtime stays at creation time. Writing file contents later does not update the directory mtime either, and bundles may be up to 1 TiB (AUDIT_EXPORT_MAX_DELIVERED_BYTES). If a concurrent export preflights the same parent while a large prepare has been running for more than 1h, the sweep unlinks the live tree's files and rmdirs it (`_remove_scratch_path_at`, lines 1216-1251). The live prepare then fails with a raw FileNotFoundError from `_open_owned_output`/`_rename_noreplace_at` after hours of work. It fails closed (no corrupt publish, because `_tree_matches_at` guards install), so this is a liveness and attribution defect. Expected: create the building directory after the parse pass, keep its mtime fresh while in use, or prove liveness (e.g. a flock on the building dir fd) before sweeping. Tests test_stale_sweep_* (tests/unit/plugins/sinks/test_audit_export_bundle_effects.py:985-1051) cover only crashed trees and parent replacement; nothing exercises a concurrent live prepare.

FINDING #25 [P3, bug] CSVSinkConfig accepts delimiters that csv.writer rejects, so the failure surfaces at publication instead of at config validation

`src/elspeth/plugins/sinks/csv_sink.py`

_validate_delimiter (csv_sink.py:148-153) only checks len(v)==1. Python's csv module rejects '"' (the default quotechar), '\n' and '\r'. Measured on Python 3.13: csv.writer(delimiter='"') raises ValueError('bad delimiter or quotechar value'), and '\n' or '\r' raises ValueError('bad delimiter value'). csv.DictWriter(fieldnames=['a'], delimiter='"') raises the same error. So a config such as `delimiter: '"'` passes validation, the pipeline runs every upstream transform (including paid LLM calls), and then prepare_effect fails inside the chunks() generator: header_text() at line 578, or the DictWriter construction at line 606, which sits outside the per-row try. The result is an uncaught ValueError at sink publication, not a config error. Expected: reject quotechar, CR and LF (or simply try constructing csv.writer) inside the field validator. Verification: rg found no delimiter tests in tests/unit/plugins/sinks/test_csv_sink*.py. The same len==1-only validator exists in csv_source.py:67-71, azure_blob_source.py:99-103 and aws_s3_source.py:92-96.

FINDING #26 [P3, bug] CSVSinkConfig encoding validator admits non-text codecs (base64, hex, rot13), which crash at publication

`src/elspeth/plugins/sinks/csv_sink.py`

_validate_encoding (csv_sink.py:155-164) only calls codecs.lookup(v), which succeeds for bytes-to-bytes and str-to-str codecs. Measured: codecs.lookup('base64'|'hex'|'rot13')._is_text_encoding is False. 'x'.encode('rot13') raises LookupError ('not a text encoding'). codecs.getincrementalencoder('base64')().encode('a,b') raises TypeError. The rot13 incremental encoder returns str, not bytes. In prepare_effect, chunks() calls encoder.encode(header_text()) at line 587 (TypeError for base64/hex, a str chunk for rot13), and row_text.encode(self._encoding) at line 610 raises LookupError, which the per-row handler does not catch (it catches only UnicodeEncodeError and csv.Error). The config is accepted, and the failure comes as an uncaught exception at publication time after all upstream work. Expected: also reject codecs whose CodecInfo._is_text_encoding is False (for example by checking with ''.encode(v)). Verification: the same codecs.lookup-only pattern appears in text_sink.py:74, json_sink.py:119, aws_s3_sink.py:109, azure_blob_sink.py:146, document_sink.py:92 and several sources and transforms, so this is a cross-plugin gap. No CSV sink test covers a non-text codec.

FINDING #27 [P3, enhancement] Pipeline-row CSV output does not guard against spreadsheet formula injection, although the same plugin's audit-export path does

`src/elspeth/plugins/sinks/csv_sink.py`

For AUDIT_EXPORT_SNAPSHOT input, CSVSink delegates to _audit_export_bundle_effects, which neutralises cells that start with = + - @ TAB CR LF (_CSV_FORMULA_PREFIXES at _audit_export_bundle_effects.py:78, _neutralize_csv_formula at :413, applied at :448). The pipeline-member path (csv_sink.py:589-635) writes row values, and the audit-context error_reason/disposition_reason text (lines 542, 549), verbatim through csv.DictWriter. Those rows often carry Tier-3 content such as LLM output, scraped pages or uploaded data, which an operator may open in Excel. So one plugin has two different security postures for the same file format, and nothing in usage_when_to_use or the composer hints warns about it. Rewriting values by default would change the output relative to the audited row data, so the concrete gap is a missing opt-in option (for example neutralize_formulas: true), recorded in config/audit, or at minimum a documented warning. Verification: rg -i 'formula' found the neutraliser only in _audit_export_bundle_effects.py, and nothing in tests/unit/plugins/sinks/test_csv_sink*.py exercises formula-prefixed values.

FINDING #41 [P3 (raised as P2), bug] DatabaseSink composer guidance contradicts the runtime: it advertises table auto-creation, 'replace', and SQL Server, and never mentions the required effect_ledger

`src/elspeth/plugins/sinks/database_sink.py`

get_agent_assistance (database_sink.py:1164-1174) tells the composer LLM the following: (a) the sink supports 'Postgres, SQLite, SQL Server'; (b) append is 'creating it if missing'; (c) 'replace' drops and recreates the table; (d) column types are mapped from schema types. get_post_call_hints (1196-1199) also warns that 'replace' DROPS the table. The runtime does none of this. _resolve_sink_effect_mode -> _validate_effect_config (343-354) runs at plugin construction (runtime_factory.py:279 and engine preflight.py:382). It raises SinkEffectCapabilityError for a missing effect_ledger, for if_exists='replace', and for any dialect other than postgresql or sqlite. _inspect_target_contract (487-490) refuses a missing target table; there is no DDL path, and write() (1147-1149) always raises. SCHEMA_TYPE_TO_SQLALCHEMY (64-72) is dead: rg finds no reader outside its definition. The class docstring (259-286, 'Creates the table on first write') is also stale. The hints never say effect_ledger is required, although example_use and usage_when_not_to_use do. A planner that follows the hints will author configs that always fail validation. Verified that the hint strings are not pinned by any test (rg 'creating it if missing|drops and recreates|DROPS and recreates' finds only database_sink.py). Expected: the hints should state that the sink supports SQLite and PostgreSQL only, appends to an operator-provisioned table, requires effect_ledger, and has no working 'replace'. Remove the dead type map and the replace hint, or narrow if_exists to Literal['append'] (a compatibility decision for the operator).

**Verifier (CONFIRMED):** get_agent_assistance (database_sink.py:1163-1176) says 'Postgres, SQLite, SQL Server', append is 'creating it if missing', 'replace' drops/recreates, and maps schema types to columns; get_post_call_hints (1197-1201) warns replace DROPS the table. Runtime: _validate_effect_config (343-354) — scratch-E/f41.py ran DatabaseSink._resolve_sink_effect_mode: no effect_ledger -> SinkEffectCapabilityError; if_exists='replace' -> 'not supported'; mssql URL -> 'dialect 'mssql' is unsupported'; only sqlite+ledger+append OK. _inspect_target_contract (487-490) refuses a missing target table; write() (1147-1149) always raises. SCHEMA_TYPE_TO_SQLALCHEMY (64-72) has no reader in src/ or tests/ (grep only hits the definition and .pyc). Class docstring (259-286) still says 'Creates the table on first write'. Impact is a fail-closed validation error for planner-authored configs (no data harm), so downgraded to P3.

FINDING #79 [P3, enhancement] Local-file storage admission makes one durable DB reservation per streamed chunk (one per CSV row in web runs)

`src/elspeth/plugins/sinks/_local_file_effects.py`

_local_file_effects.py:512-522 calls `_admit_local_file_storage(target, size_bytes=existing_storage_bytes + total)` for every chunk. When a web storage authority is bound (web/blobs/service.py:3557-3571), each call runs `self._session_operation_authority.mutate(... reserve_run_output_storage ...)`, which is a fenced write transaction (web/coordination/repository.py:3778-3792 -> `_set_run_output_storage`). Chunk size is set by the caller: csv_sink.py yields one chunk per serialized row (`yield encoder.encode(row_text)`, around line 633). Each effect also re-serializes the cumulative snapshot, so a web CSV run makes on the order of one coordination-DB write per row per effect. Empty `b''` chunks are admitted too. Correctness holds and the check fails closed, but write amplification grows with row count rather than bytes. Suggested change: admit at byte-threshold boundaries (for example every _COPY_CHUNK_BYTES) plus once before the fsync/replace, keeping a final exact admission. This is inferred from the code path; no runtime measurement was taken.

## Files a correct fix must change

- `src/elspeth/plugins/sinks/csv_sink.py`

## Test files the lane must add or change

- `tests/unit/plugins/sinks/test_file_sinks_p3_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/sinks/test_file_sinks_p3_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-01-p3-file-sinks/report.md`; the worker returns one line.
