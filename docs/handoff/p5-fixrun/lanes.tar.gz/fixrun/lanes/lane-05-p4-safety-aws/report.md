lane-05-p4-safety-aws: #38 #127 #145 #158 #159 fixed test-first (RED 44b3bef4, fix 2cb8d9b6, 25/25 lane tests green); #37 already fixed by 06c108ea (measured: 400 pages x 200k blocks 16.28s -> 0.79s, byte-identical output); all gates green (contracts, plugin lints, ruff, mypy, hasattr gate, 1155 module tests); keyless tier-model finding set unchanged, no signed fingerprints rotated.

(Written by orchestrator from the resumed lane's hand-back; the subagent's report.md write was refused.)

UNTOUCHED: none (textract_result.py changed only for #38; #37 needed no change).
OUT-OF-LIST: src/elspeth/plugins/transforms/aws/textract_inline_analysis.py — same substring dispatch as textract_document_analysis.py (#38); both now dispatch on MalformedTextractResponse.category.

Branch lane/p4-safety-aws, base 4ebe6d6b. 44b3bef4 RED tests; 2cb8d9b6 fix.

## Per finding
- #37 ALREADY FIXED by 06c108ea (ancestor of HEAD): `_project_pages` buckets LINE blocks in one pass. Measured pre-fix vs HEAD, 200k blocks: 100 pages 4.31s -> 0.46s; 400 pages 16.28s -> 0.79s; identical output.
- #38 FIXED. RED: 4 tests `assert 'too_many_blocks' == 'malformed_response'` / `'result_too_large' == 'malformed_response'`. Fix: MalformedTextractResponse gains keyword-only `category` (default malformed_response), set at the max_blocks and max_result_bytes sites; both Textract plugins use error.category, not str(error) substrings. COMPAT: audited reason changes only when provider text contains max_blocks/max_result_bytes (now malformed_response); all non-retryable. CHANGELOG: Fixed: Textract transforms record too_many_blocks/result_too_large from a structured error category, so provider text in a malformed response can no longer pick the audited failure reason. Hashes: aws_textract_document_analysis sha256:ea328c39a24bfb22 -> sha256:e45dc8dbaf712404; aws_textract_inline_analysis sha256:10ce458bfa432bdf -> sha256:8fbbdb2d684a9029.
- #127 FIXED. RED: `assert 'Default thresholds' not in ...`. Fix: hint says every category threshold is required, has no default, lower is stricter. COMPAT: planner-teaching text only. CHANGELOG: Fixed: the azure_content_safety composer hint no longer claims a default threshold of 4. Every category threshold is required, and lower values are stricter. Hash: azure_content_safety sha256:6869d9e7a5f59d57 -> sha256:20e51c74725215d4.
- #145 FIXED. RED: `assert ['safe'] == []` (field a sent before field b found invalid). Fix (process() only): validate every field first, then shutdown/deadline checks and calls, as azure/base.py. Kept clear of __init__/config for the row_deadline_seconds lane. COMPAT: a row with any invalid field fails with the same payload and makes no Bedrock call (no billed call, call record or telemetry for earlier fields); validation error now precedes a shutdown/deadline result. CHANGELOG: Fixed: the Bedrock guardrail transforms validate every configured field before the first ApplyGuardrail call, so a later invalid field no longer lets earlier fields be sent and billed. Hash: shared base, concrete plugin files unchanged.
- #158 FIXED. RED: 8 cases at pytest.raises(ValidationError). Fix: `_QUERY_TEXT_PATTERN` compiled with re.ASCII. COMPAT: non-ASCII whitespace in query text/alias rejected at config load (provider already rejected per row). CHANGELOG: Fixed: Textract query text and alias validation rejects non-ASCII whitespace (e.g. U+00A0) at config load, matching the provider pattern.
- #159 FIXED. RED: 65-char alias validated. Fix: `alias: str = Field(max_length=64)`. COMPAT: aliases >= 65 chars fail at web config load naming `alias`. CHANGELOG: Fixed: Bedrock guardrail profile aliases are limited to 64 characters at config load, matching the live check.

## Maintainer decisions
None.

## Gates (lane-reported, final tree 2cb8d9b6)
Lane tests 25 passed (RED: 17 failed at assertions, 8 passed); hashes match for 3 plugin files, old tokens absent from manifest (control 24 hits); check_contracts 0; plugin_contract rules 0 (negative control went red); ruff/format/mypy 0; test_no_hasattr_branching passed; module tests -n 3: 1155 passed; keyless trust-tier --rules all identical to base (3812 lines). No signed fingerprints rotated.

## Caveats
No full suite or testcontainer run (no schema/SQL/persistence touched).
