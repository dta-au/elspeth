DONE, with one known gap: #18, #68, #112 and #138 are fixed on lane/p2-018-068-112-138-deep-nesting. Each finding has one test commit and one fix commit. A JSONSource JSONL row about 1500 levels deep still crashes the run, in audit hashing; json_source.py belonged to lane-06, so it was left for a follow-up.

(The hub wrote this report from lane-03's hand-back, because the harness refused the lane's own report write. The logs are in logs/.)

## Commits
| Finding | Test | Fix |
|---|---|---|
| #18 | 43a899d4 | 6fd3569e |
| #68 | 97798345 | 4004c0eb |
| #112 | f5eae338 | 6e5f2021 |
| #138 | 67de2cfb | 2dd14a46 |

## Shared root cause
On Python 3.14 the C JSON decoder no longer counts nesting against the recursion limit, so it decodes about 20k levels. The crash then happens later, in a recursive walker or in hashing (stable_hash fails at depth 1500). Catching RecursionError around json.loads therefore does not help.

**Fix at every site:** run the existing `check_json_depth` before decoding, with `MAX_JSON_DEPTH=64`. This is the same bound aws_s3 and Power Automate already use. `parse_json_bounded` was not used because it also rejects duplicate keys and overflowing floats, which are unrelated behaviour changes.

**Compatibility:** JSON nested deeper than 64 levels is now quarantined or errored in four places: azure_blob, blob_json_expand, LLM response parsing, and observed/coercing source schemas. Before this change it was accepted up to about 900 levels.

## Per finding
**#18 azure_blob.**
- Fix: a whole-file JSON array that is too deep is quarantined at file level; a too-deep JSONL line is quarantined at line level, and later lines still load.
- Re-pin: c5f9aa22ec4da71d → 5cdeb02ae492c2f7.
- RED: 3 failed. GREEN: 106 passed.

**#68 blob_json_expand.**
- Fix: `_check_json_nesting` raises `invalid_json`/`nesting_too_deep` before decoding, and the row goes to on_error.
- Re-pin: 5bc93feb6e7900bd → 86a847226bed8d18.
- RED: 4 failed. GREEN: 104 passed.

**#112 schema_factory walker.**
- Fix: the walker is depth-bounded and raises `PydanticCustomError("nesting_too_deep")`.
- `NESTING_TOO_DEEP_ERROR_TYPE` is registered in contracts/safe_validation_errors.py, so the error renders by name instead of as `[custom]`.
- RED: confirmed, re-checked after one test amend. GREEN: 1238 passed.

**#138 LLM validation.**
- Fix: `check_json_depth` runs inside both existing try blocks, so deep responses become `invalid_json`/`json_parse_failed`.
- RED: 6 failed. GREEN: 3152 passed.

## Gates (2dd14a46)
| Gate | Result |
|---|---|
| ruff | 0 |
| format | 0 |
| check_contracts | 0 (census unchanged) |
| mypy, 5 src files | 0 |
| plugin_hashes lint | 0 |
| keyless trust-tier corpus | 3778 findings before and after; 4 line shifts, no new findings |
| dag + architecture, -n 2 | 2266 passed, 2 failed |

The 2 dag/architecture failures were xdist worker crashes in test_web_landscape_mutation_fencing. Both pass serially.

## Left alone
- **json_source.py (the gap above):** it needs the same pre-decode check in `_load_jsonl` and `_load_json_array`.
- **No audit-hash fallback** for rows too deep to hash.
- **Dataverse and LLM sources:** not checked for pre-decode depth bounds.
- **Performance:** `check_json_depth` adds a per-character cost on very large azure blobs.
