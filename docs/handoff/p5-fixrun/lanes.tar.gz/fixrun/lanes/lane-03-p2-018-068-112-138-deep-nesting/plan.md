# lane-03-p2-018-068-112-138-deep-nesting — #18 [P2, bug] azure_blob JSON/JSONL parsing crashes the run on deeply nested input (RecursionError not quarantined); #68 [P2, bug] blob_json_expand: deeply nested untrusted JSON raises RecursionError, which aborts the whole run instead of routing to on_error; #112 [P2, bug] Source-boundary non-canonical-number walker throws RecursionError on deeply nested Tier-3 JSON, so the run crashes instead of quarantining the row; #138 [P2, bug] LLM structured-output parsing does not catch RecursionError, so deeply nested JSON in a response crashes the run instead of going to on_error

Ticket `p2-018-068-112-138-deep-nesting` · run `p2` · branch `lane/p2-018-068-112-138-deep-nesting` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

This lane fixes 4 findings; fix each one (one test commit + one fix commit PER finding).
The listed files are where the sweep located each defect; a finding may need no change in some of them.

FINDING #18 [P2, bug] azure_blob JSON/JSONL parsing crashes the run on deeply nested input (RecursionError not quarantined)

`src/elspeth/plugins/sources/azure_blob_source.py`

Lines 984-989 (_load_json_array) and 1063-1065 (_load_jsonl) call json.loads(...) and catch only (json.JSONDecodeError, ValueError). For deeply nested input, CPython's json scanner raises RecursionError. That is a RuntimeError subclass, not a ValueError, so it escapes the Tier-3 boundary. Payloads like b'['*100000 + b']'*100000 (about 200 KB, far below the 256 MiB max_object_bytes default), or one such JSONL line, crash load(). The run aborts instead of the file or line being recorded with ctx.record_validation_error and routed to on_validation_failure. This breaks the tier model: external blob bytes must be parsed and quarantined, never allowed to crash the pipeline. One hostile line in a JSONL blob kills every other good row. The sibling aws_s3_source bounds nesting explicitly (_MAX_JSON_DEPTH = 64 at aws_s3_source.py:72, raising _JSONBoundaryError, a ValueError subclass, at lines 708/736/768), so this is an asymmetry, not a policy choice. Expected: catch RecursionError, or better, enforce a depth bound like S3's, and quarantine (file-level for json, line-level for jsonl). Verification: a read-only scratch probe (worktree src on sys.path, elspeth.__file__ confirmed inside the worktree) passed the payload to AzureBlobSource._load_json_array and _load_jsonl. Both raised RecursionError out of json/decoder.py raw_decode with no validation record. rg for 'recursion|nest|depth' in tests/unit/plugins/sources/test_azure_blob_source.py and tests/property/plugins/sources/test_azure_blob_source_properties.py finds only an unrelated data_key docstring, so no test covers this. Side note: json_source.py has no RecursionError handling either (rg), so the local JSON source likely shares the defect; it is outside this slice and was not verified.

**Verifier (CONFIRMED):** Read azure_blob_source.py:984-989 and :1063-1065: json.loads guarded only by (JSONDecodeError, ValueError). Repro .claude/lanes/20261111-plugins-review/scratch-B/repro_azure.py: depth 100000 (~200KB) -> RecursionError raised from json/decoder.py:345 via azure_blob_source.py:985 (json) and :1064 (jsonl), with 0 validation errors recorded; in JSONL the good row before it was already yielded, rows after are lost. No guard upstream: source_iteration.py:484-486 and :986-988 emit phase error and re-raise; no setrecursionlimit in src/. Note: at moderate depth (1500) json.loads succeeds and the crash instead comes from the schema walker (azure_blob_source.py:1237 -> model_validate), i.e. finding #112 -- so a depth bound before validation fixes both.

FINDING #68 [P2, bug] blob_json_expand: deeply nested untrusted JSON raises RecursionError, which aborts the whole run instead of routing to on_error

`src/elspeth/plugins/transforms/blob_json_expand.py`

blob_json_expand.py:840 and :848 call json.loads on untrusted Tier-3 text (blob bytes, or a row field on source='field') and catch only json.JSONDecodeError. Measured: json.loads('[' * 200000) raises RecursionError ('maximum recursion depth exceeded while decoding a JSON array'). RecursionError is not a _BlobJSONParseError. process() lets it escape, and the transform executor (transform.py:959-986) records the state as FAILED and re-raises it. engine/error_boundary.py:8-16 lists RecursionError in _PROGRAMMING_ERRORS, so it is treated as an engine crash rather than a row error. One hostile or malformed document, for example a CSV cell of opening brackets read with source='field', ends the run. The module docstring says the opposite: 'every parse failure is a value-level error routed by on_error, never a crash'. Sibling parsers of untrusted JSON already catch it: web_scrape_json_extraction.py:197 uses `except (json.JSONDecodeError, RecursionError)`, as do mcp/sql_policy.py:604 and azure/base.py:543. Expected: catch RecursionError next to JSONDecodeError in both parse paths and raise _BlobJSONParseError(invalid_json, error_type='nesting_too_deep'). rg for 'Recursion|nesting|deep' in tests/unit/plugins/transforms/test_blob_json_expand.py found only an unrelated deep-freeze comment, so no test covers this.

**Verifier (CONFIRMED):** blob_json_expand.py:836-851 catches only json.JSONDecodeError around json.loads. Measured json.loads depth: 5000 ok, 20000 RecursionError (20 KB of '[' — far below DEFAULT_MAX_BLOB_BYTES=100MiB; source='field' has no byte cap). Repro scratch-E/f68_69.py: BlobJSONExpand(source='field', format json and jsonl).process(row with content='['*20000) RAISED RecursionError out of process(). Escape check: transform.py:959-986 records FAILED and re-raises; processor.py:2542-2554 is_retryable returns False for RecursionError and the outer handler only converts InterruptedError/MaxRetriesExceeded/PluginContractViolation, so it propagates as a run crash; error_boundary.py:8-16 lists RecursionError as a programming error. Contradicts module docstring line ~23 ('never a crash'). Siblings catch RecursionError (call_mode_session.py:176, source_read_verification.py:73).

FINDING #112 [P2, bug] Source-boundary non-canonical-number walker throws RecursionError on deeply nested Tier-3 JSON, so the run crashes instead of quarantining the row

`src/elspeth/plugins/infrastructure/schema_factory.py`

schema_factory.py:30-73 `_find_non_canonical_number_path` recurses once per nesting level, plus one more frame for the trust_boundary wrapper around is_non_canonical_number. It has no depth bound. `_ObservedPluginSchema._validate_canonical_numbers` (line 101-104) runs it inside `model_validate` for every source schema: observed mode, and explicit mode with allow_coercion=True. Pydantic does not turn a RecursionError raised inside a validator into a ValidationError. Sources catch only ValidationError, ContractFieldLimitExceeded and ExternalHeaderError (json_source.py:580-665), so the RecursionError escapes `load()`. Python's C json parser accepts much deeper input: `json.loads` succeeded up to about 8000 levels and failed at 16000. So a single external JSONL line nested about 1000 levels deep parses fine and then kills the run. The tier model expects the source to quarantine this malformed external row through on_validation_failure. VERIFIED: in the worktree (elspeth.__file__ resolves inside it), `JSONSource({...observed...})._validate_and_yield(json.loads('{"id":1,"x":'+'['*1500+']'*1500+'}'), ...)` raised RecursionError. The traceback runs json_source.py:596 -> pydantic model_validate -> schema_factory.py:103 -> :78 -> :47/:54 (recursive) -> trust_boundary.py:249. Depth 500 passed validation. Sibling asymmetry: aws_s3_source.py:72 already enforces `_MAX_JSON_DEPTH = 64`, and contracts/json_parser.py:38 has `check_json_depth`, but json_source, blob, dataverse and LLM sources rely on this walker. Expected: the walker either walks iteratively or catches RecursionError, and raises a PydanticCustomError so the row is quarantined. Alternatively, all JSON-family sources apply a shared depth cap before validation. rg found no test in tests/unit/plugins/infrastructure or tests/unit/plugins/sources that covers deep nesting through the schema factory.

**Verifier (CONFIRMED):** Read schema_factory.py:29-73 (unbounded recursive _find_non_canonical_number_path) and :101-104 (model_validator after). Repro .claude/lanes/20261111-plugins-review/scratch-B/test_scratch_json.py::test_deep with the real JSONSource load() on JSONL: depth 500 -> 3 valid rows; depth 1500 (json.loads accepts it) -> RecursionError escapes load() after the first row, no quarantine. Same path reproduced via azure_blob (azure_blob_source.py:1237) in .claude/lanes/20261111-plugins-review/scratch-B/repro_azure.py at depth 1500. No catch upstream (source_iteration.py:484-486, :986-988 re-raise); RecursionError is not a ValidationError so Pydantic does not convert it. Default recursion limit is 1000 and src/ never raises it.

FINDING #138 [P2, bug] LLM structured-output parsing does not catch RecursionError, so deeply nested JSON in a response crashes the run instead of going to on_error

`src/elspeth/plugins/transforms/llm/validation.py`

validation.py:287-296 (extract_structured_fields) and 172-178 (validate_json_object_response) catch only (json.JSONDecodeError, ValueError) around json.loads of Tier-3 LLM content. Checked: json.loads('[' * 200000) and json.loads('{"a":' * 200000) raise RecursionError, a RuntimeError subclass that neither clause catches. Callers do not catch it either: transform.py:455 and :820, and sources/llm/source.py:472. The transform executor (engine/executors/transform.py:959-986) records the node state FAILED and re-raises, so one adversarial or degenerate provider response aborts the pipeline instead of producing TransformResult.error / on_validation_failure. Sibling Tier-3 JSON boundaries already catch it: provider.py:52, web_scrape_json_extraction.py:197, web_scrape_response.py:125, azure/base.py:543. Expected: add RecursionError to the except tuple and return a json_parse_failed reason with a fixed message (no content echo).

**Verifier (CONFIRMED):** Repro scratch-F/r138.py. json.loads('['*d) raises JSONDecodeError for d<=5000 and RecursionError for d>=10000, so about 10 KB of brackets is enough and fits well within normal output budgets. validation.validate_json_object_response('{"a":'*100000) lets RecursionError escape (except clauses at validation.py:172-178 and 287-296 catch only JSONDecodeError/ValueError). extract_structured_fields is called unguarded at transform.py:455 (and the multi-query path around :820). The batch mixin wraps worker exceptions as ExceptionResult and re-raises them in the orchestrator thread (batching/mixin.py:327-355). The executor records FAILED and re-raises (executors/transform.py:959-986). engine/error_boundary.py:8-16 lists RecursionError in _PROGRAMMING_ERRORS, so the engine treats it as crash-through. Sibling Tier-3 parsers catch RecursionError (provider.py:52, web_scrape_json_extraction.py:197, web_scrape_response.py:125, azure/base.py:543). One provider response can abort the run.

## Files a correct fix must change

- `src/elspeth/plugins/sources/azure_blob_source.py`
- `src/elspeth/plugins/transforms/blob_json_expand.py`
- `src/elspeth/plugins/infrastructure/schema_factory.py`
- `src/elspeth/plugins/transforms/llm/validation.py`

## Test files the lane must add or change

- `tests/unit/plugins/test_deep_nesting_p2_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/test_deep_nesting_p2_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-03-p2-018-068-112-138-deep-nesting/report.md`; the worker returns one line.
