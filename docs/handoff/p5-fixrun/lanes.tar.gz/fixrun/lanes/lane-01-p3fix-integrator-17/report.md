DONE: lane-01-p3fix-integrator-17 fixed the integrator's 17 (+1: sink-csv hint) full-suite failures and the planner scaffold budget overflow from ce2d6e08; commits 179f288c..0378ab72 on lane/p3fix-integrator-17 (base 6dea3074).

(Written by orchestrator from the agent's hand-back; the agent's report write was refused. Planner-budget commit 0378ab72 by the hub.)

## Fixes
- 179f288c blob_{text,csv,json}_expand: production _InvariantPayloadStore (inside execute_forward_invariant_probe) gains retrieve_bounded with real semantics (negative cap ValueError, unknown ref PayloadNotFoundError, over cap None); unused retrieve removed. New tests/unit/plugins/transforms/test_blob_expand_probe_payload_seam.py (blob_too_large at max_blob_bytes=1). Hashes re-pinned x3. Root cause #95 (26849d90).
- 0b532a4f/3d1dbf8f CSVSourceConfig refuses non-text codecs via "".encode(v) like CSVSink (#26). Composer proof test runtime half now expects PluginConfigError("not a text encoding"). Root cause #80 incremental decoder. json/text/azure_blob sources keep lookup-only validator (left).
- 1f0299cf collector tests: bisected to 44fd1af6 (#99, batch_stats float_overflow). collector_transform_error is correct (plugin returns TransformResult.error). Tests only; row-type test keeps assertions by monkeypatching _SAFE_INTEGER_MAX.
- 5500f040 Dataverse sink hint 319->276, CSV sink hint 322->278; hashes re-pinned.
- 0378ab72 DatabaseSink docstring summary (planner 'purpose') 'Append rows to an operator-provisioned database table.' (+23 B) -> 'Append rows to an existing table.' (+2 B); scaffold 141,086 -> under 141,070 ceiling (ceiling unchanged). Measured by dumping/diffing the canonical scaffold base vs head. Hash d8b9d59430a7d1bd.

## Evidence
- Agent: invariants+integration/pipeline+unit/contracts+unit/web/composer -n 2: 21195 passed, 2 failed (planner budget, then fixed by 0378ab72). ruff/format/mypy/check_contracts/plugin-hash lint 0; keyless corpus identical.
- Hub: planner+catalog+db sink+assistance coverage+composer tools 728 passed exit 0.

## COMPAT
- CSVSource with a non-text codec now fails at config (could never read a row since #80).
- batch_stats int sum beyond JSON safe range reports collector_transform_error (from #99).
