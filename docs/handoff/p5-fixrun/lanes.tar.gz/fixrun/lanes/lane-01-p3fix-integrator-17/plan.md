# lane-01-p3fix-integrator-17 — Fix 17 full-suite failures the integrator found on 2924b3d1 (invariants fixture retrieve_bounded, CSVSource bytes codecs, collector classification, Dataverse sink hint length)

Ticket `p3fix-integrator-17` · run `p3fix` · branch `lane/p3fix-integrator-17` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

See brief addendum.

## Files a correct fix must change

- `src/elspeth/plugins/sources/csv_source.py`

## Test files the lane must add or change

- `tests/unit/plugins/sources/test_p3fix_integrator.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/sources/test_p3fix_integrator.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-01-p3fix-integrator-17/report.md`; the worker returns one line.
