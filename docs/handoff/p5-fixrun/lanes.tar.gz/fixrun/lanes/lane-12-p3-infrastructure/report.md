lane-12-p3-infrastructure: all 7 findings (#126, #129, #149, #104, #0, #6, #100) fixed test-then-fix on lane/p3-infrastructure (14 commits, HEAD 9c7d512e, base 1ee11f2e); final gates exit 0.

(Written by orchestrator from the lane's hand-back; the subagent's report.md write was refused.)

## Fixes
- #126 PluginManager.create_* resolves class from itself and validates via validate_*_config(plugin_cls=...).
- #129 discovery OPTIONAL_PLUGIN_IMPORT_MODULES = {jinja2}; missing core deps raise. reviewed-writer-recipes discovery.py pin re-pinned (controlled).
- #149 chroma readiness probe: persistent path not an existing dir -> reachable=False, no client created.
- #104 runtime_factory: unknown export sink -> ValueError for every purpose (COMPAT: FRESH now refuses a mistyped export sink); landscape.export ${VAR} expanded for eligibility; deferred KV var defers the raw gate. cli.py _preflight_raw_settings_sink_effects reads the same way.
- #0 BaseTransform.column_keyed_config_keys; Truncate declares {"fields"}; fixed-schema check accepts canonical spelling. MAINTAINER: normalisation applies to all column options (list option spelling a header no longer refused at construction). Truncate hash sha256:61cdc3ececd46174.
- #6 template render timeout classified by worker CPU (/proc stat): CPU >= 2s budget -> row TemplateError; below -> retryable TemplateWorkerLostError. templates.py recipes pin re-pinned.
- #100 MultiQueryStrategy._execute_parallel records PoolExecutionContext in context_after (cumulative executor stats, not per-row deltas). node_state_context QueryOrderEntryInput read-only properties. LLMTransform hash sha256:66b97c9f1d3c8458. CONFLICT with lane-08 (llm/transform.py + its hash) expected.

## Evidence (lane-reported)
- RED per finding at assertions; GREEN sweep 24 passed; modules 158/34/73/137/106/467/264/3225/31 passed.
- ruff/format/check_contracts/mypy(11 files)/masquerade/trust_boundary/plugin_hashes (controlled)/branch-safety 0.
- Fencing test_required_work_reserve_admission_on_actual_sources passed. Keyless all-rules corpus diff not run.
