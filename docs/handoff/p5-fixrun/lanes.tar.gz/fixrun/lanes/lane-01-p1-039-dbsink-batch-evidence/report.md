FIXED #39: DatabaseSink plan evidence now binds rows by payload_hash + member_count only (row-count independent); commit rows are restaged from durable members via RestagingSinkEffectCapability. Test b51a7fc2 RED->GREEN, fix 2ac6d93f, rebased onto 21e74acc, verified on Python 3.14.6; full core/dag+architecture run did not complete (host OOM-killed xdist workers), targeted pins green; Postgres testcontainer not run (no Docker).

# Lane 01 — p1-039-dbsink-batch-evidence

Branch `lane/p1-039-dbsink-batch-evidence` in worktree
`.claude/worktrees/compassionate-brahmagupta/.claude/worktrees/lane-p1-039-dbsink-batch-evidence`.
`git log --oneline claude/compassionate-brahmagupta-o0nhlw..HEAD` (base 21e74acc):

- `b51a7fc2` test(plugins): pin DatabaseSink publication of batches above the evidence bound
- `2ac6d93f` fix(plugins): bind DatabaseSink effect rows by hash, not in plan evidence

Rebase history: originally 4a6b4ccd/f0358926 on 1a7ff0e6 -> rebased onto
c198cee8 (2ed4da89/5fbe1f72) -> per coordinator, `git rebase --onto
claude/compassionate-brahmagupta-o0nhlw c198cee8` onto 21e74acc. Only conflict
each time: `config/cicd/soft-mapping-census.yaml`, resolved by taking the base
version and regenerating with `scripts/check_contracts.py --write-census`.
database_sink.py and the sink-effect contract/executor are unchanged between
1a7ff0e6 and 21e74acc, so the source hash and session-db identities held
(re-verified live on 21e74acc). Not pushed.

## Root cause

`src/elspeth/plugins/sinks/database_sink.py` (base lines 608-636,
`prepare_effect`) put every serialized member row into
`safe_evidence["members"]`. `SinkEffectPlan.__post_init__`
(`src/elspeth/contracts/sink_effects.py:1484`) runs `_freeze_bounded_evidence`,
which raises ValueError above `_SINK_EFFECT_EVIDENCE_MAX_BYTES = 64 KiB`
(sink_effects.py:31, 287-288). The orchestrator hands each sink one effect for
all pending rows, so any load above ~64 KiB failed at prepare.
`commit_effect(plan, ctx)` only receives the plan, which is why rows had been
put in it. Even per-member hashes (~90 B each) would cap at ~700 members, so
the evidence must be independent of row count.

## Fix (database_sink.py)

- Plan evidence schema `database-effect-plan-v2`: `members` -> `member_count`.
  Rows stay bound exactly as before by `plan.payload_hash` =
  sha256(canonical_json([{ordinal, payload_hash, row}, ...])); `plan_hash`
  still binds the evidence.
- `DatabaseSink` inherits `RestagingSinkEffectCapability` (the existing nominal
  opt-in used by S3/Azure). `restage_effect` re-derives SQL rows from durable
  members using the plan's target columns, checks count and payload hash
  against the plan (DatabaseEffectLedgerError on divergence), and stages them
  per effect_id. The executor (`engine/executors/sink_effects.py:790`) always
  calls restage right before `_commit` for restaging adapters, resume
  included. `prepare_effect` also stages, so in-process prepare->commit is
  unchanged.
- `commit_effect`: an existing marker still answers without rows (replay /
  race loser); otherwise it requires staged rows bound to this payload hash
  and refuses before any write. Staged rows are dropped after commit and on
  `close()`. `reconcile_effect` uses `member_count`.
- `_serialize_any_typed_fields`: nested dict/list values now use RFC 8785
  `canonical_json` instead of `json.dumps`. Required for recovery: the payload
  store hands restage canonical rows (sorted keys, 1.0 -> 1), so json.dumps
  text would differ from the in-run text and restage would fail closed. The
  plan already named its serializer `rfc8785-sql-payload-v1`. Mutation
  control: reverting to json.dumps turns
  `test_recovery_restages_rows_from_durable_members_before_commit` red with
  "Database effect restage members diverge from the plan payload hash".

## Compatibility / behaviour changes

- Stored text for nested JSON values: `{"k": 1}` -> `{"k":1}` (sorted, compact; same JSON value).
- v1 plans are refused by the v2 parser. They cannot be resumed by new code anyway:
  resume refuses a changed plugin `source_file_hash`
  (`engine/orchestrator/implementation_compatibility.py`, PLUGIN_IMPLEMENTATION_CHANGED). No compat path added.
- A direct `commit_effect` on a fresh instance with no marker and no `restage_effect` now
  refuses (no executor path does this). Two existing tests did this and now restage first:
  `tests/integration/plugins/sinks/test_database_sink_effects.py` (response-loss test) and
  `tests/testcontainer/plugins/test_database_sink_effects_postgres.py` (race test).

## Re-pins in the fix commit (outside the listed file, why: whole-tree gates)

- `DatabaseSink.source_file_hash` -> `sha256:70aba8010449fa68` (equals
  `compute_source_file_hash` on 21e74acc; old hash had no other references).
- `config/cicd/soft-mapping-census.yaml` (`--write-census`): database_sink.py
  dict[str, Any] 9->10, dict[str, object] 4->3; soft total unchanged (2668).
- `tests/golden/state_engine/plugin_lifecycle_matrix.json`: sink:database
  `sink_effect_capability` contract -> restaging (mechanical field).
- `tests/unit/architecture/test_session_db_mutation_authority.py`: DatabaseSink
  connection identities, commit_effect fingerprint a1ed0f32c96a6da4 ->
  f259e8651bc82bb6, lines 500/913/933 -> 506/934/954 (from `scan_production_writers`).

## Evidence

RED on the final base (Python 3.14.6; detached worktree at b51a7fc2, removed after),
`pytest tests/unit/plugins/sinks/test_database_sink_large_batch.py -n 0 -q -p no:cacheprovider`, exit 1:
```
E       AssertionError: prepare_effect refused a batch above the evidence bound: safe_evidence canonical JSON exceeds the 64 KiB limit
E       AssertionError: prepare_effect refused a batch above the evidence bound: safe_evidence canonical JSON exceeds the 64 KiB limit
E       AssertionError: DatabaseSink must rebuild commit rows from durable members
3 failed in 11.46s
```
(Same RED on 1a7ff0e6/Python 3.13 and on c198cee8/3.14.)
GREEN at 2ac6d93f, same command: exit 0, `3 passed in 6.49s`.

## Gates (final: 21e74acc + 2 commits, Python 3.14.6, PYTHONPATH=worktree src + elspeth-lints/src)

- ruff check src/ tests/: exit 0
- ruff format --check src/ tests/: exit 0
- scripts/check_contracts.py: exit 0 (census 2668 soft / 426 files / 70 boundary)
- mypy src/elspeth/plugins/sinks/database_sink.py: exit 0
- module tests `-n 2` (large_batch, database_sink_effects, test_database_sink, _resume,
  database_effect_diversion, e2e csv_to_database, cli_resume_sink_capability,
  state_engine_plugin_matrix, sink_effect_preflight, sink_protocol_compliance, masquerade gate): exit 0, 437 passed, 1 skipped
- `tests/integration/core/dag tests/unit/architecture -n 2`: DID NOT COMPLETE. Stopped at the
  2 h background cap at ~97%; every `F` printed coincided with `[gwN] node down: Not properly terminated`
  (8 worker deaths); `dmesg` shows 13 OOM "Killed process" entries; host had ~1 GB free with sibling
  lanes' suites running. No assertion failure was observed, but the run is not a pass.
  Same pattern in two pre-rebase attempts on 3.13.
- Targeted architecture gates `-n 0`: test_all_production_sessions_writers_are_reviewed_typed_authorities,
  test_live_connection_domain_classification_is_exact, test_state_engine_evidence_selectors.py: exit 0, 31 passed, 1 xfailed.
- Pre-rebase (3.13, 1a7ff0e6) broader module run incl. sink_effect_executor, replay_sink_diversions,
  discovery, cli_resume_schema_validation: exit 0, 576 passed.

## Left alone / caveats

- Full `tests/integration/core/dag tests/unit/architecture` needs a rerun on a less loaded host.
- PostgreSQL testcontainer test updated but NOT run: Docker unavailable (`docker info` exit 1). Run
  `pytest tests/testcontainer/plugins/test_database_sink_effects_postgres.py -m testcontainer -n 0`.
- mypy over test files reports `tests/fixtures/base_classes.py:288` (untouched file) and, on 3.13,
  `test_database_sink_effects.py:348` (untouched line); not addressed.
- Trust-tier allowlist signatures not examined; any churn for database_sink.py is for the operator to re-sign.
- Staged rows live in memory per sink instance (already in memory as effect input); no on-disk spool.
