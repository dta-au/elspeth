# lane-01-p1-039-dbsink-batch-evidence — #39 DatabaseSink cannot publish a sink batch whose rows exceed 64 KiB: every member row is embedded in the bounded plan safe_evidence

Ticket `p1-039-dbsink-batch-evidence` · run `p1` · branch `lane/p1-039-dbsink-batch-evidence` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

FINDING #39 [P1] DatabaseSink cannot publish a sink batch whose rows exceed 64 KiB: every member row is embedded in the bounded plan safe_evidence
File: src/elspeth/plugins/sinks/database_sink.py
Sweep evidence: database_sink.py:608-636 (prepare_effect) puts every serialized member row into safe_evidence['members']. SinkEffectPlan.__post_init__ (contracts/sink_effects.py:1484) passes safe_evidence through _freeze_bounded_evidence, which raises ValueError when the canonical JSON is over _SINK_EFFECT_EVIDENCE_MAX_BYTES = 64*1024 (sink_effects.py:31, 287-288). The orchestrator writes each sink once after the whole source loop (leader_drain.py:300 flush_and_write_sinks; sink_flush.py groups all pending tokens per outcome into one sink_executor.write), so one effect holds every row bound for that sink. Any real table load therefore fails at prepare. DatabaseSink is the only sink that embeds full rows in evidence (rg '"row": ' over plugins/sinks/*.py finds only database_sink.py). Verified two ways. (1) Direct: _prepare() from tests/integration/plugins/sinks/test_database_sink_effects.py works with 10 rows but raises 'ValueError safe_evidence canonical JSON exceeds the 64 KiB limit' with 200 rows of {id, name: 500 chars}. (2) End to end: the tests/e2e/pipelines/test_csv_to_database.py pipeline (CSV, PassTransform, DatabaseSink on SQLite, observed schema, run under tests.conftest) completes with 50 rows; with 2000 tiny rows (id, nameN, score) the run raises the same ValueError. The existing e2e and integration tests use 3 to 5 rows, so nothing catches this. Expected: plan evidence should bind rows by hash (the members already carry payload_hash) or by bounded chunks, and commit should take row values from the durable member payloads. Alternatively the executor should split effects so each stays under the evidence bound. A database sink should not fail with an opaque contract ValueError once the output passes about 64 KiB.
Independent verifier (CONFIRMED): database_sink.py:608-622 appends every serialized row into safe_evidence['members'] (line 630); SinkEffectPlan.__post_init__ (sink_effects.py:1485) -> _freeze_bounded_evidence raises ValueError over _SINK_EFFECT_EVIDENCE_MAX_BYTES=64KiB (sink_effects.py:32, 287-288). No member chunking in engine/executors/sink*.py. Direct repro scratch-E/f39_direct.py via tests/integration/plugins/sinks/test_database_sink_effects.py::_prepare: 10 rows OK, 200 rows x 500-char name -> 'ValueError safe_evidence canonical JSON exceeds the 64 KiB limit'. E2E repro scratch-E/test_f39_e2e.py (reuses tests/e2e/pipelines/test_csv_to_database.py under tests.conftest, -n 0): 50 rows -> run COMPLETED (only the hard-coded ==5 assert failed); 2000 tiny (id,nameN,score) rows -> orchestrator.run raises the same ValueError at sink_effects.py:288. No doc states a row/size cap for DatabaseSink; a ~2k-row table load is a realistic configuration made unusable, so the deliberate bound is not an escape.
Verifier repro scripts (gitignored, read-only reference): .claude/lanes/20261111-plugins-review/scratch-*/ in /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta

## Files a correct fix must change

- `src/elspeth/plugins/sinks/database_sink.py`

## Test files the lane must add or change

- `tests/unit/plugins/sinks/test_database_sink_large_batch.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/sinks/test_database_sink_large_batch.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-01-p1-039-dbsink-batch-evidence/report.md`; the worker returns one line.
