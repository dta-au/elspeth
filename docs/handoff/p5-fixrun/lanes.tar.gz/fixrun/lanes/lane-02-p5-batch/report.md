lane-02-p5-batch: #102 chi_square_statistic is Pearson homogeneity chi-square over the union of categories (disclosure, hint and +64 B allowance removed); #20 one MAX_BATCH_ROWS=4096 authority declared as max_batch_rows on five batch plugins (incl. batch_duplicate_annotator), refused above cap at build and in the composer. RED e7adfdc8 (18 failed at assertions), fixes a28c9b8e d1cf2918, 20 passed; ruff/mypy/contracts/plugin lints 0. Operator re-sign: batch_drift_compare R8 _categorical_shifts fp=dc863616c567763c -> 2522e1065c2c62bc.

(Written by orchestrator from the lane's hand-back; the harness refused the lane's report write.)

CHANGELOG:
- Fixed: batch_drift_compare chi_square_statistic is now Pearson's chi-square test of homogeneity over every category seen in either cohort; categories absent from the baseline now count toward drift instead of being dropped (#102).
- Changed: an aggregation whose trigger.count exceeds a batch plugin's row cap (4096 for batch_outlier_annotator, batch_rank, batch_paired_preference, batch_drift_compare; batch_duplicate_annotator shares the same declared cap) is refused at pipeline build and in the composer instead of failing every batch at flush (#20).

COMPAT:
- BREAKING output values: chi_square_statistic changes for every categorical comparison (both cohorts contribute); re-derive thresholds. Field name/type unchanged.
- BREAKING config: trigger.count > 4096 on those plugins fails validation (previously failed every full batch at runtime).
- New class attribute max_batch_rows (default None on BaseTransform; protocol-only implementations must add it).
- Hashes: batch_rank 9ed1e4527e591e4e, batch_outlier_annotator d399987b55a5358a, batch_paired_preference 6558016bd881b03c, batch_drift_compare 04ff6dd1e539b73f, batch_duplicate_annotator 8355140f7e1278df.
- End-of-source/timeout flushes over the cap are still refused at runtime (size unknown at config time).

Gates: see lane hand-back (ruff/mypy/contracts/plugin lints 0; plugins+contracts+catalog+plugin_policy 19415 passed, 3 failures pass serially; composer 6 failures: 1 own bug fixed in d1cf2918, 1 timing-flaky also on base, 4 pass serially).
