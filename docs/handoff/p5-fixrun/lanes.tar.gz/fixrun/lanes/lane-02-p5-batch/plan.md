# lane-02-p5-batch — #102 chi_square_statistic must account for categories absent from the baseline (fix behaviour, drop the disclosure and the +64 B planner allowance); #20 refuse aggregation trigger.count above the 4096-row flush cap at config time

Ticket `p5-batch` · run `p5` · branch `lane/p5-batch` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

Maintainer ruling 2026-11-14: fix behaviour to be correct; pre-release, breaking changes wanted. #102 was previously 'fixed' by documenting the defect (usage sentence + composer hint + _DRIFT_COMPARE_CHI_SQUARE_DISCLOSURE_CANONICAL_BYTES=64 in tests/unit/web/composer/test_pipeline_planner.py); replace that with a statistically correct treatment of new categories (e.g. chi-square over the union of categories with an explicit, documented handling of zero-expected cells, or a statistic that is defined for them) and remove the disclosure sentence, hint and allowance. #20: the 4096-row cap is enforced only at flush in batch_outlier_annotator, batch_rank, batch_paired_preference, batch_drift_compare; refuse a trigger.count above the cap at config/build time (find where aggregation trigger and the plugin meet; keep one authority for the cap value). Findings text: .claude/lanes/fixrun/p4/plugins-review.md sections #102 and #20.

## Files a correct fix must change

- `src/elspeth/plugins/transforms/batch_drift_compare.py`
- `tests/unit/web/composer/test_pipeline_planner.py`

## Test files the lane must add or change

- `tests/unit/plugins/test_p5_batch_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/test_p5_batch_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-02-p5-batch/report.md`; the worker returns one line.
