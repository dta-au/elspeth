# lane-05-p5-llm-audit — #123 an empty/whitespace LLM completion is recorded with its real classification, not SUCCESS, in AuditedLLMClient and replay (Azure and Bedrock); #128 transform-side LLM configs hide api_key in repr like the sources

Ticket `p5-llm-audit` · run `p5` · branch `lane/p5-llm-audit` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

Maintainer ruling 2026-11-14 (option a): the call row must record the classification (content filter / length budget / other), not SUCCESS, when the completion is empty; replay (_replay_completion and the lane-04-p2-024-044 replay rule) must follow; the pinned test test_audited_llm_client::test_empty_string_content_is_valid encodes the defect and must be replaced. Apply to Azure and Bedrock (execute_query has the same pattern). #128: OpenRouter/Gateway transform configs still print api_key; hide it like Azure/Bedrock (repr=False / SecretStr house pattern). Findings: plugins-review.md #123 #128; lane-07-p3-llm-providers and lane-04-p2-024-044-llm-replay-timeout reports. Touch schema/Landscape persistence? If yes, also run pytest -m testcontainer for touched areas if Docker works.

## Files a correct fix must change

- `src/elspeth/plugins/infrastructure/clients/llm.py`
- `src/elspeth/plugins/transforms/llm/providers/bedrock.py`

## Test files the lane must add or change

- `tests/unit/plugins/test_p5_llm_audit_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/test_p5_llm_audit_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-05-p5-llm-audit/report.md`; the worker returns one line.
