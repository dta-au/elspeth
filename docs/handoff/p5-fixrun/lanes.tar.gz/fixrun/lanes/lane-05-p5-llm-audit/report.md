PAUSED lane-05-p5-llm-audit at 49aa21cd (RED d71c0058, 55 failed at assertions; tree clean): #123 AuditedLLMClient records empty/whitespace completions as ERROR with classify_empty_completion verdict (content_filter/refusal -> FilteredCompletionError; length/other -> EmptyCompletionError; tool_calls -> UnsupportedResponseError), replay re-raises the recorded verdict and refuses blank SUCCESS records; Azure/Bedrock/Gateway/OpenRouter use the shared classifier. #128+F2: repr=False on every plugin credential/tracing field (census test, mutation-checked); ValidationError input echo leak proven and fixed with hide_input_in_errors=True on PluginConfig. Lane test 61 passed; ruff/contracts/plugin lints 0. NEXT: mypy (OOM-killed), module tests for touched packages + web catalog/plugin_policy/composer, keyless tier scan vs lints-base.log, fix docs/guides/troubleshooting.md content_filtered note.

(Written by orchestrator from the lane's pause hand-back; the harness refused the lane's report write.)

CHANGELOG:
- Fixed: an empty or whitespace-only LLM completion is recorded as an ERROR call with its classification (content filter or refusal / token budget / unexplained) on every provider, not as SUCCESS; replay reproduces the same error (#123).
- Security: plugin credential and tracing fields are hidden from repr/str (OpenRouter/Gateway api_key, Azure Blob connection_string/sas_token/client_secret, Azure safety/AI Search/RAG api_key, tracing secrets), and plugin config validation errors no longer echo input values (#128 and siblings).

COMPAT:
- Replay refuses old SUCCESS records with empty content and old response-bearing ContentPolicyError null-content records; such runs must be re-run live.
- Exception types/messages changed: Gateway/Azure/Bedrock empty replies no longer always content_policy; null content with finish_reason=stop is EmptyCompletionError (client); tool_calls raise UnsupportedResponseError.
- Hashes: azure_blob_source 9ee9149d808922ab, azure_blob_sink 29732938fa1803b8, web_scrape 83d5afee544a8d37, textract_document_analysis a5f1d2416cbcdc3d, textract_inline_analysis 90beb1e1b3308d91, ai_search cc0bfaf91c098a98.
- NOTE merge conflicts: azure_blob_sink (also templates + io-validation), azure_blob_source (io-validation), web_scrape (web + http-deadline), ai_search (http-deadline) -> recompute hashes on merged tree.
