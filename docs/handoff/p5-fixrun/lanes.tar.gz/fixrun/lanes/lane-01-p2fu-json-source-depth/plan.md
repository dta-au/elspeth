# lane-01-p2fu-json-source-depth — JSONSource crashes on deeply nested external JSON/JSONL instead of quarantining (deep-nesting follow-up to #18/#68/#112/#138)

Ticket `p2fu-json-source-depth` · run `p2fu` · branch `lane/p2fu-json-source-depth` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

JSONSource._load_jsonl and _load_json_array decode external text with json.loads/json.load and no nesting bound. On Python 3.14 the C decoder accepts ~1500-deep documents that Python-level walkers (audit hashing / canonical_json) then cannot traverse, so the run crashes. Apply the same pre-decode check_json_depth bound (MAX_JSON_DEPTH=64) and quarantine the line/file.

## Files a correct fix must change

- `src/elspeth/plugins/sources/json_source.py`

## Test files the lane must add or change

- `tests/unit/plugins/test_json_source_depth_p2fu.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/test_json_source_depth_p2fu.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-01-p2fu-json-source-depth/report.md`; the worker returns one line.
