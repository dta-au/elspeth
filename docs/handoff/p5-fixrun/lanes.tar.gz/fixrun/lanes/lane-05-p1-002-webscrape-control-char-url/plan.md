# lane-05-p1-002-webscrape-control-char-url — #2 Row URL containing control characters (even a trailing newline) crashes the run via an uncaught httpx.InvalidURL

Ticket `p1-002-webscrape-control-char-url` · run `p1` · branch `lane/p1-002-webscrape-control-char-url` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

FINDING #2 [P1] Row URL containing control characters (even a trailing newline) crashes the run via an uncaught httpx.InvalidURL
File: src/elspeth/plugins/transforms/web_scrape.py
Sweep evidence: web_scrape.py:1324-1399 (row URL admission) and 1945-1967 (_fetch_url exception translation). In the default config (http.allowed_origins empty), validate_allowed_http_origin returns immediately (core/security/web.py:424-425), so its `ord(char) < 32` refusal never runs. validate_url_for_ssrf admits URLs with control characters: urlsplit silently drops \n and \t, and \x00 and \x7f pass through. Measured: 'https://example.com/page\n', '.../a\tb', '.../\x00' and '.../\x7f' all returned ADMITTED. The real request is then sent, and httpx.InvalidURL ('Invalid non-printable ASCII character') is raised. With no query, it comes from the shared client's _follow_redirects_safe (`httpx.URL(original_url)`, http.py:2173). With query/query_fields set, it comes from web_scrape.py:1336, whose local except catches only (TypeError, ValueError, UnicodeError). httpx.InvalidURL subclasses Exception, not ValueError or httpx.RequestError (verified via its __mro__), so neither the process() except list (SSRFBlockedError, SSRFNetworkError, TypeError, KeyError) nor _fetch_url's handlers (httpx.TimeoutException, ConnectError, RequestError, ...) translate it. Effect: Tier-3 row data escapes process() as a raw httpx exception and crashes the run instead of becoming TransformResult.error routed to on_error. A trailing newline in a CSV or LLM-produced URL cell is a realistic input. Expected: refuse control characters in the row URL at admission whatever allowed_origins is set to (the same check validate_allowed_http_origin already does), and/or translate httpx.InvalidURL into a non-retryable row error. The asymmetry is easy to show: with allowed_origins configured the same input gives a clean SSRFBlockedError refusal. Verification: a scratchpad repro drove WebScrapeTransform.process end to end (respx plus patched DNS) with url_field rows 'https://example.com/page\n', '.../\x00', '.../\x7f' and 'https://exa\x00mple.com/'. All four raised httpx.InvalidURL out of process(), both with query={'q':'x'} and with no query. The tracebacks show web_scrape.py:1336 and web_scrape.py:1905 -> http.py:2113 -> 2173. rg over tests/unit/plugins/transforms/test_web_scrape*.py finds no test that uses a control character in a row URL.
Independent verifier (CONFIRMED): Repro scratch-A/repro_ws.py drove WebScrapeTransform.process (respx + patched getaddrinfo, default http config with no allowed_origins) with url_field rows 'https://example.com/page\n', '/\x00', '/\x7f', '/a\tb', both with no query and with query={'q':'x'}. All 8 cases raised httpx.InvalidURL out of process(). No-query cases came from http.py:2173 or httpx _client.py:396. Query cases came from httpx.Request at web_scrape.py:1336, whose local except catches only (TypeError, ValueError, UnicodeError). httpx.InvalidURL.__mro__ is (InvalidURL, Exception, BaseException, object), so web_scrape.py:1389-1396 (SSRFBlocked/SSRFNetwork/TypeError/KeyError) and _fetch_url's handlers at web_scrape.py:1945-1967 do not catch it. No escape upstream: engine/executors/transform.py:959-986 records FAILED and re-raises, and processor.py:2542-2553 is_retryable returns False for it (not PluginRetryableError/ConnectionError/TimeoutError), so it propagates and crashes the run. That is Tier-3 row data crashing the run, against doctrine. Severity P1 kept: a trailing newline in a CSV or LLM cell is realistic.
Verifier repro scripts (gitignored, read-only reference): .claude/lanes/20261111-plugins-review/scratch-*/ in /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta

## Files a correct fix must change

- `src/elspeth/plugins/transforms/web_scrape.py`

## Test files the lane must add or change

- `tests/unit/plugins/transforms/test_web_scrape_control_char_url.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/transforms/test_web_scrape_control_char_url.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-05-p1-002-webscrape-control-char-url/report.md`; the worker returns one line.
