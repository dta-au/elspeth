DONE: web_scrape now refuses any row URL that contains an ASCII control character (C0 or DEL) at admission, returning SSRFBlockedError(kind="malformed_url") as a non-retryable validation_failed row error, so the run no longer crashes on httpx.InvalidURL. Commits 67bcffa1 (test) and 43493cf7 (fix) are rebased onto 21e74acc. RED was 13 assertion failures and GREEN is 20 passed on Python 3.14. The ruff, format, contracts and mypy gates are green, as are the web_scrape suites (405 passed). The DAG/architecture run had 11 failures, all from out-of-memory worker crashes or contention timeouts in tests that do not touch web_scrape; see the gates section.

## Root cause

- `src/elspeth/plugins/transforms/web_scrape.py` row URL admission (`process()`, about line 1324 on the base) passed the row URL straight to `validate_allowed_http_origin`.
- `src/elspeth/core/security/web.py:424-425`: `validate_allowed_http_origin` returns immediately when `allowed_origins` is empty, which is the default. Its control-character check runs only after that early return, and it tests only `ord(char) < 32`. So `\x7f` (DEL) passes even when origins are configured. The test file measured this: on the base tree, the `[del-in-path]` case with allowed_origins failed.
- `validate_url_for_ssrf` admits these URLs: `urlsplit` drops `\n`/`\t`, and `\x00`/`\x7f` pass through.
- httpx rejects any `char.isascii() and not char.isprintable()` (httpx/_urlparse.py:223) with `httpx.InvalidURL`. That exception subclasses Exception only. It is raised from `httpx.Request(...)` in the query path (web_scrape.py:1336, whose local except is `(TypeError, ValueError, UnicodeError)`) or from `clients/http.py:2173` `httpx.URL(original_url)` in `_follow_redirects_safe`. Neither process()'s handlers nor `_fetch_url`'s handlers catch it, so Tier-3 row data crashed the run.

## Fix (src/elspeth/plugins/transforms/web_scrape.py only)

In `process()`, after the `type(url) is not str` check and before `validate_allowed_http_origin`, which is also before any DNS lookup, REPLAY or VERIFY lookup (now line 1338):

    if any(char.isascii() and not char.isprintable() for char in url):
        raise SSRFBlockedError("URL contains an ASCII control character", kind="malformed_url")

- The predicate is exactly the one httpx uses: C0 and DEL. Non-ASCII characters (IRIs) are untouched.
- The existing `except SSRFBlockedError` turns the refusal into `row_url_policy_refusal`: `validation_failed`, `cause="malformed_url"`, value-free audit text. It is not retryable.
- `WebScrapeTransform.source_file_hash` is re-pinned from `sha256:eb90d8e44c6ff93d` to `sha256:0c38862aa7a0f075`, and `compute_source_file_hash == Cls.source_file_hash` is True on the rebased tree. A grep found the old hash in no other tracked file: it is not in the scenario-corpus manifest, any projection SHA or the registry SHA. The base did not touch web_scrape.py, core/security/web.py or clients/http.py, so the pin held across both rebases.

## Test: tests/unit/plugins/transforms/test_web_scrape_control_char_url.py (20 cases, process() end to end, respx plus patched getaddrinfo)

- Six URLs (`\n` trailing, `\t`, `\x00` in the path, `\x7f`, `\x00` in the host, `\r`) × no-query/query, with default origins. Each case asserts that nothing was raised and that the result is `status=="error"`, `reason=="validation_failed"`, `cause=="malformed_url"`, not retryable, with 0 HTTP calls.
- The same six URLs with `allowed_origins` configured. These found the DEL gap.
- A negative control: a clean URL with and without a query still succeeds, with 1 call.

## Evidence

- RED on Python 3.12 against base 1a7ff0e6: `13 failed, 7 passed`. The first failure is `E AssertionError: process() raised httpx.InvalidURL: Invalid non-printable ASCII character in URL, '\n' at position 24.` (12 failures have this form). The 13th is `assert InvalidURL("...'\x7f'...") is None` from the allowed_origins DEL case. Log: red.log.
- GREEN on Python 3.12: `20 passed` (green.log).
- Rebase: first onto c198cee8 (clean), then, per the coordinator, `git rebase --onto claude/compassionate-brahmagupta-o0nhlw c198cee8` (clean, no conflicts). `git log --oneline claude/compassionate-brahmagupta-o0nhlw..HEAD` shows only 43493cf7 and 67bcffa1. The venv was relinked to the hub's 3.14 venv (Python 3.14.6), and `elspeth.__file__` and `elspeth_lints.__file__` resolve into this worktree.
- RED on 3.14 on the new base: `git diff --quiet <base> HEAD~1 -- src` holds. Running the test file against a `git archive HEAD~1` copy gave exit 1, `13 failed, 7 passed`, with 12 `AssertionError: process() raised httpx.InvalidURL` failures (red-newbase.log).
- GREEN on 3.14: exit 0, `20 passed` (green-newbase.log).

## Gates (Python 3.14.6, rebased onto 21e74acc)

| command | exit |
|---|---|
| ruff check src/ tests/ | 0 |
| ruff format --check src/ tests/ | 0 |
| scripts/check_contracts.py | 0 |
| mypy src/elspeth/plugins/transforms/web_scrape.py | 0 |
| pytest tests/unit/plugins/transforms/test_web_scrape*.py tests/property/plugins/web_scrape -n 2 | 0 (405 passed) |
| pytest tests/integration/core/dag tests/unit/architecture -n 2 | 1 (11 failed, 2109 passed, 2 skipped, 70 min; gn-arch.log) |
| scripts/branch-safety-check.sh --intent commit (before each commit) | FAIL=0 WARN=0 |

None of the 11 DAG/architecture failures is in a file that mentions web_scrape (grep count 0):
- 10 are `worker 'gwN' crashed`: the kernel OOM-killed xdist workers (16 GB, no swap, load average around 15 on 4 CPUs, sibling lane suites running) in test_session_db_mutation_authority.py, test_web_landscape_mutation_fencing.py and test_web_reserve_reviewed_contracts.py. The serial reruns came out as follows:
  - test_session_db_mutation_authority.py: exit 0, `298 passed, 1 xfailed`.
  - test_web_landscape_mutation_fencing.py: killed by the 30-min background limit at 46%, with 0 failures so far.
  - test_web_reserve_reviewed_contracts.py: not rerun after that kill. It is NOT verified green.
- 1 is test_dag_recovery_partial_terminal.py::test_partial_terminal_sink_boundary_reopens_and_resumes_exact_survivor_once: `Failed: Timeout (>20.0s)` in setup fixture `explicit_owned_process_watchdog`. The same test on a `git archive` of the unmodified base 21e74acc fails identically (base-dagrec.log), so it is host contention, not this change.
- This change moves exactly one input to those gates, the web_scrape source_file_hash, and its strict equality is verified above.

## Caveats / left alone

- mypy on the new test file reports 3 arg-type errors for the PluginContext fakes. This is the same pattern as the sibling test_web_scrape_pagination.py, which has 34. CI type-checks only src/ and elspeth-lints/src/ (ci.yaml:124).
- `validate_url_for_ssrf` and `validate_allowed_http_origin` in core/security/web.py still admit DEL, and with empty origins they admit all control characters. Other callers of those helpers may share the gap. Hardening the shared helper has wider reach and was not needed for this defect, so I left it for the maintainer.
- Pagination next-URLs and redirect targets come from server responses, not the row URL, so they are out of this finding's scope.
- I did not run the keyless trust-tier lint. The change adds no getattr, try/except or dynamic access.
- No push. The 3.12 DAG/architecture runs were aborted before the rebase. Their partial logs are g-arch-py312-aborted.log and g314-arch-oldbase-aborted.log.
