# lane-02-p3-cloud-blob — #19 [P3, enhancement] azure_blob CSV path decodes the whole blob strictly, so one undecodable byte quarantines the entire file; #28 [P3, bug] aws_s3 CSV per-row probe checks the header with pipeline field names, but the final object uses display headers; #29 [P3, bug] aws_s3 close() sets _closed, but nothing checks it; S3SinkClosedError and other declared failure helpers are never used; #64 [P3, bug] AzureBlobSink.close() does not release the SDK transport or credential it created; #65 [P3, bug] A CSV header that cannot be encoded is treated as a per-row failure: every row is diverted, then prepare crashes; #66 [P3, enhancement] JSON/JSONL output is built fully in memory before max_blob_bytes applies, unlike CSV and the S3 sink; #150 [P3, security] account_url accepts a query string (including a SAS `sig`), which shows in repr and is concatenated to `??`

Ticket `p3-cloud-blob` · run `p3` · branch `lane/p3-cloud-blob` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

This lane fixes 7 findings; fix each one (one test commit + one fix commit PER finding).
Every finding names the files where the sweep located it; touch only what each fix needs.

FINDING #19 [P3, enhancement] azure_blob CSV path decodes the whole blob strictly, so one undecodable byte quarantines the entire file

`src/elspeth/plugins/sources/azure_blob_source.py`

_load_csv (lines 705-727) runs blob_data.decode(encoding) over the whole payload with strict errors. On any UnicodeDecodeError it records one file-level quarantine row ({container, blob_path, error}) and returns, so zero data rows are emitted. In the same plugin, _load_jsonl (lines 1027-1060) decodes with errors='surrogateescape' and quarantines only the offending line (with __raw_bytes_hex__). The sibling aws_s3_source._load_csv (aws_s3_source.py:1135) streams through a strict TextIOWrapper, so it emits the rows before the bad byte and then files a file-level error. The Azure CSV path is the only one of these that throws away every decodable row and records no line locator for the fault. Expected: decode line by line, quarantining the offending record (as JSONL does) or at least emitting the preceding rows with a line number, as S3 does. Verification: the scratch probe fed _load_csv(b'id,name\n1,a\n2,\xff\n3,c\n') and got exactly 1 output, quarantined, with 1 record_validation_error call. Rows 1 and 3, which are valid, were never emitted.

FINDING #28 [P3, bug] aws_s3 CSV per-row probe checks the header with pipeline field names, but the final object uses display headers

`src/elspeth/plugins/sinks/aws_s3_sink.py`

In _preflight_effect_members (aws_s3_sink.py:972-982), each member is probed with _serialize_rows_to_spool(..., fieldnames=probe_fields) and no header_fields, so the CSV header record is checked (record length at :544, encoding through _EncodedTextWriter) using pipeline names. _staged_effect_body (:1010-1021) then writes the real object with header_fields=display_fields, built from ORIGINAL or CUSTOM headers. The probe exists to catch row-attributable failures before the whole-object write, and it checks different header bytes from the ones actually written. Example: csv_options.encoding=ascii (or latin-1) with headers={'name': 'Café'}, or ORIGINAL mode where the source header is non-ASCII. Every row passes the probe. The final _serialize_rows_to_spool then raises S3RecordSerializationError from prepare_effect, so the whole sink effect fails with no row attribution and only the static message 'S3 output record could not be serialized safely.' The same mismatch applies to the max_record_chars check on the header. The sibling azure_blob_sink probe (_preflight_effect_members -> _serialize_rows -> _serialize_csv -> _get_field_names_and_display, azure_blob_sink.py:651-664 and :880-930) does include display headers. Expected: the probe and the final write check the same header bytes, or CUSTOM labels are checked against csv_options.encoding and the record limit at config time. A CUSTOM mapping that misses a field is likewise only caught at the final write (_display_fieldnames :1191-1194). Verification: read both call sites and the Azure sibling. rg of tests/unit/plugins/sinks/test_aws_s3_sink.py for header/encoding tests found only data-row encoding cases (e.g. :362 snowman with ascii) and no test with a display header that cannot be encoded.

FINDING #29 [P3, bug] aws_s3 close() sets _closed, but nothing checks it; S3SinkClosedError and other declared failure helpers are never used

`src/elspeth/plugins/sinks/aws_s3_sink.py`

close() (:1210-1221) sets self._closed=True and drops the client. However, _get_s3_client (:826-829) never checks _closed and quietly builds a new boto3 client, so a call after close (inspect_effect, commit_effect, reconcile_effect) does not fail. That is the lifecycle-invariant gap the brief describes. S3SinkClosedError (:628) is declared for exactly this case and is never raised. rg over the repo finds no other reference to S3SinkClosedError, S3SinkPoisonedError (:624), _raise_conditional_rejected (:636), _raise_sink_write_rejected (:640) or _raise_audit_integrity (:648); only _raise_outcome_unknown is used (:1152). The error taxonomy also suggests distinctions the engine does not act on. _provider_failure_kind and _DEFINITE_REJECTION_CODES pick between S3ConditionalWriteRejectedError, S3SinkWriteError and S3WriteOutcomeUnknownError. The only production caller, sink_effects.py:1683-1688, catches BaseException, calls mark_response_lost and re-raises, so every class follows the same reconcile path. Expected: _get_s3_client raises S3SinkClosedError once _closed is set, and the dead classes and helpers are removed (or wired up) so the module does not claim guards it lacks. Verification: rg for each symbol across src/ and tests/, and read the engine's _commit handler.

FINDING #64 [P3, bug] AzureBlobSink.close() does not release the SDK transport or credential it created

`src/elspeth/plugins/sinks/azure_blob_sink.py`

azure_blob_sink.py:535-540 and 1000-1004. `_get_container_client` builds a BlobServiceClient (which owns the HTTP transport/session and, for MI/SP auth, a DefaultAzureCredential/ClientSecretCredential), keeps only `service_client.get_container_client(...)`, and drops the service client. In the installed azure-storage-blob, get_container_client wraps the parent transport in `TransportWrapper` (_blob_service_client.py ~line 761), and TransportWrapper.close/__exit__ are `pass` (_shared/base_client.py:374-381). ContainerClient.close() → `self._client.close()` therefore never closes the underlying session or the credential. close() appears to release resources but actually does nothing. The unit test TestAzureBlobSinkCloseResourceRelease (tests/unit/plugins/sinks/test_azure_blob_sink_serialization.py:89-121) says 'close() must release Azure SDK resources', but it checks this with a fake container client and so cannot catch the problem. Expected: keep the BlobServiceClient (and any credential) and close those in close(), or create the ContainerClient directly so it owns its transport. Also null the reference before calling close so a raising close is not retried. Cross-file: src/elspeth/plugins/sources/azure_blob_source.py:543-546/1325-1330 has the same pattern (it closes only a derived BlobClient).

FINDING #65 [P3, bug] A CSV header that cannot be encoded is treated as a per-row failure: every row is diverted, then prepare crashes

`src/elspeth/plugins/sinks/azure_blob_sink.py`

azure_blob_sink.py:934-947 together with 659-672. The per-member probe `_serialize_rows([output_row])` also encodes the header record. If the header is configured and cannot be encoded (for example csv_options.encoding='ascii' with a CUSTOM/ORIGINAL display header 'Prénom', or declared fixed-schema names), the header encode raises AzureBlobRecordSerializationError, the exception reserved for per-row failures. `_preflight_effect_members` then diverts every row with the reason 'CSV encoding (ascii) failed: UnicodeEncodeError', even though the row values are clean. prepare_effect then serializes the empty survivor set, the header encode raises again (uncaught), and the run crashes. This contradicts the class docstring (lines 86-93): 'Catching it can never absorb row-independent config integrity failures.' Expected: a header encode failure is a config defect and should raise a non-row exception (bare ValueError, like the CUSTOM-mapping check), ideally at init time, since the encoding and display names are known then. Verification: I built AzureBlobSink with {encoding:'ascii', headers:{'name':'Prénom'}, schema fixed [name: str]}. `_serialize_rows([{'name':'bob'}])` and `[{'name':'alice'}]` both raised AzureBlobRecordSerializationError('UnicodeEncodeError'). rg over tests/unit/plugins/sinks/test_azure_blob_sink*.py and tests/unit/plugins/transforms/azure/test_blob_sink.py finds no test for header encode failure.

FINDING #66 [P3, enhancement] JSON/JSONL output is built fully in memory before max_blob_bytes applies, unlike CSV and the S3 sink

`src/elspeth/plugins/sinks/azure_blob_sink.py`

azure_blob_sink.py:694/755 and 969-982. CSV output goes through the incremental `_serialize_csv` generator 'so the stage enforces max_blob_bytes'. JSON and JSONL are passed as `(self._serialize_rows(rows),)`, so `json.dumps(rows, indent=2)` / the joined line list builds the whole str and then the whole bytes in memory before prepare_remote_object sees any limit. The cap allows up to 1 GiB, so an over-limit cumulative snapshot can use several times the cap in memory before it is rejected. The AWS S3 twin (aws_s3_sink.py:555-578) streams JSON/JSONL through `json_encoder.iterencode` into a bounded spool, and also enforces a per-record size (`max_record_chars`) that Azure does not have. Smaller related difference: S3 ends every JSONL record with '\n' (line 577), while Azure's `"\n".join(lines)` leaves the last record unterminated. The same rows therefore produce different bytes on the two cloud sinks, and an appending JSONL consumer would merge the last line. Expected: stream JSON/JSONL as chunks, as `_serialize_csv` does, and terminate every JSONL record.

FINDING #150 [P3, security] account_url accepts a query string (including a SAS `sig`), which shows in repr and is concatenated to `??`

`src/elspeth/plugins/infrastructure/azure_auth.py`

azure_auth.py:79-89 checks account_url only for HTTPS, a hostname and no userinfo (url_validation.py:30-52). A query string or fragment is accepted. The Azure portal's 'Blob service SAS URL' is account_url + '?sv=...&sig=...', which is easy to paste here. account_url is not repr=False (:72), unlike sas_token and connection_string, so the signature shows wherever the model is repr'd or account_url is echoed. Verified: AzureAuthConfig(use_managed_identity=True, account_url='https://acct.blob.core.windows.net/?sv=2022&sig=SECRETSIG') validates, and its repr prints sig=SECRETSIG. ELSPETH's own is_sensitive_query_param('sig') returns True. Also, with sas_token set, :206-207 builds f"{account_url.rstrip('/')}?{sas}", so an account_url that already has a query (verified: it is accepted together with sas_token) produces a malformed '...?x=1?sv=...' URL. Expected: refuse a query/fragment on account_url (or at least any sensitive query parameter) and point the operator to sas_token.

## Files a correct fix must change

- `src/elspeth/plugins/sinks/aws_s3_sink.py`
- `src/elspeth/plugins/sinks/azure_blob_sink.py`

## Test files the lane must add or change

- `tests/unit/plugins/sinks/test_cloud_blob_p3_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/sinks/test_cloud_blob_p3_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-02-p3-cloud-blob/report.md`; the worker returns one line.
