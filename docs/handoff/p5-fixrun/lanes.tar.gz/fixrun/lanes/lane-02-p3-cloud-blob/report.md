DONE: lane-02-p3-cloud-blob fixed all 7 findings (#150, #29, #28, #65, #64, #66, #19) test-then-fix on lane/p3-cloud-blob (14 commits); lane file 19 fail/5 controls on base, 24/24 on branch; 4 aws_s3_sink R6 allowlist entries stale (operator re-sign); fencing re-pinned 283->284 (09f096ce…).

(Written by orchestrator from the lane's hand-back; the subagent's report.md write was refused.)

## Fixes
- #150 azure_auth account_url refuses query/fragment (SAS goes in sas_token); hide_input_in_errors=True.
- #29 aws_s3_sink _get_s3_client raises S3SinkClosedError after close(). Removed unused S3SinkPoisonedError and three _raise_* helpers (COMPAT: S3SinkPoisonedError gone).
- #28 aws_s3_sink CSV probe uses the display header; S3HeaderSerializationError(ValueError) for unencodable header.
- #65 azure_blob_sink unencodable CSV header -> ValueError (config error), not row failure.
- #64 AzureAuthConfig.close_blob_service_client closes service client and MI/SP credential; sink and source use it.
- #66 azure_blob_sink streams JSON/JSONL in 64 KiB chunks; every JSONL record ends "\n" (COMPAT: trailing newline; restaging a pre-change JSONL body fails closed).
- #19 azure_blob_source decodes CSV with surrogateescape; undecodable row quarantined alone (__raw_bytes_hex__, __line_number__, __row_number__); undecodable header still quarantines whole file.

## Re-pins
- source_file_hash: aws_s3_sink, azure_blob_sink, azure_blob_source.
- Fencing _EXPECTED_CALL_COUNT 284, caller SHA 09f096ced9565e7d34d8c447419d2f058a2461fe4d2d7441e59bab5ba570e4d6 (arrival: AzureBlobSource._load_csv._quarantine_undecodable_file -> ctx.record_validation_error). Will conflict textually with lane-04's 284 re-pin: re-measure at merge.

## Evidence (lane-reported)
- ruff/format/check_contracts/mypy 0; S3 256, Azure sink 200, Azure source 222, Azure 809, masquerade 243 passed.
- Trust-tier: no new findings; 4 aws_s3_sink R6 entries stale (_preflight_effect_members x2, _EncodedTextWriter._encode, _serialize_rows_to_spool) — operator re-sign.
- Fencing file OOM-killed; dag+architecture timed out ~88% — verify suite must confirm.

## Compatibility
- Observed-mode unencodable row key now a header config error on S3 and Azure.
