lane-01-p4-llm: all 8 P4 findings (#33 #34 #46 #87 #88 #143 #154 #59) fixed on lane/p4-llm (test e05b2776, fix 3c28de08); 9 RED tests went GREEN, gates pass, no signed tier_model fingerprints rotated.

(Written by orchestrator from the lane's hand-back; the subagent's report.md write was refused. Logs in this dir: red.log, green.log, modtests.log, rerun.log, tier_before.log, tier_after.log, contracts.log, lints.log, mypy.log.)

UNTOUCHED: none.

Files outside the expected list: src/elspeth/contracts/pdf_render.py (#59 TypedDict); config/cicd/soft-mapping-census.yaml (#143 retired one Mapping[str, Any] site, 2649 -> 2648); tests pinning old behaviour: tests/unit/plugins/llm/test_validation.py, tests/property/plugins/llm/test_response_validation_properties.py, tests/unit/plugins/test_deep_nesting_p2_sweep.py (#143), tests/unit/plugins/llm/test_audit_metadata_functions.py (#88), tests/unit/plugins/llm/test_image_inputs.py (#154), tests/integration/audit/test_audit_field_separation.py (#87).

## RED (e05b2776): 9 failed / 3 controls passed, all AssertionError
- #33 `assert "LLM query 'q1' template" in "...LLM prompt_template uses its row as an object..."`
- #34 plan compiled 3x for 1 query but 11x for 5 queries
- #46 `assert '' is None`
- #87 `'_parts_hash' in LLM_AUDIT_SUFFIXES`
- #88 `'TokenUsage | None' == 'TokenUsage'`
- #143 `'validate_json_object_response' not in vars(validation)`
- #154 `{'actual': '5'} != {'actual': 'more than 4'}`
- #59 `'max_total_bytes' in PDFRenderLimitsData.__required_keys__`
GREEN: 12 passed.

## Per finding
- #33 FIXED. `_validate_template_row_access` names the template slot at fault. COMPAT: refusal text only, only for query templates. CHANGELOG: LLM config refusals for row-object misuse or dynamic row access now name the query template at fault instead of always blaming prompt_template.
- #34 FIXED. `LLMConfig.external_inputs_by_query()` compiles once; per-template parses memoized; compile count equal for 1 and 5 queries. COMPAT: none. CHANGELOG: Ordered-mode LLM config validation compiles the ordered query plan once per validation pass instead of once per query.
- #46 FIXED. SingleQueryStrategy passes `system_prompt or None` to the tracer. COMPAT: Langfuse telemetry only. CHANGELOG: Single-query LLM transforms no longer record an empty system message in Langfuse when system_prompt is "".
- #87 FIXED. `_parts_hash` added to LLM_AUDIT_SUFFIXES. COMPAT: get_llm_audit_fields() returns one more name. CHANGELOG: `_parts_hash` is registered as an LLM audit-only field, so the row/audit separation guards cover it.
- #88 FIXED. `populate_llm_operational_fields(usage: TokenUsage, model: str)`, None fallback removed. COMPAT: internal signature. CHANGELOG: populate_llm_operational_fields now requires a TokenUsage and a model string, matching the non-nullable output schema.
- #143 FIXED. Removed validate_json_object_response and its result types; property suite now targets extract_structured_fields. COMPAT: removes public names from llm.validation (no src callers). CHANGELOG: Removed the unused validate_json_object_response parser; LLM response property tests now exercise the production parser extract_structured_fields.
- #154 FIXED. too_many_images reason records `"actual": "more than <max>"`. COMPAT: Landscape reason value text changes. CHANGELOG: too_many_images error reasons now report "more than N" instead of a misleading max+1 count.
- #59 FIXED, NEEDS MAINTAINER CONFIRMATION before landing. `PDFRenderLimitsData` gains `max_total_bytes`; `_render_request` records it. COMPAT (breaking for persisted runs): the request is the replay/verify match key, so replay/verify of pdf_rasterize runs recorded before this change no longer matches and fails closed with AuditIntegrityError; format string stays "pdf_rasterize/v1". CHANGELOG: pdf_rasterize's audited render request now records max_total_bytes; replay/verify of PDF runs recorded before this change is refused.

## Hashes
LLMTransform sha256:3060577e04da31de -> sha256:f6ef87bfdf2fac79; PDFRasterize sha256:30f98ba21f7a8e25 -> sha256:d393cd68e73b92f6; LLM source unchanged (de4aa949d26f8c1e). Neither old token in scenario-corpus manifest.

## Gates (lane-reported)
check_contracts 0; plugin_contract.{component_type,options_metadata,plugin_hashes} 0; ruff/format pass; mypy 8 files clean; test_no_hasattr_branching 0; keyless tier_model corpus identical before/after (3806 lines). Pre-existing stale: pdf_rasterize.py:R5:PDFRasterize:_map_document_result fp=3a7765ad5e1c5b49, fp=52b9ef4c1f113d8a. Module tests -n 3: 9438 passed, 6 failed, 1 error; 3 lane-caused fixed; 4 wall-clock timeouts under load ~20 passed serially (319 passed, exit 0).

## Maintainer decisions
- #59: accept that pre-change pdf_rasterize runs can no longer be replayed/verified? Bump format to "pdf_rasterize/v2" so the refusal is explicit?

## #59 follow-up (orchestrator, maintainer ruling "land, bump to v2")
- RED b6ffd565: 2 tests failed at assertions (no PDF_RENDER_FORMAT in contracts.pdf_render; v1 receipt refusal message did not name the retired format).
- Fix 49e4655d: contracts/pdf_render.py PDF_RENDER_FORMAT = "pdf_rasterize/v2", PDF_RENDER_RETIRED_FORMATS = {"pdf_rasterize/v1"}; pdf_rasterize request and receipt use it; replay preload (core/replay_payload_store.py) and receipt restore refuse a v1 record with "recorded as pdf_rasterize/v1, which is no longer replayed (current pdf_rasterize/v2)". Two tests pinning "v1" updated.
- PDFRasterize source_file_hash: sha256:d393cd68e73b92f6 -> sha256:334c2c2d700d33c5 (not in scenario-corpus manifest).
- Gates: 1107 related tests passed (-n 3); ruff/format/mypy clean; check_contracts 0; plugin_contract rules 0; keyless tier_model corpus 3806 lines, touched-file findings identical to the lane's tier_after.log.
- CHANGELOG (replaces the #59 line): pdf_rasterize's audited render request now records max_total_bytes and its format is pdf_rasterize/v2; replay/verify of a PDF run recorded as pdf_rasterize/v1 is refused with a message naming the retired format.
- Maintainer decision #59: resolved (bump to v2).
