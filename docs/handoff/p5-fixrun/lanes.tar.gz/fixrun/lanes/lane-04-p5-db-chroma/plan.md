# lane-04-p5-db-chroma — DatabaseSink if_exists and Chroma on_duplicate stop advertising values the sink refuses; Chroma refuses whitespace-only document ids

Ticket `p5-db-chroma` · run `p5` · branch `lane/p5-db-chroma` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

Maintainer ruling 2026-11-14: fix behaviour. database_sink.py types if_exists as Literal['append','replace'] but refuses 'replace' at validation (#41 only fixed guidance); chroma_sink.py types on_duplicate as Literal['overwrite','skip','error'] but only overwrite works and the hint advertises skip/error. Make the config type admit exactly what works (remove the dead values and their refusal branches), update hints/usage/catalog goldens/examples. Chroma: whitespace-only ids are still accepted (lane-09-p2-090-091 report) — refuse them as invalid ids with the existing diversion/validation shape.

## Files a correct fix must change

- `src/elspeth/plugins/sinks/database_sink.py`
- `src/elspeth/plugins/sinks/chroma_sink.py`

## Test files the lane must add or change

- `tests/unit/plugins/test_p5_db_chroma_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/test_p5_db_chroma_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-04-p5-db-chroma/report.md`; the worker returns one line.
