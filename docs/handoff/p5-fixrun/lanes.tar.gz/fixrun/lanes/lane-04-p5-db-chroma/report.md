lane-04-p5-db-chroma: DatabaseSink if_exists is Literal['append'] and Chroma on_duplicate is Literal['overwrite'] (dead values refused at config validation; refusal branches, the 'replace' post-call hint and guidance removed); Chroma diverts whitespace-only ids. RED c9fc99c1 (6 failed at assertions, 2 controls), fix 0ab33a6f (8 passed); follow-up commit removes the dead DuplicateDocumentError and the stale set_output.md doc text. ruff/mypy/contracts (census re-pinned)/plugin lints 0.

(Written by orchestrator from the lane's hand-back; the harness refused the lane's report write.)

CHANGELOG:
- Database and Chroma sinks admit only the write modes they perform: database if_exists accepts only append; chroma_sink on_duplicate accepts only overwrite; replace/skip/error are refused at config validation. A Chroma row with a whitespace-only document id is diverted per row like an empty id.

COMPAT:
- Config: if_exists: replace or on_duplicate: skip|error now fail with PluginConfigError at load/compose (they never worked; previously refused later).
- Runtime data: a whitespace-only Chroma id is diverted instead of published.
- Catalog knob_schema enums for both fields shrink to one value.
- Removed public error class elspeth.contracts.errors.DuplicateDocumentError (dead; documented only for on_duplicate='error').
- Hashes: database_sink sha256:9c9ef5408017aa9b, chroma_sink sha256:7c867fa7cf994920.
- config/cicd/soft-mapping-census.yaml re-pinned (boundary 70 -> 69); on merge conflict re-run scripts/check_contracts.py --write-census.

Gates: pytest -n 2 1670 passed (sinks, catalog, plugin_policy, integration); tests/unit/web/composer not completed in full (memory), 36 relevant composer files run serially all exit 0. No new tier-model fingerprints.
