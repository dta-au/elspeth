DONE: lane-01-p3aws-guardrail-deadline-config made the Bedrock guardrail row deadline configurable (row_deadline_seconds, default 300, gt=0) per maintainer ruling; 7 new tests RED->GREEN; 3048 AWS/guardrail tests pass; plugin hashes unchanged.

- RED (86ff6f2b): 3 tests failed at assertions (field missing from BedrockGuardrailTransformConfig.model_fields; extra_forbidden for row_deadline_seconds).
- Fix (49dbf01f): BedrockGuardrailTransformConfig.row_deadline_seconds: int = Field(300, gt=0) wired to _row_deadline_seconds; GUARDRAIL_ROW_DEADLINE_SECONDS is now the int default. docs/reference/configuration.md documents it, the engine-retry re-run of all fields, and that the failed attempt's calls stay recorded.
- Gates: plugin_contract.{component_type,options_metadata,plugin_hashes} exit 0; check_contracts 0 (census 2647 unchanged); ruff/format/mypy clean. bedrock_prompt_shield sha256:b391e6dc564071b9 and bedrock_content_safety sha256:a2616df0b0a79c6b unchanged.
- COMPAT: additive optional YAML option; default behaviour unchanged. Web Composer guardrail profiles do not expose it (planner-settable options remain fields/schema/source), so web sessions use 300.
- CHANGELOG: Added: `row_deadline_seconds` option (default 300) for aws_bedrock_prompt_shield and aws_bedrock_content_safety bounds how long a row may keep starting Guardrail calls.
- Maintainer decision (optional): carry row_deadline_seconds on the operator Bedrock guardrail profile so web deployments can tune it.
