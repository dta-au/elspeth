# lane-01-p3aws-guardrail-deadline-config — Bedrock guardrail row deadline configurable (maintainer ruling on AWS review #4)

Ticket `p3aws-guardrail-deadline-config` · run `p3awsfu` · branch `lane/p3aws-guardrail-deadline-config` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

Maintainer ruled the 300 s guardrail row deadline should be configurable. Add BedrockGuardrailTransformConfig.row_deadline_seconds (default 300, gt=0, mirroring azure max_capacity_retry_seconds) and wire it to the transform's _row_deadline_seconds.

## Files a correct fix must change

- `src/elspeth/plugins/transforms/aws/_guardrail_transform.py`

## Test files the lane must add or change

- `tests/unit/plugins/transforms/aws/test_guardrail_deadline_config.py`

## Test command (must be RED before the fix, GREEN after)

```
/home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.venv/bin/python -m pytest tests/unit/plugins/transforms/aws/test_guardrail_deadline_config.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-01-p3aws-guardrail-deadline-config/report.md`; the worker returns one line.
