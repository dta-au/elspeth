# lane-05-p3-blob-rasterize — #55 [P3, security] pdf_rasterize parent never re-checks worker-claimed page text size (or width/height) before emitting it; #56 [P3, bug] Replay receipt validation does not enforce one output row per rendered page (duplicate page rows accepted); #69 [P3 (raised as P2), bug] blob_json_expand: JSONL split with str.splitlines() breaks valid records containing U+2028, U+2029 or U+0085; #70 [P3, bug] blob_json_expand: NaN/Infinity constants are accepted at parse time; siblings reject them at the boundary; #81 [P3, enhancement] blob_fetch VERIFY-mode branch and HTTP status mapping have no tests; #95 [P3, enhancement] max_blob_bytes is checked only after the whole blob has been read; the bounded retrieve API is not used; #132 [P3 (raised as P2), bug] PoolRenderer.render leaks its temp output dir (rendered page PNGs) when the worker dies or raises outside the protocol; #156 [P3, bug] Rasterize worker's per-page MemoryError guard misses text extraction and page load; whole document is mislabelled MALFORMED 'document parse' failure; #162 [P3, bug] renderer_identity() requires libpdfium.so, so pdf_rasterize crashes on macOS/Windows although its worker supports non-Linux

Ticket `p3-blob-rasterize` · run `p3` · branch `lane/p3-blob-rasterize` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

This lane fixes 9 findings; fix each one (one test commit + one fix commit PER finding).
Every finding names the files where the sweep located it; touch only what each fix needs.

FINDING #55 [P3, security] pdf_rasterize parent never re-checks worker-claimed page text size (or width/height) before emitting it

`src/elspeth/plugins/transforms/pdf_rasterize.py`

Where: pdf_rasterize.py:900-970 (_admit_render_result) and :1115-1121 (_map_rasterize_response). What is wrong: the admission docstring says the worker parses hostile PDF bytes, so its claims are checked rather than believed. It re-checks containment, the PNG signature, max_page_bytes and max_total_bytes against the bytes it reads. It never checks the bound that max_page_text_bytes promises: page.text is copied into row data (:1121) and into the audit receipt (:736), and the only check is `type(page.text) is str`. The only enforcement of max_page_text_bytes is inside the worker (worker.py:164-169, `len(text.encode('utf-8')) > request.max_page_text_bytes`). The same applies to width_px and height_px (:1113-1114): their type and range are not checked, and they are not compared with max_page_pixels or the PNG IHDR. Why it matters: the config text (:229-232) promises the bound 'Guards against an unbounded page_text row feeding a downstream LLM'. Under this file's own threat model (a compromised worker; see the containment-breach RuntimeErrors at :948 and :1094), that bound fails open while every sibling size bound is enforced by the parent. Expected: in admission, convert a page whose `len(text.encode('utf-8')) > max_page_text_bytes` into a RefusedPage(OVERSIZE_TEXT), refuse non-None text when extract_text is false, and check that width/height are positive exact ints. Verification: read worker.py:150-175 and protocol.py (RenderedPage carries no validation). `rg max_page_text_bytes tests/unit/plugins/transforms/test_pdf_rasterize*.py` returns nothing, so no test sends a stub renderer with oversize text.

FINDING #56 [P3, bug] Replay receipt validation does not enforce one output row per rendered page (duplicate page rows accepted)

`src/elspeth/plugins/transforms/pdf_rasterize.py`

Where: pdf_rasterize.py:801-872 (_restore_render_receipt). What is wrong: the success path checks `len(rows) == len(rendered)` (:805). For each output row it checks only that its page_number is in pages_by_number (:840-842). Nothing tracks which pages have already been claimed. A receipt with rendered pages {1,2} and two identical rows for page 1 passes every check. Replay then emits page 1 twice and drops page 2, while restore_output (:873-877) still restores page 2's payload. Why it matters: the live path's comment at :664-665 says the receipt records the admitted response 'so replay's one-row-per-rendered-page check holds'. The check enforces equal counts and membership, not a one-to-one mapping. This is Tier-1 audit data whose validator is meant to raise AuditIntegrityError on any inconsistency, so this is a partial invariant enforcement. Expected: keep a seen-set of page numbers across rows and raise AuditIntegrityError on a repeat, or require the set of row page numbers to equal set(pages_by_number). Verification: read the loop at :835-872; there is no seen/consumed set. tests/unit/plugins/transforms/test_pdf_rasterize_replay.py has only 4 tests (happy replay, verify mismatch, missing source request, refused-page replay). `rg duplicate` in that file finds nothing, and none of the ~20 AuditIntegrityError branches in _restore_render_receipt has a negative test.

FINDING #69 [P3 (raised as P2), bug] blob_json_expand: JSONL split with str.splitlines() breaks valid records containing U+2028, U+2029 or U+0085

`src/elspeth/plugins/transforms/blob_json_expand.py`

blob_json_expand.py:836 iterates `text.splitlines()`. str.splitlines treats U+2028, U+2029, U+0085 and \x1c-\x1e as line breaks. JSON allows U+2028, U+2029 and U+0085 unescaped inside strings, and json.dumps(..., ensure_ascii=False) writes them raw; they are common in scraped or rich text. Measured: `'{"a":"x y"}\n'.splitlines()` returns 2 pieces, while json.loads of the same record succeeds. A valid JSONL document is therefore cut mid-string, and the whole document is quarantined as invalid_json (phase=jsonl_line) with a wrong line_number. The JSONL source siblings split only on real newlines. azure_blob_source.py:1027-1033 iterates io.TextIOWrapper(..., newline=''), and json_source.py:320-333 iterates the file object. As a result, the same bytes parse as a source but fail inside this transform. Expected: split on '\n' only (text.split('\n'), stripping a trailing '\r'), or iterate a TextIOWrapper the way azure_blob_source does. rg for '2028|splitlines' under tests for blob_json_expand found nothing.

**Verifier (CONFIRMED):** blob_json_expand.py:836 iterates text.splitlines(). Repro scratch-E/f68_69.py: two valid JSONL records written with ensure_ascii=False containing U+2028 and U+0085; json.loads of each '\n'-split line succeeds, but BlobJSONExpand(source='field', format='jsonl').process returned status=error reason {'reason':'invalid_json','phase':'jsonl_line','line_number':1,'error':'Unterminated string ...'}. Valid document is quarantined via on_error (not a crash, not silent), so P3 rather than P2.

FINDING #70 [P3, bug] blob_json_expand: NaN/Infinity constants are accepted at parse time; siblings reject them at the boundary

`src/elspeth/plugins/transforms/blob_json_expand.py`

blob_json_expand.py:840 and :848 call json.loads without parse_constant, so NaN, Infinity and -Infinity in the untrusted document become Python float('nan') or float('inf') in the emitted rows. Every sibling JSON boundary rejects them at parse time with parse_constant=_reject_nonfinite_constant: json_source.py:333 and :376, azure_blob_source.py:985 and :1064, and aws_s3_source.py:1281. This follows the canonical-JSON policy in core/canonical.py:8 ('NaN and Infinity are strictly REJECTED'). Here the value passes parsing and fails later when TransformExecutor hashes the outputs (transform.py:736-748). That failure becomes a non_canonical_output_violation, a PluginContractViolation charged to the plugin. non_canonical_output.py:13-16 says the boundary should have quarantined such a value. The row is still routed, so no data is lost. However, bad external input is recorded in the audit trail as a plugin contract breach rather than as invalid_json. Expected: pass parse_constant to both json.loads calls, handle the resulting ValueError as invalid_json with error_type='non_finite_constant', and add a test (rg for 'NaN|Infinity' in test_blob_json_expand.py finds none).

FINDING #81 [P3, enhancement] blob_fetch VERIFY-mode branch and HTTP status mapping have no tests

`src/elspeth/plugins/transforms/blob_fetch.py`

Two risky branches have no tests. (1) The RunMode.VERIFY branch at blob_fetch.py:550-576 builds a pre-DNS HTTPCallRequest with fingerprinted X-Abuse-Contact / X-Fetch-Reason / Host headers and calls session.preflight_verify_http_request before resolving DNS again. (2) The status-code mapping in _fetch_url at 705-718 (404/403/401 become non-retryable ClientError subclasses; 429 and 5xx become retryable errors re-raised at 607-608; 408 is retryable; unresolved 3xx becomes InvalidURLError), plus the conversion to a routed 'api_error' row error at 609-615. If any header name or value drifts from what AuditedHTTPClient records, verify runs falsely diverge or falsely match. A wrong retryable flag either loops retries on a permanent 4xx or routes a transient 5xx to on_error. Verification: in every test file that references BlobFetch, rg for RunMode.VERIFY, ServerError, RateLimitError and NotFoundError matched nothing for blob_fetch. tests/unit/plugins/transforms/test_blob_fetch.py only covers REPLAY (line 313), and test_network_boundary_siblings.py only covers body/encoding refusals. The sibling web_scrape does have a VERIFY test (tests/unit/plugins/transforms/test_web_scrape_security.py:338-365), so this is an asymmetry. Suggested tests: a VERIFY-mode test that checks the preflight request_data headers, and a parametrised status-code test that checks retryable raise versus routed error.

FINDING #95 [P3, enhancement] max_blob_bytes is checked only after the whole blob has been read; the bounded retrieve API is not used

`src/elspeth/plugins/transforms/blob_text_expand.py`

At blob_text_expand.py:391, process calls self._payload_store.retrieve(blob_ref), which reads and hash-verifies the entire payload. Only afterwards does line 413-414 compare len(body) with max_blob_bytes. A blob far over the cap (default 100 MiB) is therefore fully loaded into memory before it is refused, so the field reads as a resource limit but does not stop the read. The PayloadStore protocol already provides retrieve_bounded(content_hash, *, max_bytes) (contracts/payload_store.py:76-82: 'Implementations must stop reading after max_bytes + 1 bytes'), and web_scrape.py:1294 and source_snapshot.py:65 already use it for this purpose. Expected: call retrieve_bounded(blob_ref, max_bytes=self._max_blob_bytes), and treat a None return as blob_too_large, keeping the IntegrityError and PayloadNotFoundError handling as it is. The siblings have the same pattern: blob_csv_expand.py:613/639 and blob_json_expand.py:714/731 also call retrieve() and then check the size.

FINDING #132 [P3 (raised as P2), bug] PoolRenderer.render leaks its temp output dir (rendered page PNGs) when the worker dies or raises outside the protocol

`src/elspeth/plugins/infrastructure/rasterize/renderer.py`

renderer.py:127 creates output_dir with tempfile.mkdtemp before the call. The submit() failure path (lines 142-146) discards it because 'no caller will ever receive this output_dir'. The BrokenProcessPool arm (154-158) and the generic-Exception arm (172-178) raise RuntimeError without discarding it, and so does a failure in _ensure_pool() (line 139) or in the on_submitted seam (148). The only production caller, pdf_rasterize.py:662, calls `result, output_dir = self._renderer.render(body)` outside its try/finally (the finally at line 699 calls discard). On these paths the caller never gets the path, so the directory and any page images the worker already wrote (derived document content) stay in the system temp dir for good. This breaks the method's own ownership contract ('The CALLER owns output_dir'), because the caller never receives it. Expected: discard(output_dir) on every path that raises, matching the submit() arm. Verification: I ran PoolRenderer with elspeth.testing.rasterize_fakes.crashing_worker and raising_worker, with TMPDIR pointed at the scratchpad. Both raised RuntimeError('...code bug...') and both left an elspeth-rasterize-* directory behind (2 leaked dirs observed). tests/unit/plugins/infrastructure/rasterize/test_renderer.py::test_worker_death_is_a_tier1_code_bug and ::test_worker_exception_outside_the_protocol_is_a_tier1_code_bug assert only the RuntimeError, never cleanup.

**Verifier (CONFIRMED):** renderer.py:127 mkdtemp; only the submit() failure arm (142-146) discards it. The BrokenProcessPool arm (154-158), the generic-Exception arm (172-178), _ensure_pool() (139) and on_submitted (148) raise without discard, and pdf_rasterize.py:662 calls render() before its try/finally (699). Repro .claude/lanes/20261111-plugins-review/scratch-D/r132.py with TMPDIR=.claude/lanes/20261111-plugins-review/scratch-D/tmp132: crashing_worker -> RuntimeError, 1 leaked dir; raising_worker -> RuntimeError, 2 leaked dirs. elspeth-rasterize-acwma5_2 and elspeth-rasterize-l_j082k0 remained on disk. Severity lowered: this happens only on Tier-1 code-bug crash paths that end the run, so the impact is residual derived-document files in the system temp dir (hygiene and data-at-rest), not a correctness or audit defect.

FINDING #156 [P3, bug] Rasterize worker's per-page MemoryError guard misses text extraction and page load; whole document is mislabelled MALFORMED 'document parse' failure

`src/elspeth/plugins/infrastructure/rasterize/worker.py`

The worker catches MemoryError only around `page.render`/`encode_rgb_png` (lines 137-143). If RLIMIT_AS trips in `document[index]` (line 118), `page.get_size()` (122), `page.get_textpage()` (155) or `textpage.get_text_range()` (159), the MemoryError leaves `rasterize_document`. renderer.py:164-170 then catches it and returns `DocumentRefusal(kind=MALFORMED, detail='document parse exceeded the worker memory limit')`; its comment assumes that only the PARSE can reach this handler. Text extraction on a single page with extract_text=True is a realistic memory hotspot. When it runs out of memory, the whole document is refused as malformed with a false 'parse' detail. The expected outcome is a per-page `RefusedPage(kind=MEMORY_EXHAUSTED)` while the other pages still render. That breaks the documented contract (module docstring: page problems become page refusals) and makes the audit detail inaccurate. Verified by reading renderer.py:120-178 (the only MemoryError handler outside the worker) and worker.py:114-177. Expected behaviour: put MemoryError in the same per-page handling for page load, get_size and text extraction, or narrow the renderer's detail text.

FINDING #162 [P3, bug] renderer_identity() requires libpdfium.so, so pdf_rasterize crashes on macOS/Windows although its worker supports non-Linux

`src/elspeth/plugins/infrastructure/rasterize/identity.py`

identity.py:19-21 filters the pypdfium2 distribution files for names ending in '/libpdfium.so' and raises RuntimeError unless exactly one matches. The pypdfium2 wheels ship libpdfium.dylib on macOS and pdfium.dll on Windows. Measured on Linux: the installed distribution lists 'pypdfium2_raw/libpdfium.so'. The worker treats other platforms as supported (worker.py:41-43, 'Linux-only; a no-op elsewhere' for rlimits), yet pdf_rasterize.py:752 calls renderer_identity() to build every audited receipt. On a non-Linux host, every live rasterize call therefore raises an uncaught RuntimeError, which looks like a framework crash rather than a clear platform refusal. Expected: match the platform's native library name (or the pypdfium2_raw binary entry whatever its extension), or refuse non-Linux platforms explicitly at config or on_start time. No test exercises the non-.so branch (grep for renderer_identity under tests/ finds only receipt-shape assertions).

## Files a correct fix must change

- `src/elspeth/plugins/transforms/blob_json_expand.py`
- `src/elspeth/plugins/transforms/pdf_rasterize.py`

## Test files the lane must add or change

- `tests/unit/plugins/transforms/test_blob_rasterize_p3_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/transforms/test_blob_rasterize_p3_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-05-p3-blob-rasterize/report.md`; the worker returns one line.
