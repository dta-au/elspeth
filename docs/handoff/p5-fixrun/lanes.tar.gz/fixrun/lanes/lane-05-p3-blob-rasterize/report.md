PARTIAL: lane-05-p3-blob-rasterize fixed 8 of 9 findings (#55, #56, #69, #70, #95, #132, #156, #162) test-then-fix on lane/p3-blob-rasterize (HEAD 062a7278); #81 has no defect (VERIFY parity and status mapping measured correct), so no commits.

(Written by orchestrator from the lane's hand-back; the subagent's report.md write was refused.)

## Fixes
- #69 blob_json_expand JSONL splits on "\n" only (strip one "\r"); U+2028/2029/0085 no longer split records.
- #70 blob_json_expand rejects NaN/Infinity via parse_constant -> invalid_json, error_type=non_finite_constant (base crashed in narrow_contract_to_output).
- #95 blob_text/csv/json_expand read with retrieve_bounded(max_bytes=max_blob_bytes); None -> blob_too_large. COMPAT: blob_too_large reason no longer carries body_size.
- #132 PoolRenderer.render discards output_dir on every raising path (try/finally around _render_into).
- #156 worker._render_page: per-page MemoryError -> RefusedPage(MEMORY_EXHAUSTED) for that page only.
- #162 renderer_identity accepts libpdfium.so / libpdfium.dylib / pdfium.dll (exactly one match still required).
- #55 pdf_rasterize _page_claim_refusal: bad geometry -> INVALID_GEOMETRY; over max_page_pixels -> OVERSIZE_PIXELS; text while extract_text false -> RENDER_ERROR; over max_page_text_bytes -> OVERSIZE_TEXT.
- #56 replay refuses duplicate page rows (AuditIntegrityError). Also fixed: multi-page replay could never succeed (per-row contracts vs success_multi shared-contract rule); rows now share row-0 contract, differing field set -> AuditIntegrityError.

## Evidence (lane-reported)
- Lane file 43 passed at HEAD; 36 failed / 7 controls passed in git archive of 10d56017 (all assertion failures).
- ruff/format/check_contracts/mypy(10 files) exit 0; masquerade etc. 292 passed; hash-pin tests 617 passed.
- Keyless trust-tier: finding sets identical after normalisation; no signature churn.
- Fencing inventory OOM-killed; diff has no record_/landscape/execution. lines (control: `retrieve` matched 6).
- DAG/architecture -n 2 gate stopped at 2h limit ~98% with xdist workers lost to OOM — verify's suite covers it.

## Left alone
- #55 no PNG IHDR cross-check (fixtures lack IHDR).
- pdf_rasterize retrieve()+max_input_bytes has the #95 pattern; not named by the finding.
- #81 regression-only tests are a maintainer call.
