PARTIAL: lane-10-p3-cloud-transforms landed 8 of 9 (#35, #30, #36, #50, #61, #98, #114, #144; 16 commits, HEAD f897d4d2, base 1ee11f2e); #134 needs a maintainer policy decision (which prompt_shield analysis_type values count as an effective PROMPT_SHIELD control).

(Written by orchestrator from the lane's hand-back; the subagent's report.md write was refused.)

## Fixes
- #35 Textract FORMS entries carry value_selection_status (SELECTED/NOT_SELECTED/None); malformed selection fails closed.
- #30 textract_inline_analysis reads with retrieve_bounded; blob_too_large actual ">max" (COMPAT).
- #36 Textract transforms keep a private shutdown Event; engine shutdown_event held read-only and never set by close().
- #50 Guardrail client counts botocore attempts via before-send hook; transport errors report observed attempts.
- #61 analyze_lro (shared DI/Content Understanding base): poll-phase network errors retried in place until poll deadline; submit unchanged.
- #98 BucketRegionUnverifiedError(inherited=True) for followers; reason cache_status "shared_failure" (contracts/errors.py TransformErrorReason gains NotRequired cache_status).
- #114 Azure safety field loop checks row deadline before each field -> retry_timeout row_deadline_exceeded (behaviour change).
- #144 Guardrail transform rejects empty / over-length text as invalid_input (empty_field/field_too_long); bare ValueError no longer caught. MAX_REQUEST_TEXT_CHARS public.

## #134 options (maintainer)
(a) credit only analysis_type both; (b) credit any, made explicit by test; (c) split PROMPT_SHIELD direct/indirect. ~10 lines in prompt_shield.is_effective_blocking_control.

## Evidence (lane-reported)
- RED 12 failed (all assertions) / 3 controls; GREEN 15 passed.
- ruff/format/check_contracts (census 2668)/mypy(10 files)/plugin_hashes/trust_boundary 0; masquerade+TypeError gates 287 passed; modules 1436 passed.
- Keyless trust-tier for touched files: 0 new / 0 gone. No fencing change. Hashes strict-checked for 4 plugins; none in scenario manifest.

## Caveats
- plugin_hashes lint PLUGIN_DIRS omits plugins/transforms/aws (pre-existing gap).
- #144 operators see invalid_input instead of api_call_failed.

## #134 LANDED on lane (hub, 2026-11-12)
Maintainer ruled option (a): only analysis_type both earns PROMPT_SHIELD credit. Tests 3f6a2ecd (RED 6 failed at assertions / 3 controls), fix on top; GREEN 9 passed; azure+sweep+web/plugin_policy 1018 passed (py3.14); mypy/ruff 0; hash f4b81d89abde328e. COMPAT: single-analysis shields no longer satisfy a required PROMPT_SHIELD control.
