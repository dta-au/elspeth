PAUSED (WIP) lane-01-p5-http-deadline (run p5b) at d40f8805: one absolute per-request deadline for every audited HTTP request (clients/deadline.py: http_deadline_scope ContextVar + deadline_bound_client / DeadlineBoundTransport over httpcore network_backend); wired into http.py get/post/request_ssrf_safe+redirects, Power Automate, Dataverse (request_timeout_seconds), web_scrape pagination budget; timeout descriptions say "Total wall-clock deadline". RED dae3761e (10 failed at assertions), sweep 16 passed. NEXT: composer suite rerun (3 undiagnosed failures at 54%), mypy and keyless tier scan rerun after final deadline.py change, then a non-WIP commit.

(Written by orchestrator from the lane's pause hand-back; the harness refused the lane's report write.)

CHANGELOG:
- Fixed: every audited HTTP request is cut off at its configured timeout, now an absolute total covering connect, send, headers, full body and redirect hops (web_scrape, blob_fetch, OpenRouter/Gateway LLM transform and source, Azure content safety, prompt shield, AI Search, Document Intelligence, Content Understanding, Dataverse client). Previously per socket operation, so a slow-drip upstream could hold a worker without limit.
- Fixed: web_scrape pagination max_elapsed_seconds also bounds the page in flight.
- Changed: timeout descriptions state the total bound.

COMPAT:
- timeout / timeout_seconds / request_timeout / request_timeout_seconds on those plugins mean total wall time per request; slow steady responses that used to finish now time out — raise values for large/slow responses.
- A web_scrape page cut off by the pagination budget returns pagination_limit_exceeded instead of a retryable timeout.
- DataverseClient gains request_timeout_seconds (default 30 s, unchanged behaviour default).
- Hashes: azure_ai_search 434d9c3dbf1ff981, blob_fetch d8d0383ba08931bd, web_scrape 93087269252f83e1 (NOTE: lane-03-p5-web also changes web_scrape.py -> merge conflict / recompute on merged tree).

Unresolved: SDK LLM paths (Azure OpenAI via openai SDK, Bedrock via litellm) still per-phase — candidate for lane p5-llm-pool-deadline (owns llm/transform.py); residual overshoot (DNS, TLS multi-read, 16 KiB write slice, rate-limiter wait before scope); private httpx._utils.get_environment_proxies import (httpx 0.28.1 pin); wall-clock sweep test not marked timing_sensitive; two R1 ContextVar.get() misfires for operator adjudication.
