# lane-01-p5-http-deadline — Every HTTP plugin gets an absolute per-request deadline (not just Power Automate); timeout descriptions state the real bound

Ticket `p5-http-deadline` · run `p5b` · branch `lane/p5-http-deadline` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

Maintainer-approved 2026-11-14 from the systems sweep (.claude/lanes/fixrun/p5/systems-sweep.md families F9 and the F8/F9 timeout-description item — read it, with sites and repros in .claude/lanes/fixrun/p5/sweep-scratch/). Only Power Automate gets an absolute HTTP deadline (plugins/infrastructure/clients/http.py ~1816); httpx timeouts are per-operation, so a slow-drip upstream holds web_scrape, blob_fetch, OpenRouter/Gateway LLM, Dataverse and Azure safety/DI/CU workers without bound and breaks the batch-wait arithmetic in azure/base.py and llm/transform.py. Fix at the shared client: one absolute deadline mechanism used by every HTTP caller (no per-plugin copies), deriving from each plugin's configured timeout so 'timeout' means total wall time; make the batch-wait arithmetic consistent with it; correct every 'Request timeout in seconds' description to the real semantics. RED test: a slow-drip local server (bytes trickled under the per-read timeout) must be cut off at the configured total for each caller family. Coordinate: lane p5-llm-pool-deadline (row deadline from accept, llm/transform.py) runs later; do not implement that here, but leave the arithmetic correct.

## Files a correct fix must change

- `src/elspeth/plugins/infrastructure/clients/http.py`

## Test files the lane must add or change

- `tests/unit/plugins/test_p5_http_deadline_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/test_p5_http_deadline_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-01-p5-http-deadline/report.md`; the worker returns one line.
