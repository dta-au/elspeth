PAUSED lane-01-p5-146-truncate at 4dec8792 (branch lane/p4-146-truncate, tree clean): truncate declares declared_string_input_fields = frozenset(cfg.fields) like its siblings; strict, the skip branch and the header-alias lookup/collision plan removed; missing field fails with existing missing_field. RED 1e58fc41 (15 failed at assertions). NEXT STEP: broad pytest gate at -n 2 -rfE (stopped at ~75% for the pause; one worker OOM crash) and the plugin_hashes negative control.

(Written by orchestrator from the lane's pause hand-back; the harness refused the lane's report write. Logs in lanes/lane-146-truncate/.)

column_keyed_config_keys: KEPT on Truncate (its only user) — consumed_input_fields does not read declared_string_input_fields; dict-valued fields reach demotion protection and the fixed-schema read check only through it. It carries no lookup behaviour; comments corrected.

CHANGELOG:
- Changed: truncate declares its fields as string-typed inputs like keyword_filter and the guardrails; a producer that types a truncated field int/float/bool is refused at build, and field names follow the standard spelling rule (#146).

COMPAT (breaking):
- strict removed (refused as an unknown option).
- A configured field missing from a row fails it with missing_field via on_error (previously skipped silently).
- fields keys must be normalized names; header spellings refused at build or routed per row with declared_field_is_header_spelling.
- A producer provably typing a truncated field non-string is refused at build (previously every row failed type_mismatch).
- Composer graphs setting strict on truncate need reinspection.
- Hash: Truncate sha256:61cdc3ececd46174 -> sha256:4ae16e87917a4322; knob_schema golden regenerated (strict knob gone). plugin_version stays 1.0.0 (maintainer call).

Gates: ruff/format/mypy/check_contracts/plugin_contract 0; focused pytest 478 passed, 1 env-only (sqlite3 CLI); keyless trust-tier identical (no rotations). Broad gate incomplete.
