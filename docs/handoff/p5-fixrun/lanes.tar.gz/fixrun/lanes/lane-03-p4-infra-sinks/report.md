lane-03-p4-infra-sinks: all 9 findings (#1 #7 #8 #12 #15 #16 #17 #31 #89) fixed test-first on lane/p4-infra-sinks (5b7deb7a..83d626ae, 11 tests RED-at-assertion on base 4ebe6d6b, 21/21 green); every gate is green (3954 module tests at -n 3, contracts, plugin_contract, ruff/format/mypy, no_hasattr, masquerade). Operator follow-up: 4 signed tier_model R6 fingerprints rotated and need re-signing, plus 2 new masquerade-baseline entries to review.

(Written by orchestrator from the resumed lane's hand-back; the subagent's report.md write was refused. Gate logs r2-*.log in this directory.)

UNTOUCHED: none.
OUTSIDE EXPECTED LIST: config/cicd/masquerade_baseline.yaml (+2: aws_s3_source `_s3_body_member` external-parse sentinel getattr; test double `_ProxiedBody.__getattr__` approved-introspection); tests/unit/web/plugin_policy/test_coverage.py and tests/unit/plugins/transforms/test_cloud_transforms_p3_sweep.py (#1 phantom detect_only replaced by real non-blocking configs); tests/unit/plugins/sources/test_aws_s3_source.py (#12 non-callable read is InvalidS3Body).

## Commits (base 4ebe6d6b)
5b7deb7a RED tests; 742fd8dd #1; e6962eeb #7; 807d4b06 test #8; a580e603 #8; da070d6f #12; 43ac4bc1 #15 #16 #17; 939812b9 #31; 6bb30830 #89; abe894c8 #12 follow-up; 83d626ae #15 follow-up.

## RED
Final lane test file against base sources: 11 failed, 10 passed, every failure an AssertionError in the lane test file. GREEN on HEAD: 21 passed.

## Per finding
- #1 FIXED. Dead detect_only branch removed from BaseTransform.is_effective_blocking_control; coverage tests use real non-blocking configs. COMPAT none in production. CHANGELOG: Plugins: base blocking-control credit no longer reads an undeclared `detect_only` option; non-blocking configurations are refused only by each plugin's own override.
- #7 FIXED. _BoundedTemplate.render is value-free whenever the context carries a TemplateRow; operator-only contexts keep raw bounded diagnostics; docstrings match. COMPAT: errors rendering a TemplateRow via create_sandboxed_environment() (default value_free=False) carry only the exception class name. CHANGELOG: Templates: a render whose context carries row data always reports failures value-free, so row values cannot leak into error text.
- #8 FIXED. validate_sink_config uses sink_cls.get_config_model(config) and reports dispatch ValueError as ValidationError(field="provider"). COMPAT none today. CHANGELOG: Plugins: sink pre-validation resolves the config model with the config, as the runtime does, and reports a provider-dispatch rejection as a validation error.
- #12 FIXED. runtime_checkable Protocols removed; sentinel getattr parse (except AttributeError + module sentinel) into frozen _AdmittedS3Body; bytes checks kept. COMPAT: non-callable read is S3SourceReadError(InvalidS3Body) not TypeError; dynamic wrappers admitted. CHANGELOG: aws_s3 source: the S3 response Body is parsed at the SDK boundary (ADR-032) instead of gated by a runtime_checkable Protocol; a malformed Body is reported as InvalidS3Body. Hash AWSS3Source sha256:f203696d50207e25 -> sha256:2053b8a8ff1fd1b1.
- #15 FIXED. A probe that is still present after a failed removal is recorded in probe_cleanup_failures; measuring OSError goes to the existing handler. COMPAT: an unremovable probe fails preflight. CHANGELOG: Audit export bundle: preflight fails when a probe it created cannot be removed, instead of leaking it silently.
- #16 FIXED. Same-device check compares the real staging parent. COMPAT none with today's layout. CHANGELOG: Audit export bundle: preflight's same-device check compares the real staging parent.
- #17 FIXED. Reconcile fallback evidence records measured staging state; 'divergent' only for a compared staging tree. COMPAT: persisted evidence value changes from 'divergent' to absent/symlink/other where measured. CHANGELOG: Audit export bundle: reconcile evidence records the measured staging state instead of always 'divergent'.
- #31 FIXED. `<base64 32-byte digest>-<1..10000>` recognised as composite, recorded as no full-object checksum; malformed still rejected. COMPAT: overwrite=true can replace a foreign multipart SHA-256 object (still not declarable as predecessor). CHANGELOG: aws_s3 sink: a multipart (composite) ChecksumSHA256 is recorded as no full-object checksum instead of failing as malformed. Hash AWSS3Sink sha256:9f0d21a6ac2e98ed -> sha256:3d90ff2251470de9.
- #89 FIXED. Batch material cached per effect_id + frozen effect_input identity, cleared in close(); plan-hash check still per member. COMPAT none. CHANGELOG: Dataverse sink: member-effect validation computes batch plan material once per batch, not once per member. Hash DataverseSink sha256:985091dfc97a79ff -> sha256:e4c1991fde2f2ab9.
Scenario corpus: no old/new tokens in manifest (control: 25 sha256 lines read).

## Gates (lane-reported, HEAD 83d626ae)
Lane test 21 passed; module tests -n 3: 3954 passed; check_contracts 0 (census 2649 unchanged); plugin_contract rules 0 (negative control red); ruff/format/mypy clean; test_no_hasattr_branching passed; test_masquerade_gate 243 passed, 1 skipped.

## Tier-model keyless scan (base vs HEAD)
plugins/sources max_hits 46/40 -> 44/40 (down). ROTATED SIGNED FINGERPRINTS (operator re-sign, config/cicd/enforce_tier_model/plugins.yaml):
- plugins/sinks/_audit_export_bundle_effects.py:R6:preflight_audit_export_bundle fp=cdf1bcdadf070049 -> fp=5481a8ab94a9c2e5
- plugins/sources/aws_s3_source.py:R6:_download_s3_object fp=62f0723837985815, 8a3c108521ec3dc1, f10bcbe2e4af8648 -> fp=249a0ac76f8e242f, aa8501bfaedfd2fd, 2111f16f3ee30405
No judge signatures touched.

## Maintainer decisions / review items
1. masquerade_baseline.yaml +2 entries (ADR-032 sentinel getattr at `_s3_body_member`, and the test double) — orchestrator view: this is the gate's per-site pin for the parse pattern ADR-032 prescribes, not a blanket widening; confirm.
2. #7 forces value-free rendering for row-carrying contexts rather than flipping create_sandboxed_environment's default to value_free=True; flip the default instead if preferred.
