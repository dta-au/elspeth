DONE (with one caveat): #47, #74, #83 and #84 are committed on lane/p2-047-074-083-084-dataverse as 8 commits (c02c3719..eda08176). The caveat: #83 was fixed by correcting the guidance, so real row-level 4xx diversion still needs a maintainer decision on which Dataverse error codes count as row faults.

(The hub wrote this from lane-07's hand-back, because the harness refused the lane's own report write. Logs are in this lane dir: red47/74/83/84.log, final2.log, final3.log.)

## #47: FormattedValue annotations were never requested
**Root cause:**
- No request sent `Prefer: odata.include-annotations`.
- The strip regex was anchored with `re.match`, so property-level annotations were kept as columns.

**Fix:**
- New helper `_include_annotations_headers`, and an `annotations=` keyword on `paginate_odata`, `paginate_fetchxml` and `get_page`. FetchXML merges it into its single Prefer header.
- The header goes through `extra_headers`, so the audit record and VERIFY see the same request shape. The VERIFY nextLink preflight now passes the same headers.
- The strip pattern is now `@(?:odata|Microsoft\.Dynamics\.CRM)\.`, applied with `.search`.
- DataverseSource hash re-pinned: 8d3f3de6d9e62d9f -> a6da227d8a3dfe57.

**Evidence:** RED: 5 failed. GREEN: 8 passed.

## #74: nextLink was not held to the environment's https origin
**Fix:** `_https_origin` checks the nextLink's origin (https, host, and port, with 443 as the default port) before any VERIFY, SSRF check or request. A mismatch raises `ssrf_rejected` and is not retryable. The existing evil.com test now expects the earlier message.

**Evidence:**
- RED: "bearer token was sent to the nextLink" in 4 cases: http, another tenant, another region, another port.
- GREEN: 14 passed, including same-origin controls.

## #83: row 4xx diversion was unreachable
**Fix:** the composer hints now say every failed write raises and that `on_write_failure` does not route Dataverse error responses.

**Evidence:** RED: 5 failed. GREEN: 19 passed.

**Open for the maintainer:** real diversion needs a decision on which OData `error.code` values count as row-attributable. A wrong list would make discard mode drop rows silently.

## #84: reconcile reported 'divergent' for any member with a lookup
**Fix:**
- The reconcile GET now requests the `associatednavigationproperty` annotation.
- `_reconciled_property_matches` matches a `<nav>@odata.bind` against the `_<attr>_value` whose annotation names that navigation property and whose value is the lower-cased id.
- A lookup bound to another record, or removed, still reads as divergent.
- Census unchanged. The tier-model max_hits are not exceeded.
- DataverseSink hash re-pinned to b6385bbac6b974d2.

**Evidence:** RED: `'divergent' == 'exact'`, 2 failed. GREEN: 23 passed.

**Left alone:** server-side normalisation of decimals and datetimes.

## Gates
| Check | Result |
|---|---|
| ruff | 0 |
| format | 0 |
| check_contracts | 0 (census 2668) |
| mypy | 0 |
| sink/diversion/hash/catalog tests | 361 passed |
| corpus/source/client/paging/pipeline tests | 817 passed |
| branch-safety | 0 |

Keyless tier-model findings for the Dataverse files: only the pre-existing expired per-file rules. No signatures were touched.
