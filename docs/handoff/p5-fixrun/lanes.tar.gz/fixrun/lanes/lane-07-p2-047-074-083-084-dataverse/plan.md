# lane-07-p2-047-074-083-084-dataverse — #47 [P2, bug] Dataverse include_formatted_values does nothing because the request never asks for FormattedValue annotations; #74 [P2, security] Dataverse nextLink is not held to HTTPS or to the configured environment host, so the bearer token can go to another host or over plaintext; #83 [P2, bug] Dataverse row-level diversion is unreachable in production: no client error is ever categorised row_data_error; #84 [P2, bug] Dataverse reconcile always reports 'divergent' (UNKNOWN) for sinks with lookups, blocking crash recovery

Ticket `p2-047-074-083-084-dataverse` · run `p2` · branch `lane/p2-047-074-083-084-dataverse` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

This lane fixes 4 findings; fix each one (one test commit + one fix commit PER finding).
The listed files are where the sweep located each defect; a finding may need no change in some of them.

FINDING #47 [P2, bug] Dataverse include_formatted_values does nothing because the request never asks for FormattedValue annotations

`src/elspeth/plugins/sources/dataverse.py`

dataverse.py:163-166 documents `include_formatted_values` as 'Preserve Dataverse formatted value annotations', and _strip_odata_metadata (lines 615-656) turns `<field>@OData.Community.Display.V1.FormattedValue` keys into `<field>__formatted`. But the Dataverse Web API only returns those annotations when the request sends `Prefer: odata.include-annotations="OData.Community.Display.V1.FormattedValue"` (or "*"). Nothing sends that header. DataverseClient.get_auth_headers (clients/dataverse.py:316-328) sends only Authorization, Accept and the OData-*Version headers. get_page, paginate_odata and paginate_fetchxml call _execute_request without `extra_headers`, and `rg 'Prefer|include-annotations' src/elspeth` finds no request header anywhere. As a result, against a real environment, `include_formatted_values: true` silently returns no `__formatted` fields and raises no error. Under an observed schema the fields are simply missing. Under a fixed schema that declares `x__formatted` as required, every row is quarantined. The unit tests (test_dataverse_source.py:818-855, 1638, 1679) inject the annotation keys straight into mocked responses and never check the outgoing headers, so they cannot catch this. A related latent problem shows up once annotations are requested: _ODATA_ANNOTATION_PATTERN `^@odata\.|@Microsoft\.Dynamics\.CRM\.` is used with re.match, which anchors both alternatives at position 0. Property-level annotations such as `_parentcustomerid_value@Microsoft.Dynamics.CRM.lookuplogicalname` or `x@odata.type` are therefore NOT stripped; I confirmed this by running the regex: lookuplogicalname -> False, `@odata.etag` -> True. Test line 1567 uses a bare `@Microsoft.Dynamics.CRM.lookuplogicalname` key, which real responses never contain. Expected behaviour: when include_formatted_values is true, send the Prefer header for the FormattedValue annotation (and record it in the fingerprinted request headers), and anchor the strip pattern so it also catches `<prop>@...` annotations. Alternatively, reject the option at config time until it works.

**Verifier (CONFIRMED):** sources/dataverse.py:163-166 documents include_formatted_values, and _strip_odata_metadata:615-656 maps '<f>@OData.Community.Display.V1.FormattedValue' to '<f>__formatted'. Per https://learn.microsoft.com/en-us/power-apps/developer/data-platform/webapi/query/select-columns#include-formatted-values-in-results, 'To include formatted values in your results, use the Prefer request header ... Prefer: odata.include-annotations="OData.Community.Display.V1.FormattedValue"'. No Prefer header is ever sent: the grep is empty, and the #71 repro captured prefer=None on the client's GET path, which paginate_odata shares. So the option is a silent no-op against a real Dataverse. Fixed schemas that require x__formatted will quarantine every row (traced, not run). The regex sub-claim is also confirmed by running it: _ODATA_ANNOTATION_PATTERN.match gives '@odata.etag' True, '@Microsoft.Dynamics.CRM.totalrecordcount' True, '_ownerid_value@Microsoft.Dynamics.CRM.lookuplogicalname' False, 'x@odata.type' False. The same MS page shows real keys are property-prefixed ('_ownerid_value@Microsoft.Dynamics.CRM.lookuplogicalname'). That part is latent until annotations are requested.

FINDING #74 [P2, security] Dataverse nextLink is not held to HTTPS or to the configured environment host, so the bearer token can go to another host or over plaintext

`src/elspeth/plugins/infrastructure/clients/dataverse.py`

Location: dataverse.py:827-834 (paginate_odata) and _validate_url_ssrf at 331-378. Only environment_url passes validate_credential_safe_https_url (line 274). A Tier-3 @odata.nextLink is checked only against the family-wide domain allowlist (`*.crm.dynamics.com`, etc.) and validate_url_for_ssrf. validate_url_scheme accepts both http and https (core/security/web.py, around line 503). _execute_request then attaches `Authorization: Bearer <token>` (line 513-514) whatever the scheme or host, and adds SNI and TLS only when the scheme is https (line 538). Consequences: (1) a nextLink `http://<org>.crm.dynamics.com/...` sends the bearer token in cleartext to port 80 of the pinned IP; (2) a nextLink to any other tenant's `*.crm.dynamics.com` (anyone can provision one) receives this environment's bearer token. The module's own design treats nextLink as an SSRF and redirection vector (error text: 'Possible SSRF attempt via @odata.nextLink redirection'). The test module header (test_dataverse_client.py:7) claims 'reject cross-host nextLink URLs', but the only test (line 711) uses evil.com, which the allowlist catches. No test covers a same-family foreign host or an http scheme. Expected behaviour: require nextLink scheme == 'https' and hostname (and port) equal to the configured environment_url host before attaching credentials. Raise DataverseClientError(error_category='ssrf_rejected') otherwise.

**Verifier (CONFIRMED):** Code: paginate_odata (clients/dataverse.py:827-834) validates nextLink only through _validate_url_ssrf (331-378): the family-wide fnmatch allowlist (DATAVERSE_DOMAIN_ALLOWLIST '*.crm.dynamics.com' etc.) plus validate_url_for_ssrf, and core/security/web.py:88 ALLOWED_SCHEMES={'http','https'}. _execute_request:513-514 merges the Bearer header unconditionally, and SNI is set only for https (538). Repro (scratch-C/repro_client.py) with environment_url=https://myorg.crm.dynamics.com: (a) nextLink http://myorg.crm.dynamics.com/... was followed as `http://20.0.0.1/...` with Authorization 'Bearer SECRET', i.e. plaintext; (b) nextLink https://attacker.crm.dynamics.com/... was followed with Host attacker.crm.dynamics.com and the same bearer token. No same-host or https check exists. Precondition: the nextLink must come from the TLS-protected configured Dataverse endpoint (or a compromised or proxied response), so exploitability is limited. However, the module explicitly treats nextLink as an SSRF/redirect vector, and the token's audience (environment_url/.default) is replayable against the victim org. The test at test_dataverse_client.py:711 covers only evil.com. I kept P2; P3 is defensible given the trusted-origin precondition.

FINDING #83 [P2, bug] Dataverse row-level diversion is unreachable in production: no client error is ever categorised row_data_error

`src/elspeth/plugins/sinks/dataverse.py`

`_is_row_attributable_write_error` (dataverse.py:77-80) diverts only when `error.error_category in {'row_data_error'}`. An rg for `row_data_error` across src/ finds only this constant (line 73). `DataverseClient._classify_error` (clients/dataverse.py:438-474) creates 400/404/409/412/422 errors with the default `error_category='protocol_error'` and never sets `row_data_error`. Only test doubles produce it (tests/unit/plugins/sinks/test_dataverse_sink.py:884, tests/unit/engine/test_dataverse_member_effect_diversion.py:76). So the `on_write_failure` diversion branch in `commit_member_effect` (lines 659-680) cannot run against real Dataverse, and every row-level 4xx raises and aborts the effect. Requiring structured classification fails closed, so this is not data loss. However, the plugin's own composer/agent guidance (lines 353-354) tells operators and the planner that "a non-retryable 4xx about the row (400/404/409/412/422) diverts that row and the batch continues" and to "Set on_write_failure to a quarantine sink so single-row 4xx don't abort the batch". That is false at runtime. Expected: either the client classifies row-attributable Dataverse error bodies (for example the OData `error.code` for attribute validation or duplicate key) as `row_data_error`, or the hints and docstring state that every 4xx currently aborts. Verification: rg for producers of `row_data_error` in src/ (none), read `_classify_error`, and read the test doubles that inject the category by hand.

**Verifier (CONFIRMED):** `grep -rn row_data_error src/` finds only sinks/dataverse.py:73, the consumer constant. DataverseClientError's default error_category is 'protocol_error' (clients/dataverse.py ~line 96). The only error_category= values set in the client are ssrf_rejected (365,376), auth_failure (432), empty_page_guard (814) and protocol_violation (889,907). _classify_error (438-474) never parses the error body or sets row_data_error. So _is_row_attributable_write_error (sinks/dataverse.py:77-80) is always False for real responses, and the diversion branch in commit_member_effect (~659-680) is unreachable outside test doubles. The fail-closed direction is intentional per the comment at 60-72 ('Status-only failures must raise'), so no data is lost. But the composer hints at 353-354 promise that a row 4xx 'diverts that row and the batch continues', which is false at runtime. Defect: dead feature plus misleading operator/planner guidance.

FINDING #84 [P2, bug] Dataverse reconcile always reports 'divergent' (UNKNOWN) for sinks with lookups, blocking crash recovery

`src/elspeth/plugins/sinks/dataverse.py`

`reconcile_member_effect` (dataverse.py:698-716) checks the GET response with `all(key in actual and actual[key] == value for key, value in expected.items())`, where `expected` is the PATCH payload from `_map_row`. For any configured lookup, that payload has the write-only annotation key `<nav>@odata.bind: '/accounts(guid)'` (line 471-472). A Dataverse GET of the record never returns `@odata.bind` keys; it returns `_<nav>_value: '<guid>'`. So for every member with a non-null lookup, `key in actual` is False and reconcile returns `SinkEffectReconcileResult.unknown(... 'divergent')` even when the write landed exactly. The coordinator (engine/executors/sink_effects.py:898-899) raises `SinkEffectUnknownError` on UNKNOWN. After a response-lost commit, recovery for a lookup-bearing Dataverse sink therefore can never complete without operator action. Expected: compare only properties Dataverse returns, translating `<nav>@odata.bind` to `_<nav>_value` and the GUID, or use `$select`, or leave bind keys out of the exactness check. Verification: read `_map_row` and the reconcile comparison, and read the coordinator's UNKNOWN handling. The reconcile tests use `_RecoverableDataverseClient` (test_dataverse_sink.py:862-895), which stores and echoes the PATCH body verbatim, so `@odata.bind` keys round-trip. That masks the defect, and no test covers reconcile with lookups.

**Verifier (CONFIRMED):** _map_row (sinks/dataverse.py:~446-474) emits '<target_field>@odata.bind': '/<entity>(<guid>)' for non-null lookups. reconcile_member_effect (~688-716) uses `expected` = that payload and requires `all(key in actual and actual[key] == value ...)`, where actual is a plain GET by alternate key (client.get_page, no $select, no Prefer). @odata.bind is write-only association syntax. A GET returns the lookup as '_<nav>_value': '<guid>' (https://learn.microsoft.com/en-us/power-apps/developer/data-platform/webapi/query/select-columns#lookup-property-data and the retrieve-table-row page's response examples), so `key in actual` can never hold for a bind key, and reconcile returns unknown('divergent'). engine/executors/sink_effects.py:752-753 and 898-899 raise SinkEffectUnknownError on UNKNOWN, so recovery after a response-lost commit for any member with a non-null lookup cannot auto-resolve. Traced, not run against live Dataverse; the plugin-level path is deterministic. The echo double in test_dataverse_sink.py masks it, and no reconcile test uses lookups (grep for odata.bind/lookups near reconcile is empty). Server-side value normalisation (decimals, datetimes) could cause further false-divergent results even without lookups.

## Files a correct fix must change

- `src/elspeth/plugins/sources/dataverse.py`
- `src/elspeth/plugins/infrastructure/clients/dataverse.py`
- `src/elspeth/plugins/sinks/dataverse.py`

## Test files the lane must add or change

- `tests/unit/plugins/test_dataverse_p2_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/test_dataverse_p2_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-07-p2-047-074-083-084-dataverse/report.md`; the worker returns one line.
