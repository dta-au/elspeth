lane-02-p4-batch-json: 10 of 11 findings fixed test-first on lane/p4-batch-json (RED tests 62fcba07, fix bfd81f67: #53 #54 #101 #102 #105 #111 #120 #121 #135 #136). #146 (truncate) needs a maintainer decision because it conflicts with the field-spelling ruling, so truncate.py is untouched. All gates pass. One signed tier_model allowlist entry (mixin.py R9 evict_submission) is now stale; the operator needs to remove it and re-sign.

(Written by orchestrator from the resumed lane's hand-back; the subagent's report.md write was refused. truncate.py removed from this lane's expected files by the orchestrator, recorded in status.json orchestrator_notes.)

UNTOUCHED: src/elspeth/plugins/transforms/truncate.py — #146 needs a maintainer decision.

Branch lane/p4-batch-json, HEAD bfd81f67. 62fcba07 = RED tests only (tests/unit/plugins/test_p4_batch_json_sweep.py); bfd81f67 = fixes, hash re-pins, golden updates.

## RED evidence
Lane test file run against `git archive 62fcba07 src`: exit 1, 27 failed / 5 passed, every failure AssertionError or `Failed: DID NOT RAISE`. The 5 passing are guards (#53/#54 blob_too_large and decode_failed; #121 ordinary interpolation; #135 int/float admission). GREEN on HEAD: 32 passed.

## Per finding
- #53 FIXED (coverage). Every routed blob_csv_expand reason has a focused test. COMPAT none. CHANGELOG: blob_csv_expand: every routed error reason now has a focused unit test.
- #54 FIXED. `_parse_csv` spreads `_source_identity(loaded)` into every parse-phase reason. COMPAT additive (`field`, plus `blob_ref` on the blob arm). CHANGELOG: blob_csv_expand: CSV parse-phase error reasons now name their source (field, blob_ref) like empty_csv and load errors. Hash sha256:36274db08c825a1e -> sha256:64de4207fc6d2406.
- #101 FIXED. Success rows emit baseline_/cohort_missing_indices and baseline_/cohort_non_finite_indices (declared `any` created fields). COMPAT additive, four new output fields. CHANGELOG: batch_drift_compare: success rows now list skipped missing/non-finite rows by batch index per cohort, as batch_stats does. Hash sha256:73159752694bcabe -> sha256:a0f9d0027187a0ac (shared with #102).
- #102 FIXED (disclosure). usage_when_not_to_use and a composer hint state chi_square_statistic covers only baseline-supported categories. COMPAT none. CHANGELOG: batch_drift_compare: document that chi_square_statistic covers only baseline-supported categories.
- #105 FIXED. Dead JSON-array append branch and helper removed; reaching it with include_baseline raises FrameworkBugError. COMPAT none for valid configs. CHANGELOG: json sink: remove the unreachable JSON-array append path (format=json never appends). Hash sha256:0241bd4eb91ae378 -> sha256:6c9b64bb34350d2c; manifest token moved on 15 lines; EXPECTED_CASE_REGISTRY_SHA256 and reopen-resume resumed_full_projection_sha256 re-pinned in test_dag_scenario_corpus_contract.py.
- #111 FIXED. New `index_field` option (default item_index), validated like line_explode's. COMPAT backward compatible. CHANGELOG: json_explode: new index_field option (default item_index) so nested explodes do not collide. Hash sha256:1919e96964500441 -> sha256:bc435c1144336235; manifest 1 line.
- #120 FIXED. Tracking key deleted only when buffer.evict() returns True, under _batch_submissions_lock. COMPAT bug fix. CHANGELOG: batch transforms: a refused eviction no longer replaces a completed row's result with a KeyError. OPERATOR: signed entry plugins/infrastructure/batching/mixin.py:R9:BatchTransformMixin:evict_submission:fp=0415707765ca653e is now STALE — remove and re-sign.
- #121 FIXED. Non-finite interpolation span uses lower*(1-f)+upper*f; finite spans byte-identical. COMPAT batches that failed with float_overflow now succeed. CHANGELOG: batch_distribution_profile: percentiles of extreme opposite-sign finite values no longer fail with float_overflow. Hash sha256:e4a5e61cadd31134 -> sha256:7eda1973294bc95a.
- #135 FIXED. `value: float = Field(strict=True)`. COMPAT BREAKING: `value: true/false` or a quoted number now fails at config load instead of becoming 1.0/0.0/0.5. CHANGELOG: batch_threshold_summary: threshold value must be a number; booleans and numeric strings are now refused at config load. Hash sha256:7cb6f69881bb092a -> sha256:bb849e2af579a479.
- #136 FIXED. Values admit str, int, float, bool, Decimal, datetime (as require_scalar_group_key); non-finite Decimal skipped and reported. COMPAT such batches now succeed; wrong_type `expected` text changed. CHANGELOG: batch_top_k: count datetime and Decimal values (as group_by already admits); non-finite Decimals are skipped and reported. Hash sha256:26510751574334a4 -> sha256:1d3cfb23e9f4708c.

## Maintainer decisions
- #146 truncate never declares declared_string_input_fields. Declaring the fields folds them into declared_read_fields, which the field-name spelling rule (operator ruling 2026-09-25) enforces at build time, in the Composer Stage-1 mirror and per row; truncate deliberately resolves original-header spellings (pinned by test_truncate.py::test_success_reason_uses_normalized_field_name_for_original_header_config), so declaring would refuse that supported config. Options: (a) new type-only build check resolving names like the row lookup; (b) accept refusing header-spelled truncate configs and declare; (c) close as by-design, runtime-only enforcement.

## Gates (lane-reported, final tree bfd81f67)
Hashes match pins for all 7 touched plugins (truncate unchanged sha256:61cdc3ececd46174); 0 old-token hits in manifest (positive control 15 hits); check_contracts 0; plugin_contract rules 0; ruff/format 0; mypy 8 files clean; test_no_hasattr_branching passed; lane test 32 passed; module tests -n 3: 874 passed; catalog goldens 4 passed; keyless tier_model base vs HEAD on touched files: only delta is the stale R9 entry (3806 vs 3807 lines).

## Verify follow-up (orchestrator, 2026-11-14)
- verify on merged tree c69e530f+bfd81f67 failed SUITE: 3 failures, all failing serially:
  test_plugin_assistance_coverage::test_builtin_plugin_publishes_discovery_hints[transform-batch_drift_compare] (#102 hint 328 > 280 chars) and
  test_pipeline_planner::test_initial_request_declares_supplied_information_and_keeps_discovery_available[live|small] (scaffold 141255 > 141070 B).
- 6d4dc817 merges base c69e530f into the lane; ece45597 shortens the #102 hint and usage sentence, re-pins source_file_hash sha256:a0f9d0027187a0ac -> sha256:fd51fd5370b91aab, and prices the remaining usage sentence as _DRIFT_COMPARE_CHI_SQUARE_DISCLOSURE_CANONICAL_BYTES = 64 (measured 141061 B without / 141125 B with, instrument checked against the known failing value) under the 2026-11-10 operator ruling.
- Gates: 752 related tests passed (-n 4), ruff/format/mypy/check_contracts/plugin_contract lints 0. Simulated chain +safety-aws +infra-sinks: assistance coverage, planner, web/catalog 694 passed.
- CHANGELOG (#102, replaces the earlier line): batch_drift_compare: document that chi_square_statistic omits categories absent from the baseline (usage text and composer hint).
- Maintainer review: the +64 B planner scaffold allowance.
