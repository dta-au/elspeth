# lane-08-p3-llm-core — #32 [P3, bug] LLMConfig accepts contradictory pool delay knobs; the invariant is checked only lazily, outside from_dict; #45 [P3, bug] Single-query success_reason under-reports fields_added and records a different 'model' meaning than multi-query mode; #116 [P3, enhancement] Multi-query (upstream mode, no prefix override) accepts output suffixes that the raw response and operational fields silently overwrite; single-prompt mode refuses them; #139 [P3, security] Langfuse tracer keyed by public_key silently ignores a later plugin's host and secret_key, so traces go to the first host configured in the process; #148 [P3 (raised as P2), bug] Required image input with an empty list silently sends a text-only LLM call; #151 [P3, bug] Tracing config without `provider` silently drops every other key (tracing quietly disabled)

Ticket `p3-llm-core` · run `p3` · branch `lane/p3-llm-core` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

This lane fixes 6 findings; fix each one (one test commit + one fix commit PER finding).
Every finding names the files where the sweep located it; touch only what each fix needs.

FINDING #32 [P3, bug] LLMConfig accepts contradictory pool delay knobs; the invariant is checked only lazily, outside from_dict

`src/elspeth/plugins/transforms/llm/base.py`

base.py:413-469: the flat pool fields (min_dispatch_delay_ms, max_dispatch_delay_ms and the others) are each range-checked, but nothing in LLMConfig enforces PoolConfig's cross-field rule that min <= max (pooling/config.py _validate_delay_invariants). That rule runs only when the `pool_config` property builds a PoolConfig, and the only caller of that property is LLMTransform.__init__ (transform.py:1564). I reproduced it from the worktree with the venv interpreter and confirmed elspeth.__file__ resolves into the worktree. `LLMConfig.from_dict({provider:'azure', schema:{mode:observed}, prompt_template:'hi', pool_size:4, min_dispatch_delay_ms:9000, max_dispatch_delay_ms:10})` succeeds. Reading `.pool_config` afterwards raises a raw pydantic `ValidationError for PoolConfig` whose text echoes the whole input dict. Because the error is not a PluginConfigError, it bypasses the redacted, field-attributed error category that from_dict promises (the docstring at base.py:589-592 says config-shape errors belong inside model_validate). With pool_size=1 the same contradiction is accepted silently: pool_config returns None and the knobs are ignored. Tests: tests/unit/plugins/llm/test_pool_config.py:101 checks only PoolConfig directly. rg found no test that feeds the contradiction through LLMConfig.from_dict. Expected behaviour: an LLMConfig model_validator rejects min_dispatch_delay_ms > max_dispatch_delay_ms whatever pool_size is, ideally by building PoolConfig at validation time, so the failure arrives as a PluginConfigError at config or compose time.

FINDING #45 [P3, bug] Single-query success_reason under-reports fields_added and records a different 'model' meaning than multi-query mode

`src/elspeth/plugins/transforms/llm/transform.py`

In single mode, transform.py:492 records `fields_added: [response_field, *output_field suffixes]`. But populate_llm_operational_fields (llm/__init__.py:345-346) also writes `<response_field>_usage` and `<response_field>_model` into the row, and those are left out. Multi-query mode (transform.py:1042/1209) lists every key it added, operational fields included. Siblings (textract, batch_duplicate_annotator) use `sorted(self.declared_output_fields)`. The `metadata.model` key also means different things in the two modes. Single mode stores the model the provider actually served (`result.model`, line 494). Multi-query stores the configured `self.model` (lines 1043/1210) and records no served model or usage in the audit metadata. A Landscape/TUI reader (tui/widgets/node_detail.py:259 shows 'Fields added') therefore gets an incomplete field inventory, and the same key holds the served model in one mode and the configured model in the other. Probe run in the worktree (provider mock serving 'served-model', config 'configured-model'). Single: row gained ['llm_response','llm_response_model','llm_response_usage'] but fields_added=['llm_response'] and metadata.model='served-model'. Multi: fields_added listed all three and metadata.model='configured-model'. Tests in tests/unit/plugins/llm/test_llm_success_reason.py:290-298 only assert that fields_added is a non-empty list, so the omission goes undetected. Expected: fields_added in both modes is the full set of written fields (e.g. sorted(declared_output_fields)), and the audit metadata keeps the configured model and the served model under separate, consistent keys.

FINDING #116 [P3, enhancement] Multi-query (upstream mode, no prefix override) accepts output suffixes that the raw response and operational fields silently overwrite; single-prompt mode refuses them

`src/elspeth/plugins/transforms/llm/multi_query.py`

resolve_queries (lines 452-469) reserves only {usage, model, error}, taken from MULTI_QUERY_GUARANTEED_SUFFIXES and a literal. It does not reserve the response field itself or `<response_field>_usage` / `<response_field>_model`. A query `a` with `output_fields: [{suffix: llm_response, type: integer}]` therefore publishes `a_llm_response`. At row assembly (transform.py:825-829) the typed extracted value is written there and then overwritten by the raw content string. A suffix of `llm_response_usage` is likewise overwritten by populate_llm_operational_fields. In structured mode the LLM is asked for that field, and its value is thrown away with no diagnostic. I confirmed that resolve_queries accepts both suffixes. The stricter `unique_query_generated_fields` inventory only runs in ordered mode or when some query sets structured_output_prefix (base.py:604-605, transform.py:1609-1612). Single-prompt mode refuses exactly these suffixes (base.py:678-689, `collides with the transform's own response/operational fields`, tested in test_transform.py:4106-4130), and the reserved-suffix error message itself says the check exists 'to prevent silent data loss'. This is deliberate legacy precedence: test_structured_output_prefix.py:122-130 (`test_upstream_default_keeps_legacy_operational_precedence`) checks that the overwrite happens, and the `_llm_created_output_fields` docstring records it. So it is a sanctioned compatibility choice rather than an accident. It remains an asymmetry with single mode and a silent-discard path. Suggested change: refuse `{response_field}{guaranteed_suffix}` collisions in upstream mode too, once the operator approves dropping the pinned legacy behaviour. That is a config-compatibility decision under the 0.8.5+ posture.

FINDING #139 [P3, security] Langfuse tracer keyed by public_key silently ignores a later plugin's host and secret_key, so traces go to the first host configured in the process

`src/elspeth/plugins/transforms/llm/langfuse.py`

langfuse.py:290-296 builds a Langfuse client per tracer from tracing_config.host and secret_key. Langfuse 3.14.6 (the installed version) caches LangfuseResourceManager per process keyed only by public_key (site-packages/langfuse/_client/resource_manager.py:101-102). That cache holds the span processor/exporter's base_url and secret_key. Reproduced: two create_langfuse_tracer calls with public_key 'pk-x' and hosts https://lf-a.example.com then https://lf-b.example.com. The second client has _base_url = lf-b, but _resources.base_url = lf-a, and both share one resources object. Traces from the second plugin (rendered prompts and responses, i.e. row data) are exported to host A with secret A. This bypasses the fail-closed per-config host egress validation described in tracing.py:106-114. It also contradicts the LangfuseTracingConfig docstring that multiple plugins 'can have different Langfuse configurations (e.g., different hosts)'. In a long-running process (web server), a rotated secret_key is ignored until restart. Expected: detect a cached resource manager whose base_url or secret_key differs from the requested config and refuse it, or pass an isolated tracer_provider/httpx client per config. At minimum, correct the docstring claim.

FINDING #148 [P3 (raised as P2), bug] Required image input with an empty list silently sends a text-only LLM call

`src/elspeth/plugins/transforms/llm/image_inputs.py`

image_inputs.py:153-173: `required` refuses only an absent or None field. If a required field holds [] (or ()), refs = enumerate([]) adds nothing, no error is returned, and resolve_image_parts returns (). The LLM call then goes ahead with no image, and the result is attributed to a row whose required image was never sent. This is a realistic Tier-2 input: an upstream extraction or explode that found no attachments. Verified by running resolve_image_parts({'pic': []}, specs=[ImageInputConfig(field='pic', format='png')], ...), which returns (). The default required=True (:33) and the declared_input_fields treatment in base.py:1154-1174 both treat required images as mandatory inputs. Expected: when spec.required and the resolved ref collection is empty, return a row-level TransformResult.error (e.g. missing_field or invalid_input/error_type='empty_image_list'). rg in tests/unit/plugins/llm/test_image_inputs.py found no empty-list case.

**Verifier (CONFIRMED):** Repro scratch-F/r148.py. resolve_image_parts(row {'pic': []} or {'pic': ()}, specs=[ImageInputConfig(field='pic', format='png')]) (required defaults to True, image_inputs.py:33) returns (). {'pic': None} returns missing_field. image_inputs.py:153-170 refuses only an absent or None field, and enumerate([]) adds nothing. The upstream guard _blank_required_input_result (transform.py:157-180) catches only None and blank str, not empty containers, so [] passes. transform.py:325-335 / 677-687 then dispatch with image_parts=() as a text-only call. No docs or test define empty-list semantics (test_image_inputs.py has no [] case). Lowered to P3 because 'required' for a list column is ambiguous and the behaviour may be a design gap rather than a regression. Still, required=True sending zero images contradicts the declared_input_fields treatment (base.py:1154-1174).

FINDING #151 [P3, bug] Tracing config without `provider` silently drops every other key (tracing quietly disabled)

`src/elspeth/plugins/transforms/llm/tracing.py`

tracing.py:172 and 184-185: when 'provider' is absent it defaults to 'none', and case 'none' returns TracingConfig(provider='none'), discarding all other keys. So `tracing: {connection_string: ${APPLICATIONINSIGHTS_CONNECTION_STRING}, enable_content_recording: false}` (operator forgot provider), or `{provider: none, host: ...}`, is accepted and tracing is silently off. Verified: parse_tracing_config({'connection_string': 'InstrumentationKey=x'}) returns TracingConfig(provider='none') with no error. That contradicts the module's own fail-loud posture (unknown providers raise at :186; the azure/provider mismatch raises in transform.py:1550). Expected: when provider resolves to 'none', refuse any other keys (keep {} meaning no tracing). The test test_empty_dict_returns_base_config covers only {}.

## Files a correct fix must change

- `src/elspeth/plugins/transforms/llm/transform.py`

## Test files the lane must add or change

- `tests/unit/plugins/llm/test_llm_core_p3_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/llm/test_llm_core_p3_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-08-p3-llm-core/report.md`; the worker returns one line.
