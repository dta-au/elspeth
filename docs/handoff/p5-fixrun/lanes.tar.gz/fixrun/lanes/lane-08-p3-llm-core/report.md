PARTIAL: lane-08-p3-llm-core landed #32, #45, #139, #148, #151 (10 commits, HEAD 97cd5fa1, base 1ee11f2e); #116 skipped — needs a maintainer config-compatibility decision (dropping pinned legacy upstream-mode precedence).

(Written by orchestrator from the lane's hand-back; the subagent's report.md write was refused.)

## Fixes
- #32 shared validate_pool_delay_invariants (pooling/config.py) used by PoolConfig and new LLMConfig._validate_pool_knobs; contradictory pool delay knobs refused at from_dict (min>max always; AIMD rules when pool_size>1).
- #45 single-query fields_added from get_llm_guaranteed_fields (adds <rf>_usage, <rf>_model); metadata.model = configured model in both modes; served model as metadata.served_model (single) and <query>_served_model (multi). COMPAT: readers of single-mode metadata.model as served model must read served_model. LLMTransform source_file_hash sha256:239240ed0e8901b7.
- #139 Langfuse tracer refuses a client whose shared resource manager has a different base_url/secret_key than requested (langfuse caches per public_key); refuses divergent LANGFUSE_BASE_URL env too.
- #148 required image field with empty list/tuple -> invalid_input empty_image_list row error.
- #151 tracing config with provider none/omitted plus other keys refused (names keys only). COMPAT.

## #116 (not landed)
Pinned by test_structured_output_prefix::test_upstream_default_keeps_legacy_operational_precedence; remedy requires operator approval to drop legacy behaviour.

## Evidence (lane-reported)
- RED per finding at assertions; GREEN lane 17 passed; modules 4293 passed, 1 terra-pricing load timeout (passes serially).
- ruff/format/check_contracts (2668)/mypy 0; keyless trust-tier diff empty (controlled); no fencing change.

## #116 LANDED on lane (agent, 2026-11-12)
Maintainer: drop legacy. a81edd3e tests (11/12 RED at assertion, 1 control), 8c96452a fix: unique_query_generated_fields enforced for every multi-query config; legacy precedence filters/docstrings/teaching text removed (composer state parity, catalog goldens, docs/guides/ordered-llm-queries.md); 5 pinning tests replaced/deleted. LLMTransform hash 3c60f14ba869b372. COMPAT/BREAKING: upstream multi-query configs with suffix colliding with response/_usage/_model now refused at config. Left: _strict_generated_fields row-time check still opt-in; llm/model_catalog.py compat re-export (~30 importers). Full: p3/l08-116-report.md
