# lane-02-p3aws-guardrails — AWS review 2026-11-13 Bedrock guardrails: #4 P2 no deadline/shutdown/throttle handling; #5 P3 unhashable value escapes parser; #8 P3 ARN region/partition cross-check

Ticket `p3aws-guardrails` · run `p3aws` · branch `lane/p3aws-guardrails` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

FIRST STEP: merge the integrator tip into your lane branch so the widened plugin_hashes rule (f585ee70: it now scans plugins/transforms/aws) applies to you: `git fetch origin claude/zen-turing-pphown && git merge --no-ff 1e57572b` (resolve any conflict by keeping both sides' intent; CHANGELOG is the integrator's — keep theirs, never edit CHANGELOG yourself). The full review is at .claude/lanes/fixrun/p3aws/aws-review.md (copied from docs/architecture/reviews/2026-11-13-aws-transforms-review.md on 1e57572b) — read your findings there in full; line numbers are at f585ee70. Method: systematic debugging + TDD per finding: write a failing test that fails AT AN ASSERTION on the current code (assert new symbols exist with hasattr/find_spec before using them), commit tests, then the fix, then the next finding. Re-pin every touched plugin's source_file_hash with scripts.cicd.plugin_hash.compute_source_file_hash and check that nothing else pins the old token (grep docs/architecture/dag/scenario-corpus/v1/manifest.yaml); run `python scripts/check_contracts.py` (soft-mapping census: convert to owned types rather than adding soft mappings; only re-pin with --write-census if the site is an inherited contract) and `elspeth-lints check --rules plugin_contract --root src/elspeth` with PYTHONPATH covering src and elspeth-lints/src. Rules: no # noqa / # type: ignore / allowlist widening; no git stash; never touch judge signatures (if a signed tier_model entry's fingerprint rotates, list it in report.md for operator re-sign); no CHANGELOG edits; Python is the worktree .venv (3.14). If a fix needs a design decision outside the plugin (e.g. engine call-mode admission semantics), implement the plugin-side part, write the decision needed into report.md under 'Maintainer decisions', and do not invent engine policy. report.md must include per finding: RED evidence, fix summary, COMPAT/behaviour changes, a one-line CHANGELOG entry, and re-pinned hashes. Finding 4: BedrockGuardrailTransformBase.process has no row deadline, no shutdown check and treats throttling as permanent api_call_failed; mirror azure/base.py (row deadline -> retry_timeout/row_deadline_exceeded, shutdown check in the field loop, throttles retried in place within the row budget or raised as PluginRetryableError so the engine retries), and split error_type into malformed_response vs service_error carrying the retryable bit. Must stay fail-closed: no path may end in a validated success unless every configured field passed. Finding 5: guardrails_client.parse_guardrail_response must type-check confidence/action/filterStrength (type(x) is not str or x not in ...) so a wrong-typed provider value raises GuardrailResponseError and the call is recorded; add wrong-type mutators to the malformed-response tests. Finding 8: move the guardrail ARN partition/region cross-check from guardrail_profiles.BedrockGuardrailProfileSettings into a shared function used by BedrockGuardrailTransformConfig too.

## Files a correct fix must change

- `src/elspeth/plugins/transforms/aws/_guardrail_transform.py`
- `src/elspeth/plugins/transforms/aws/guardrails_client.py`

## Test files the lane must add or change

- `tests/unit/plugins/transforms/aws/test_aws_review_guardrails.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/transforms/aws/test_aws_review_guardrails.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash .claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-02-p3aws-guardrails/report.md`; the worker returns one line.
