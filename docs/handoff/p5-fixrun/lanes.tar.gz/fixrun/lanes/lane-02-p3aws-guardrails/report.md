DONE: lane-02-p3aws-guardrails fixed AWS review #4 (P2), #5 and #8 (P3) test-first on lane/p3aws-guardrails (HEAD 0cea569f); lane tests 26/26, wider AWS+guardrail 685 passed; no plugin hash moved; tier-model scan identical to base.

(Written by orchestrator from the lane's hand-back; the subagent's report.md write was refused by the harness.)

## Commits (after merge 8f0c5e9e of integrator 1e57572b)
4658036f test #5 / e43f4598 fix #5 / d6616b39 test #8 / 2cb0118e fix #8 / 3023fba2 test #4 / 0cea569f fix #4

## #5 (P3) wrong-typed provider value escaped parser
RED 6 failed at assertions (TypeError unhashable instead of GuardrailResponseError). Fix: parse_guardrail_response type-checks confidence/action/filterStrength and top-level action before membership.
CHANGELOG: Fixed: Bedrock guardrail response parser refuses wrong-typed confidence/action/filterStrength values as a recorded malformed response instead of crashing with an unaudited TypeError (AWS review #5).

## #8 (P3) transform config ARN cross-check
RED 7 failed at assertions. Fix: shared guardrail_profiles.validate_guardrail_arn_binding(identifier, *, region) used by the operator profile and BedrockGuardrailTransformConfig (_arn_binding after-validator). Schema unchanged.
COMPAT: a YAML config whose ARN names another region or a non-aws partition is now rejected at config validation (PluginConfigError).
CHANGELOG: Fixed: aws_bedrock_prompt_shield / aws_bedrock_content_safety config now rejects a guardrail ARN whose partition or region contradicts region, as the operator profile already did (AWS review #8).

## #4 (P2) deadline / shutdown / throttling
RED 9 failed at assertions. Fix in BedrockGuardrailTransformBase.process: GUARDRAIL_ROW_DEADLINE_SECONDS=300 checked before each field (retry_timeout/row_deadline_exceeded); shutdown check (ctx.shutdown_event + private event set by close()) -> shutdown_requested; retryable throttling/5xx/transport raise PluginRetryableError(retryable=True) for the engine retry policy (no in-place sleep, keeps replay deterministic); terminal failures split into malformed_response / service_error. Still fail-closed.
COMPAT: row error_type guardrail_service_error removed (now malformed_response | service_error); retryable failures go through engine retry policy (transient_error_no_retry when no policy); new outcomes row_deadline_exceeded and shutdown_requested. Frontend RunsHistoryDrawer.test.tsx still uses the old string as display sample data (left).
CHANGELOG: Fixed: Bedrock guardrail transforms stop scanning at a 300 s row deadline (retry_timeout/row_deadline_exceeded), honour shutdown between fields, hand retryable throttling/5xx/transport failures to the engine retry policy, and report terminal failures as malformed_response or service_error instead of one guardrail_service_error (AWS review #4).

## Gates (lane-reported)
plugin_contract rules exit 0 (mutation control went red then green); check_contracts 0 (census unchanged); ruff/format/mypy clean on touched files; keyless tier_model scan identical to base (3804 lines). Pre-existing stale signed entries needing operator re-sign: guardrails_client.py:R6:BedrockGuardrailsClient:apply_guardrail fingerprints 0ec2780db7b46669, 5ae32372cad087cf, b56971e35f73d863.

## Maintainer decisions
1. Make the 300 s row deadline an operator setting (Azure has max_capacity_retry_seconds, default 3600)?
2. Engine retry re-scans and re-bills already-passed fields; in-row retry avoids that but makes replay timing-dependent. Acceptable?
3. Bump plugin_version ("1.0.0") given changed row-error shapes?
