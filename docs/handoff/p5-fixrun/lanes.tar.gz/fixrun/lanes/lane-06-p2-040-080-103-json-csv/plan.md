# lane-06-p2-040-080-103-json-csv — #40 [P2, bug] JSONSource data_key and non-array structural quarantines record one row in Landscape but route a different one, so the validation-error link is lost (and snapshot_for_resume crashes); #80 [P2, bug] CSV decode errors are reported at the wrong line and row: TextIOWrapper decodes in ~8 KB chunks; #103 [P2 (raised as P1), bug] JSONL append glues the first new record onto an existing last line that has no trailing newline

Ticket `p2-040-080-103-json-csv` · run `p2` · branch `lane/p2-040-080-103-json-csv` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

This lane fixes 3 findings; fix each one (one test commit + one fix commit PER finding).
The listed files are where the sweep located each defect; a finding may need no change in some of them.

FINDING #40 [P2, bug] JSONSource data_key and non-array structural quarantines record one row in Landscape but route a different one, so the validation-error link is lost (and snapshot_for_resume crashes)

`src/elspeth/plugins/sources/json_source.py`

At json_source.py:419-431, 436-449 and 456-469, ctx.record_validation_error() receives row={'file_path', 'data_key'} (or {'file_path'}), while the SourceRow.quarantined that is yielded carries row={'file_path', 'structure_error'}. PluginContext links a quarantined emission to its recorded error by stable_hash of the row (plugin_context.py:399-415, _validation_error_match_key / pop_pending_quarantine_validation_error_id). Because the payloads differ, the lookup never matches. Effect in a normal run: quarantine_router.py:150-152 gets validation_error_id=None, so the quarantined token is ingested with no link to its validation_errors record, and an orphan entry stays in _pending_quarantine_validation_errors. Effect with snapshot_for_resume=true: source_snapshot.py:81-83 raises OrchestrationInvariantError('quarantined source snapshot emission has no recorded validation error'), so a Tier-3 structural fault crashes the run. Verified with a real PluginContext and Landscape writer (make_recorder_with_run, run under tests.conftest): a missing data_key file and a non-array root both give pop_pending_quarantine_validation_error_id(row) == None, while a row-level non-object element links correctly (verr_...). The file's own _record_parse_error helper (lines 668-690) passes the same payload to both calls; these three sites duplicate that logic and diverge from it. Existing tests (test_json_source.py:978-1160) check only that the error was recorded, never the linkage. Expected: use _record_parse_error (same row for record and yield) at all three sites.

**Verifier (CONFIRMED):** Read json_source.py:417-469: record_validation_error row={'file_path','data_key'} / {'file_path'} but SourceRow.quarantined row={'file_path','structure_error'}; linkage key is stable_hash(row) (plugin_context.py:399-415, :641-642). Repro .claude/lanes/20261111-plugins-review/scratch-B/test_scratch_json.py (pytest -p tests.conftest -n 0, real PluginContext + Landscape writer): root list with data_key, missing data_key, and non-array root all give pop_pending_quarantine_validation_error_id(row) == None with 1 orphan pending entry; control case '[1]' (row-level) links to 'verr_f5892b2a55ee'. Normal run: quarantine_router.py:150-152 ingests with validation_error_id=None. JSONSourceConfig has snapshot_for_resume (json_source.py:86); with it on, source_iteration.py:611 wraps the stream in capture_source_snapshot_rows which raises OrchestrationInvariantError at source_snapshot.py:81-83.

FINDING #80 [P2, bug] CSV decode errors are reported at the wrong line and row: TextIOWrapper decodes in ~8 KB chunks

`src/elspeth/plugins/sources/csv_source.py`

Location: csv_source.py:493-520 (data-row UnicodeDecodeError handler), plus the header path at 382-384 and load() at 245-271. The problem: open(..., encoding=...) returns a TextIOWrapper, and it decodes the file in chunks of about 8 KB with a strict incremental decoder. A bad byte therefore raises UnicodeDecodeError as soon as csv.reader asks for the first line of the chunk that contains it, not at the bad line. The handler sets `physical_line = reader.line_num + 1` and `source_row_index = row_num`. Both record the first line of that chunk, not the line that holds the bad byte. The valid rows between the chunk start and the bad line are never emitted, and the audit record says the decode failure happened at a line that decodes cleanly. If the bad byte is in the first chunk, the header read at 383 only catches csv.Error. The UnicodeDecodeError then escapes to load(), and load() quarantines the whole file as one file-level row with no line number. Why it matters: the Landscape validation error (`__line_number__`, `__row_number__`, source_row_index) is audit provenance. It must point at the offending external record. Here it names an earlier, valid record, so an operator who opens the file at that line finds nothing wrong. Expected behaviour: the error points at the line that actually holds the bad byte. One way: decode line by line, for example by opening in binary and decoding each physical line or record with an incremental decoder, so rows before it are emitted. If that is not done, the record should at least say the location is chunk-approximate and stop presenting it as an exact line. Verification: I ran plain Python with the same open()+csv.reader(strict=True) setup on 3000 rows of 'i,rowi' with 0xff injected at line 2001. reader.line_num was 1431 when the error was raised, so CSVSource would report line 1432 and source_row_index 1431 while the bad line is 2001. About 569 valid rows were neither emitted nor quarantined. With 0xff at line 151 of 200, zero records were read before the error, so the header read fails and the whole file is quarantined. The existing test test_truncated_utf16_decode_error_uses_next_data_row_index (tests/unit/plugins/sources/test_csv_source.py:908) only truncates at EOF, where chunk and line coincide, so it cannot catch this.

**Verifier (CONFIRMED):** Read csv_source.py:224 (text-mode open, strict decode), :493-520 (physical_line = reader.line_num+1, source_row_index=row_num), :245-271 (file-level fallback), :380-384 (header path catches only csv.Error). Repro with the real plugin .claude/lanes/20261111-plugins-review/scratch-B/test_scratch_decode.py: 3000 rows, 0xff on physical line 2001 -> 1430 valid rows, quarantine at source_row_index 1430, __line_number__ 1432 (bad line is 2001; ~569 valid rows neither emitted nor audited). 200 rows, 0xff on line 151 -> 0 valid rows, one file-level quarantine with no line number. Audit provenance names a clean line and silently drops rows; existing test test_truncated_utf16_decode_error_uses_next_data_row_index only covers EOF.

FINDING #103 [P2 (raised as P1), bug] JSONL append glues the first new record onto an existing last line that has no trailing newline

`src/elspeth/plugins/sinks/json_sink.py`

json_sink.py:503-510 (jsonl_chunks): in append mode it streams the existing target file unchanged (iter_path_chunks) and then writes `serialized + "\n"` straight after it. The only check on the baseline is validate_output_target (json_sink.py:290-307), which reads just the FIRST line and confirms it is a JSON object. It never checks that the file ends on an LF record boundary, and never looks at any line after the first. So if the existing JSONL file's last line has no trailing newline (common with hand-written files, `json.dump`, or other tools), the first appended record is joined onto that line and the published artifact is corrupt. The sibling TextSink.validate_output_target (text_sink.py:176-194) refuses exactly this case ('Existing text output does not end at an LF record boundary'). Expected: refuse the append, or start a new line, when the baseline does not end with '\n' in the configured encoding (and ideally validate every line, not just the first). Reproduced in the worktree (PYTHONPATH pointed at the worktree src) using the test helper `_prepare` from tests/unit/plugins/sinks/test_local_file_sink_effects.py: target contains '{"id": 0}' with no newline; JSONSink(format=jsonl, mode=append, collision_policy=append_or_create) commit of row {"id":1} produced '{"id": 0}{"id": 1}\n'. rg under tests/ found no test of a baseline without a trailing newline (test_append_successor_effects_preserve_text_and_json_baselines always writes '\n').

**Verifier (CONFIRMED):** json_sink.py:501-510 jsonl_chunks streams baseline via iter_path_chunks then encodes serialized+'\n' with no boundary check; validate_output_target (json_sink.py:285-307) reads only the first line. Repro scratch-E/f103.py using tests/unit/plugins/sinks/test_local_file_sink_effects.py::_prepare: target '{"id": 0}' (no LF), JSONSink(format=jsonl, mode=append, collision_policy=append_or_create): validate_output_target() valid=True, commit_effect produced '{"id": 0}{"id": 1}\n' (corrupt JSONL). Also confirmed a baseline '{"id": 0}\nnot json\n' validates as valid=True. TextSink.validate_output_target (text_sink.py:176-194) refuses the no-trailing-LF case. Silent output corruption, but only with a pre-existing operator file lacking a trailing newline -> P2.

## Files a correct fix must change

- `src/elspeth/plugins/sources/json_source.py`
- `src/elspeth/plugins/sources/csv_source.py`
- `src/elspeth/plugins/sinks/json_sink.py`

## Test files the lane must add or change

- `tests/unit/plugins/test_json_csv_p2_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/test_json_csv_p2_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-06-p2-040-080-103-json-csv/report.md`; the worker returns one line.
