DONE: #40, #80 and #103 are fixed on lane/p2-040-080-103-json-csv in 6 commits (35b6939b..b55a454e). Each finding's test failed at an assertion before its fix and passes after it. All hash and corpus pins are re-pinned.

(The hub wrote this from lane-06's hand-back, because the harness refused the lane's own report write. The logs are in this lane dir.)

## Commits
| Finding | Test | Fix |
|---|---|---|
| #40 | 35b6939b | f77aac22 |
| #80 | c7f8647c | 50d05064 |
| #103 | a20ac085 | b55a454e |

## #40: JSONSource structural quarantine is not linked to its validation error
**Root cause.** The three structural-quarantine sites passed `record_validation_error` a different row from the `SourceRow.quarantined` they yielded. The stable_hash lookup therefore never matched: the link came back None, and snapshot_for_resume crashed.

**Fix.** All three sites now go through `_record_parse_error` with one shared `{file_path, structure_error}` row.

**RED / GREEN.**
- RED: 4 failed, "quarantined structural row is not linked to its recorded validation error".
- GREEN: 4 passed; 70 passed together with test_json_source.

**Re-pins.**
- JSONSource hash: 0c356038d5722d0c -> 204c8485e712dc75.
- EXPECTED_CASE_REGISTRY_SHA256 updated.

## #80: CSV decode errors reported at the wrong line and row
**Root cause.** Text-mode TextIOWrapper decodes about 8 KB at a time, so it raised at the first line of the chunk that contained the bad byte. As a result:
- the error was recorded against the wrong line and row;
- valid rows before the bad byte were dropped without audit;
- a bad byte in the first chunk escaped the header read.

**Fix.**
- The file is now opened in binary.
- `_iter_decoded_text` decodes incrementally and strictly, and replays a failing chunk one byte at a time.
- `_iter_physical_lines` splits lines exactly as `newline=""` would.
- The result is that `reader.line_num` is now exact.

**RED / GREEN.**
- RED: 3 failed, e.g. `assert 1430 == 1999`.
- GREEN: 1165 passed (sources unit + integration).

**Equivalence and cost.**
- A differential test against text mode covered utf-8, utf-16, utf-8-sig and cp1252 at several chunk sizes: 0 mismatches. A negative control confirmed the test can fail.
- Overhead is about 0.75 µs per line.

**Re-pins.**
- CSVSource hash: 5a67572be967d4aa -> 94e4e14b6d89d7e1 (15 manifest tokens).
- reopen-resume projection updated.
- EXPECTED_CASE_REGISTRY_SHA256 updated.

## #103: JSONL append glues onto an unterminated last line
**Root cause.** `jsonl_chunks` copies the existing file byte for byte and then appends, while validation parsed only the first line.

**Fix.** `_scan_existing_jsonl` reads the whole file once and refuses it on any of:
- an invalid line;
- a non-object line;
- no trailing LF (the same rule TextSink uses);
- a decode failure.

It returns the first-line keys, so the separate first-line read is gone; this also kept json_sink's isinstance count within the tier-model limit.

**RED / GREEN.**
- RED: 4 failed, including the reproduction of the glued output `'{"id": 0}{"id": 1}\n'`.
- GREEN: 12 passed, plus a control that a properly terminated file still appends.

**Re-pins.**
- JSONSink hash: 9ef547005076060e -> 0241bd4eb91ae378 (17 tokens).
- reopen-resume projection updated.
- EXPECTED_CASE_REGISTRY_SHA256 updated.

## Gates (final tree b55a454e)
- ruff 0, ruff format 0, check_contracts 0, mypy (3 touched files) 0.
- pytest -n 2 over dag, corpus contract, digest shape, sweep, sources and sinks: 2818 passed and 1 failed. The failure was the azure remote-object TemplateError timeout under load; it passes serially. It touches none of the lane's files.
- Keyless tier_model findings are identical before and after (3656).
- branch-safety: 0.

## Caveats
- **#80:** a bad byte on the header line or in skip_rows still produces a whole-file quarantine with no line number. CSVSource still stops reading after a decode error.
- **TextSource** probably has the same UTF-16 chunking problem. It is untouched.
- **#103 compatibility change:** append and resume now refuse an existing JSONL that is malformed, unterminated or undecodable. Before, they corrupted it.
