DONE: #60, #67 and #122 are fixed on lane/p2-060-067-122-transforms in 6 commits (a789bd32..e5fc6c7b), one test commit and one fix commit per finding.

(The hub wrote this report from lane-08's hand-back, because the harness refused the lane's own report write.)

## #60: reference_join admitted non-canonical table values
**Root cause.** `build_reference_index` sized resolved values without checking that numbers were canonical. NaN, Infinity, 1e999 and integers beyond ±(2^53-1) therefore passed load and then failed on the first matching row.

**Fix.** New `_refuse_non_canonical_numbers` walks every resolved value iteratively and applies the hasher's own `is_non_canonical_number`. A non-canonical value raises ReferenceTableError naming the field, the key and its position.

**Tests.** RED: 7 cases DID NOT RAISE. GREEN: 8 passed.

## #67: field_mapper dotted source overwrote an existing field
**Root cause.** The collision loop skipped a mapping when `source not in row`. A nested path is never `in` the row, so a dotted source was never checked for collisions.

**Fix.** A dotted-source collision is now decided on `target in row_data` alone.

**Tests.** RED: DID NOT RAISE PluginContractViolation. GREEN: 10 passed.

## #122: batch_replicate kept the first row's contract
**Root cause.** The output contract merged buffered rows' contracts first-wins, and raised on mixed contract modes.

**Fix.** The contract is now built with `join_batch_contracts`, as batch_rank does.

**Tests.** RED: `int is object` assertion, and the mixed-mode case raised instead of joining. GREEN: 12 passed.

## Re-pins
| Plugin | Old hash | New hash |
|---|---|---|
| ReferenceJoin | d2a1c1af474e1429 | 6b310e8be342a48d |
| FieldMapper | 9f4e287978efe335 | 02daa59b58731a0c |
| BatchReplicate | a00352057226befe | 16baea08f1c1df3b |

None of these plugins is in the scenario-corpus manifest, so no manifest change was needed. The plugin_hashes lint exits 0.

## Gates
| Gate | Result |
|---|---|
| reference_join + corpus tests | 714 passed |
| field_mapper tests | 198 passed |
| dotted-path users | 210 passed |
| batch_replicate + architecture/DAG tests | 624 passed |
| ruff, format, check_contracts | 0 |
| mypy on the src files | 0 |
| branch-safety | 0 |

mypy on the test file reports one error at tests/fixtures/landscape.py:793. It is already present on the base.

## Left alone
- batch_outlier_annotator has the same first-wins merge.
- reference_join `default_values` are not canonical-checked.
