# lane-08-p2-060-067-122-transforms — #60 [P2, bug] reference_join accepts non-canonical JSON values (NaN/Infinity, ints beyond 2^53) at config load; the first matching row then crashes the run or is routed as a contract violation; #67 [P2, bug] field_mapper: dotted-source collision check never runs, so an existing field is silently overwritten when the executor collision gate is off; #122 [P2, bug] batch_replicate builds the output contract first-wins across heterogeneous buffered rows, so emitted copies can carry a contract that misdescribes their own values

Ticket `p2-060-067-122-transforms` · run `p2` · branch `lane/p2-060-067-122-transforms` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

This lane fixes 3 findings; fix each one (one test commit + one fix commit PER finding).
The listed files are where the sweep located each defect; a finding may need no change in some of them.

FINDING #60 [P2, bug] reference_join accepts non-canonical JSON values (NaN/Infinity, ints beyond 2^53) at config load; the first matching row then crashes the run or is routed as a contract violation

`src/elspeth/plugins/transforms/reference_join.py`

reference_join.py:342 parses the table with plain `json.loads(..., object_pairs_hook=...)`. That call still accepts the NaN, Infinity and -Infinity literals and integers of any size. `_bounded_canonical_size` (lines 116-119) counts an int as `len(str(value))` and any float as 32 bytes without checking that the value is canonical. So build_reference_index puts these values into the index and config validation passes. The module's stated contract (docstring lines 400-404: every failure it can detect is reported at load, not deep into a run) is broken. The same thinking is already applied to keys: `_coerce_key` at line 494 refuses non-finite floats, but values get no such check. Reproduced in the worktree. (a) Table `[{"sku":"a","rate":NaN}]` with output `r: ref['rate']` loads fine and the index holds `{'a': {'r': nan}}`. Then `ReferenceJoin.process` on a row with k='a' raises `ValueError: Cannot infer type from non-finite float: nan` from `narrow_contract_to_output` (line 1079) inside the plugin. That is an uncaught exception from process(), so the node state fails and the run crashes on the first matching row. (b) Table value `12345678901234567890` loads fine and process returns success. Then `stable_hash(row)` raises `IntegerDomainError ... exceeds safe integer domain`, which engine/executors/transform.py:742 turns into a per-row PluginContractViolation routed to on_error, so every row that matches the entry fails at runtime. Expected: refuse non-finite floats and integers outside the canonical-JSON safe range at load, either inside `_bounded_canonical_size` or as a canonical check on each resolved value, with a ReferenceTableError naming the entry and field. No test covers this: rg for nan/NaN/Infinity/parse_constant/9007199254740 in tests/unit/plugins/transforms/test_reference_join*.py returns nothing.

**Verifier (CONFIRMED):** Repro scratch-A/repro60.py. Table '[{"sku":"a","rate":NaN}]' and '...Infinity' both loaded through ReferenceJoin(...), and process() on row {k:'a'} raised ValueError 'Cannot infer type from non-finite float: nan' (schema_contract.py:113 -> type_normalization.py:97/147, via reference_join.py:1079 narrow_contract_to_output). That is an uncaught exception from process(), which the executor re-raises (transform.py:959-986) and the processor does not retry, so the run crashes on the first matching row. Table value 12345678901234567890 loaded, process returned success, and stable_hash raised IntegerDomainError; transform.py:742 converts that into a routed non_canonical_output_violation (per-row error, not a crash). Load-time sizing at reference_join.py:116-119 does no canonical check. This breaks the load-time contract in the build_reference_index docstring (reference_join.py:399-403). rg finds no nan/Infinity/9007199254740 test in test_reference_join*.py. Note: the table is operator or composer config, not Tier-3 rows, so P2 rather than P1.

FINDING #67 [P2, bug] field_mapper: dotted-source collision check never runs, so an existing field is silently overwritten when the executor collision gate is off

`src/elspeth/plugins/transforms/field_mapper.py`

field_mapper.py:778-800. The process-side collision check exists for the case where the executor preflight gate (transform.py:470) is turned off. That happens when forwards_input_fields is False, which line 420 sets whenever any mapping source is an unresolved original header such as 'First Name'. The loop starts with `if target not in row_data or source not in row: continue`. For a dotted source like 'meta.origin', `source in row` goes through PipelineRow.__contains__ (schema_contract.py:704), which resolves the name through the contract and the literal payload keys. A dotted path is neither, so the check returns False and the loop continues. The `if "." in source: collisions.add(target)` branch at 783-786 therefore cannot run unless the row happens to have a literal dotted key. The mapping loop then executes `output[target] = value` and overwrites the existing input field. Reproduced with the worktree's src on the path (elspeth.__file__ confirmed inside the worktree). Config was FieldMapper({schema: observed, mapping: {'First Name': 'first', 'meta.origin': 'status'}}) and the OBSERVED row was {first_name:'A', meta:{origin:'X'}, status:'ORIGINAL'}. The result was status=success, row {'meta': {'origin': 'X'}, 'status': 'X', 'first': 'A'}. The original 'status' value was lost without an error. forwards_input_fields=False and passes_through_input=False, so the executor gate never fired. Config validation does not catch it either: _reject_overlapping_rename_graphs compares sources and targets, and 'meta.origin' is not 'status'. Expected: for dotted sources, test for a collision on `target in row_data` alone (dotted reads never consume the target), and raise PluginContractViolation as the flat branch does. rg found no test for this branch: the only hit for its comment is the source line itself.

**Verifier (CONFIRMED):** Repro scratch-A/repro67b.py: OBSERVED row {first_name:'A', meta:{origin:'X'}, status:'ORIGINAL'} with contract original_name 'First Name' for first_name, and FieldMapper mapping {'First Name':'first','meta.origin':'status'}. Result: forwards_input_fields=False, passes_through_input=False, status success, row {'meta':{'origin':'X'},'status':'X','first':'A'}. ORIGINAL was silently overwritten. Control mapping {'First Name':'first','meta':'status'} raised PluginContractViolation 'would overwrite existing input fields ['status']'. Cause: field_mapper.py:780 `source in row` is False for a dotted path, so the dotted branch at :782-785 cannot run. The executor gate at engine/executors/transform.py:471-474 is off because can_overwrite_input_fields needs passes_through or forwards_input_fields. One correction to the finding: with no original-header source ({'meta.origin':'status'} alone), forwards_input_fields=True and the executor gate covers it. The defect needs the original-header plus dotted-source combination.

FINDING #122 [P2, bug] batch_replicate builds the output contract first-wins across heterogeneous buffered rows, so emitted copies can carry a contract that misdescribes their own values

`src/elspeth/plugins/transforms/batch_replicate.py`

At batch_replicate.py:386-390, merged_fields keeps the FIRST FieldContract seen per normalized_name across emitted_contracts. Every copy is then wrapped in that one locked contract (lines 404-409, 424). When buffered rows come from different producers (two sources on one queue, or row_union branches, which batch_rank.py:322-335 says is realistic), the result is wrong in two ways. First, a field typed differently by a later row keeps row 0's type. Second, a field that only some rows carry stays required=True. Lines 378-385 also raise ValueError when contract modes differ, where join_batch_contracts would take the most restrictive mode. The sibling batch_rank (line 335) and batch_duplicate_annotator (line 243) both use elspeth.contracts.union_merge.join_batch_contracts, which yields object on a type conflict, AND on required and OR on nullable, so each emitted row's contract admits its own values. Expected: batch_replicate should use join_batch_contracts over the contracts of rows that produced output. Verification: I ran a scratch script against the worktree's src (elspeth.__file__ confirmed inside the worktree) with row0={x:1,y:'a',copies:1} (x:int, y:str required) and row1={x:'hello',copies:1} (x:str, no y). The copy from row1 came back as {'x':'hello','copies':1,'copy_index':0} with contract [x:int required, y:str required, copies:int, copy_index:int]: x is misdescribed as int and y is listed as required but absent. rg found no batch_replicate test with heterogeneous contracts; the only hit, tests/unit/plugins/test_validation_path_agreement.py, is about config agreement. The same first-wins pattern exists in batch_outlier_annotator.py:558-562, which is not in my slice.

**Verifier (CONFIRMED):** batch_replicate.py:386-390 merges FieldContracts first-wins; 378-385 raise ValueError on mode mismatch. Repro scratch-E/f122.py: row0 FLEXIBLE {x:int req, y:str req, copies:int}, row1 {x:str req, copies:int}; process() success, row1 copy {'x':'hello','copies':1,'copy_index':0} carries contract x:int required, y:str required (absent), copies:int, copy_index:int. join_batch_contracts over the same two contracts gives x:object, y:str optional (as batch_rank.py:322-335 uses). No downstream escape: batch_contract_validation.validate_success_outputs (188-245) explicitly does not check carried input fields, so the wrong contract propagates.

## Files a correct fix must change

- `src/elspeth/plugins/transforms/reference_join.py`
- `src/elspeth/plugins/transforms/field_mapper.py`
- `src/elspeth/plugins/transforms/batch_replicate.py`

## Test files the lane must add or change

- `tests/unit/plugins/transforms/test_transforms_p2_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/transforms/test_transforms_p2_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-08-p2-060-067-122-transforms/report.md`; the worker returns one line.
