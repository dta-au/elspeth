# lane-13-p3-misc-transforms — #58 [P3, enhancement] safety_utils 'all' mode silently excludes nested string content from security scans; #77 [P3 (raised as P2), security] keyword_filter ReDoS guard misses `{,n}` quantifiers, so nested-repetition patterns like `(a+){,40}` are accepted; #78 [P3, bug] keyword_filter with a single-string `fields` skips the build-time string-type check that the list form gets; #96 [P3, bug] RetrievalOutputConfig accepts a template and a pattern together when either is an empty string; the runtime then ignores one of them without saying so; #106 [P3, bug] type_coerce 'strict' int/float parsing accepts digit-group underscores and non-ASCII Unicode digits; #109 [P3, bug] type_coerce emits out-of-safe-range integers, so the row fails later as a generic non-canonical output violation instead of a type_coerce failure; #110 [P3, enhancement] type_coerce maps an empty or whitespace string to False for bool while int/float reject it; #142 [P3, bug] RAG provider registry treats a missing chromadb submodule as 'provider not installed', despite its own docstring

Ticket `p3-misc-transforms` · run `p3` · branch `lane/p3-misc-transforms` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

This lane fixes 8 findings; fix each one (one test commit + one fix commit PER finding).
Every finding names the files where the sweep located it; touch only what each fix needs.

FINDING #58 [P3, enhancement] safety_utils 'all' mode silently excludes nested string content from security scans

`src/elspeth/plugins/transforms/safety_utils.py`

Where: safety_utils.py:23-24. What is wrong: `fields: all` selects only top-level fields whose value is exactly a str. A field holding a dict or list that contains strings (for example JSON-source rows) is dropped from fields_to_scan, with no error, metadata or audit note. Why it matters: keyword_filter (keyword_filter.py:313-372) then returns success with action 'filtered' for a row whose blocked content sits inside a nested value. For example, {'payload': {'text': 'secret'}} passes a `secret` blocklist. Azure content_safety/prompt_shield (azure/base.py:346-378) send only top-level strings to the API and report 'validated'. Explicitly named non-string fields fail closed (non_string_field), but 'all' mode is fail-open for nested text, and the success_reason does not record which fields were scanned or skipped. The '... all string fields' wording in keyword_filter.py:163 and azure/base.py:98 documents the behaviour, but nothing tells an operator that nested values went unscanned. Expected: either recurse into containers in 'all' mode, or at least record the skipped non-string fields in success_reason so the audit trail shows what was not scanned. Verification: read both callers. tests/unit/plugins/transforms/test_keyword_filter.py::test_skips_non_string_fields_when_all tests only scalar non-strings, and `rg` finds no test with a nested dict/list value in 'all' mode.

FINDING #77 [P3 (raised as P2), security] keyword_filter ReDoS guard misses `{,n}` quantifiers, so nested-repetition patterns like `(a+){,40}` are accepted

`src/elspeth/plugins/transforms/keyword_filter.py`

keyword_filter.py:31-54 `_brace_quantifier_end` treats a brace as a quantifier only when at least one digit comes before the comma (lines 38-41 return None when `i == digits_start`). Python's `re` also accepts `{,n}` (0 to n), so `(a+){,100}` is not seen as quantified, `_nested_repetition_detected` returns False, and `KeywordFilterConfig.validate_patterns_not_empty` (lines 176-190) accepts it. That breaks the guard's stated job of rejecting nested quantifiers (lines 134-149). Verification run in the worktree venv: `_nested_repetition_detected('(a+){,100}')` -> False, while `'(a+){0,100}'` -> True and `'(a+)+'` -> True. `KeywordFilterConfig.from_dict({'fields':['x'],'blocked_patterns':['^(a+){,40}$'],'schema':{'mode':'observed'}})` was accepted. `re.compile('^(a+){,40}$').search('a'*26+'!')` took about 2.8 s, and the time grows exponentially with input length. The comment at lines 24-25 says the remaining gaps are acceptable because patterns are operator-authored, but the Web Composer's LLM planner also writes keyword_filter options (tests/fixtures/composer_convergence/03_keyword_route_edit.json), so a planner-authored pattern can stall a worker on a hostile row. Expected: `_brace_quantifier_end` also recognises `{,n}`, so the empty lower bound counts as a quantifier and the pattern is rejected. Missing test: tests/unit/plugins/transforms/test_keyword_filter.py has nested-quantifier cases at lines 100-128 but none uses the `{,n}` form.

**Verifier (CONFIRMED):** Ran in the worktree venv: _nested_repetition_detected('(a+){,100}') -> False, '(a+){0,100}' -> True, '(a+)+' -> True. KeywordFilterConfig.from_dict with blocked_patterns ['^(a+){,40}$'] was accepted. Timing re.search on 'a'*n+'!' gave 0.04s at n=20, 0.18s at 22 and 0.75s at 24 (about 2x per character, exponential). Cause: keyword_filter.py:38-41 returns None when no digit precedes the comma. The guard bypass is real, but I downgraded to P3. The module comment at keyword_filter.py:18-25 documents the guard as defence-in-depth, not comprehensive, and already-accepted forms such as alternation '(a|a)+' give an equivalent ReDoS, so the security gained by fixing only this is marginal. It is still an implementation bug, because the equivalent '{0,n}' is rejected.

FINDING #78 [P3, bug] keyword_filter with a single-string `fields` skips the build-time string-type check that the list form gets

`src/elspeth/plugins/transforms/keyword_filter.py`

keyword_filter.py:271-272 sets `declared_string_input_fields` only when `self._fields` is not a str. The config allows `fields: str | list[str]` (lines 161-164), and `get_fields_to_scan` (safety_utils.py:25-26) treats a single non-'all' string as one named field. At runtime that field fails closed (`named_fields = self._fields != 'all'`, lines 314-347), but the static declaration is never made. As a result, `validate_transform_declared_string_input_fields` (core/dag/schema_validation.py ~1985-2060), which skips a transform when `declared` is empty, never sees the field. The field-spelling rule that reads the same declaration (tests/integration/pipeline/test_field_name_spelling_rule.py:26,365) is skipped too. A producer that types `message` as int therefore passes `elspeth run` / POST /validate and then quarantines every row at runtime, which is exactly the defect elspeth-b19dfe41fb closed for the list form. Verification by instantiating the plugin: `fields='message'` -> declared_string_input_fields=frozenset(); `fields=['message']` -> frozenset({'message'}). Expected: a single non-'all' string is declared as `frozenset({self._fields})`, the same as the list form.

FINDING #96 [P3, bug] RetrievalOutputConfig accepts a template and a pattern together when either is an empty string; the runtime then ignores one of them without saying so

`src/elspeth/plugins/transforms/rag/core.py`

core.py:148 `validate_query_modes` checks `if self.query_template and self.query_pattern`, which tests truthiness. QueryBuilder (rag/query.py:68,74) decides by `is not None`. So a config where one option is "" passes validation. The contradictory state then reaches runtime. Case 1: query_template='' with query_pattern='(\w+)'. QueryBuilder compiles the empty template, build() takes the template branch (query.py:102), and the pattern is never used. Every row renders an empty query and fails validation. A spawn ProcessPoolExecutor is still started for the unused regex. Case 2: query_template='{{ query }}' with query_pattern=''. The template wins, and the empty pattern still compiles and spawns a pool. This breaks the documented rule that the two modes are mutually exclusive, and options are dropped without any message. Expected: refuse when both are `is not None`, and preferably also refuse an empty template or pattern. Verification: I built RetrievalOutputConfig against the worktree source (I confirmed core.__file__ resolves into the worktree). Both ('', '(\w+)') and ('{{ query }}', '') were ACCEPTED. The existing tests (tests/unit/plugins/transforms/rag/test_config.py:52, test_core.py:52) only cover two non-empty values, which are rejected correctly.

FINDING #106 [P3, bug] type_coerce 'strict' int/float parsing accepts digit-group underscores and non-ASCII Unicode digits

`src/elspeth/plugins/transforms/type_coerce.py`

type_coerce.py:122-125 (coerce_to_int) and :167-170 (coerce_to_float) parse with Python's int()/float() after strip(). Those accept PEP 515 underscores and any Unicode Nd digits, so they are not the strict parse the module and docstrings promise ('Coerce value to int with strict rules'; the docstring lists only plain integer strings as accepted). Measured on this tree: coerce_to_int('1_000') -> 1000, ' 1_0 ' -> 10, fullwidth '１２３' -> 123, Arabic-Indic '٤٢' -> 42, and coerce_to_float('1_000.5') -> 1000.5. So an identifier-like or malformed cell such as '12_34' quietly becomes the number 1234 when the plugin should route it as not_integer_string. That is the implicit fabrication the plugin exists to prevent. Expected: accept only an optional sign plus ASCII digits for int (for example a regex like ^[+-]?[0-9]+$ before int()), and the matching ASCII grammar for float; anything else raises CoercionError. Verification: ran the coercion functions directly with PYTHONPATH pointing at the worktree (elspeth.__file__ confirmed inside the worktree). rg for '1_000' and 'underscore' in tests/unit/plugins/transforms/test_type_coerce.py found nothing, so no test pins or exercises this branch.

FINDING #109 [P3, bug] type_coerce emits out-of-safe-range integers, so the row fails later as a generic non-canonical output violation instead of a type_coerce failure

`src/elspeth/plugins/transforms/type_coerce.py`

coerce_to_int (type_coerce.py:117-125) returns any parsed int. Measured: coerce_to_int('9007199254740993') and coerce_to_int('99999999999999999999') both succeed, and core.canonical.is_non_canonical_number() returns True for the result. Sources quarantine such values at the boundary (schema_factory._reject_non_canonical_numbers), but here type_coerce manufactures one from a string. The row then reaches TransformExecutor._populate_audit_fields (engine/executors/transform.py:735-748), where stable_hash fails and a PluginContractViolation is raised. That violation is routed, so the row is not lost, but the audit reason is a generic 'non-canonical output' contract violation that blames the plugin. It is not the type_mismatch/CoercionError taxonomy (_FAILURE_MESSAGES) that type_coerce documents for its failures. Expected: coerce_to_int (and the str->float path for ints) refuses values outside ±(2**53-1) with a dedicated CoercionError failure arm such as 'out_of_range', so the row routes with an accurate type_coerce reason. Verification: read the executor path and non_canonical_output.py, and ran the function directly. No test in tests/unit/plugins/transforms/test_type_coerce.py covers integer strings beyond 2**53.

FINDING #110 [P3, enhancement] type_coerce maps an empty or whitespace string to False for bool while int/float reject it

`src/elspeth/plugins/transforms/type_coerce.py`

type_coerce.py:180 includes '' in _BOOL_FALSE_STRINGS, so coerce_to_bool('') and coerce_to_bool('   ') return False. The int and float arms (lines 120-121 and 165-166) reject the same input as empty_string. A blank CSV cell is a missing value, so to: bool turns 'unknown' into a definite False, a fabricated fact that never routes to on_error. That conflicts with the tier-model rule against defaulting missing values. This is deliberate and pinned (test_type_coerce.py:259, 'whitespace-only = empty = false'), so it is a policy question for the operator rather than an accident. Recommendation: reject empty strings as empty_string for bool as well, consistent with the sibling arms, or make the behaviour an explicit opt-in. Verification: read coerce_to_bool and the pinning test.

FINDING #142 [P3, bug] RAG provider registry treats a missing chromadb submodule as 'provider not installed', despite its own docstring

`src/elspeth/plugins/transforms/rag/config.py`

config.py:62-70 swallows ModuleNotFoundError when exc.name == 'chromadb' or exc.name.startswith('chromadb.'). The docstring (25-29) and comment (63-67) say that an installed chromadb which fails its own import is a broken install and must propagate. The 'chromadb.' prefix only occurs when top-level chromadb IS importable but a submodule is missing (chroma.py:27-28 does `import chromadb` and then `import chromadb.api`), which is exactly that broken-install case, and it gets swallowed. The result is an empty PROVIDERS map and the confusing validation error 'Unknown provider: 'chroma'. Available: []' (line 87) for an installed provider, with no install or repair remediation. No test covers this branch: rg for _get_providers and ModuleNotFoundError under tests/ finds nothing. Expected: swallow only exc.name == 'chromadb', and have the unknown-provider message say the provider requires the elspeth[rag] extra when it is a known Literal value missing from the registry.

## Files a correct fix must change

- `src/elspeth/plugins/transforms/type_coerce.py`
- `src/elspeth/plugins/transforms/keyword_filter.py`

## Test files the lane must add or change

- `tests/unit/plugins/transforms/test_misc_transforms_p3_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/transforms/test_misc_transforms_p3_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-13-p3-misc-transforms/report.md`; the worker returns one line.
