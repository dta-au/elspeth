# lane-08-p5-llm-pool-deadline — Pooled LLM rows: the row deadline starts at accept and covers time queued behind other rows in the shared pool

Ticket `p5-llm-pool-deadline` · run `p5` · branch `lane/p5-llm-pool-deadline` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

Maintainer ruling 2026-11-14: close the gap. lane-04-p2-024-044-llm-replay-timeout report: 'Pooled mode is not fully covered. Rows queued behind other rows in the shared thread pool spend time that no fixed wait accounts for. Closing that gap needs a row-level deadline set at accept.' Implement the row-level deadline set at accept, carried into the pooled worker, so the plugin's structured retry/timeout result is produced before the batch waiter fires. Composer invariants are irrelevant here; do not change replay semantics. Run after p5-llm-audit (shared LLM code).

## Files a correct fix must change

- `src/elspeth/plugins/transforms/llm/transform.py`

## Test files the lane must add or change

- `tests/unit/plugins/test_p5_llm_pool_deadline_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/test_p5_llm_pool_deadline_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-08-p5-llm-pool-deadline/report.md`; the worker returns one line.
