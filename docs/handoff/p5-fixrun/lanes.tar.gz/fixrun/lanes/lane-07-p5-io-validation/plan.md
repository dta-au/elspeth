# lane-07-p5-io-validation — #25/#26 sibling sources and sinks validate delimiter and text codec at config like CSVSink; TextSource UTF-16 chunking; aws_s3_source JSONL CRLF line number

Ticket `p5-io-validation` · run `p5` · branch `lane/p5-io-validation` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

Maintainer ruling 2026-11-14: fix the same bug in every sibling, not one plugin. CSVSink now validates delimiter by building a csv.writer and encoding by probing ''.encode(v). Still missing: delimiter in csv_source, azure_blob_source, aws_s3_source; non-text codec in text/json/aws_s3/azure_blob/document sinks and json/text/azure_blob/aws_s3 sources (check every encoding option in src/elspeth/plugins). Use ONE shared validator (do not copy-paste). TextSource probably has the UTF-16 chunking bug lane-06-p2-040-080-103 fixed in JSON/CSV sources: prove it RED first, then fix. aws_s3_source JSONL: an oversized-line bounded read ending between CR and LF counts the stray LF as an extra line (lane-02-p2-009-010 report): fix the line number. Reports: lane-01-p3-file-sinks, lane-01-p3fix-integrator-17, lane-06-p2-040-080-103-json-csv, lane-02-p2-009-010-aws-s3-source.

## Files a correct fix must change

- `src/elspeth/plugins/sources/csv_source.py`
- `src/elspeth/plugins/sources/text_source.py`
- `src/elspeth/plugins/sources/aws_s3_source.py`
- `src/elspeth/plugins/sinks/text_sink.py`

## Test files the lane must add or change

- `tests/unit/plugins/test_p5_io_validation_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/test_p5_io_validation_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-07-p5-io-validation/report.md`; the worker returns one line.
