PAUSED lane-07-p5-io-validation at d2fc6dab (tree clean): F1 one validation authority (validate_text_encoding / validate_csv_delimiter, TextEncoding/CSVDelimiter types on every plugin encoding and CSV delimiter field incl. cloud sinks and blob expanders) and F5/F6 one decoding authority (plugins/infrastructure/text_decoding.py: utf-8 decoded as utf-8-sig; byte-escape instead of surrogateescape in Azure CSV/JSONL and S3 JSONL; S3 split-CRLF line number). Lane test 84 passed. NEXT STEP: re-run the final -n 2 regression set (sinks, sources, infrastructure, blob transforms, file_inject, validation_path_agreement, sweep, web catalog/plugin_policy/composer) — it was stopped at 50% with 2 unidentified failures; re-run each failure with -n 0 before crediting.

(Written by orchestrator from the lane's pause hand-back; the harness refused the lane's report write.)

Commits (base b02c94dc): b4633f1f RED F1 (63 failed at assertions, 7 controls); f70b9eba fix F1; 9b4c49de RED F5/F6+CRLF (12 failed at assertions, 2 passed); d2fc6dab fix.
Not RED-able (already fixed on base, kept as regression pins): TextSource UTF-16 chunking; blob_csv_expand BOM.

CHANGELOG:
- Fixed: every plugin encoding option refuses non-text codecs at config load, and every CSV delimiter option refuses '"', '\n' and '\r'.
- Fixed: every reader consumes a leading UTF-8 BOM.
- Fixed: an undecodable UTF-16/32 code unit in Azure CSV/JSONL or S3 JSONL quarantines only its own record.
- Fixed: S3 JSONL line numbers no longer shift by one after an oversized line split between CR and LF.

COMPAT:
- Config: non-text codec or csv-refused delimiter fails at load (previously crashed at run time).
- Data: with default utf-8 a leading BOM is no longer part of the first row's value.
- Audit shape: Azure CSV/JSONL and S3 JSONL emit one quarantine per bad record (__raw_bytes_hex__, U+DC00+b escape) instead of one whole-file quarantine.
- Codec/delimiter error messages changed.
- Hashes (15 plugins): aws_s3_sink d3e6874fba82116c, azure_blob_sink 62d8755d10542a35 (NOTE: lane-06-p5-templates also changes azure_blob_sink -> recompute on merge), csv_sink c3acfd7dc4a8fc84, document_sink 6bea437cbc601a66, json_sink 4c5c6d960228d88d, text_sink 1cafb69592dde13b, aws_s3_source 235a36bcefdada6d, azure_blob_source 5da3ed9923a70982, csv_source 9ce7cf9e1d01b40a, json_source 47746b3fbe3b15a6, text_source f95c7e1aff517bfa, blob_csv_expand 9c68394fd5a4d3f7, blob_json_expand 95094a9c9643321b, blob_text_expand a9e7961f0bd05f10, file_inject 984f1065b34bb6cc; scenario-corpus manifest updated.

Operator re-sign: aws_s3_source R6 249a0ac76f8e242f->d1dbe040ed716bf0, aa8501bfaedfd2fd->544f9d5d85d97af1, 2111f16f3ee30405->958201e42c6ea7fd (line shift); R5 e27ff772a315bc1b moved from json_source to text_decoding.py (re-bind).

Review item (agent claim, not a ruling): "S3 CSV and S3 JSON-array decoding stays strict by design" — check against the fix-every-sibling ruling on resume.
