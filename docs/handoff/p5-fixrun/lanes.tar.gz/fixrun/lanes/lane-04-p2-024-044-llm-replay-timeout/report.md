DONE: #24 and #44 are fixed on lane/p2-024-044-llm-replay-timeout. Commits: 63690f16 test#24, abe66d64 fix#24, 49725dea test#44, 49549c45 fix#44. Lane test: 5 passed. Pooled mode is still not fully covered by #44 (see caveats).

(The hub wrote this report from lane-04's hand-back, because the harness refused the lane's own report write.)

## #24: replaying a content-filtered completion
**Root cause.** `clients/llm.py _replay_completion` raised a bare ValueError for any recorded ERROR that carried a response payload. The live run records a content-filtered (null-content) completion as exactly that: a ContentPolicyError/content_policy ERROR with an `LLMCallResponse(content="")`. Replay therefore crashed the run where live mode routed the row to on_error.

**Fix.** Replay now reads the recorded classification first. It accepts only ContentPolicyError/content_policy with empty content. For that case it rebuilds the response, records it with the same payload and usage, and raises ContentPolicyError. Every other ERROR that carries a response is still refused.

The response rebuild moved into `_rebuild_recorded_response(evidence: ReplayCallEvidence)`. Its parameter is the owned `ReplayCallEvidence` type, so the soft-mapping census is unchanged at 2668.

**RED:** "replay raised ValueError: Recorded LLM response-processing error cannot be reproduced exactly".
**GREEN:** 1 passed.

## #44: LLM batch wait has no headroom
**Root cause.** `transform.py connect_output` set `batch_wait_timeout = max_capacity_retry_seconds`. The waiter's clock starts at accept, but the plugin's retry budget starts later, in the worker. The waiter therefore always fires before the plugin returns its structured retry_timeout result.

**Fix.** The wait is now: budget + (queries × provider request timeout) + 30 s headroom. The request timeout comes from:
| Provider | Request timeout |
|---|---|
| OpenRouter / Gateway | configured `timeout_seconds` |
| Azure | 600 s (openai SDK default) |
| Bedrock | 6000 s (`litellm.request_timeout`) |

Tests check the Azure and Bedrock constants against the installed SDKs. `LLMTransform.source_file_hash` is re-pinned from 498b84f2c8939775 to 0e12f0bdebf60583; the old hash had no other references.

**RED:** 4 failed (e.g. `assert 30.0 > (30 + 45.0)`).
**GREEN:** 5 passed.

## Gates
| Gate | Result |
|---|---|
| Lane test | 5 passed |
| Client tests | 217 passed |
| `connect_output`/batch_wait users | 1015 passed |
| Architecture/hash tests | 896 passed, 1 xfailed |
| ruff | 0 |
| ruff format | 0 |
| check_contracts | 0 (census 2668) |
| mypy | 0 |
| Keyless lints | 3777 findings before and after, identical |
| branch-safety | 0 |

The full arch/dag selection was not run in the lane; the hub's verify covers it.

## Caveats
- **Pooled mode is not fully covered.** Rows queued behind other rows in the shared thread pool spend time that no fixed wait accounts for. Closing that gap needs a row-level deadline set at accept, which is a design change to shared pooling.
- **Azure/Bedrock waits are long.** With no request timeout configured, the wait for these providers is long (Bedrock is about 9630 s at defaults). Setting an explicit SDK timeout would be a separate behaviour change.
- **History was rewritten before handback.** A non-interactive autosquash folded a #24 contracts correction into abe66d64.
