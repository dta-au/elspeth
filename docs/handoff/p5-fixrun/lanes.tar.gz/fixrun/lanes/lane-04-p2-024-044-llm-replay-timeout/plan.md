# lane-04-p2-024-044-llm-replay-timeout — #24 [P2, bug] Replay crashes on a recorded content-filtered (null-content) LLM completion instead of reproducing ContentPolicyError; #44 [P2, bug] LLM batch_wait_timeout equals the retry budget with no headroom, so the engine's waiter times out before the plugin can return its structured retry_timeout result

Ticket `p2-024-044-llm-replay-timeout` · run `p2` · branch `lane/p2-024-044-llm-replay-timeout` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

This lane fixes 2 findings; fix each one (one test commit + one fix commit PER finding).
The listed files are where the sweep located each defect; a finding may need no change in some of them.

FINDING #24 [P2, bug] Replay crashes on a recorded content-filtered (null-content) LLM completion instead of reproducing ContentPolicyError

`src/elspeth/plugins/infrastructure/clients/llm.py`

The live null-content branch (llm.py:1103-1152) records an ERROR call with category="content_policy" AND a response payload (an LLMCallResponse with content="" and the raw response), then raises ContentPolicyError. On replay, _replay_completion (llm.py:437-442) checks `if evidence.response_data is not None: raise ValueError("Recorded LLM response-processing error cannot be reproduced exactly")` BEFORE it looks at the category. CallModeSession.replay_call (src/elspeth/engine/orchestrator/call_mode_session.py:327-346) returns the retained response data for ERROR calls whenever it is AVAILABLE, and the base _record_call (clients/base.py:155-230) persists response_data for ERROR status. So any source run in which a provider content-filtered a completion (Azure finish_reason=content_filter with null content is a realistic case) cannot be replayed: the replay raises a bare ValueError, which LLM transforms do not catch as LLMClientError, so the whole replay run crashes rather than routing that row to on_error the way the live run did. The guard's own message says 'response-processing', but this error's category is content_policy, so the guard refuses more than it describes. Expected: either rebuild the recorded response DTO and re-raise ContentPolicyError (passing response_data so the replay record matches the source), or refuse with a typed AuditIntegrityError that names the content_policy case. Verification: the replay tests in tests/unit/plugins/clients/test_audited_llm_client.py (test_replay_llm_error_preserves_classification, lines 182-228) only parametrize rate_limit and network with response_data=None. No test replays a content_policy error that has response_data.

**Verifier (CONFIRMED):** llm.py:1103-1152 records the null-content call as ERROR with response_data=LLMCallResponse(content='') and category='content_policy'. _replay_completion (llm.py:437-442) raises ValueError('Recorded LLM response-processing error cannot be reproduced exactly') whenever evidence.response_data is not None, before it reads the category. CallModeSession.replay_call (engine/orchestrator/call_mode_session.py:309-346) returns response.data for an ERROR call whose response state is AVAILABLE. Repro .claude/lanes/20261111-plugins-review/scratch-D/replay_cp.py (replay session returning ERROR + response_data + content_policy classification, reusing the fakes from tests/unit/plugins/clients/test_audited_llm_client.py) printed 'ValueError is LLMClientError: False Recorded LLM response-processing error cannot be reproduced exactly'. The replay tests (test_audited_llm_client.py:182-228) parametrize only rate_limit/network with response_data=None. Caveat: this is reached only when the source run kept the ERROR response payload (a payload store is configured, which replay needs anyway). The bare ValueError is not a typed AuditIntegrityError and is not caught by LLM transforms.

FINDING #44 [P2, bug] LLM batch_wait_timeout equals the retry budget with no headroom, so the engine's waiter times out before the plugin can return its structured retry_timeout result

`src/elspeth/plugins/transforms/llm/transform.py`

transform.py:1817 passes `batch_wait_timeout=float(self._max_capacity_retry_seconds)` to init_batch_processing. The plugin's own retry budgets use that same number of seconds, measured from a LATER start point. Sequential multi-query starts its row-level deadline when the worker begins (transform.py:927-928). In parallel mode the PooledExecutor starts each query's deadline when that query's worker starts (pooling/executor.py:571-572). Neither clock includes the call that is still running when the deadline is checked. The engine's waiter starts earlier, at accept (engine/executors/transform.py:624). Under sustained 429/5xx, the waiter's TimeoutError therefore always fires before `_sequential_retry_timeout_result` or the pool's `_build_retry_timeout_result` can return. The structured `retry_timeout` error (with elapsed_seconds, max_seconds and discarded_successful_queries), which is meant to route through on_error, cannot be reached in practice. Instead the node state is completed FAILED with a raw exception (executors/transform.py:959-985) and the submission is evicted. processor.py:2553 classes TimeoutError as retryable, so with a retry manager the whole row is re-attempted while the orphaned worker of the first attempt keeps making billable provider calls whose results are discarded. Siblings already handle this. azure/base.py:165-168 uses `max(batch_wait_timeout_seconds, max_capacity_retry_seconds + _AZURE_HTTP_TIMEOUT_SECONDS)`. textract_inline_analysis.py:341 and textract_document_analysis.py:425 likewise add the SDK attempt time plus headroom. LLMTransform has neither a configurable batch_wait_timeout nor any headroom. Expected: the effective wait covers the retry budget plus the provider request timeout and some headroom, so the plugin's structured result always wins the race. Verification: read connect_output, the sequential and pool deadline code, executor TimeoutError eviction and processor is_retryable. `rg batch_wait_timeout tests/unit/plugins/llm` returns nothing, so no test pins the LLM wait/budget relation.

**Verifier (CONFIRMED):** Traced, not run (timing race). transform.py:1817 connect_output passes batch_wait_timeout=float(max_capacity_retry_seconds). engine/executors/transform.py:603-624 calls accept() and then waiter.wait(timeout=batch_wait_timeout), so the waiter's clock starts at accept. Sequential multi-query starts its budget inside the worker (transform.py:927-928) and returns _sequential_retry_timeout_result only once time.monotonic() >= retry_deadline (974-986). The PooledExecutor sets start_time/max_time when the worker starts (pooling/executor.py:571-572) and checks it only between attempts, so an in-flight provider call can push the return past the deadline. The plugin's earliest structured retry_timeout return is therefore t_worker_start + T, while the waiter fires at t_accept + T, with t_accept <= t_worker_start. Under sustained retryable errors the waiter always wins. The executor then completes the node state FAILED with the raw TimeoutError and evicts the submission (executors/transform.py:959-985). processor.py:2553 classes TimeoutError as retryable while the orphaned worker keeps calling the provider. No upstream guard exists: azure/base.py:165-168 and textract_*:341/425 add headroom, and LLMTransform has none. rg batch_wait_timeout over tests/unit/plugins/llm returns nothing. Escalation is via exception rather than a crash, so P2 stands.

## Files a correct fix must change

- `src/elspeth/plugins/infrastructure/clients/llm.py`
- `src/elspeth/plugins/transforms/llm/transform.py`

## Test files the lane must add or change

- `tests/unit/plugins/llm/test_llm_p2_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/llm/test_llm_p2_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-04-p2-024-044-llm-replay-timeout/report.md`; the worker returns one line.
