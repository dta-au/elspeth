lane-01-p3aws-textract: AWS review Textract findings #1, #2/#3 (plugin side), #6, #7, #9, #10 and #11 landed as TDD test+fix pairs on lane/p3aws-textract (97976708..a637bf49); hashes re-pinned, contracts and plugin_contract lints green, no signed tier_model fingerprint rotated; 7 maintainer decisions recorded.

# Detail

Branch `lane/p3aws-textract`, worktree `.claude/worktrees/compassionate-brahmagupta/.claude/worktrees/lane-p3aws-textract`.
The integrator tip 1e57572b was merged first as merge commit f4eb5484. Nothing has been pushed.

| Commit | Content |
|---|---|
| 97976708 | test #1 (RED) |
| e4ad4492 | fix #1, which also covers #11 |
| f5bb3980 | test #2/#3 (RED) |
| 74241bdb | fix #2/#3 |
| b40c6355 | test #6 (RED) |
| 59e46e9e | fix #6 |
| 71d7506a | test #7 (RED) |
| 1bb3f777 | fix #7 |
| 5439556a | test #9 (RED) |
| 06c108ea | fix #9 |
| a6168341 | test #10 (RED) |
| a637bf49 | fix #10 |

All new tests are in `tests/unit/plugins/transforms/aws/test_aws_review_textract.py`, 38 tests, all passing at HEAD. The RED logs, pytest's own failure record captured before each fix, sit next to this report: `f1-red.log`, `f23-red.log`, `f6-red.log`, `f7-red.log`, `f9-red.log` and `f10-red.log`. Every RED test failed at an assertion (`AssertionError` or pytest `Failed: DID NOT RAISE`), never at an import or crash.

## Finding 1 (P1): retryable Textract failures are never retried

**RED** (`f1-red.log`, 9 failed / 4 passed): every test failed with `expected a raised PluginRetryableError, got TransformResult(status='error', ..., retryable=True)` for:
- submit;
- the poll paths;
- an unverified bucket region;
- inline AnalyzeDocument;
- the inline hint;
- the real-engine retry test.

**Fix** (e4ad4492):
- `textract_document_analysis.py` raises `PluginRetryableError` after the audited client has recorded the call, in two cases:
  - a retryable `TextractServiceError` from StartDocumentAnalysis;
  - a retryable `BucketRegionUnverifiedError`.
- Non-retryable failures stay `TransformResult.error(retryable=False)`.
- In the poll loop, a retryable GetDocumentAnalysis error is retried in place, with backoff, for the same page request until the poll deadline. It is not resubmitted.
- If the poll is still failing transiently at the deadline, it escalates as a raised `PluginRetryableError`.
- `poll_timeout` is now an explicit permanent row error (`retryable=False`). The poll_timeout_seconds description and the `_poll_and_collect` docstring document this.
- `textract_inline_analysis.py` raises `PluginRetryableError` for a retryable AnalyzeDocument error.
- The inline composer hint was corrected. It now says that SDK retries, and engine row retries when the pipeline configures retry, can repeat a billable call.

**Engine path proven:** `test_f1_engine_retries_a_throttled_submit_and_reattaches_to_the_same_job` runs a real `Orchestrator` with `RetrySettings(max_attempts=3)` and fake SDKs. The worker's raised exception reaches `RowProcessor`'s retry through the batch mixin's ExceptionResult and the SharedBatchAdapter waiter re-raise. The test asserts:
- two StartDocumentAnalysis calls, with identical ClientRequestTokens (the deterministic token comes from token_id, so the retry re-attaches to the same job);
- node states `[(0, failed), (1, completed)]`.

**#11:** the four tests that asserted `result.retryable` were updated and renamed in e4ad4492. They are in `test_textract_document_analysis.py` and `test_textract_inline_analysis.py`, and now assert raised `PluginRetryableError` or `retryable=False`.

**COMPAT:**
- Transient Textract and HeadBucket failures now consume engine retry attempts. With no retry configured they surface as the engine's retry-exhausted row failure, not a `submit_failed`/`analysis_failed` row error.
- `poll_timeout` stays a row error, now honestly non-retryable.

**CHANGELOG:** `Fixed: Textract transforms now raise PluginRetryableError for throttled/transient failures so engine retry policy applies (previously retryable=True on a row result was silently ignored); transient poll errors retry in place until the poll deadline.`

**Hashes:**
- `aws_textract_document_analysis`: sha256:a97410d662ec7aa7 -> sha256:0e7af16858c73555
- `aws_textract_inline_analysis`: sha256:19fad219cdcf149e -> sha256:eb22e71cfc4999d4
- The knob golden `transform__aws_textract_document_analysis.json` was regenerated.

## Findings 2 and 3 (P2): verify/replay determinism (plugin side; engine policy deferred)

**RED** (`f23-red.log`, 13 failed): all failed at an assertion. That includes `"has_source_call" in vars(...)` and the substituted-request assertions. The replay tests monkeypatch `_wait_for_shutdown` to raise, so the old code failed at an assertion instead of sleeping.

**Fix** (74241bdb):
- **#2 verify:**
  - `TextractClient.get_document_analysis` reads the archived request at the same parent-local index (`archived_call_request`).
  - It requires `operation == get_document_analysis` and a well-formed job id.
  - It pins the source job id per row and raises `AuditIntegrityError` if the id changes.
  - It requires the archived next_token fingerprint to match the presence of a live next_token: a 64-hex fingerprint when one is present, None otherwise.
  - It substitutes the source job id and next_token fingerprint into the lookup request used for admission and verification, as the start token already was.
- **#3 replay:**
  - `_poll_and_collect(replay=True)` never sleeps.
  - It ends the poll loop from the archive: the deadline is reached when the source made no poll at the next index, measured by `TextractClient.source_has_next_poll`.
  - The wall-clock deadline checks are skipped in replay.
- **HeadBucket single-flight in replay:**
  - The leader is elected from the archive, via `HeadBucketClient.source_made_head_bucket_call` and `BucketRegionCoordinator.verify_replay`.
  - The row whose source state made the HeadBucket call always replays its own call.
  - Followers wait (bounded by `S3_HEAD_BUCKET_SDK_ALLOWANCE_SECONDS`) for its cached proof or its failure. A follower inherits the failure (`inherited=True`).
  - A follower whose leader never settles fails closed with `AuditIntegrityError`.
- **Engine addition (read-only):**
  - `CallModeSession.has_source_call(...)` in `contracts/call_mode.py`.
  - `AuditedCallModeSession.has_source_call` in `engine/orchestrator/call_mode_session.py`. It is a request-hash existence query at a parent-local index, allowed only in REPLAY/VERIFY, and consumes and admits nothing.
  - Its `request_data: Mapping[str, Any]` parameter is the same inherited contract every CallModeSession method takes. The soft-mapping census was therefore re-pinned with `--write-census` (2647 -> 2649: +1 Protocol, +1 implementation) in the same commit.

**COMPAT:**
- Replay of async Textract runs no longer sleeps and no longer depends on wall-clock timing.
- Verify mode admits a poll against the source job id instead of always refusing.
- A new read-only method was added to the CallModeSession protocol. Third-party session implementations, if any, must add it.

**CHANGELOG:** `Fixed: aws_textract_document_analysis replay no longer sleeps or races the wall clock and ends polling from the archive; verify mode substitutes the source job id and next_token fingerprint; HeadBucket single-flight leadership in replay follows the source run.`

**Hashes:** `aws_textract_document_analysis` sha256:0e7af16858c73555 -> sha256:66ffa277493ed1c3

## Finding 6 (P3): attempt counts under-recorded

**RED** (`f6-red.log`, 2 failed):
- A real botocore Textract client and the S3 HeadBucket client have their HTTP layer raise `SSLError`.
- botocore made 3 sends (the test asserts this first, and it passed), but the classification came back `assert False is True` on `.retryable`, i.e. `botocore_error`, `attempts: 1`.

**Fix** (59e46e9e):
- `textract_client._provider_error` and `textract_bucket_region._provider_outcome` now classify by botocore's own retry rule. `isinstance(error, (botocore ConnectionError, HTTPClientError))` maps to a retryable `transport_error`.
- They record the before-send-observed attempt count for every non-ClientError failure.
- `build_s3_head_bucket_sdk_client` registers the same per-thread `before-send` counter (`before-send.s3`), and `HeadBucketClient` resets it before each call.
- The existing builder test now asserts the registration.

**COMPAT:** SSLError, ProxyConnectionError, ResponseStreamingError and generic HTTPClientError are now retryable transport errors (previously a permanent `botocore_error`). Audited `attempts` now equals the HTTP attempts actually started.

**CHANGELOG:** `Fixed: Textract and S3 HeadBucket audit records now carry the observed HTTP attempt count for every botocore transport error, and classify SSL/proxy/streaming failures as retryable like botocore does.`

**Hashes:** none. `textract_client.py` and `textract_bucket_region.py` carry no source_file_hash. The plugin hashes were verified unchanged.

## Finding 7 (P3): inline transform has no configuration ceilings

**RED** (`f7-red.log`, 5 failed):
- `DID NOT RAISE PluginConfigError` for `max_blocks=10**12`, `max_result_bytes=10**15`, `request_timeout_seconds=1e9` and `batch_wait_timeout_seconds=1e12`.
- `assert 'MAX_INLINE_BLOCKS' in vars(module)`.

**Fix** (1bb3f777): `le=` ceilings, with each default at its ceiling:

| Field | Ceiling |
|---|---|
| max_blocks | 100000 |
| max_result_bytes | 50000000 |
| request_timeout_seconds | 120 |
| batch_wait_timeout_seconds | 480, which is 3 x (120 + 10) + 90 |

**COMPAT:**
- Inline configs above these ceilings are now rejected at load.
- The batch_wait default changes from 420 to 480. That equals the effective wait the transform already derived from the default read timeout, so default runs behave identically. The knob golden was regenerated for this one-line change.

**CHANGELOG:** `Changed: aws_textract_inline_analysis now caps max_blocks (100000), max_result_bytes (50 MB), request_timeout_seconds (120) and batch_wait_timeout_seconds (480; default raised from 420 to match the already-effective wait).`

**Hashes:** `aws_textract_inline_analysis` sha256:eb22e71cfc4999d4 -> sha256:10ce458bfa432bdf

## Finding 9 (P3): `_project_pages` is quadratic

**RED** (`f9-red.log`): `AssertionError: 18120 Page reads for 360 blocks` on 60 pages x 5 lines, against a bound of 3 x 360.

**Fix** (06c108ea): each PAGE's number is read once, and LINE blocks are bucketed by page in a single pass in block order.
- Lines on undeclared pages are still excluded.
- A repeated PAGE number still gets an independent copy of its lines.

Measured against the base function, interleaved blocks at 60 lines per page:

| Pages | Blocks | Base | New | Output |
|---|---|---|---|---|
| 100 | 6,100 | 0.223 s | 0.202 s | equal |
| 200 | 12,200 | 0.724 s | 0.317 s | equal |
| 400 | 24,400 | 2.92 s | 0.507 s | equal |

**COMPAT:** none, since the output is identical. Error path reporting for malformed LINE blocks may name a different first-bad block.

**CHANGELOG:** `Fixed: Textract page projection is linear in the block count (was quadratic, minutes of GIL-held CPU at the configured ceilings).`

**Hashes:** none, since `textract_result.py` carries no source_file_hash.

## Finding 10 (P3): per-row S3 key bounded in characters

**RED** (`f10-red.log`, 2 failed): `expected a row result, got ('docs', 'ééé…', None)` for a 600-character / 1200-byte key, and the same for a lone-surrogate key.

**Fix** (a637bf49): per-row bucket mode now checks `len(key.encode("utf-8")) > S3_MAX_KEY_BYTES`, matching the static branch. It also rejects lone surrogates, which cannot be UTF-8 encoded, as `invalid_s3_key` before encoding. A 1024-byte key is accepted (control test).

**COMPAT:** a multibyte key over 1024 bytes now fails locally as `invalid_input`/`invalid_s3_key` instead of `submit_failed` with a provider code. A surrogate-bearing key fails as `invalid_s3_key` instead of failing inside the SDK.

**CHANGELOG:** `Fixed: aws_textract_document_analysis per-row bucket mode bounds S3 keys in UTF-8 bytes (1024), like static-bucket mode.`

**Hashes:** `aws_textract_document_analysis` sha256:66ffa277493ed1c3 -> sha256:ea328c39a24bfb22

## Final hashes and gates at HEAD a637bf49

**Final hashes:**
- `aws_textract_document_analysis` = sha256:ea328c39a24bfb22
- `aws_textract_inline_analysis` = sha256:10ce458bfa432bdf

**Stale tokens:** a grep over src, docs (including the scenario-corpus manifest), config and tests for every old token (a97410d6…, 0e7af168…, 66ffa277…, 19fad219…, eb22e71c…) returned no matches.

**Gates:**
- `python scripts/check_contracts.py` exits 0.
- `elspeth-lints check --rules plugin_contract.plugin_hashes`, `plugin_contract.component_type` and `plugin_contract.options_metadata --root src/elspeth` each exit 0. The positive control for plugin_hashes was done in #1: a mutated hash made it go red.
- ruff check and ruff format are clean on all touched files. mypy on src/elspeth/plugins/transforms/aws, contracts/call_mode.py and call_mode_session.py reports no issues.
- `scripts/branch-safety-check.sh --intent commit` reported FAIL=0 WARN=0 before every commit.

**Tests:**
- `tests/unit/plugins/transforms/aws` + `test_cloud_transforms_p3_sweep.py` + `tests/unit/web/catalog` at -n 4: 791 passed, exit 0.
- `tests/unit/engine/orchestrator` + aws: 1674 passed, exit 0, measured after #2/#3.
- `tests/unit/architecture` + `tests/unit/elspeth_lints/test_masquerade_gate.py` at -n 2 on HEAD a637bf49 (log `arch-head.log`): exit 1. 2254 passed, 1 skipped, 1 xfailed, 1 failed. The one failure is `test_web_landscape_mutation_fencing.py::test_required_work_reserve_rejects_protected_instance_formal_recovery`, which hit `Failed: Timeout (>900.0s) from pytest-timeout` while the host was under load (about 2 GB free). That is not an assertion failure. It is a whole-tree web-landscape scan, and the lane touched no web or landscape files; the same file timed out in the earlier wide run. The masquerade gate, including the seeder test that timed out earlier, passed.

**Trust-tier, keyless** (`ELSPETH_JUDGE_METADATA_SIGNATURE_VERIFY_MODE=shape-only-when-key-missing elspeth-lints check --rules trust_tier.tier_model`):
- Run on the base f4eb5484 (a git-archive copy of src, config and pyproject) and on HEAD.
- Positive control: line numbers differ in the touched files, so each run read its own tree.
- The finding corpora with line and column stripped are identical (diff of 0 lines). There are no new findings and no stale or expired allowlist entries.

## Signed tier_model entries whose fingerprint rotated

None. The keyless scan shows no new Stale/Expired `fp=` entries between base and HEAD. No judge signature was touched, and the HMAC key was never present.

## Maintainer decisions

1. **Verify-mode response comparison for async Textract.** Admission now matches the source request, but `verify_call` compares responses. Provider-generated `JobId`, `NextToken` fingerprints, attempts and RequestId differ in every live verify run, so a verify run will still report differences. This needs an engine-level response exclusion or normalisation policy per call type or operation. Not invented here.
2. **Index-exact verify of IN_PROGRESS polls.** A live verify job polls a different number of times than the source job. The parent-local index alignment then drifts, and `assert_complete` would flag unconsumed or extra calls. Options:
   - verify only the start call and the terminal page sequence;
   - make IN_PROGRESS polls non-indexed;
   - or accept verify-mode refusal for async Textract.

   Engine policy, deliberately not decided. The plugin side stops at substituted admission.
3. **`CallModeSession.has_source_call` (new engine API).** A read-only request-hash existence query at a parent-local index, allowed in REPLAY/VERIFY. The census was re-pinned on the inherited `request_data` Mapping contract. Please confirm the protocol addition is acceptable, or name the owned type you want instead. Passing a precomputed hash would move hashing responsibility into plugins.
4. **Replay residuals (documented in code):**
   - A final SUCCEEDED page that arrived after the source deadline replays as success.
   - A replay follower inherits the latest recorded failure for its bucket.
   - A follower whose source leader never replays (for example a partial replay) fails closed with `AuditIntegrityError` after the bounded wait.
5. **Verify mode for the HeadBucket single-flight is still race-dependent.** In verify, leadership is decided by the live race, not the archive, so the row that issues the live HeadBucket may differ from the source row. Fixing this needs the same engine decision as item 2.
6. **`poll_timeout` was decided as a permanent row error.** A transient error still present at the deadline escalates as `PluginRetryableError`, so the engine retry re-attaches to the same job through the deterministic ClientRequestToken. Please confirm, or prefer a retryable timeout.
7. **Follower evidence does not name the leader's state_id.** Optional, and not done. It would make cached and inherited HeadBucket evidence traceable to the leading call.

## Caveats

- The earlier wide run (web/catalog, plugins, architecture and dag at -n 4, before #6–#10) had 5 pytest-timeout failures under host memory pressure: one dag recovery test, three web_landscape_mutation_fencing tests and the masquerade-gate seeder test. They were unrelated to the touched files. The serial re-run of those 5 was killed by the background time limit after 2 passes.
- The full `pytest tests/` suite and the testcontainer suite were not run, per the brief: -n 4 ceiling and never the whole tree. The `has_source_call` engine addition is read-only and touches no schema or SQL, but it is shared runtime code, so the orchestrator's pre-merge full-suite gate should cover it.
