# lane-01-p3aws-textract — AWS review 2026-11-13 Textract: #1 P1 retryable failures never retried; #2 P2 verify mode; #3 P2 replay timing; #6 #7 #9 #10 #11 P3

Ticket `p3aws-textract` · run `p3aws` · branch `lane/p3aws-textract` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

FIRST STEP: merge the integrator tip into your lane branch so the widened plugin_hashes rule (f585ee70: it now scans plugins/transforms/aws) applies to you: `git fetch origin claude/zen-turing-pphown && git merge --no-ff 1e57572b` (resolve any conflict by keeping both sides' intent; CHANGELOG is the integrator's — keep theirs, never edit CHANGELOG yourself). The full review is at .claude/lanes/fixrun/p3aws/aws-review.md (copied from docs/architecture/reviews/2026-11-13-aws-transforms-review.md on 1e57572b) — read your findings there in full; line numbers are at f585ee70. Method: systematic debugging + TDD per finding: write a failing test that fails AT AN ASSERTION on the current code (assert new symbols exist with hasattr/find_spec before using them), commit tests, then the fix, then the next finding. Re-pin every touched plugin's source_file_hash with scripts.cicd.plugin_hash.compute_source_file_hash and check that nothing else pins the old token (grep docs/architecture/dag/scenario-corpus/v1/manifest.yaml); run `python scripts/check_contracts.py` (soft-mapping census: convert to owned types rather than adding soft mappings; only re-pin with --write-census if the site is an inherited contract) and `elspeth-lints check --rules plugin_contract --root src/elspeth` with PYTHONPATH covering src and elspeth-lints/src. Rules: no # noqa / # type: ignore / allowlist widening; no git stash; never touch judge signatures (if a signed tier_model entry's fingerprint rotates, list it in report.md for operator re-sign); no CHANGELOG edits; Python is the worktree .venv (3.14). If a fix needs a design decision outside the plugin (e.g. engine call-mode admission semantics), implement the plugin-side part, write the decision needed into report.md under 'Maintainer decisions', and do not invent engine policy. report.md must include per finding: RED evidence, fix summary, COMPAT/behaviour changes, a one-line CHANGELOG entry, and re-pinned hashes. ORDER: finding 1 (P1) first and land it as its own test+fix commit pair before anything else. Finding 1: Textract transforms return TransformResult.error(retryable=True) which the engine never reads (engine/processor.py is_retryable only honours raised PluginRetryableError/ConnectionError/TimeoutError/CapacityError; azure/base.py:439 documents this). Fix: raise PluginRetryableError after the audited client has recorded the call for submit-side and inline transient failures (as azure/analyze_lro.py does); in the poll loop retry a retryable TextractServiceError in place until the poll deadline without resubmitting (mirror test_f61_poll_network_error_is_retried_in_place_without_resubmitting); decide poll_timeout explicitly and document it. IMPORTANT: aws_textract_document_analysis is a batch/worker-pool transform — trace how a raised exception from the worker reaches RowProcessor's retry (batching/mixin.py, late-failure handling) and prove with a test that drives the real engine retry path (not result.retryable) that a throttled row is retried and re-attaches to the same job via the deterministic ClientRequestToken. Fix the misleading inline composer hint about engine retries if it becomes untrue/true. Update the four tests in finding 11 that assert result.retryable. Then findings 2 and 3 (verify/replay determinism: job id and next_token fingerprints substituted like the start token; replay skips sleeps and ends the poll loop from the archive; leader/follower in bucket-region from the archive) — if index-exact verify of IN_PROGRESS polls needs an engine-level policy, stop at the plugin side and record the decision. Then P3s 6 (observed attempts for all BotoCoreError, HeadBucket hook), 7 (inline config le= ceilings), 9 (bucket LINE blocks by page in one pass), 10 (byte-length key check in per-row bucket mode).

## Files a correct fix must change

- `src/elspeth/plugins/transforms/aws/textract_document_analysis.py`
- `src/elspeth/plugins/transforms/aws/textract_inline_analysis.py`
- `src/elspeth/plugins/transforms/aws/textract_client.py`

## Test files the lane must add or change

- `tests/unit/plugins/transforms/aws/test_aws_review_textract.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/transforms/aws/test_aws_review_textract.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash .claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-01-p3aws-textract/report.md`; the worker returns one line.
