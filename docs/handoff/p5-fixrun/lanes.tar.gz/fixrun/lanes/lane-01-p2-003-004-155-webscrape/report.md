DONE: #3, #4 and #155 fixed on lane/p2-003-004-155-webscrape in 6 commits (one test commit and one fix commit per finding). Each lane test failed at an assertion on the base; the lane file now passes 6/6. ruff, format, contracts, mypy on src, the 373 web_scrape tests and the targeted whole-tree gates are green. The full arch/dag selection timed out on the loaded host.

(The hub wrote this file from lane-01's hand-back, because the harness refused the lane's own report write.)

## Commits
| Commit | Kind | Finding |
|---|---|---|
| 49da8550 | test | #3 |
| 5610b309 | fix (+ re-pin) | #3 |
| 4145508f | test | #4 |
| 1db143c2 | fix (+ re-pin) | #4 |
| 8b640a0d | test | #155 |
| 0063e792 | fix | #155 |

## #3: cycle check
**Root cause:** `seen_urls` was filled with raw httpx URL spellings, but each next_url is rewritten by fingerprint_url before the membership test. A self-link that fingerprint_url had rewritten was therefore never recognised as already seen.

**Fix:** `seen_urls` now holds fingerprint_url forms on both sides: web_scrape.py:1541 and :1672.

**Evidence:**
- RED: `assert 2 == 1` on call_count.
- GREEN: 1 passed; with the pagination tests, 30 passed.

## #4: replay/verify crash
**Root cause:** in replay and verify, fingerprint_url called urlsplit before any URL-shape check, so a malformed URL raised `ValueError('Invalid IPv6 URL')` uncaught.

**Fix:** `validate_url_scheme(url)` now runs before the mode branches (web_scrape.py:1354).
- This makes no DNS call, so the replay no-DNS test still passes.
- Live behaviour is unchanged.

**Evidence:**
- RED: the replay and verify cases fail ("raised ValueError('Invalid IPv6 URL') instead of refusing the row"); the live control passes. 2 failed, 2 passed.
- GREEN: 4 passed.

## #155: invalid next_link_selector
**Root cause:** web_scrape_pagination.py:46-51 caught only ValueError and TypeError. SelectorSyntaxError is neither, so it escaped as a raw exception.

**Fix:** SelectorSyntaxError is added to the caught tuple, so it now surfaces as a ValueError. This mirrors web_scrape_extraction.

**Evidence:**
- RED: "expected ValidationError/PluginConfigError, got SelectorSyntaxError". 2 failed, 4 passed.
- GREEN: 6 passed.

## Re-pins
WebScrapeTransform.source_file_hash changed twice:
- 0c38862aa7a0f075 → 2506325fd6780ba3 (#3)
- 2506325fd6780ba3 → 1ecbd3ab145d2c04 (#4)

No other reference to the hash needed changing: no manifest, projection or case-registry pin.

## Gates
| Gate | Result |
|---|---|
| Lane test | exit 0, 6 passed |
| ruff | 0 |
| ruff format | 0 |
| check_contracts | 0 |
| mypy (src files) | 0 |
| web_scrape tests | 373 passed |
| Targeted whole-tree gates (corpus contract, plugin metadata, catalog, protocols, validation path, process-path gate, masquerade, digest shape) | 1125 passed, 1 skipped |
| branch-safety --intent commit | 0 |

## Caveats
- **Arch/dag selection not completed.** The full `tests/integration/core/dag tests/unit/architecture` run was killed at 87% after 30 minutes under load average 11; its 2 F marks were killed xdist workers. The hub's verify suite covers this selection.
- **Test-file mypy errors.** The test file has 9 mypy errors of the same kind as its sibling test file. These are outside CI's mypy scope.
- **Trust-tier lint not compared.** The keyless lint findings were not compared before and after. No getattr or broad-except changes were made.
