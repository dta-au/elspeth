# lane-01-p2-003-004-155-webscrape — #3 [P2, bug] Pagination cycle detection compares a canonicalized next URL against raw seen URLs, so it fetches page 1 again and duplicates its content and records; #4 [P2, bug] Replay/verify mode crashes on a malformed row URL that live mode refuses cleanly; #155 [P2, bug] PaginationConfig lets an invalid next_link_selector escape as a raw soupsieve.SelectorSyntaxError instead of a config validation error

Ticket `p2-003-004-155-webscrape` · run `p2` · branch `lane/p2-003-004-155-webscrape` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

This lane fixes 3 findings; fix each one (one test commit + one fix commit PER finding).
The listed files are where the sweep located each defect; a finding may need no change in some of them.

FINDING #3 [P2, bug] Pagination cycle detection compares a canonicalized next URL against raw seen URLs, so it fetches page 1 again and duplicates its content and records

`src/elspeth/plugins/transforms/web_scrape.py`

web_scrape.py:1522-1525 seeds seen_urls with initial_request_url (`str(httpx.Request('GET', url, params=...).url)`) and with final_hostname_url, which equals request.original_url when there are no params or redirects (http.py:1933, 1855). Both are the raw spelling. Line 1565 then rewrites every discovered next_url to `fingerprint_url(next_url)`, which re-encodes the query with urllib urlencode (fingerprinting.py:380). Line 1570 checks `next_url in seen_urls`. When the starting URL's query contains characters that urlencode escapes but httpx leaves alone (for example ':' or ','), a self-link or back-link is not recognised. The page is fetched again, and its content and records are appended a second time. Cycle detection only fires on the next iteration, after line 1656 adds the canonical form. Expected: compare like with like by canonicalizing seen URLs with the same fingerprint_url, or canonicalizing both sides. Verification: a scratchpad repro reused tests/unit/plugins/transforms/test_web_scrape_pagination.py fixtures (next_link_css mode) with row url 'https://example.com/page-1?sort=a:b' and a page linking to '/page-1?sort=a:b'. Result: success, route.call_count == 2, content 'first Next first Next', pagination_stop_reason 'cycle', 2 pagination_pages. Control: the existing test_cycle_stops_without_refetch, which has no query, fetches once. Change-detection fingerprints and records are therefore corrupted by the duplicate page.

**Verifier (CONFIRMED):** Repro scratch-A/repro_ws.py reused the test_web_scrape_pagination fixtures (next_link_css, a.next). Row url 'https://example.com/page-1?sort=a:b' with a self-link '/page-1?sort=a:b' gave success, route.call_count=2, content 'first Next first Next', stop_reason 'cycle' and 2 pagination_pages. The control without a query gave call_count=1 and content 'first Next'. Code: web_scrape.py:1522-1525 seeds seen_urls with the raw httpx spelling, web_scrape.py:1565 rewrites next_url via fingerprint_url, and the membership test at :1570 compares mismatched spellings. Page 1 is fetched again, and its content and records are duplicated into the output and fingerprint. The bound is a single extra page, so P2 stands as a data-integrity defect.

FINDING #4 [P2, bug] Replay/verify mode crashes on a malformed row URL that live mode refuses cleanly

`src/elspeth/plugins/transforms/web_scrape.py`

web_scrape.py:1343-1360. In RunMode.REPLAY and VERIFY, process() evaluates `fingerprint_url(url)` on the raw Tier-3 row URL before any SSRF validation. In the default config, validate_allowed_http_origin is a no-op (empty allowed_origins), so nothing has checked the URL yet. fingerprint_url calls urlsplit, which raises ValueError on a malformed authority such as 'http://[bad/x' (measured: ValueError 'Invalid IPv6 URL'). ValueError is not in the except list at 1392-1399. Live mode instead reaches validate_url_for_ssrf, which turns the same input into SSRFBlockedError('Malformed URL ...') (measured), and that becomes a row_url_policy_refusal error result. So a run that recorded a clean row refusal cannot be replayed or verified: the replay crashes on the same row. Expected: run the same SSRF-shape refusal (or catch ValueError there and map it to row_url_policy_refusal) before computing audited_url in replay and verify, so replay reproduces the live outcome. Verification: called fingerprint_url and validate_url_for_ssrf directly on 'http://[bad/x' and saw ValueError and SSRFBlockedError respectively. Code reading confirms the ordering at lines 1333, 1343-1349 and 1352-1358.

**Verifier (CONFIRMED):** Repro scratch-A/repro4.py ran process() on row url 'http://[bad/x', default config. LIVE returned TransformResult.error {'reason':'validation_failed','error_type':'SSRFBlockedError','cause':'malformed_url'}. With a stub call_mode_session in REPLAY and in VERIFY mode, process raised ValueError 'Invalid IPv6 URL' before replay_ssrf_request was reached. The stub raises if called, and it was not called: fingerprint_url(url) is evaluated as an argument at web_scrape.py:1346/1355. validate_allowed_http_origin(url, ()) returns None (no-op), and the except list at :1389-1396 has no ValueError. Like #2, the executor and processor re-raise non-retryable exceptions, so replay or verify of a run that recorded a clean refusal crashes. Caveat: the session was a SimpleNamespace stub, but the crash happens before any session method is used.

FINDING #155 [P2, bug] PaginationConfig lets an invalid next_link_selector escape as a raw soupsieve.SelectorSyntaxError instead of a config validation error

`src/elspeth/plugins/transforms/web_scrape_pagination.py`

Lines 46-50: `_validate_mode` calls `BeautifulSoup(...).select(self.next_link_selector)` and catches only `(ValueError, TypeError)`. `soupsieve.SelectorSyntaxError` subclasses `Exception` directly (MRO measured: SelectorSyntaxError -> Exception -> BaseException), so it is not caught. It also skips pydantic's ValueError-to-ValidationError conversion. Measured: `PaginationConfig(mode='next_link_css', next_link_selector='a[')` raises `soupsieve.util.SelectorSyntaxError: Malformed attribute selector at position 1`. A full `WebScrapeConfig.from_dict({... 'pagination': {'mode':'next_link_css','next_link_selector':'a['}}, plugin_name='web_scrape')` raises the same raw soupsieve exception instead of PluginConfigError. The result is a crash-shaped, unstructured error on operator or Composer-authored input. The sibling validator `_validate_css_selector` in web_scrape_extraction.py:21-28 handles this correctly by catching `soupsieve.SelectorSyntaxError` and re-raising ValueError. Expected behaviour: catch soupsieve.SelectorSyntaxError (or reuse `_validate_css_selector`) and raise ValueError so the error becomes a normal config ValidationError/PluginConfigError. Test gap: in tests/unit/plugins/transforms/test_web_scrape_pagination.py, next_link_selector appears only with the valid value 'a.next' (lines 89, 176, 273). No test uses an invalid selector.

**Verifier (CONFIRMED):** Ran PaginationConfig(mode='next_link_css', next_link_selector='a[') and got soupsieve.util.SelectorSyntaxError. Ran WebScrapeConfig.from_dict({... 'pagination': {'mode':'next_link_css','next_link_selector':'a['}}, plugin_name='web_scrape') and got the same raw SelectorSyntaxError, not PluginConfigError. Cause: web_scrape_pagination.py:46-49 catches only (ValueError, TypeError), and config_base.py:355-363 converts only ValidationError and ValueError. Downstream: plugins/infrastructure/validation.py:159-165 (validate_transform_config) catches only PydanticValidationError and PluginConfigError, and web/composer/state.py:2118 treats any other exception as an engine defect that 'must crash through'. So a planner-authored bad selector crashes the composer probe instead of producing a config error. No test uses an invalid selector (only 'a.next' at test_web_scrape_pagination.py:89,176,273).

## Files a correct fix must change

- `src/elspeth/plugins/transforms/web_scrape.py`
- `src/elspeth/plugins/transforms/web_scrape_pagination.py`

## Test files the lane must add or change

- `tests/unit/plugins/transforms/test_web_scrape_p2_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/transforms/test_web_scrape_p2_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-01-p2-003-004-155-webscrape/report.md`; the worker returns one line.
