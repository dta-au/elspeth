"""Tests for Dataverse source plugin."""

from __future__ import annotations

import urllib.parse
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field, replace
from types import SimpleNamespace
from typing import Any
from unittest.mock import patch

import httpx
import pytest

from elspeth.contracts import CallStatus
from elspeth.contracts.coordination import CoordinationToken
from elspeth.contracts.enums import RunMode
from elspeth.contracts.errors import AuditIntegrityError
from elspeth.core.security.web import SSRFBlockedError, SSRFSafeRequest
from elspeth.plugins.infrastructure.clients.dataverse import (
    DataverseClient,
    DataverseClientError,
    DataversePageResponse,
)
from elspeth.plugins.infrastructure.clients.fingerprinting import fingerprint_url
from elspeth.plugins.infrastructure.config_base import PluginConfigError


@pytest.mark.parametrize("consumption", ["not_started", "partial", "closed", "empty", "discarded"])
def test_load_statistics_distinguish_lifecycle_states(consumption: str) -> None:
    from elspeth.contracts.events import DataverseLoadStatistics

    rows = [] if consumption == "empty" else [{"contactid": "first", "fullname": "First"}, {"contactid": "second"}]
    if consumption == "discarded":
        rows = [{"contactid": "missing_name"}, {"fullname": "missing_id"}]
    source = _make_source_for_load(
        [_make_page(rows)],
        _base_config(schema={"mode": "fixed", "fields": ["contactid: str", "fullname: str"]}, on_validation_failure="discard"),
    )
    ctx = _mock_lifecycle_context()
    iterator = source.load(_mock_source_context())
    if consumption in ("partial", "closed"):
        next(iterator)
        if consumption == "closed":
            iterator.close()
    elif consumption in ("empty", "discarded"):
        assert list(iterator) == []
    source.on_complete(ctx)
    ctx.telemetry_emit.assert_called_once()
    event = ctx.telemetry_emit.call_args.args[0]
    assert isinstance(event, DataverseLoadStatistics)
    assert event.run_id == ctx.run_id
    assert event.node_id == ctx.node_id
    assert event.pages_fetched == (0 if consumption == "not_started" else 1)
    assert event.rows_yielded == (1 if consumption in ("partial", "closed") else 0)
    assert event.rows_rejected == (2 if consumption == "discarded" else 0)
    assert (
        event.load_state
        == {
            "not_started": "not_started",
            "partial": "partial",
            "closed": "partial",
            "empty": "exhausted",
            "discarded": "exhausted",
        }[consumption]
    )
    iterator.close()


def test_statistics_reset_on_new_lifecycle() -> None:
    source = _make_source_for_load([_make_page([{"count": 1}, {"count": "bad"}])], _base_config(on_validation_failure="discard"))
    list(source.load(_mock_source_context()))
    ctx = _mock_lifecycle_context()
    source.on_complete(ctx)
    assert ctx.telemetry_emit.call_args.args[0].rows_yielded == 1
    assert ctx.telemetry_emit.call_args.args[0].rows_rejected == 1
    source.close()
    with (
        patch("azure.identity.ClientSecretCredential", new=_client_secret_credential_factory),
        patch("elspeth.plugins.sources.dataverse.DataverseClient", new=_dataverse_client_factory(_DataverseClientFake())),
    ):
        source.on_start(ctx)
    source.on_complete(ctx)
    assert ctx.telemetry_emit.call_count == 2
    event = ctx.telemetry_emit.call_args.args[0]
    assert (event.pages_fetched, event.rows_yielded, event.rows_rejected, event.load_state) == (0, 0, 0, "not_started")
    source.close()


@pytest.mark.parametrize("audit_failure", ["page", "validation"])
def test_statistics_do_not_count_failed_audit_writes(audit_failure: str) -> None:
    from elspeth.contracts.errors import AuditIntegrityError

    source = _make_source_for_load([_make_page([{"count": 1}, {"count": "bad"}])], _base_config(on_validation_failure="discard"))
    ctx = _mock_source_context()
    if audit_failure == "page":
        # Metadata audit succeeds; fail the data-page audit before counting it.
        ctx.record_call.side_effect = iter([None, AuditIntegrityError("audit unavailable")])
    else:
        ctx.record_validation_error.side_effect = AuditIntegrityError("audit unavailable")
    with pytest.raises(AuditIntegrityError, match="audit unavailable"):
        list(source.load(ctx))
    lifecycle = _mock_lifecycle_context()
    source.on_complete(lifecycle)
    event = lifecycle.telemetry_emit.call_args.args[0]
    assert event.load_state == "failed"
    assert event.pages_fetched == (0 if audit_failure == "page" else 1)
    assert event.rows_yielded == (0 if audit_failure == "page" else 1)
    assert event.rows_rejected == 0


# Dynamic schema config for tests
DYNAMIC_SCHEMA = {"mode": "observed"}
# A declared field the fixture rows omit, so validation fails through the real schema.
_REQUIRED_FIELD_SCHEMA = {"mode": "fixed", "fields": ["contactid: str", "required_field: str"]}
FIXED_SCHEMA = {
    "mode": "fixed",
    "fields": [
        {"name": "contactid", "type": "string"},
        {"name": "fullname", "type": "string"},
    ],
}
FLEXIBLE_SCHEMA = {
    "mode": "flexible",
    "fields": [
        {"name": "contactid", "type": "string"},
    ],
}

# Standard quarantine routing
QUARANTINE_SINK = "quarantine"

# Minimal valid auth config
VALID_AUTH = {
    "method": "service_principal",
    "tenant_id": "test-tenant",
    "client_id": "test-client",
    "client_secret": "test-secret",
}

# Valid environment URL
VALID_ENV_URL = "https://myorg.crm.dynamics.com"


def _base_config(**overrides: Any) -> dict[str, Any]:
    """Build a minimal valid structured-query config with overrides."""
    config: dict[str, Any] = {
        "environment_url": VALID_ENV_URL,
        "auth": VALID_AUTH,
        "entity": "contact",
        "schema": DYNAMIC_SCHEMA,
        "on_validation_failure": QUARANTINE_SINK,
    }
    config.update(overrides)
    return config


def _fetchxml_config(**overrides: Any) -> dict[str, Any]:
    """Build a minimal valid FetchXML config with overrides."""
    config: dict[str, Any] = {
        "environment_url": VALID_ENV_URL,
        "auth": VALID_AUTH,
        "fetch_xml": '<fetch><entity name="contact"><attribute name="fullname"/></entity></fetch>',
        "schema": DYNAMIC_SCHEMA,
        "on_validation_failure": QUARANTINE_SINK,
    }
    config.update(overrides)
    return config


def test_discovery_query_guidance_matches_accepted_configuration() -> None:
    from elspeth.plugins.sources.dataverse import DataverseSource, DataverseSourceConfig

    assert DataverseSourceConfig.from_dict(_base_config()).entity == "contact"
    assert DataverseSourceConfig.from_dict(_fetchxml_config()).fetch_xml is not None
    with pytest.raises(PluginConfigError, match="query_mode"):
        DataverseSourceConfig.from_dict(_base_config(query_mode="odata"))
    with pytest.raises(PluginConfigError, match="exactly one"):
        DataverseSourceConfig.from_dict(_fetchxml_config(entity="contact"))
    for option, value in (("select", ["fullname"]), ("filter", "statecode eq 0"), ("orderby", "fullname"), ("top", 1)):
        with pytest.raises(PluginConfigError, match="require entity"):
            DataverseSourceConfig.from_dict(_fetchxml_config(**{option: value}))

    assistance = DataverseSource.get_agent_assistance()
    assert assistance is not None
    hints = " ".join(assistance.composer_hints)
    assert "query_mode" not in hints
    assert "exactly one of entity (structured OData) or fetch_xml (FetchXML)" in hints
    assert "select/filter/orderby/top require entity" in hints


def _make_page(
    rows: list[dict[str, Any]],
    *,
    next_link: str | None = None,
    paging_cookie: str | None = None,
    more_records: bool | None = False,
    status_code: int = 200,
    latency_ms: float = 10.0,
) -> DataversePageResponse:
    """Build a canned DataversePageResponse."""
    return DataversePageResponse(
        status_code=status_code,
        rows=rows,
        latency_ms=latency_ms,
        headers={"content-type": "application/json"},
        request_headers={"Authorization": "<fingerprint:test-fake>"},
        request_url="https://test.crm.dynamics.com/api/data/v9.2/contacts",
        next_link=next_link,
        paging_cookie=paging_cookie,
        more_records=more_records,
    )


@dataclass(frozen=True, slots=True)
class _RecordedCall:
    args: tuple[Any, ...]
    kwargs: dict[str, Any]


class _CallRecorder:
    """Minimal callable test double exposing the call assertions used here."""

    def __init__(self, return_value: Any = None, side_effect: Any = None) -> None:
        self.return_value = return_value
        self.side_effect = side_effect
        self.call_args_list: list[_RecordedCall] = []

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        self.call_args_list.append(_RecordedCall(args=args, kwargs=dict(kwargs)))
        if self.side_effect is None:
            return self.return_value
        if isinstance(self.side_effect, BaseException):
            raise self.side_effect
        if callable(self.side_effect):
            return self.side_effect(*args, **kwargs)
        result = next(self.side_effect)
        if isinstance(result, BaseException):
            raise result
        return result

    @property
    def call_count(self) -> int:
        return len(self.call_args_list)

    @property
    def call_args(self) -> _RecordedCall:
        return self.call_args_list[-1]

    def assert_called_once(self) -> None:
        if self.call_count != 1:
            raise AssertionError(f"Expected 1 call, got {self.call_count}")

    def assert_not_called(self) -> None:
        if self.call_count != 0:
            raise AssertionError(f"Expected no calls, got {self.call_count}")


@dataclass(slots=True)
class _LifecycleContextFake:
    run_id: str = "test-run-123"
    node_id: str | None = "source-node"
    operation_id: str | None = "op-001"
    call_mode_session: Any = None
    landscape: Any = None
    payload_store: Any = None
    rate_limit_registry: Any = None
    telemetry_emit: _CallRecorder = field(default_factory=_CallRecorder)
    concurrency_config: Any = None
    shutdown_event: Any = None


@dataclass(slots=True)
class _SourceContextFake:
    run_id: str = "test-run-123"
    node_id: str | None = "source-node"
    operation_id: str | None = "op-001"
    call_mode_session: Any = None
    landscape: Any = None
    telemetry_emit: _CallRecorder = field(default_factory=_CallRecorder)
    record_call: _CallRecorder = field(default_factory=_CallRecorder)
    record_validation_error: _CallRecorder = field(default_factory=_CallRecorder)


@dataclass(frozen=True, slots=True)
class _CredentialToken:
    token: str = "test-token"


class _CredentialFake:
    def get_token(self, *_args: Any, **_kwargs: Any) -> _CredentialToken:
        return _CredentialToken()


class _DataverseClientFake:
    def __init__(
        self,
        *,
        metadata_page: DataversePageResponse | None = None,
        odata_pages: list[DataversePageResponse] | None = None,
        fetchxml_pages: list[DataversePageResponse] | None = None,
    ) -> None:
        self.get_page = _CallRecorder(return_value=metadata_page or _make_metadata_page("contact"))
        self.paginate_odata = _CallRecorder(return_value=iter(odata_pages or []))
        self.paginate_fetchxml = _CallRecorder(return_value=iter(fetchxml_pages or []))
        self.get_auth_headers = _CallRecorder(return_value={"Authorization": "Bearer test"})
        self.reconstruct_credential = _CallRecorder()
        self.close = _CallRecorder()


class _OperationLandscapeFake:
    def __init__(self) -> None:
        self.record_operation_call = _CallRecorder(
            return_value=SimpleNamespace(
                request_hash="req-hash",
                response_hash="resp-hash",
            )
        )


def _make_metadata_page(
    logical_name: str,
    url: str | None = None,
    *,
    entity_set_name: str = "contacts",
    rows: list[dict[str, Any]] | None = None,
) -> DataversePageResponse:
    request_url = url or f"{VALID_ENV_URL}/api/data/v9.2/EntityDefinitions(LogicalName='{logical_name}')?$select=LogicalName,EntitySetName"
    return DataversePageResponse(
        status_code=200,
        rows=rows if rows is not None else [{"LogicalName": logical_name, "EntitySetName": entity_set_name}],
        latency_ms=5.0,
        headers={"content-type": "application/json"},
        request_headers={"Authorization": "<fingerprint:test-fake>"},
        request_url=request_url,
        next_link=None,
        paging_cookie=None,
        more_records=None,
    )


def _mock_lifecycle_context(run_id: str = "test-run-123") -> _LifecycleContextFake:
    """Build a LifecycleContext fake for on_start()."""
    return _LifecycleContextFake(run_id=run_id)


def _mock_source_context() -> _SourceContextFake:
    """Build a SourceContext fake for load()."""
    return _SourceContextFake()


def _plugin_context_for_operation_calls(*, telemetry_emit: Any) -> Any:
    """Build a real PluginContext configured for source operation call recording."""
    from elspeth.contracts.plugin_context import PluginContext

    return PluginContext(
        run_id="test-run-123",
        config={},
        landscape=_OperationLandscapeFake(),
        node_id="source-node",
        operation_id="op-001",
        coordination_token=CoordinationToken(run_id="test-run-123", worker_id="mock-worker", leader_epoch=1),
        telemetry_emit=telemetry_emit,
    )


def _client_secret_credential_factory(*_args: Any, **_kwargs: Any) -> _CredentialFake:
    return _CredentialFake()


def _make_ssrf_safe(url: str) -> SSRFSafeRequest:
    parsed = urllib.parse.urlparse(url)
    hostname = parsed.hostname or "localhost"
    path = parsed.path or "/"
    if parsed.query:
        path = f"{path}?{parsed.query}"
    return SSRFSafeRequest(
        original_url=url,
        resolved_ip="127.0.0.1",
        host_header=hostname,
        port=parsed.port or 443,
        path=path,
        scheme=parsed.scheme,
        bare_hostname=hostname,
    )


def _dataverse_client_factory(client: _DataverseClientFake) -> Callable[..., _DataverseClientFake]:
    def factory(*_args: Any, **_kwargs: Any) -> _DataverseClientFake:
        return client

    return factory


def _make_source(config: dict[str, Any]) -> Any:
    """Create a DataverseSource with real schema and contract collaborators."""
    from elspeth.plugins.sources.dataverse import DataverseSource

    return DataverseSource(config)


def _make_source_unlocked(config: dict[str, Any]) -> Any:
    """Create a DataverseSource with an unlocked contract (for contract builder tests)."""
    return _make_source(config)


def _make_source_for_load(pages: list[DataversePageResponse], config: dict[str, Any]) -> Any:
    """Create DataverseSource for load() tests with a fake client."""
    from elspeth.plugins.sources.dataverse import DataverseSource

    source = DataverseSource(config)

    if source._entity is not None:
        metadata_url = (
            f"{source._environment_url.rstrip('/')}/api/data/{source._api_version}/"
            f"EntityDefinitions(LogicalName='{source._entity}')?$select=LogicalName,EntitySetName"
        )
        client = _DataverseClientFake(
            metadata_page=_make_metadata_page(source._entity, metadata_url),
            odata_pages=pages,
        )
    else:
        client = _DataverseClientFake(fetchxml_pages=pages)
    source._client = client

    return source


def _make_source_for_start_and_load(
    config: dict[str, Any],
    *,
    mock_client: _DataverseClientFake,
) -> Any:
    """Create DataverseSource for lifecycle + load() tests with a patched client."""
    from elspeth.plugins.sources.dataverse import DataverseSource

    source = DataverseSource(config)

    lifecycle_ctx = _mock_lifecycle_context()
    with (
        patch("azure.identity.ClientSecretCredential", new=_client_secret_credential_factory),
        patch(
            "elspeth.plugins.sources.dataverse.DataverseClient",
            new=_dataverse_client_factory(mock_client),
        ),
    ):
        source.on_start(lifecycle_ctx)

    return source


# ─────────────────────────────────────────────────────────────────────────
# Config validation tests
# ─────────────────────────────────────────────────────────────────────────


class TestDataverseSourceConfigValidation:
    """Tests for DataverseSourceConfig validation rules."""

    def test_valid_structured_config(self) -> None:
        """Accept a minimal valid structured-query config."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        cfg = DataverseSourceConfig.from_dict(_base_config())
        assert cfg.entity == "contact"
        assert cfg.fetch_xml is None

    @pytest.mark.parametrize(
        "entity",
        ["contact name", "contact/path", "contact?query", "contact#fragment", "contact\x00name", "1contact", " contact", "contact "],
    )
    def test_entity_rejects_values_outside_dataverse_identifier_grammar(self, entity: str) -> None:
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        with pytest.raises(PluginConfigError, match="ASCII identifier"):
            DataverseSourceConfig.from_dict(_base_config(entity=entity))

    @pytest.mark.parametrize(
        "entity_set_name",
        [
            "contact sets",
            "contacts/path",
            "contacts?query",
            "contacts#fragment",
            "contacts\x00name",
            "1contacts",
            " contacts",
            "contacts ",
        ],
    )
    def test_entity_set_name_rejects_values_outside_dataverse_identifier_grammar(self, entity_set_name: str) -> None:
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        with pytest.raises(PluginConfigError, match="ASCII identifier"):
            DataverseSourceConfig.from_dict(_base_config(entity_set_name=entity_set_name))

    @pytest.mark.parametrize("entity", ["contact", "_contact2", "contact_name2"])
    def test_logical_names_accept_lowercase_ascii_identifiers(self, entity: str) -> None:
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        cfg = DataverseSourceConfig.from_dict(_base_config(entity=entity))
        assert cfg.entity == entity

    @pytest.mark.parametrize("entity", ["Contact", "CONTACT", "contact_Name"])
    def test_logical_names_reject_uppercase_ascii(self, entity: str) -> None:
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        with pytest.raises(PluginConfigError, match="lowercase ASCII identifier"):
            DataverseSourceConfig.from_dict(_base_config(entity=entity))

    @pytest.mark.parametrize("entity_set_name", ["contacts", "_Contacts2", "Contact_Sets2"])
    def test_entity_set_names_preserve_ascii_case(self, entity_set_name: str) -> None:
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        cfg = DataverseSourceConfig.from_dict(_base_config(entity_set_name=entity_set_name))
        assert cfg.entity_set_name == entity_set_name

    @pytest.mark.parametrize("entity_set_name", ["", "   "])
    def test_entity_set_name_rejects_blank_values(self, entity_set_name: str) -> None:
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        with pytest.raises(PluginConfigError, match="entity_set_name"):
            DataverseSourceConfig.from_dict(_base_config(entity_set_name=entity_set_name))

    @pytest.mark.parametrize("entity_set_name", ["<OPERATOR_REQUIRED>", "operator required", "operator_required"])
    def test_entity_set_name_rejects_placeholders(self, entity_set_name: str) -> None:
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        with pytest.raises(PluginConfigError, match="placeholder"):
            DataverseSourceConfig.from_dict(_base_config(entity_set_name=entity_set_name))

    @pytest.mark.parametrize("config", [_base_config(entity_set_name="contacts"), _fetchxml_config(entity_set_name="contacts")])
    def test_entity_set_name_is_available_in_both_query_modes(self, config: dict[str, Any]) -> None:
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        cfg = DataverseSourceConfig.from_dict(config)
        assert cfg.entity_set_name == "contacts"

    @pytest.mark.parametrize("entity", ["<OPERATOR_REQUIRED>", "operator required", "operator_required"])
    def test_entity_placeholder_rejected(self, entity: str) -> None:
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        with pytest.raises(PluginConfigError, match="placeholder"):
            DataverseSourceConfig.from_dict(_base_config(entity=entity))

    @pytest.mark.parametrize("entity", ["todo", "unknown", "unset", "required"])
    def test_plain_placeholder_words_can_be_entity_names(self, entity: str) -> None:
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        cfg = DataverseSourceConfig.from_dict(_base_config(entity=entity))
        assert cfg.entity == entity

    @pytest.mark.parametrize("select_field", ["<OPERATOR_REQUIRED>", "operator required", "operator_required"])
    def test_select_placeholder_rejected(self, select_field: str) -> None:
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        with pytest.raises(PluginConfigError, match="placeholder"):
            DataverseSourceConfig.from_dict(_base_config(select=[select_field]))

    @pytest.mark.parametrize("select_field", ["todo", "unknown", "unset", "required", "<literal>"])
    def test_plain_placeholder_words_can_be_select_fields(self, select_field: str) -> None:
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        cfg = DataverseSourceConfig.from_dict(_base_config(select=[select_field]))
        assert cfg.select == [select_field]

    def test_valid_fetchxml_config(self) -> None:
        """Accept a minimal valid FetchXML config."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        cfg = DataverseSourceConfig.from_dict(_fetchxml_config())
        assert cfg.entity is None
        assert cfg.fetch_xml is not None

    @pytest.mark.parametrize(
        "logical_name",
        ["Contact", "contact_Name", "contact name", "contact/path", "contact?query", "contact#fragment", "1contact"],
    )
    def test_fetchxml_entity_rejects_invalid_logical_name(self, logical_name: str) -> None:
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        fetch_xml = f'<fetch><entity name="{logical_name}"><attribute name="fullname"/></entity></fetch>'
        with pytest.raises(PluginConfigError, match="ASCII identifier"):
            DataverseSourceConfig.from_dict(_fetchxml_config(fetch_xml=fetch_xml))

    def test_mutual_exclusion_both_present(self) -> None:
        """Reject config with both entity and fetch_xml."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        config = _base_config(
            fetch_xml='<fetch><entity name="contact"/></fetch>',
        )
        with pytest.raises(PluginConfigError, match="exactly one"):
            DataverseSourceConfig.from_dict(config)

    def test_mutual_exclusion_neither_present(self) -> None:
        """Reject config with neither entity nor fetch_xml."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        config = _base_config()
        del config["entity"]
        with pytest.raises(PluginConfigError, match="exactly one"):
            DataverseSourceConfig.from_dict(config)

    def test_select_requires_entity(self) -> None:
        """select is only valid in structured mode (with entity)."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        config = _fetchxml_config(select=["fullname"])
        with pytest.raises(PluginConfigError, match=r"select.*require entity"):
            DataverseSourceConfig.from_dict(config)

    def test_filter_requires_entity(self) -> None:
        """filter is only valid in structured mode."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        config = _fetchxml_config(filter="statecode eq 0")
        with pytest.raises(PluginConfigError, match=r"select.*require entity"):
            DataverseSourceConfig.from_dict(config)

    def test_orderby_requires_entity(self) -> None:
        """orderby is only valid in structured mode."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        config = _fetchxml_config(orderby="createdon desc")
        with pytest.raises(PluginConfigError, match=r"select.*require entity"):
            DataverseSourceConfig.from_dict(config)

    def test_top_requires_entity(self) -> None:
        """top is only valid in structured mode."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        config = _fetchxml_config(top=100)
        with pytest.raises(PluginConfigError, match=r"select.*require entity"):
            DataverseSourceConfig.from_dict(config)

    def test_https_enforcement_rejects_http(self) -> None:
        """environment_url must use HTTPS."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        config = _base_config(environment_url="http://myorg.crm.dynamics.com")
        with pytest.raises(PluginConfigError, match="HTTPS"):
            DataverseSourceConfig.from_dict(config)

    def test_https_enforcement_accepts_https(self) -> None:
        """HTTPS URLs are accepted."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        cfg = DataverseSourceConfig.from_dict(_base_config())
        assert cfg.environment_url.startswith("https://")

    def test_environment_url_rejects_embedded_credentials(self) -> None:
        """environment_url must not carry userinfo into token scopes or audit URLs."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        config = _base_config(environment_url="https://user:pass@myorg.crm.dynamics.com")
        with pytest.raises(PluginConfigError, match="embedded credentials"):
            DataverseSourceConfig.from_dict(config)

    def test_on_validation_failure_required(self) -> None:
        """on_validation_failure cannot be omitted."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        config = _base_config()
        del config["on_validation_failure"]
        with pytest.raises(PluginConfigError):
            DataverseSourceConfig.from_dict(config)

    def test_on_validation_failure_not_empty(self) -> None:
        """on_validation_failure cannot be empty string."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        config = _base_config(on_validation_failure="")
        with pytest.raises(PluginConfigError, match="on_validation_failure"):
            DataverseSourceConfig.from_dict(config)

    def test_on_validation_failure_not_whitespace(self) -> None:
        """on_validation_failure cannot be whitespace-only."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        config = _base_config(on_validation_failure="   ")
        with pytest.raises(PluginConfigError, match="on_validation_failure"):
            DataverseSourceConfig.from_dict(config)

    def test_on_validation_failure_strips_whitespace(self) -> None:
        """on_validation_failure value is stripped."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        cfg = DataverseSourceConfig.from_dict(_base_config(on_validation_failure="  quarantine  "))
        assert cfg.on_validation_failure == "quarantine"

    def test_fetchxml_bad_xml_syntax(self) -> None:
        """FetchXML with broken XML syntax fails at config time."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        config = _fetchxml_config(fetch_xml="<fetch><not-closed>")
        with pytest.raises(PluginConfigError, match="invalid XML syntax"):
            DataverseSourceConfig.from_dict(config)

    def test_fetchxml_wrong_root_element(self) -> None:
        """FetchXML with non-<fetch> root element fails at config time."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        config = _fetchxml_config(
            fetch_xml='<query><entity name="contact"/></query>',
        )
        with pytest.raises(PluginConfigError, match="root element must be <fetch>"):
            DataverseSourceConfig.from_dict(config)

    def test_fetchxml_valid_xml(self) -> None:
        """Valid FetchXML passes syntax validation."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        cfg = DataverseSourceConfig.from_dict(_fetchxml_config())
        assert cfg.fetch_xml is not None
        assert "<fetch>" in cfg.fetch_xml

    def test_additional_domains_valid(self) -> None:
        """Accept valid additional domain patterns."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        config = _base_config(additional_domains=["*.crm12.dynamics.com"])
        cfg = DataverseSourceConfig.from_dict(config)
        assert cfg.additional_domains == ["*.crm12.dynamics.com"]

    def test_additional_domains_rejects_non_microsoft_tld(self) -> None:
        """Reject additional domain patterns that don't target Microsoft TLDs."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        config = _base_config(additional_domains=["*.evil.example.com"])
        with pytest.raises(PluginConfigError, match="rejected"):
            DataverseSourceConfig.from_dict(config)

    def test_structured_query_with_all_odata_options(self) -> None:
        """Accept structured query with select, filter, orderby, top."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        config = _base_config(
            select=["contactid", "fullname"],
            filter="statecode eq 0",
            orderby="createdon desc",
            top=100,
        )
        cfg = DataverseSourceConfig.from_dict(config)
        assert cfg.select == ["contactid", "fullname"]
        assert cfg.filter == "statecode eq 0"
        assert cfg.orderby == "createdon desc"
        assert cfg.top == 100

    def test_normalize_fields_config_key_rejected(self) -> None:
        """normalize_fields is no longer a valid config key."""
        from elspeth.plugins.infrastructure.config_base import PluginConfigError
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        with pytest.raises(PluginConfigError):
            DataverseSourceConfig.from_dict(_base_config(normalize_fields=True))

    def test_include_formatted_values_defaults_false(self) -> None:
        """include_formatted_values defaults to False."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        cfg = DataverseSourceConfig.from_dict(_base_config())
        assert cfg.include_formatted_values is False

    def test_api_version_defaults_to_v92(self) -> None:
        """api_version defaults to v9.2."""
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        cfg = DataverseSourceConfig.from_dict(_base_config())
        assert cfg.api_version == "v9.2"


# ─────────────────────────────────────────────────────────────────────────
# OData metadata stripping tests
# ─────────────────────────────────────────────────────────────────────────


class TestODataMetadataStripping:
    """Tests for _strip_odata_metadata behavior."""

    def test_strips_odata_fields(self) -> None:
        """@odata.* fields are removed from rows."""
        source = _make_source(_base_config())
        row = {
            "contactid": "abc-123",
            "fullname": "Alice",
            "@odata.etag": 'W/"123"',
            "@odata.context": "https://...",
        }
        cleaned = source._strip_odata_metadata(row)
        assert "contactid" in cleaned
        assert "fullname" in cleaned
        assert "@odata.etag" not in cleaned
        assert "@odata.context" not in cleaned

    def test_strips_microsoft_dynamics_crm_fields(self) -> None:
        """@Microsoft.Dynamics.CRM.* fields are removed."""
        source = _make_source(_base_config())
        row = {
            "contactid": "abc-123",
            "@Microsoft.Dynamics.CRM.totalrecordcount": 42,
        }
        cleaned = source._strip_odata_metadata(row)
        assert "contactid" in cleaned
        assert "@Microsoft.Dynamics.CRM.totalrecordcount" not in cleaned

    def test_formatted_values_excluded_by_default(self) -> None:
        """Formatted value annotations pass through as raw keys when include_formatted_values=False.

        The formatted value suffix is NOT an @odata.* or @Microsoft.Dynamics.CRM.*
        annotation — it lives on the field key itself (e.g., statecode@OData.Community...).
        When include_formatted_values=False, these keys are not extracted into
        __formatted fields but they do pass through as regular keys.
        """
        source = _make_source(_base_config(include_formatted_values=False))
        row = {
            "statecode": 0,
            "statecode@OData.Community.Display.V1.FormattedValue": "Active",
        }
        cleaned = source._strip_odata_metadata(row)
        # The raw annotation key passes through (it doesn't match OData strip patterns)
        assert cleaned["statecode"] == 0
        assert "statecode@OData.Community.Display.V1.FormattedValue" in cleaned
        # No __formatted suffix key is created
        assert "statecode__formatted" not in cleaned

    def test_formatted_values_included_with_suffix(self) -> None:
        """Formatted values get __formatted suffix when include_formatted_values=True."""
        source = _make_source(_base_config(include_formatted_values=True))
        row = {
            "statecode": 0,
            "statecode@OData.Community.Display.V1.FormattedValue": "Active",
        }
        cleaned = source._strip_odata_metadata(row)
        assert cleaned == {"statecode": 0, "statecode__formatted": "Active"}

    def test_formatted_value_collision_detection(self) -> None:
        """Collision detected when both 'field__formatted' and formatted annotation exist."""
        source = _make_source(_base_config(include_formatted_values=True))
        row = {
            "statecode": 0,
            "statecode__formatted": "manually set",
            "statecode@OData.Community.Display.V1.FormattedValue": "Active",
        }
        with pytest.raises(ValueError, match="collision"):
            source._strip_odata_metadata(row)

    def test_multiple_formatted_values(self) -> None:
        """Multiple formatted values are preserved correctly."""
        source = _make_source(_base_config(include_formatted_values=True))
        row = {
            "statecode": 0,
            "statecode@OData.Community.Display.V1.FormattedValue": "Active",
            "statuscode": 1,
            "statuscode@OData.Community.Display.V1.FormattedValue": "Active",
            "@odata.etag": 'W/"123"',
        }
        cleaned = source._strip_odata_metadata(row)
        assert cleaned == {
            "statecode": 0,
            "statecode__formatted": "Active",
            "statuscode": 1,
            "statuscode__formatted": "Active",
        }

    def test_data_fields_preserved(self) -> None:
        """Regular data fields are not stripped."""
        source = _make_source(_base_config())
        row = {
            "contactid": "abc",
            "fullname": "Alice",
            "emailaddress1": "alice@example.com",
            "revenue": 1000.50,
        }
        cleaned = source._strip_odata_metadata(row)
        assert cleaned == row


# ─────────────────────────────────────────────────────────────────────────
# Field normalization tests
# ─────────────────────────────────────────────────────────────────────────


class TestFieldNormalization:
    """Tests for _normalize_row_fields behavior."""

    def test_normalization_always_applies(self) -> None:
        """Field names are always normalized."""
        source = _make_source(_base_config())
        row = {"Contact ID": "abc", "Full Name": "Alice"}
        result = source._normalize_row_fields(row, is_first_row=True)
        # Normalized names should be valid Python identifiers
        for key in result:
            assert key.isidentifier(), f"Key '{key}' is not a valid identifier"

    def test_field_resolution_populated_on_first_row(self) -> None:
        """Field resolution mapping is created on the first row."""
        source = _make_source(_base_config())
        assert source._field_resolution is None
        source._normalize_row_fields({"contactid": "abc"}, is_first_row=True)
        assert source._field_resolution is not None

    def test_field_resolution_reused_on_subsequent_rows(self) -> None:
        """Field resolution mapping is reused (not re-created) for subsequent rows."""
        source = _make_source(_base_config())
        source._normalize_row_fields({"contactid": "abc"}, is_first_row=True)
        resolution1 = source._field_resolution
        source._normalize_row_fields({"contactid": "def"}, is_first_row=False)
        resolution2 = source._field_resolution
        assert resolution1 is resolution2


# ─────────────────────────────────────────────────────────────────────────
# DataverseSource construction and lifecycle tests
# ─────────────────────────────────────────────────────────────────────────


class TestDataverseSourceConstruction:
    """Tests for DataverseSource.__init__ and on_start."""

    def test_construction_structured_query(self) -> None:
        """DataverseSource can be constructed with structured query config."""
        source = _make_source(_base_config())
        assert source.name == "dataverse"
        assert source._entity == "contact"
        assert source._fetch_xml is None

    def test_construction_fetchxml_query(self) -> None:
        """DataverseSource can be constructed with FetchXML config."""
        source = _make_source(_fetchxml_config())
        assert source._entity is None
        assert source._fetch_xml is not None

    def test_on_start_creates_client(self) -> None:
        """on_start() creates a DataverseClient without probing entity metadata."""
        source = _make_source(_base_config())
        assert source._client is None

        lifecycle_ctx = _mock_lifecycle_context()
        mock_client = _DataverseClientFake()

        with (
            patch("azure.identity.ClientSecretCredential", new=_client_secret_credential_factory),
            patch(
                "elspeth.plugins.sources.dataverse.DataverseClient",
                new=_dataverse_client_factory(mock_client),
            ),
        ):
            source.on_start(lifecycle_ctx)

        assert source._client is not None
        mock_client.get_page.assert_not_called()

    def test_additional_domains_stored_as_tuple(self) -> None:
        """additional_domains are stored as a tuple for immutability."""
        source = _make_source(_base_config(additional_domains=["*.crm12.dynamics.com"]))
        assert source._additional_domains == ("*.crm12.dynamics.com",)

    def test_no_additional_domains_gives_empty_tuple(self) -> None:
        """No additional_domains results in an empty tuple."""
        source = _make_source(_base_config())
        assert source._additional_domains == ()

    def test_load_metadata_probe_404_raises_descriptive_error(self) -> None:
        """404 metadata probe is audited and raises a descriptive entity-not-found error."""
        mock_client = _DataverseClientFake()
        mock_client.get_page.side_effect = DataverseClientError(
            "Not Found",
            retryable=False,
            status_code=404,
        )
        source = _make_source_for_start_and_load(
            _base_config(),
            mock_client=mock_client,
        )
        ctx = _mock_source_context()

        with pytest.raises(DataverseClientError, match="Entity 'contact' not found"):
            list(source.load(ctx))

        assert ctx.record_call.call_count == 1
        call_kwargs = ctx.record_call.call_args.kwargs
        assert call_kwargs["status"] == CallStatus.ERROR
        assert call_kwargs["error"]["status_code"] == 404

    def test_load_metadata_probe_403_without_fallback_fails_closed(self) -> None:
        """403 metadata probe is audited and cannot guess an entity-set path."""
        mock_client = _DataverseClientFake(odata_pages=[_make_page([{"contactid": "1", "fullname": "Alice"}])])
        mock_client.get_page.side_effect = DataverseClientError(
            "Forbidden",
            retryable=False,
            status_code=403,
        )
        source = _make_source_for_start_and_load(
            _base_config(),
            mock_client=mock_client,
        )
        ctx = _mock_source_context()

        with pytest.raises(DataverseClientError, match="entity_set_name"):
            list(source.load(ctx))

        assert ctx.record_call.call_count == 1
        metadata_call = ctx.record_call.call_args.kwargs
        assert metadata_call["status"] == CallStatus.ERROR
        assert metadata_call["error"]["status_code"] == 403
        mock_client.paginate_odata.assert_not_called()

    def test_load_metadata_probe_403_uses_explicit_entity_set_fallback(self) -> None:
        """403 metadata probe may use an explicit, validated entity-set identity."""
        mock_client = _DataverseClientFake(odata_pages=[_make_page([{"contactid": "1", "fullname": "Alice"}])])
        mock_client.get_page.side_effect = DataverseClientError(
            "Forbidden",
            retryable=False,
            status_code=403,
        )
        source = _make_source_for_start_and_load(
            _base_config(entity_set_name="contacts"),
            mock_client=mock_client,
        )
        ctx = _mock_source_context()

        rows = list(source.load(ctx))

        assert len(rows) == 1
        assert ctx.record_call.call_count == 2
        assert ctx.record_call.call_args_list[0].kwargs["status"] == CallStatus.ERROR
        assert mock_client.paginate_odata.call_args.args[0].startswith(f"{VALID_ENV_URL}/api/data/v9.2/contacts")

    def test_successful_metadata_conflicting_with_fallback_fails_closed(self) -> None:
        mock_client = _DataverseClientFake(
            metadata_page=_make_metadata_page("contact", entity_set_name="people"),
            odata_pages=[_make_page([{"contactid": "1"}])],
        )
        source = _make_source_for_start_and_load(
            _base_config(entity_set_name="contacts"),
            mock_client=mock_client,
        )
        ctx = _mock_source_context()

        with pytest.raises(DataverseClientError, match="does not match"):
            list(source.load(ctx))

        mock_client.paginate_odata.assert_not_called()
        assert ctx.record_call.call_args.kwargs["status"] == CallStatus.ERROR

    def test_load_metadata_probe_5xx_reraises(self) -> None:
        """5xx metadata probe is audited and re-raises the original error."""
        original_error = DataverseClientError(
            "Internal Server Error",
            retryable=True,
            status_code=500,
        )
        mock_client = _DataverseClientFake()
        mock_client.get_page.side_effect = original_error
        source = _make_source_for_start_and_load(
            _base_config(),
            mock_client=mock_client,
        )
        ctx = _mock_source_context()

        with pytest.raises(DataverseClientError, match="Internal Server Error") as exc_info:
            list(source.load(ctx))

        assert exc_info.value is original_error
        assert ctx.record_call.call_count == 1
        call_kwargs = ctx.record_call.call_args.kwargs
        assert call_kwargs["status"] == CallStatus.ERROR
        assert call_kwargs["error"]["status_code"] == 500

    def test_error_page_call_audit_preserves_request_headers(self) -> None:
        """elspeth-98855f307a: the page-fetch error audit must include the
        fingerprinted request_headers the client preserved on the error, mirroring
        the success path — otherwise replay/verify loses outbound metadata."""
        source = _make_source(_base_config())
        ctx = _mock_source_context()
        err = DataverseClientError(
            "boom",
            retryable=False,
            status_code=500,
            request_url="https://test.crm.dynamics.com/api/data/v9.2/contacts",
            request_headers={"Authorization": "<fingerprint:abc>"},
        )

        source._record_page_call(
            ctx,
            url="https://test.crm.dynamics.com/api/data/v9.2/contacts",
            error=err,
            error_reason="protocol error",
        )

        ctx.record_call.assert_called_once()
        req = ctx.record_call.call_args.kwargs["request_data"]
        assert req["headers"] == {"Authorization": "<fingerprint:abc>"}


# ─────────────────────────────────────────────────────────────────────────
# Build query URL tests
# ─────────────────────────────────────────────────────────────────────────


class TestBuildQueryUrl:
    """Tests for _build_query_url."""

    def test_entity_only(self) -> None:
        """URL with entity only, no query params."""
        source = _make_source(_base_config())
        url = source._build_query_url("contacts")
        assert url == "https://myorg.crm.dynamics.com/api/data/v9.2/contacts"

    def test_with_select(self) -> None:
        """URL includes $select parameter."""
        source = _make_source(_base_config(select=["contactid", "fullname"]))
        url = source._build_query_url("contacts")
        assert "$select=contactid,fullname" in url

    def test_with_filter(self) -> None:
        """URL includes $filter parameter (percent-encoded)."""
        source = _make_source(_base_config(filter="statecode eq 0"))
        url = source._build_query_url("contacts")
        assert "$filter=statecode%20eq%200" in url

    def test_with_orderby(self) -> None:
        """URL includes $orderby parameter (percent-encoded)."""
        source = _make_source(_base_config(orderby="createdon desc"))
        url = source._build_query_url("contacts")
        assert "$orderby=createdon%20desc" in url

    def test_with_top(self) -> None:
        """URL includes $top parameter."""
        source = _make_source(_base_config(top=50))
        url = source._build_query_url("contacts")
        assert "$top=50" in url

    def test_with_all_params(self) -> None:
        """URL includes all OData parameters."""
        source = _make_source(
            _base_config(
                select=["contactid"],
                filter="statecode eq 0",
                orderby="createdon desc",
                top=10,
            )
        )
        url = source._build_query_url("contacts")
        assert "$select=contactid" in url
        assert "$filter=statecode%20eq%200" in url
        assert "$orderby=createdon%20desc" in url
        assert "$top=10" in url

    def test_custom_api_version(self) -> None:
        """URL uses configured API version."""
        source = _make_source(_base_config(api_version="v9.1"))
        url = source._build_query_url("contacts")
        assert "/api/data/v9.1/" in url

    def test_trailing_slash_on_env_url(self) -> None:
        """Trailing slash on environment_url is stripped."""
        source = _make_source(_base_config(environment_url="https://myorg.crm.dynamics.com/"))
        url = source._build_query_url("contacts")
        assert "//api" not in url
        assert "/api/data/" in url


# ─────────────────────────────────────────────────────────────────────────
# load() tests — structured query mode
# ─────────────────────────────────────────────────────────────────────────


class TestDataverseSourceLoadStructured:
    """Tests for load() with structured OData queries."""

    @pytest.mark.parametrize("reason", ["missing", "ambiguous"])
    def test_verify_refuses_metadata_before_credential_or_client(self, reason: str) -> None:
        source = _make_source(_base_config())
        source._client = _DataverseClientFake()

        class _VerifySession:
            mode = RunMode.VERIFY

            def preflight_verify_operation_http_managed_identity(self, **_kwargs: Any) -> None:
                raise AuditIntegrityError(f"source metadata call {reason}")

        lifecycle_ctx = _mock_lifecycle_context()
        source_ctx = _mock_source_context()
        lifecycle_ctx.call_mode_session = source_ctx.call_mode_session = _VerifySession()
        with (
            patch.object(type(source._auth_config), "create_credential", side_effect=AssertionError("credential constructed")),
            patch("elspeth.plugins.sources.dataverse.DataverseClient", side_effect=AssertionError("client constructed")),
            pytest.raises(AuditIntegrityError, match=f"source metadata call {reason}"),
        ):
            source.on_start(lifecycle_ctx)
            list(source.load(source_ctx))
        source_ctx.record_call.assert_not_called()

    def test_verify_records_metadata_and_page_verdicts_in_order(self) -> None:
        source = _make_source(_base_config())
        headers = {
            "Authorization": f"<fingerprint:{'a' * 64}>",
            "Accept": "application/json",
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
        }
        metadata_page = replace(_make_metadata_page("contact"), request_headers=headers)
        data_page = replace(_make_page([{"contactid": "1"}]), request_headers=headers)
        events: list[str] = []

        class _VerifySession:
            mode = RunMode.VERIFY

            def preflight_verify_operation_http_managed_identity(self, **kwargs: Any) -> Any:
                url = kwargs["request_data"]["url"]
                kind = "metadata" if "EntityDefinitions" in url else "page"
                assert kwargs["request_data"]["headers"] == {key: value for key, value in headers.items() if key != "Authorization"}
                events.append(f"preflight:{kind}")
                return SimpleNamespace(source_call_id=f"source-{kind}")

            def admit_verify_operation_http_managed_identity(self, **kwargs: Any) -> str:
                kind = "metadata" if "EntityDefinitions" in kwargs["request_data"]["url"] else "page"
                assert kwargs["source_call_id"] == f"source-{kind}"
                events.append(f"admit:{kind}:{kwargs['current_call_index']}")
                return kwargs["source_call_id"]

            def verify_call(self, **kwargs: Any) -> None:
                assert kwargs["live_status"] is CallStatus.SUCCESS
                events.append(f"verify:{kwargs['current_call_index']}")

        session = _VerifySession()
        lifecycle_ctx = _mock_lifecycle_context()
        source_ctx = _mock_source_context()
        lifecycle_ctx.call_mode_session = source_ctx.call_mode_session = session
        source_ctx.record_call = _CallRecorder(
            side_effect=lambda **_kwargs: SimpleNamespace(
                call_index=source_ctx.record_call.call_count - 1, call_id=f"current-{source_ctx.record_call.call_count}"
            )
        )

        def client_factory(*_args: Any, before_request: Callable[[str], None], **_kwargs: Any) -> _DataverseClientFake:
            assert events == ["preflight:metadata"]
            events.append("client")
            client = _DataverseClientFake(metadata_page=metadata_page)

            def get_metadata(url: str) -> DataversePageResponse:
                before_request(url)
                events.append("dispatch:metadata")
                return metadata_page

            def get_pages(url: str) -> Any:
                before_request(url)
                events.append("dispatch:page")
                yield data_page

            client.get_page.side_effect = get_metadata
            client.paginate_odata.side_effect = get_pages
            return client

        with (
            patch.object(type(source._auth_config), "create_credential", return_value=_CredentialFake()),
            patch("elspeth.plugins.sources.dataverse.DataverseClient", side_effect=client_factory),
        ):
            source.on_start(lifecycle_ctx)
            assert events == []
            rows = list(source.load(source_ctx))
        assert len(rows) == 1
        assert source_ctx.record_call.call_count == 2
        assert events == [
            "preflight:metadata",
            "client",
            "preflight:metadata",
            "dispatch:metadata",
            "admit:metadata:0",
            "verify:0",
            "preflight:page",
            "dispatch:page",
            "admit:page:1",
            "verify:1",
        ]

    @pytest.mark.parametrize("reason", ["missing", "ambiguous"])
    def test_verify_refuses_page_before_dispatch(self, reason: str) -> None:
        source = _make_source(_base_config())
        metadata_page = replace(
            _make_metadata_page("contact"),
            request_headers={
                "Authorization": f"<fingerprint:{'a' * 64}>",
                "Accept": "application/json",
                "OData-MaxVersion": "4.0",
                "OData-Version": "4.0",
            },
        )
        events: list[str] = []

        class _VerifySession:
            mode = RunMode.VERIFY

            def preflight_verify_operation_http_managed_identity(self, **kwargs: Any) -> Any:
                if "EntityDefinitions" not in kwargs["request_data"]["url"]:
                    raise AuditIntegrityError(f"source page call {reason}")
                events.append("metadata preflight")
                return SimpleNamespace(source_call_id="source-metadata")

            def admit_verify_operation_http_managed_identity(self, **_kwargs: Any) -> str:
                return "source-metadata"

            def verify_call(self, **_kwargs: Any) -> None:
                events.append("metadata verdict")

        lifecycle_ctx = _mock_lifecycle_context()
        source_ctx = _mock_source_context()
        lifecycle_ctx.call_mode_session = source_ctx.call_mode_session = _VerifySession()
        source_ctx.record_call = _CallRecorder(return_value=SimpleNamespace(call_index=0, call_id="current-metadata"))

        def client_factory(*_args: Any, before_request: Callable[[str], None], **_kwargs: Any) -> _DataverseClientFake:
            client = _DataverseClientFake(metadata_page=metadata_page)

            def get_metadata(url: str) -> DataversePageResponse:
                before_request(url)
                return metadata_page

            def get_pages(url: str) -> Any:
                before_request(url)
                events.append("page dispatched")
                yield _make_page([{"contactid": "1"}])

            client.get_page.side_effect = get_metadata
            client.paginate_odata.side_effect = get_pages
            return client

        with (
            patch.object(type(source._auth_config), "create_credential", return_value=_CredentialFake()),
            patch("elspeth.plugins.sources.dataverse.DataverseClient", side_effect=client_factory),
            pytest.raises(AuditIntegrityError, match=f"source page call {reason}"),
        ):
            source.on_start(lifecycle_ctx)
            list(source.load(source_ctx))
        assert source_ctx.record_call.call_count == 1
        assert events == ["metadata preflight", "metadata preflight", "metadata verdict"]

    def test_verify_persists_metadata_error_verdict(self) -> None:
        source = _make_source(_base_config())
        verdicts: list[Any] = []
        headers = {
            "Authorization": f"<fingerprint:{'a' * 64}>",
            "Accept": "application/json",
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
        }

        class _VerifySession:
            mode = RunMode.VERIFY

            def preflight_verify_operation_http_managed_identity(self, **_kwargs: Any) -> Any:
                return SimpleNamespace(source_call_id="source-metadata-error")

            def admit_verify_operation_http_managed_identity(self, **kwargs: Any) -> str:
                assert kwargs["source_call_id"] == "source-metadata-error"
                return "source-metadata-error"

            def verify_call(self, **kwargs: Any) -> None:
                verdicts.append(kwargs)

        lifecycle_ctx = _mock_lifecycle_context()
        source_ctx = _mock_source_context()
        lifecycle_ctx.call_mode_session = source_ctx.call_mode_session = _VerifySession()
        source_ctx.record_call = _CallRecorder(return_value=SimpleNamespace(call_index=0, call_id="current-error"))

        def client_factory(*_args: Any, before_request: Callable[[str], None], **_kwargs: Any) -> _DataverseClientFake:
            client = _DataverseClientFake()

            def metadata_error(url: str) -> None:
                before_request(url)
                raise DataverseClientError(
                    "metadata server error",
                    retryable=True,
                    status_code=500,
                    request_url=url,
                    request_headers=headers,
                )

            client.get_page.side_effect = metadata_error
            return client

        with (
            patch.object(type(source._auth_config), "create_credential", return_value=_CredentialFake()),
            patch("elspeth.plugins.sources.dataverse.DataverseClient", side_effect=client_factory),
            pytest.raises(DataverseClientError, match="metadata server error"),
        ):
            source.on_start(lifecycle_ctx)
            list(source.load(source_ctx))
        assert source_ctx.record_call.call_count == 1
        assert verdicts[0]["live_status"] is CallStatus.ERROR
        assert verdicts[0]["current_call_index"] == 0
        assert verdicts[0]["live_error_data"]["status_code"] == 500

    def test_structured_load_resolves_logical_name_to_entity_set_before_pagination(self) -> None:
        metadata_page = _make_metadata_page("contact", entity_set_name="contacts")
        mock_client = _DataverseClientFake(
            metadata_page=metadata_page,
            odata_pages=[_make_page([{"contactid": "1"}])],
        )
        source = _make_source_for_start_and_load(
            _base_config(
                select=["contactid", "fullname"],
                filter="statecode eq 0",
                orderby="createdon desc",
                top=25,
            ),
            mock_client=mock_client,
        )

        list(source.load(_mock_source_context()))

        metadata_url = mock_client.get_page.call_args.args[0]
        assert "EntityDefinitions(LogicalName='contact')" in metadata_url
        assert metadata_url.endswith("?$select=LogicalName,EntitySetName")
        data_url = mock_client.paginate_odata.call_args.args[0]
        assert data_url == (
            f"{VALID_ENV_URL}/api/data/v9.2/contacts"
            "?$select=contactid,fullname&$filter=statecode%20eq%200&$orderby=createdon%20desc&$top=25"
        )

    def test_metadata_error_without_request_url_does_not_invent_audit_url(self) -> None:
        mock_client = _DataverseClientFake()
        mock_client.get_page.side_effect = DataverseClientError(
            "metadata request rejected before URL binding",
            retryable=False,
            error_category="protocol_error",
        )
        source = _make_source_for_start_and_load(_base_config(), mock_client=mock_client)
        ctx = _mock_source_context()

        with pytest.raises(DataverseClientError, match="before URL binding"):
            next(source.load(ctx))

        mock_client.paginate_odata.assert_not_called()
        ctx.record_call.assert_called_once()
        assert ctx.record_call.call_args.kwargs["request_data"]["url"] is None

    @pytest.mark.parametrize(
        ("metadata_rows", "message", "expected_category"),
        [
            ([], "exactly one", "metadata_identity_invalid"),
            (
                [
                    {"LogicalName": "contact", "EntitySetName": "contacts"},
                    {"LogicalName": "contact", "EntitySetName": "people"},
                ],
                "exactly one",
                "metadata_identity_invalid",
            ),
            ([{"LogicalName": "contact"}], "EntitySetName", "metadata_identity_invalid"),
            ([{"LogicalName": "contact", "EntitySetName": ""}], "EntitySetName", "metadata_identity_invalid"),
            ([{"LogicalName": "contact", "EntitySetName": "   "}], "EntitySetName", "metadata_identity_invalid"),
            ([{"LogicalName": "contact", "EntitySetName": None}], "EntitySetName", "metadata_identity_invalid"),
            ([{"LogicalName": "contact", "EntitySetName": 123}], "EntitySetName", "metadata_identity_invalid"),
            ([{"LogicalName": "account", "EntitySetName": "contacts"}], "LogicalName", "metadata_identity_conflict"),
            ([{"EntitySetName": "contacts"}], "LogicalName", "metadata_identity_invalid"),
            ([{"LogicalName": "", "EntitySetName": "contacts"}], "LogicalName", "metadata_identity_invalid"),
            ([{"LogicalName": "   ", "EntitySetName": "contacts"}], "LogicalName", "metadata_identity_invalid"),
            ([{"LogicalName": None, "EntitySetName": "contacts"}], "LogicalName", "metadata_identity_invalid"),
            ([{"LogicalName": 123, "EntitySetName": "contacts"}], "LogicalName", "metadata_identity_invalid"),
            ([{"LogicalName": "contact/path", "EntitySetName": "contacts"}], "LogicalName", "metadata_identity_invalid"),
            ([{"LogicalName": "contact?query", "EntitySetName": "contacts"}], "LogicalName", "metadata_identity_invalid"),
            ([{"LogicalName": "contact#fragment", "EntitySetName": "contacts"}], "LogicalName", "metadata_identity_invalid"),
            ([{"LogicalName": "contact name", "EntitySetName": "contacts"}], "LogicalName", "metadata_identity_invalid"),
            ([{"LogicalName": "contact\x00name", "EntitySetName": "contacts"}], "LogicalName", "metadata_identity_invalid"),
            ([{"LogicalName": "Contact", "EntitySetName": "contacts"}], "LogicalName", "metadata_identity_invalid"),
            ([{"LogicalName": "contact_Name", "EntitySetName": "contacts"}], "LogicalName", "metadata_identity_invalid"),
            ([{"LogicalName": "contact", "EntitySetName": "contacts/path"}], "EntitySetName", "metadata_identity_invalid"),
            ([{"LogicalName": "contact", "EntitySetName": "contacts?query"}], "EntitySetName", "metadata_identity_invalid"),
            ([{"LogicalName": "contact", "EntitySetName": "contacts#fragment"}], "EntitySetName", "metadata_identity_invalid"),
            ([{"LogicalName": "contact", "EntitySetName": "contact sets"}], "EntitySetName", "metadata_identity_invalid"),
            ([{"LogicalName": "contact", "EntitySetName": "contacts\x00name"}], "EntitySetName", "metadata_identity_invalid"),
        ],
        ids=[
            "zero-rows",
            "multiple-rows",
            "missing-entity-set",
            "blank-entity-set",
            "whitespace-entity-set",
            "none-entity-set",
            "non-string-entity-set",
            "mismatched-logical-name",
            "missing-logical-name",
            "blank-logical-name",
            "whitespace-logical-name",
            "none-logical-name",
            "non-string-logical-name",
            "logical-name-path-delimiter",
            "logical-name-query-delimiter",
            "logical-name-fragment-delimiter",
            "logical-name-space-delimiter",
            "logical-name-control-character",
            "logical-name-uppercase-leading",
            "logical-name-uppercase-interior",
            "entity-set-path-delimiter",
            "entity-set-query-delimiter",
            "entity-set-fragment-delimiter",
            "entity-set-space-delimiter",
            "entity-set-control-character",
        ],
    )
    def test_invalid_metadata_identity_fails_before_pagination(
        self,
        metadata_rows: list[dict[str, Any]],
        message: str,
        expected_category: str,
    ) -> None:
        metadata_page = _make_metadata_page("contact", rows=metadata_rows)
        mock_client = _DataverseClientFake(
            metadata_page=metadata_page,
            odata_pages=[_make_page([{"contactid": "1"}])],
        )
        source = _make_source_for_start_and_load(_base_config(), mock_client=mock_client)
        ctx = _mock_source_context()

        with pytest.raises(DataverseClientError, match=message):
            list(source.load(ctx))

        mock_client.paginate_odata.assert_not_called()
        assert ctx.record_call.call_count == 1
        audit_call = ctx.record_call.call_args.kwargs
        assert audit_call["status"] == CallStatus.ERROR
        assert audit_call["error"]["reason"] == expected_category

    def test_load_single_page(self) -> None:
        """Load yields valid rows from a single page."""
        pages = [
            _make_page(
                [
                    {"contactid": "1", "fullname": "Alice"},
                    {"contactid": "2", "fullname": "Bob"},
                ]
            ),
        ]
        source = _make_source_for_load(pages, _base_config())
        ctx = _mock_source_context()

        rows = list(source.load(ctx))
        assert len(rows) == 2
        assert all(not r.is_quarantined for r in rows)

    def test_load_multiple_pages(self) -> None:
        """Load yields rows from multiple pages."""
        pages = [
            _make_page(
                [{"contactid": "1", "fullname": "Alice"}],
                next_link="https://myorg.crm.dynamics.com/api/data/v9.2/contacts?$skiptoken=1",
            ),
            _make_page([{"contactid": "2", "fullname": "Bob"}]),
        ]
        source = _make_source_for_load(pages, _base_config())
        ctx = _mock_source_context()

        rows = list(source.load(ctx))
        assert len(rows) == 2

    def test_load_strips_odata_metadata(self) -> None:
        """OData annotation fields are stripped before yielding."""
        pages = [
            _make_page(
                [
                    {
                        "contactid": "1",
                        "fullname": "Alice",
                        "@odata.etag": 'W/"123"',
                        "@Microsoft.Dynamics.CRM.lookuplogicalname": "contact",
                    }
                ]
            ),
        ]
        source = _make_source_for_load(pages, _base_config())
        ctx = _mock_source_context()

        rows = list(source.load(ctx))
        assert len(rows) == 1
        row_data = rows[0].row
        assert "contactid" in row_data
        assert "@odata.etag" not in row_data
        assert "@Microsoft.Dynamics.CRM.lookuplogicalname" not in row_data

    def test_load_records_page_calls(self) -> None:
        """Structured load records the metadata probe plus each fetched page."""
        pages = [
            _make_page(
                [{"contactid": "1"}],
                next_link="https://myorg.crm.dynamics.com/next",
            ),
            _make_page([{"contactid": "2"}]),
        ]
        source = _make_source_for_load(pages, _base_config())
        ctx = _mock_source_context()

        list(source.load(ctx))
        assert ctx.record_call.call_count == 3

    def test_load_records_entity_metadata_probe_before_structured_page_fetch(self) -> None:
        """Structured load records the startup entity metadata probe inside load()."""
        metadata_url = f"{VALID_ENV_URL}/api/data/v9.2/EntityDefinitions(LogicalName='contact')?$select=LogicalName,EntitySetName"
        metadata_page = DataversePageResponse(
            status_code=200,
            rows=[{"LogicalName": "contact", "EntitySetName": "contacts"}],
            latency_ms=5.0,
            headers={"content-type": "application/json"},
            request_headers={"Authorization": "<fingerprint:test-fake>"},
            request_url=metadata_url,
            next_link=None,
            paging_cookie=None,
            more_records=None,
        )
        data_page = _make_page([{"contactid": "1", "fullname": "Alice"}])

        mock_client = _DataverseClientFake(
            metadata_page=metadata_page,
            odata_pages=[data_page],
        )

        source = _make_source_for_start_and_load(
            _base_config(),
            mock_client=mock_client,
        )
        ctx = _mock_source_context()

        rows = list(source.load(ctx))

        assert len(rows) == 1
        assert ctx.record_call.call_count == 2
        assert "EntityDefinitions(LogicalName='contact')" in ctx.record_call.call_args_list[0].kwargs["request_data"]["url"]

    def test_load_quarantines_on_formatted_value_collision(self) -> None:
        """Formatted value collision quarantines the row."""
        pages = [
            _make_page(
                [
                    {
                        "statecode": 0,
                        "statecode__formatted": "existing",
                        "statecode@OData.Community.Display.V1.FormattedValue": "Active",
                    }
                ]
            ),
        ]
        source = _make_source_for_load(
            pages,
            _base_config(include_formatted_values=True),
        )
        ctx = _mock_source_context()

        rows = list(source.load(ctx))
        assert len(rows) == 1
        assert rows[0].is_quarantined
        assert "collision" in rows[0].quarantine_error.lower()
        ctx.record_validation_error.assert_called_once()
        call_kwargs = ctx.record_validation_error.call_args.kwargs
        assert call_kwargs["schema_mode"] == "odata_strip"
        assert "collision" in call_kwargs["error"].lower()

    def test_load_quarantines_an_unsafe_integer_value_free(self) -> None:
        """H1 (lane 5887): an OData integer outside ±(2**53-1) is quarantined, not passed as valid."""
        pages = [_make_page([{"contactid": "c1", "n": 9_007_199_254_740_993}, {"contactid": "c2", "n": 5}])]
        source = _make_source_for_load(pages, _base_config())
        ctx = _mock_source_context()

        rows = list(source.load(ctx))

        assert [row.is_quarantined for row in rows] == [True, False]
        assert rows[0].quarantine_error == "1 validation error: <root>: [non_canonical_number]"
        assert "9007199254740993" not in ctx.record_validation_error.call_args.kwargs["error"]
        assert rows[1].row["n"] == 5

    def test_load_discard_does_not_yield_quarantined(self) -> None:
        """When on_validation_failure='discard', quarantined rows are not yielded."""
        pages = [
            _make_page(
                [
                    {
                        "statecode": 0,
                        "statecode__formatted": "existing",
                        "statecode@OData.Community.Display.V1.FormattedValue": "Active",
                    }
                ]
            ),
        ]
        source = _make_source_for_load(
            pages,
            _base_config(
                include_formatted_values=True,
                on_validation_failure="discard",
            ),
        )
        ctx = _mock_source_context()

        rows = list(source.load(ctx))
        assert len(rows) == 0
        # Validation error is still recorded
        ctx.record_validation_error.assert_called_once()

    def test_load_schema_validation_failure_quarantines(self) -> None:
        """Rows failing schema validation are quarantined, the failure named by its declared field."""
        pages = [_make_page([{"contactid": "1"}])]
        source = _make_source_for_load(pages, _base_config(schema=_REQUIRED_FIELD_SCHEMA))
        ctx = _mock_source_context()

        rows = list(source.load(ctx))
        assert len(rows) == 1
        assert rows[0].is_quarantined
        assert rows[0].quarantine_destination == QUARANTINE_SINK
        assert rows[0].quarantine_error == "1 validation error: required_field: [missing]"
        ctx.record_validation_error.assert_called_once()

    def test_load_schema_validation_failure_discard(self) -> None:
        """Schema validation failure with discard yields no rows."""
        pages = [_make_page([{"contactid": "1"}])]
        source = _make_source_for_load(pages, _base_config(schema=_REQUIRED_FIELD_SCHEMA, on_validation_failure="discard"))
        ctx = _mock_source_context()

        rows = list(source.load(ctx))
        assert len(rows) == 0

    def test_load_client_error_propagates(self) -> None:
        """DataverseClientError during pagination propagates directly."""
        source = _make_source_for_load([], _base_config())
        # Override client to raise
        source._client.paginate_odata.side_effect = DataverseClientError("Server error", retryable=True, status_code=500, latency_ms=100.0)

        ctx = _mock_source_context()
        with pytest.raises(DataverseClientError, match="Server error"):
            list(source.load(ctx))

    def test_load_client_error_records_audit(self) -> None:
        """Pagination errors are audited after the structured metadata probe succeeds."""
        source = _make_source_for_load([], _base_config())
        error = DataverseClientError("Server error", retryable=True, status_code=500, latency_ms=100.0)
        source._client.paginate_odata.side_effect = error

        ctx = _mock_source_context()
        with pytest.raises(DataverseClientError):
            list(source.load(ctx))

        assert ctx.record_call.call_count == 2
        call_kwargs = ctx.record_call.call_args_list[-1].kwargs
        assert call_kwargs["status"] == CallStatus.ERROR
        assert call_kwargs["error"]["status_code"] == 500

    def test_load_empty_pages(self) -> None:
        """Empty pages produce no rows."""
        pages = [_make_page([])]
        source = _make_source_for_load(pages, _base_config())
        ctx = _mock_source_context()

        rows = list(source.load(ctx))
        assert len(rows) == 0

    def test_load_valid_and_quarantined_mixed(self) -> None:
        """Valid and quarantined rows can be interleaved."""
        pages = [
            _make_page(
                [
                    {"contactid": "1", "fullname": "Alice"},
                    {"contactid": "2"},  # Will fail validation
                    {"contactid": "3", "fullname": "Charlie"},
                ]
            ),
        ]
        source = _make_source_for_load(pages, _base_config(schema={"mode": "fixed", "fields": ["contactid: str", "fullname: str"]}))
        ctx = _mock_source_context()

        rows = list(source.load(ctx))
        valid_rows = [r for r in rows if not r.is_quarantined]
        quarantined_rows = [r for r in rows if r.is_quarantined]
        assert [r.row["contactid"] for r in valid_rows] == ["1", "3"]
        assert [r.row["contactid"] for r in quarantined_rows] == ["2"]
        assert quarantined_rows[0].quarantine_error == "1 validation error: fullname: [missing]"


# ─────────────────────────────────────────────────────────────────────────
# load() tests — FetchXML mode
# ─────────────────────────────────────────────────────────────────────────


class TestDataverseSourceLoadFetchXML:
    """Tests for load() with FetchXML queries."""

    def test_fetchxml_load_single_page(self) -> None:
        """FetchXML load yields rows from a single page."""
        pages = [
            _make_page(
                [
                    {"contactid": "1", "fullname": "Alice"},
                ]
            ),
        ]
        source = _make_source_for_load(pages, _fetchxml_config())
        ctx = _mock_source_context()

        rows = list(source.load(ctx))
        assert len(rows) == 1
        assert not rows[0].is_quarantined

    def test_fetchxml_missing_entity_element(self) -> None:
        """FetchXML without <entity> element raises RuntimeError."""
        source = _make_source_for_load(
            [],
            _fetchxml_config(
                fetch_xml="<fetch><all-attributes/></fetch>",
            ),
        )
        ctx = _mock_source_context()

        with pytest.raises(RuntimeError, match="missing <entity> element"):
            list(source.load(ctx))

    def test_fetchxml_entity_missing_name_attribute(self) -> None:
        """FetchXML <entity> without name attribute raises RuntimeError."""
        source = _make_source_for_load(
            [],
            _fetchxml_config(
                fetch_xml="<fetch><entity><attribute name='fullname'/></entity></fetch>",
            ),
        )
        ctx = _mock_source_context()

        with pytest.raises(RuntimeError, match="missing 'name' attribute"):
            list(source.load(ctx))

    def test_fetchxml_uses_paginate_fetchxml(self) -> None:
        """FetchXML resolves its logical name and preserves the original XML."""
        original_xml = '<fetch><entity name="contact"><attribute name="fullname"/></entity></fetch>'
        mock_client = _DataverseClientFake(
            metadata_page=_make_metadata_page("contact", entity_set_name="contacts"),
            fetchxml_pages=[_make_page([{"contactid": "1"}])],
        )
        source = _make_source_for_start_and_load(
            _fetchxml_config(fetch_xml=original_xml),
            mock_client=mock_client,
        )
        ctx = _mock_source_context()

        list(source.load(ctx))
        assert "EntityDefinitions(LogicalName='contact')" in mock_client.get_page.call_args.args[0]
        assert mock_client.get_page.call_args.args[0].endswith("?$select=LogicalName,EntitySetName")
        source._client.paginate_fetchxml.assert_called_once()
        assert source._client.paginate_fetchxml.call_args.args == ("contacts", original_xml)
        source._client.paginate_odata.assert_not_called()

    def test_fetchxml_pre_request_ssrf_rejection_audits_full_candidate_url(self) -> None:
        """The composed source/client audit records the rejected FetchXML candidate."""
        original_xml = '<fetch><entity name="contact"><attribute name="fullname"/></entity></fetch>'
        source = _make_source(_fetchxml_config(fetch_xml=original_xml))
        client = DataverseClient(
            environment_url=VALID_ENV_URL,
            credential=_CredentialFake(),  # type: ignore[arg-type]  # test fake
        )
        client._client.close()
        transport_requests: list[httpx.Request] = []

        def handle_request(request: httpx.Request) -> httpx.Response:
            transport_requests.append(request)
            return httpx.Response(
                status_code=200,
                json={"value": [{"LogicalName": "contact", "EntitySetName": "contacts"}]},
            )

        client._client = httpx.Client(transport=httpx.MockTransport(handle_request), timeout=30.0)
        source._client = client
        ctx = _mock_source_context()
        serialized_xml = '<fetch><entity name="contact"><attribute name="fullname" /></entity></fetch>'
        expected_url = f"{VALID_ENV_URL}/api/data/v9.2/contacts?fetchXml={urllib.parse.quote(serialized_xml)}"

        def validate_candidate(url: str, **_kwargs: Any) -> SSRFSafeRequest:
            if "fetchXml=" in url:
                raise SSRFBlockedError("candidate rejected", kind="blocked_range")
            return _make_ssrf_safe(url)

        try:
            with (
                patch(
                    "elspeth.plugins.infrastructure.clients.dataverse.validate_url_for_ssrf",
                    side_effect=validate_candidate,
                ),
                pytest.raises(DataverseClientError) as exc_info,
            ):
                next(source.load(ctx))
        finally:
            client.close()

        error = exc_info.value
        assert error.error_category == "ssrf_rejected"
        assert error.request_url == expected_url
        assert len(transport_requests) == 1
        assert ctx.record_call.call_count == 2
        audit_call = ctx.record_call.call_args.kwargs
        assert audit_call["status"] == CallStatus.ERROR
        # Persisted copy rides fingerprint_url (elspeth-3f583950c1); the full
        # candidate URL survives because fetchXml is not a sensitive param.
        assert audit_call["request_data"]["url"] == fingerprint_url(expected_url)
        audit_headers = audit_call["request_data"]["headers"]
        assert audit_headers["Accept"] == "application/json"
        auth_value = audit_headers.get("Authorization")
        if auth_value is not None:
            assert auth_value.startswith("<fingerprint:")
        assert audit_call["error"]["reason"] == "ssrf_rejected"

    @pytest.mark.parametrize(
        ("guard", "expected_reason", "expected_success_calls"),
        [
            ("odata_empty_guard", "empty_page_guard", 4),
            ("fetchxml_missing_morerecords", "protocol_violation", 2),
            ("fetchxml_missing_cookie", "protocol_violation", 2),
        ],
    )
    def test_post_response_pagination_guard_audits_causal_page_context(
        self,
        guard: str,
        expected_reason: str,
        expected_success_calls: int,
    ) -> None:
        metadata_body = {"value": [{"LogicalName": "contact", "EntitySetName": "contacts"}]}
        if guard == "odata_empty_guard":
            config = _base_config()
            data_bodies = [
                {"value": [], "@odata.nextLink": f"{VALID_ENV_URL}/api/data/v9.2/contacts?page=2"},
                {"value": [], "@odata.nextLink": f"{VALID_ENV_URL}/api/data/v9.2/contacts?page=3"},
                {"value": [], "@odata.nextLink": f"{VALID_ENV_URL}/api/data/v9.2/contacts?page=4"},
            ]
        elif guard == "fetchxml_missing_morerecords":
            config = _fetchxml_config()
            data_bodies = [{"value": []}]
        else:
            config = _fetchxml_config()
            data_bodies = [{"value": [], "@Microsoft.Dynamics.CRM.morerecords": True}]

        response_bodies = iter([metadata_body, *data_bodies])

        def handle_request(_request: httpx.Request) -> httpx.Response:
            return httpx.Response(status_code=200, json=next(response_bodies))

        source = _make_source(config)
        client = DataverseClient(
            environment_url=VALID_ENV_URL,
            credential=_CredentialFake(),  # type: ignore[arg-type]  # test fake
        )
        client._client.close()
        client._client = httpx.Client(transport=httpx.MockTransport(handle_request), timeout=30.0)
        source._client = client
        ctx = _mock_source_context()

        try:
            with (
                patch(
                    "elspeth.plugins.infrastructure.clients.dataverse.validate_url_for_ssrf",
                    side_effect=lambda url, **_kwargs: _make_ssrf_safe(url),
                ),
                pytest.raises(DataverseClientError),
            ):
                next(source.load(ctx))
        finally:
            client.close()

        assert ctx.record_call.call_count == expected_success_calls + 1
        causal_page_audit = ctx.record_call.call_args_list[-2].kwargs
        error_audit = ctx.record_call.call_args_list[-1].kwargs
        assert causal_page_audit["status"] == CallStatus.SUCCESS
        assert causal_page_audit["response_data"]["row_count"] == 0
        assert error_audit["status"] == CallStatus.ERROR
        assert error_audit["request_data"] == causal_page_audit["request_data"]
        assert error_audit["error"]["reason"] == expected_reason
        assert error_audit["error"]["status_code"] == causal_page_audit["response_data"]["status_code"]
        assert error_audit["latency_ms"] == causal_page_audit["latency_ms"]


# ─────────────────────────────────────────────────────────────────────────
# Schema contract locking tests
# ─────────────────────────────────────────────────────────────────────────


class TestSchemaContractLocking:
    """Tests for schema contract locking behavior during load()."""

    @pytest.mark.parametrize("on_validation_failure", ["quarantine", "discard"])
    def test_first_row_contract_field_cap_is_a_counted_validation_failure(
        self,
        monkeypatch: pytest.MonkeyPatch,
        on_validation_failure: str,
    ) -> None:
        """An over-wide first row must follow Dataverse row-failure policy."""
        import elspeth.contracts.contract_builder as contract_builder

        monkeypatch.setattr(contract_builder, "_MAX_INFERRED_CONTRACT_FIELDS", 1)
        pages = [_make_page([{"contactid": "1", "fullname": "Alice"}])]
        source = _make_source_for_load(
            pages,
            _base_config(
                schema={"mode": "observed"},
                on_validation_failure=on_validation_failure,
            ),
        )
        ctx = _mock_source_context()

        rows = list(source.load(ctx))

        if on_validation_failure == "quarantine":
            assert len(rows) == 1
            assert rows[0].is_quarantined is True
            assert rows[0].quarantine_destination == "quarantine"
        else:
            assert rows == []
        assert source._first_valid_row_processed is False
        assert source._quarantine_count == 1
        ctx.record_validation_error.assert_called_once()
        error_call = ctx.record_validation_error.call_args.kwargs
        assert error_call["destination"] == on_validation_failure
        assert "exceeds maximum inferred schema fields" in error_call["error"]
        assert source.get_field_resolution() is None

    @pytest.mark.parametrize("on_validation_failure", ["quarantine", "discard"])
    def test_sparse_contract_field_cap_is_a_counted_validation_failure(
        self,
        monkeypatch: pytest.MonkeyPatch,
        on_validation_failure: str,
    ) -> None:
        """A later sparse field beyond the cap must be counted and routed."""
        import elspeth.contracts.contract_builder as contract_builder

        monkeypatch.setattr(contract_builder, "_MAX_INFERRED_CONTRACT_FIELDS", 1)
        pages = [_make_page([{"contactid": "1"}, {"contactid": "2", "fullname": "Alice"}])]
        source = _make_source_for_load(
            pages,
            _base_config(
                schema={"mode": "observed"},
                on_validation_failure=on_validation_failure,
            ),
        )
        ctx = _mock_source_context()

        rows = list(source.load(ctx))

        assert rows[0].is_quarantined is False
        if on_validation_failure == "quarantine":
            assert len(rows) == 2
            assert rows[1].is_quarantined is True
            assert rows[1].quarantine_destination == "quarantine"
        else:
            assert len(rows) == 1
        assert source._first_valid_row_processed is True
        assert source._quarantine_count == 1
        resolution = source.get_field_resolution()
        assert resolution is not None
        assert resolution[0] == {"contactid": "contactid"}
        ctx.record_validation_error.assert_called_once()
        error_call = ctx.record_validation_error.call_args.kwargs
        assert error_call["destination"] == on_validation_failure
        assert "exceeds maximum inferred schema fields" in error_call["error"]

    def test_contract_locked_after_first_valid_row(self) -> None:
        """Contract builder processes first valid row and sets the flag."""
        pages = [_make_page([{"contactid": "1", "fullname": "Alice"}])]
        source = _make_source_for_load(pages, _base_config())
        assert source._contract_builder is not None

        ctx = _mock_source_context()
        rows = list(source.load(ctx))

        assert len(rows) == 1
        assert source._first_valid_row_processed is True

    def test_contract_flag_set_on_first_row_only(self) -> None:
        """_first_valid_row_processed is set on first valid row, not re-triggered."""
        pages = [
            _make_page(
                [
                    {"contactid": "1", "fullname": "Alice"},
                    {"contactid": "2", "fullname": "Bob"},
                ]
            )
        ]
        source = _make_source_for_load(pages, _base_config())
        ctx = _mock_source_context()

        rows = list(source.load(ctx))
        assert len(rows) == 2
        # Flag was set on the first row
        assert source._first_valid_row_processed is True

    def test_schema_lock_scoping_is_instance_level(self) -> None:
        """_first_valid_row_processed is instance-level, not reset per page.

        The flag is set on the first valid row of the first page and
        remains True across subsequent pages.
        """
        pages = [
            _make_page(
                [{"contactid": "1", "fullname": "Alice"}],
                next_link="https://myorg.crm.dynamics.com/next",
            ),
            _make_page([{"contactid": "2", "fullname": "Bob"}]),
        ]
        source = _make_source_for_load(pages, _base_config())
        ctx = _mock_source_context()

        rows = list(source.load(ctx))
        assert len(rows) == 2
        # Flag set on first page, first row — stays True through second page
        assert source._first_valid_row_processed is True

    def test_contract_force_locked_when_no_valid_rows(self) -> None:
        """Contract is force-locked when load() yields no valid rows."""
        pages = [_make_page([])]
        source = _make_source_for_load(pages, _base_config())
        ctx = _mock_source_context()

        list(source.load(ctx))
        assert source._first_valid_row_processed is False
        # Contract should have been set on source (via set_schema_contract)
        # even though no valid rows were processed
        contract = source.get_schema_contract()
        assert contract is not None

    def test_first_valid_row_flag_resets_per_load_call(self) -> None:
        """_first_valid_row_processed resets at the start of each load() call."""
        pages = [_make_page([{"contactid": "1"}])]
        source = _make_source_for_load(pages, _base_config())
        ctx = _mock_source_context()

        # First load
        list(source.load(ctx))
        assert source._first_valid_row_processed is True

        # The flag is reset inside load() (line 450)
        source._client.paginate_odata.return_value = iter([_make_page([{"contactid": "2"}])])
        list(source.load(ctx))
        # Second load resets the flag, then processes and sets it again
        assert source._first_valid_row_processed is True

    def test_valid_rows_carry_contract(self) -> None:
        """Each valid SourceRow carries the schema contract."""
        pages = [_make_page([{"contactid": "1", "fullname": "Alice"}])]
        source = _make_source_for_load(pages, _base_config())
        ctx = _mock_source_context()

        rows = list(source.load(ctx))
        assert len(rows) == 1
        assert rows[0].contract is not None

    def test_fetchxml_sparse_attributes_are_added_to_emitted_row_contract(self) -> None:
        """Later sparse Dataverse attributes must stay under schema-contract custody."""
        from elspeth.plugins.sources.dataverse import DataverseSource

        pages = [_make_page([{"a": 1}, {"a": 2, "b": "new"}])]

        source = DataverseSource(_fetchxml_config(schema={"mode": "observed"}))

        source._client = _DataverseClientFake(fetchxml_pages=pages)

        rows = list(source.load(_mock_source_context()))

        assert len(rows) == 2
        assert rows[0].is_quarantined is False
        assert rows[1].is_quarantined is False
        assert rows[1].row == {"a": 2, "b": "new"}

        resolution = source.get_field_resolution()
        assert resolution is not None
        mapping, _version = resolution
        assert mapping == {"a": "a", "b": "b"}

        second_contract = rows[1].contract
        assert second_contract is not None
        assert {field.normalized_name for field in second_contract.fields} == {"a", "b"}
        assert second_contract.get_field("b").original_name == "b"


# ─────────────────────────────────────────────────────────────────────────
# get_field_resolution tests
# ─────────────────────────────────────────────────────────────────────────


class TestGetFieldResolution:
    """Tests for get_field_resolution()."""

    def test_returns_none_before_load(self) -> None:
        """get_field_resolution returns None before any rows are processed."""
        source = _make_source(_base_config())
        assert source.get_field_resolution() is None

    def test_returns_mapping_after_normalization(self) -> None:
        """get_field_resolution returns the mapping and version after rows are processed."""
        source = _make_source(_base_config())
        source._normalize_row_fields({"contactid": "abc"}, is_first_row=True)

        result = source.get_field_resolution()
        assert result is not None
        mapping, version = result
        assert isinstance(mapping, Mapping)
        assert version is not None
        assert isinstance(version, str)

    def test_returns_mapping_with_already_clean_names(self) -> None:
        """get_field_resolution works when field names are already clean identifiers."""
        source = _make_source(_base_config())
        source._normalize_row_fields({"contactid": "abc"}, is_first_row=True)

        result = source.get_field_resolution()
        assert result is not None
        mapping, _ = result
        assert mapping["contactid"] == "contactid"


# ─────────────────────────────────────────────────────────────────────────
# close() tests
# ─────────────────────────────────────────────────────────────────────────


class TestDataverseSourceClose:
    """Tests for close() resource cleanup."""

    def test_close_releases_client(self) -> None:
        """close() calls client.close() and sets client to None."""
        source = _make_source(_base_config())
        mock_client = _DataverseClientFake()
        source._client = mock_client

        source.close()

        mock_client.close.assert_called_once()
        assert source._client is None

    def test_close_when_no_client(self) -> None:
        """close() is safe when client was never created."""
        source = _make_source(_base_config())
        assert source._client is None
        source.close()  # Should not raise


# ─────────────────────────────────────────────────────────────────────────
# Record page call tests
# ─────────────────────────────────────────────────────────────────────────


class TestRecordPageCall:
    """Tests for _record_page_call audit recording."""

    def _make_source_with_client(self) -> Any:
        source = _make_source(_base_config())
        source._client = _DataverseClientFake()
        return source

    def test_record_success(self) -> None:
        """Success page records CallStatus.SUCCESS with row count.

        Headers are already fingerprinted by the client before reaching
        the DataversePageResponse DTO — the source passes them through.
        """
        from elspeth.contracts import CallStatus, CallType

        source = self._make_source_with_client()
        ctx = _mock_source_context()

        page = _make_page([{"id": "1"}, {"id": "2"}], latency_ms=42.0)
        source._record_page_call(ctx, url="https://test.com/api", page=page)

        ctx.record_call.assert_called_once()
        call_kwargs = ctx.record_call.call_args
        assert call_kwargs.kwargs["call_type"] == CallType.HTTP
        assert call_kwargs.kwargs["status"] == CallStatus.SUCCESS
        assert call_kwargs.kwargs["response_data"]["row_count"] == 2
        assert call_kwargs.kwargs["latency_ms"] == 42.0
        # Headers passed through as-is (already fingerprinted by client)
        assert call_kwargs.kwargs["request_data"]["headers"] == page.request_headers

    def test_record_success_includes_odata_pagination_metadata(self) -> None:
        """Success audit payload keeps lightweight pagination metadata."""
        source = self._make_source_with_client()
        ctx = _mock_source_context()

        page = DataversePageResponse(
            status_code=200,
            rows=[{"id": "1"}],
            latency_ms=42.0,
            headers={"content-type": "application/json", "odata-version": "4.0"},
            request_headers={"Authorization": "<fingerprint:test-fake>"},
            request_url="https://test.com/api?$skiptoken=abc",
            next_link="https://test.com/api?$skiptoken=def",
            paging_cookie=None,
            more_records=None,
        )
        source._record_page_call(ctx, url=page.request_url, page=page)

        response_data = ctx.record_call.call_args.kwargs["response_data"]
        assert response_data["headers"] == page.headers
        # Persisted copy is fingerprinted (elspeth-3f583950c1): benign query
        # params survive modulo re-encoding ($ -> %24).
        assert response_data["next_link"] == fingerprint_url(page.next_link)
        assert "skiptoken=def" in response_data["next_link"]
        assert response_data["paging_cookie"] is None
        assert response_data["more_records"] is None

    def test_record_success_includes_fetchxml_pagination_metadata(self) -> None:
        """FetchXML call records paging cookie and explicit terminal flag."""
        source = self._make_source_with_client()
        ctx = _mock_source_context()

        page = DataversePageResponse(
            status_code=200,
            rows=[{"id": "1"}],
            latency_ms=42.0,
            headers={"content-type": "application/json"},
            request_headers={"Authorization": "<fingerprint:test-fake>"},
            request_url="https://test.com/api",
            next_link=None,
            paging_cookie="cookie-123",
            more_records=False,
        )
        source._record_page_call(ctx, url=page.request_url, page=page)

        response_data = ctx.record_call.call_args.kwargs["response_data"]
        assert response_data["paging_cookie"] == "cookie-123"
        assert response_data["more_records"] is False

    def test_record_error(self) -> None:
        """Error page records CallStatus.ERROR with error details."""
        from elspeth.contracts import CallStatus, CallType

        source = self._make_source_with_client()
        ctx = _mock_source_context()

        error = DataverseClientError("Server error", retryable=True, status_code=500, latency_ms=100.0)
        source._record_page_call(ctx, url="https://test.com/api", error=error, error_reason="pagination_error")

        ctx.record_call.assert_called_once()
        call_kwargs = ctx.record_call.call_args
        assert call_kwargs.kwargs["call_type"] == CallType.HTTP
        assert call_kwargs.kwargs["status"] == CallStatus.ERROR
        assert call_kwargs.kwargs["error"]["status_code"] == 500

    def test_no_recording_when_no_args(self) -> None:
        """No record_call when neither page, error, nor error_reason provided."""
        source = self._make_source_with_client()
        ctx = _mock_source_context()

        source._record_page_call(ctx, url="https://test.com/api")
        ctx.record_call.assert_not_called()

    def test_record_success_emits_single_completion_event_via_plugin_context(self) -> None:
        """Real PluginContext path emits one completion event per Dataverse page call."""
        source = self._make_source_with_client()
        events: list[Any] = []
        ctx = _plugin_context_for_operation_calls(telemetry_emit=events.append)

        page = _make_page([{"id": "1"}], latency_ms=42.0)
        source._record_page_call(ctx, url="https://test.com/api", page=page)

        assert len(events) == 1


# ---------------------------------------------------------------------------
# Bug fix: server-controlled pagination URLs fingerprinted before persistence
# (elspeth-3f583950c1)
# ---------------------------------------------------------------------------


HOSTILE_URL = "https://alice:s3cret-pass@myorg.crm.dynamics.com/api/data/v9.2/contacts?sig=RAW_QUERY_SECRET&view=full#frag-secret"
HOSTILE_NEXT_LINK = "https://bob:n3xt-pass@myorg.crm.dynamics.com/api/data/v9.2/contacts?token=RAW_LINK_SECRET&$skiptoken=2#next-frag"
_RAW_MARKERS = ("s3cret-pass", "RAW_QUERY_SECRET", "frag-secret", "n3xt-pass", "RAW_LINK_SECRET", "next-frag")


def _assert_no_raw_markers(text: str) -> None:
    for marker in _RAW_MARKERS:
        assert marker not in text, f"raw sensitive value {marker!r} persisted: {text!r}"


class TestRecordPageCallUrlFingerprinting:
    """After page 1, url IS the server-supplied @odata.nextLink — Tier-3 data.

    Persisted copies must ride the same fingerprint_url treatment the
    sibling AuditedHTTPClient path applies (blob_fetch.py / http.py
    convention); pagination itself keeps using the raw DTO value.
    """

    def _make_source_with_client(self) -> Any:
        source = _make_source(_base_config())
        source._client = _DataverseClientFake()
        return source

    def _hostile_page(self) -> DataversePageResponse:
        return DataversePageResponse(
            status_code=200,
            rows=[{"id": "1"}],
            latency_ms=42.0,
            headers={"content-type": "application/json"},
            request_headers={"Authorization": "<fingerprint:test-fake>"},
            request_url=HOSTILE_URL,
            next_link=HOSTILE_NEXT_LINK,
            paging_cookie=None,
            more_records=None,
        )

    def test_success_branch_fingerprints_url_and_next_link(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("ELSPETH_FINGERPRINT_KEY", "dataverse-test-key")
        monkeypatch.delenv("ELSPETH_ALLOW_RAW_SECRETS", raising=False)
        source = self._make_source_with_client()
        ctx = _mock_source_context()

        source._record_page_call(ctx, url=HOSTILE_URL, page=self._hostile_page())

        kwargs = ctx.record_call.call_args.kwargs
        persisted_url = kwargs["request_data"]["url"]
        persisted_next = kwargs["response_data"]["next_link"]
        for persisted in (persisted_url, persisted_next):
            _assert_no_raw_markers(persisted)
            assert "myorg.crm.dynamics.com" in persisted  # redaction is surgical, not blinding
        query = dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(persisted_url).query))
        assert query["sig"].startswith("<fingerprint:")
        assert query["view"] == "full"
        next_query = dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(persisted_next).query))
        assert next_query["token"].startswith("<fingerprint:")
        assert next_query["$skiptoken"] == "2"

    def test_success_branch_preserves_none_next_link(self) -> None:
        source = self._make_source_with_client()
        ctx = _mock_source_context()

        page = DataversePageResponse(
            status_code=200,
            rows=[],
            latency_ms=1.0,
            headers={},
            request_headers={},
            request_url="https://myorg.crm.dynamics.com/api/data/v9.2/contacts",
            next_link=None,
            paging_cookie=None,
            more_records=False,
        )
        source._record_page_call(ctx, url=page.request_url, page=page)

        assert ctx.record_call.call_args.kwargs["response_data"]["next_link"] is None

    def test_error_branch_fingerprints_url(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("ELSPETH_FINGERPRINT_KEY", "dataverse-test-key")
        monkeypatch.delenv("ELSPETH_ALLOW_RAW_SECRETS", raising=False)
        source = self._make_source_with_client()
        ctx = _mock_source_context()

        error = DataverseClientError("Server error", retryable=True, status_code=500, latency_ms=100.0)
        source._record_page_call(ctx, url=HOSTILE_URL, error=error, error_reason="pagination_error")

        persisted_url = ctx.record_call.call_args.kwargs["request_data"]["url"]
        _assert_no_raw_markers(persisted_url)
        assert "myorg.crm.dynamics.com" in persisted_url

    def test_success_branch_audit_miss_message_fingerprints_url(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from elspeth.contracts.errors import AuditIntegrityError

        monkeypatch.setenv("ELSPETH_FINGERPRINT_KEY", "dataverse-test-key")
        monkeypatch.delenv("ELSPETH_ALLOW_RAW_SECRETS", raising=False)
        source = self._make_source_with_client()
        ctx = _mock_source_context()
        ctx.record_call = _CallRecorder(side_effect=RuntimeError("db down"))

        with pytest.raises(AuditIntegrityError) as excinfo:
            source._record_page_call(ctx, url=HOSTILE_URL, page=self._hostile_page())
        _assert_no_raw_markers(str(excinfo.value))

    def test_error_branch_audit_miss_message_fingerprints_url(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from elspeth.contracts.errors import AuditIntegrityError

        monkeypatch.setenv("ELSPETH_FINGERPRINT_KEY", "dataverse-test-key")
        monkeypatch.delenv("ELSPETH_ALLOW_RAW_SECRETS", raising=False)
        source = self._make_source_with_client()
        ctx = _mock_source_context()
        ctx.record_call = _CallRecorder(side_effect=RuntimeError("db down"))

        error = DataverseClientError("Server error", retryable=True, status_code=500, latency_ms=100.0)
        with pytest.raises(AuditIntegrityError) as excinfo:
            source._record_page_call(ctx, url=HOSTILE_URL, error=error, error_reason="pagination_error")
        _assert_no_raw_markers(str(excinfo.value))


# ---------------------------------------------------------------------------
# Bug fix: normalize_field_name quarantine (elspeth-4668a0f43d)
# ---------------------------------------------------------------------------


class TestNormalizeFieldQuarantine:
    """Verify that normalize_field_name errors quarantine the row, not crash the load."""

    def test_normalize_row_fields_raises_on_empty_field_name(self) -> None:
        """The primitive _normalize_row_fields raises ValueError for unnormalizable fields.

        This tests the mechanism — that ValueError propagates from
        normalize_field_name. The quarantine behavior (catching this
        ValueError in load()) is tested separately below.
        """
        source = _make_source(_base_config())

        # Build the initial resolution mapping from a valid row
        source._normalize_row_fields({"contactid": "abc"}, is_first_row=True)

        # A subsequent row with a new field that normalizes to empty raises
        with pytest.raises(ValueError, match="empty"):
            source._normalize_row_fields({"!!!": "value", "contactid": "abc"}, is_first_row=False)

    def test_normalize_error_in_load_yields_quarantined_row(self) -> None:
        """In the full load() path, normalize errors yield quarantined rows."""
        source = _make_source(_base_config())
        ctx = _mock_source_context()

        # Fake client returns a page with a problematic field.
        page = _make_page([{"!!!": "trash-field-name"}])
        mock_client = _DataverseClientFake(odata_pages=[page])
        source._client = mock_client

        rows = list(source.load(ctx))

        # Row should be quarantined, not crash
        assert len(rows) == 1
        assert rows[0].is_quarantined is True
        assert rows[0].quarantine_error is not None
        assert "Field normalization failed" in rows[0].quarantine_error
        assert rows[0].quarantine_destination == "quarantine"

        # Validation error should be recorded in audit trail
        ctx.record_validation_error.assert_called_once()
        call_kwargs = ctx.record_validation_error.call_args.kwargs
        assert call_kwargs["schema_mode"] == "field_normalization"


# ---------------------------------------------------------------------------
# Bug fix: audit trail records actual URL per page (elspeth-fafd21248c)
# ---------------------------------------------------------------------------


class TestAuditUrlPerPage:
    """Verify audit trail records the actual URL for each page, not the initial URL."""

    def test_record_page_call_uses_page_request_url(self) -> None:
        """_record_page_call receives page.request_url, not rebuilt URL."""
        source = self._make_source_with_client()
        ctx = _mock_source_context()

        next_url = "https://test.crm.dynamics.com/api/data/v9.2/contacts?$skiptoken=abc"
        # Simulate a page 2 response with a different request_url
        page2 = DataversePageResponse(
            status_code=200,
            rows=[{"id": "2"}],
            latency_ms=15.0,
            headers={"content-type": "application/json"},
            request_headers={"Authorization": "[FINGERPRINT]"},
            request_url=next_url,
            next_link=None,
            paging_cookie=None,
            more_records=False,
        )

        source._record_page_call(ctx, url=page2.request_url, page=page2)

        call_kwargs = ctx.record_call.call_args.kwargs
        # fingerprint_url re-encodes the query ($ -> %24) but keeps the
        # nextLink identity — the page-2 URL, not the rebuilt initial URL.
        assert call_kwargs["request_data"]["url"] == fingerprint_url(next_url)
        assert "skiptoken=abc" in call_kwargs["request_data"]["url"]

    def _make_source_with_client(self) -> Any:
        source = _make_source(_base_config())
        source._client = _DataverseClientFake()
        return source


# ---------------------------------------------------------------------------
# Bug fix: URL percent-encoding (elspeth-5bd2873b3e)
# ---------------------------------------------------------------------------


class TestUrlPercentEncoding:
    """Entity names and filter values are percent-encoded in URLs."""

    def test_filter_with_single_quote_encoded(self) -> None:
        """Single quotes in $filter are percent-encoded."""
        source = _make_source(_base_config(filter="name eq 'O''Brien'"))
        url = source._build_query_url("contacts")
        # Single quotes should be encoded as %27
        assert "%27" in url
        assert "'" not in url.split("$filter=")[1]

    def test_filter_with_ampersand_encoded(self) -> None:
        """Ampersand in $filter can't break URL structure."""
        source = _make_source(_base_config(filter="name eq 'A&B'"))
        url = source._build_query_url("contacts")
        # The & inside the filter value must be encoded as %26
        filter_part = url.split("$filter=")[1]
        assert "&" not in filter_part  # No raw ampersand in filter value
        assert "%26" in filter_part

    def test_filter_with_hash_encoded(self) -> None:
        """Hash in $filter can't truncate URL as fragment."""
        source = _make_source(_base_config(filter="name eq 'test#1'"))
        url = source._build_query_url("contacts")
        assert "%23" in url
        assert "#" not in url.split("$filter=")[1]

    def test_entity_set_name_in_path_encoded(self) -> None:
        """Resolved entity-set name with special chars is percent-encoded in the path."""
        source = _make_source(_base_config())
        url = source._build_query_url("my entity")
        assert "/my%20entity" in url  # Slash-anchored: confirms it's in the path
        assert "my entity" not in url

    def test_normal_entity_set_unchanged(self) -> None:
        """Normal entity-set names (alphanumeric) pass through unmodified."""
        source = _make_source(_base_config())
        url = source._build_query_url("contacts")
        assert "/contacts" in url

    def test_orderby_with_special_chars_encoded(self) -> None:
        """$orderby values with special characters are percent-encoded."""
        source = _make_source(_base_config(orderby="name desc, 'special'"))
        url = source._build_query_url("contacts")
        assert "%27" in url  # single quote encoded
        assert "%20" in url  # space encoded

    def test_select_identifiers_not_encoded(self) -> None:
        """$select column names (Dataverse identifiers) are NOT encoded."""
        source = _make_source(_base_config(select=["contactid", "fullname"]))
        url = source._build_query_url("contacts")
        assert "$select=contactid,fullname" in url  # literal, no encoding


# ---------------------------------------------------------------------------
# Bug fix: unmapped fields trigger field resolution rebuild (review finding)
# ---------------------------------------------------------------------------


class TestUnmappedFieldsRebuildResolution:
    """Verify that rows with fields not in the initial mapping trigger a
    _field_resolution rebuild so new fields are correctly normalized."""

    def test_new_field_on_page2_is_normalized(self) -> None:
        """When page 2 introduces a field not in page 1, the new field
        appears correctly normalized in output rows and the field
        resolution mapping is rebuilt to include it."""
        pages = [
            _make_page(
                [{"contactid": "1", "fullname": "Alice"}],
                next_link="https://myorg.crm.dynamics.com/api/data/v9.2/contacts?$skiptoken=1",
            ),
            _make_page(
                [{"contactid": "2", "fullname": "Bob", "jobtitle": "Engineer"}],
            ),
        ]
        source = _make_source_for_load(pages, _base_config())
        ctx = _mock_source_context()

        rows = list(source.load(ctx))

        assert len(rows) == 2
        # All rows should be valid (not quarantined)
        assert all(not r.is_quarantined for r in rows)

        # Page 1 row has only contactid and fullname
        assert "contactid" in rows[0].row
        assert "fullname" in rows[0].row

        # Page 2 row has the new field "jobtitle" correctly normalized
        assert "jobtitle" in rows[1].row
        assert rows[1].row["jobtitle"] == "Engineer"

        # Field resolution should have been rebuilt to include jobtitle
        resolution = source.get_field_resolution()
        assert resolution is not None
        mapping, _ = resolution
        assert "jobtitle" in mapping

    def test_new_field_with_non_identifier_name_is_normalized(self) -> None:
        """New fields with non-identifier names (e.g., spaces) are
        normalized through the same algorithm on rebuild."""
        pages = [
            _make_page(
                [{"contactid": "1", "fullname": "Alice"}],
                next_link="https://myorg.crm.dynamics.com/next",
            ),
            _make_page(
                [{"contactid": "2", "fullname": "Bob", "Job Title": "Engineer"}],
            ),
        ]
        source = _make_source_for_load(pages, _base_config())
        ctx = _mock_source_context()

        rows = list(source.load(ctx))

        assert len(rows) == 2
        assert all(not r.is_quarantined for r in rows)

        # The new field should be normalized (spaces -> underscore, lowered)
        row2 = rows[1].row
        assert "job_title" in row2
        assert row2["job_title"] == "Engineer"

        # Resolution mapping should include the new field after rebuild
        resolution = source.get_field_resolution()
        assert resolution is not None
        mapping, _ = resolution
        assert "Job Title" in mapping
        assert mapping["Job Title"] == "job_title"

    def test_resolution_not_rebuilt_when_fields_match(self) -> None:
        """Field resolution is NOT rebuilt when a subsequent row has the
        same fields as the initial mapping."""
        pages = [
            _make_page(
                [{"contactid": "1", "fullname": "Alice"}],
                next_link="https://myorg.crm.dynamics.com/next",
            ),
            _make_page(
                [{"contactid": "2", "fullname": "Bob"}],
            ),
        ]
        source = _make_source_for_load(pages, _base_config())
        ctx = _mock_source_context()

        # Process first page to establish initial resolution
        rows = list(source.load(ctx))
        assert len(rows) == 2

        # Resolution should not have changed (same fields on both pages)
        resolution = source.get_field_resolution()
        assert resolution is not None
        mapping, _ = resolution
        # Only the original fields should be in the mapping
        assert set(mapping.keys()) == {"contactid", "fullname"}


class TestDataverseSparseFieldMapping:
    """elspeth-594221617d: sparse Dataverse rows + field_mapping order-independence."""

    def test_sparse_field_mapping_is_order_independent(self) -> None:
        """An optional mapped attribute appearing only in a later row must neither
        quarantine the sparse first row nor mis-map the later-only key. Order-
        independence pins both the quarantine and the else-branch mis-mapping."""
        # Sparse row first; mapped 'Customer Name' appears only in the later row.
        src = _make_source(_base_config(field_mapping={"customer_name": "client_name"}))
        r1 = src._normalize_row_fields({"contactid": "1"}, is_first_row=True)
        r2 = src._normalize_row_fields({"contactid": "2", "Customer Name": "Alice"}, is_first_row=False)
        assert r1 == {"contactid": "1"}
        assert r2 == {"contactid": "2", "client_name": "Alice"}

        # Reversed order must produce identical normalized output.
        src2 = _make_source(_base_config(field_mapping={"customer_name": "client_name"}))
        r1b = src2._normalize_row_fields({"contactid": "2", "Customer Name": "Alice"}, is_first_row=True)
        r2b = src2._normalize_row_fields({"contactid": "1"}, is_first_row=False)
        assert r1b == {"contactid": "2", "client_name": "Alice"}
        assert r2b == {"contactid": "1"}


class TestFieldResolutionUnion:
    """B4.3: field resolution after heterogeneous rows must be the UNION."""

    def test_field_resolution_is_union_across_heterogeneous_rows(self) -> None:
        """B4.3: get_field_resolution() must be the UNION of all keys seen across rows.

        When row1={contactid, name} is followed by row2={contactid, email}, the
        resolution must contain {contactid, name, email} -- not just {contactid,
        email} (the last row's keys). Before the fix the rebuild replaced the
        resolution with list(row.keys()) on the NEW row only, discarding 'name'
        from the Landscape field-resolution audit record (elspeth-594221617d).
        """
        pages = [
            _make_page(
                [{"contactid": "1", "fullname": "Alice"}],
                next_link="https://myorg.crm.dynamics.com/api/data/v9.2/contacts?$skiptoken=1",
            ),
            _make_page([{"contactid": "2", "jobtitle": "Engineer"}]),
        ]
        source = _make_source_for_load(pages, _base_config())
        ctx = _mock_source_context()

        rows = list(source.load(ctx))

        assert len(rows) == 2
        assert all(not r.is_quarantined for r in rows)

        resolution = source.get_field_resolution()
        assert resolution is not None
        mapping, _ = resolution
        # Union: all keys from both rows must be present
        assert "fullname" in mapping, "field 'fullname' from row 1 was lost after row 2 rebuilt the resolution"
        assert "jobtitle" in mapping, "field 'jobtitle' from row 2 must be present"
        assert "contactid" in mapping


class TestFieldMappingCollisionPolarity:
    """B3.1: field_mapping-created collisions are config faults (crash), not data
    faults (quarantine). Azure Blob JSON differs because blob row field sets are
    external source data and are quarantined per row."""

    def test_field_mapping_collision_crashes_not_quarantines(self) -> None:
        """A field_mapping that collapses two fields into one final name is a CONFIG
        fault and must crash the run, not be silently quarantined.

        field_mapping={'contactid': 'id'} on a row that also carries a passthrough
        field 'id' causes check_mapping_collisions to raise a plain ValueError.
        Before the fix, the broad 'except ValueError' in load() masked it as a
        per-row quarantine; after the fix only ExternalHeaderError (data faults) is
        caught, so the plain ValueError propagates and crashes.
        """
        pages = [_make_page([{"contactid": "1", "id": "other"}])]
        source = _make_source_for_load(
            pages,
            _base_config(field_mapping={"contactid": "id"}),
        )
        ctx = _mock_source_context()

        with pytest.raises(ValueError, match="collision"):
            list(source.load(ctx))


class TestDeclaredFieldReachability:
    """Config-time rejection of declared names no row can carry (elspeth-3664e213c4).

    Dataverse shares the sparse JSON-object resolution seam: attribute names
    are normalized to lowercase identifiers while declared schema names are
    used verbatim, so a declared mixed-case name can never match a row key.
    """

    def test_mixed_case_declared_names_rejected(self) -> None:
        from elspeth.plugins.infrastructure.config_base import PluginConfigError
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        with pytest.raises(PluginConfigError, match="can never appear"):
            DataverseSourceConfig.from_dict(
                _base_config(schema={"mode": "flexible", "fields": [{"name": "FullName", "field_type": "str"}]})
            )

    def test_normalized_declared_names_accepted(self) -> None:
        from elspeth.plugins.sources.dataverse import DataverseSourceConfig

        cfg = DataverseSourceConfig.from_dict(
            _base_config(schema={"mode": "flexible", "fields": [{"name": "fullname", "field_type": "str"}]})
        )
        assert cfg.schema_config.fields is not None
