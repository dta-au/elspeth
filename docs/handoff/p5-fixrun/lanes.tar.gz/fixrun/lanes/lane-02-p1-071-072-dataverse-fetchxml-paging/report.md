DONE: #71/#72 fixed in clients/dataverse.py plus the review follow-ups: Prefer requested and now recorded in the audit (VERIFY builds the same shape; DataverseSource hash re-pinned), absent morerecords ends pagination, inner paging cookie decoded twice, and a page-1 probe refuses silent truncation when annotations are not honoured. 8 commits (4 test/fix pairs) on 9131a99e; lane test 20 passed, Dataverse tests 935 passed, Python 3.14.6.

(Written by the hub from lane-02's SubagentHandback; the harness refused the lane's own report file.)

## Root cause
- #71 (`paginate_fetchxml`, src/elspeth/plugins/infrastructure/clients/dataverse.py):
  - It sent no `Prefer: odata.include-annotations` header, so Dataverse never returned the morerecords or paging-cookie annotations.
  - It raised `protocol_violation` when morerecords was absent, and the contract omits morerecords on the final page. Every FetchXML load therefore failed after page 1.
- #72 (same function): it sent `unquote(<whole annotation>)` as the paging cookie. The real cookie is the `pagingcookie` attribute of a `<cookie .../>` wrapper element, URL-encoded twice.

## Fix
- **#71:**
  - Adds `_FETCHXML_PREFER_HEADER` (dataverse.py:77) and passes it to each page request through `extra_headers`.
  - An absent morerecords now means end of results.
  - A cookie without morerecords still raises protocol_violation, and so does morerecords=true without a cookie.
- **#72:** adds `_extract_fetchxml_paging_cookie` (dataverse.py:141).
  - It parses the annotation with ElementTree, treating it as Tier-3 external data.
  - It returns the `pagingcookie` attribute decoded twice.
  - A parse failure or a missing attribute raises DataverseClientError(protocol_violation) with the page context.
- **Tests:**
  - New test file `tests/unit/plugins/infrastructure/clients/test_dataverse_fetchxml_paging.py`, 10 tests.
  - Existing tests that encoded the old contract were updated in the fix commits: test_dataverse_client.py and test_dataverse_source.py.

## RED and GREEN (Python 3.14, base 21e74acc)
- **RED for #71:** exit 1, 3 failed and 2 passed.
  - `AssertionError: FetchXML request sent no Prefer header`
  - `final page without annotations raised: ...missing '@Microsoft.Dynamics.CRM.morerecords'` (x2)
- **RED for #72:** exit 1, 5 failed and 5 passed.
  - A wrapper-vs-inner cookie assertion (x2).
  - `malformed paging-cookie annotation was forwarded to Dataverse` (x3).
- **GREEN:** the lane test exits 0 with 10 passed. The Dataverse unit and integration tests exit 0 with 905 passed.

## Gates
- **Lint and types:** ruff check 0, ruff format --check 0, check_contracts 0, mypy on the touched files 0.
- **Plugin hashes:** unchanged, since no plugin file was touched.
- **Keyless elspeth-lints:** exit 1, the existing corpus. It has 0 findings in dataverse.py (the positive control has 38) and no signature churn.
- **DAG and architecture tests:** `pytest tests/integration/core/dag tests/unit/architecture -n 2` exits 1, with 11 failed and 2215 passed.
  - 10 of the failures are workers killed by the cgroup out-of-memory killer, in whole-tree web scans this lane does not touch.
  - The other 1 is a 20s timeout in test_dag_recovery_partial_terminal, which also times out with the base client source.
  - All of these are in the hub's baseline flake set (baseline-314-failures.txt). On the base they pass when re-run serially.

## Left alone (first round; the 1st and 3rd bullets were superseded by the review follow-ups below)
- `Prefer` is missing from the audited `request_headers`. This was already true for all `extra_headers`, and changing it would alter the VERIFY replay request shape, which is a separate decision.
- The fix has not been tested against a live Dataverse.
- A server that ignored `Prefer` would end pagination after page 1 without an error.


## Review follow-ups (approved by the maintainer after the Fable review)

### Pair A: Prefer in the audit record (3158c3ae test, 81858686 fix)
- `_execute_request` now fingerprints the merged headers. Sensitive values are still fingerprinted; other headers, Prefer among them, pass through as-is.
- `before_request` now takes `(url, extra_headers)`.
- `DataverseSource._verify_request_data(url, extra_headers)` merges the extras, so the request VERIFY builds has the same shape as the recorded one.
- `DataverseSource.source_file_hash` is re-pinned from a993a9a403c9b3b8 to 8d3f3de6d9e62d9f. Nothing else in the tree references the old token. The sink hash is unchanged.
- The commit body states the compatibility break: FetchXML runs recorded before this fix are not verifiable. Every such real run failed after page 1 anyway.
- **RED:** exit 1, 2 failed / 10 passed: "audit record omits the Prefer header that was sent".
- **Negative control:** fingerprinting alone, without the VERIFY widening, makes the VERIFY test fail with "archived request missing or ambiguous".
- **GREEN:** 12 passed; Dataverse tests 927 passed.

### Pair B: page-1 truncation guard (c30b8cb4 test, 9e6bbfd5 fix)
- When page 1 has no morerecords and no cookie and is full, the client makes one audited request with `page="2"` and no cookie. Full means rows are non-empty and `count` is either unset or not above the row count.
- **Probe returns rows:** it raises DataverseClientError(protocol_violation, "paging annotations not honoured; refusing to truncate") with the probe's context.
- **Probe is empty:** the run ends cleanly.
- No probe is made when `top` is set, when page 1 is partial or empty, or when it is annotated.
- **RED:** exit 1, 3 failed / 17 passed. One failure is "a full page 1 without paging annotations was accepted as the whole result set".
- **GREEN:** 20 passed; Dataverse tests 935 passed.

### Gates at HEAD 9e6bbfd5
- **Lint, contracts, types:** ruff 0, format 0, check_contracts 0, mypy src/ elspeth-lints/src/ 0.
- **Hash pins:** they match.
- **Not rerun by the lane:** the arch/DAG suite and the keyless trust-tier scan. The hub verify suite covers arch/DAG.

### Left alone
- morerecords=true without a cookie still raises; this is a follow-up.
- `paginate_odata` calls the preflight hook twice for each nextLink. This predates the lane.
