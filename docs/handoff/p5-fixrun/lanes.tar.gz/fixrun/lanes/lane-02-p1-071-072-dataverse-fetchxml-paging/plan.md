# lane-02-p1-071-072-dataverse-fetchxml-paging — #71 FetchXML pagination fails because the client never asks for the morerecords annotation and requires it on the final page; #72 FetchXML paging cookie is injected as the wrapper element, decoded once, instead of the inner pagingcookie attribute decoded twice

Ticket `p1-071-072-dataverse-fetchxml-paging` · run `p1` · branch `lane/p1-071-072-dataverse-fetchxml-paging` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

FINDING #71 [P1] FetchXML pagination fails because the client never asks for the morerecords annotation and requires it on the final page
File: src/elspeth/plugins/infrastructure/clients/dataverse.py
Sweep evidence: Location: dataverse.py:883-894 (paginate_fetchxml) and dataverse.py:316-329 / 877 (get_auth_headers and get_page send no Prefer header). paginate_fetchxml raises DataverseClientError(error_category='protocol_violation') whenever page.more_records is None, which is when '@Microsoft.Dynamics.CRM.morerecords' is missing. Microsoft's Web API documentation (learn.microsoft.com .../fetchxml/page-results, read during this review) says two relevant things. First, the fetchxmlpagingcookie and morerecords annotations are returned only when the request sends `Prefer: odata.include-annotations="Microsoft.Dynamics.CRM.fetchxmlpagingcookie,Microsoft.Dynamics.CRM.morerecords"` (or `"*"`). Second, 'On the final page, the response doesn't include the @Microsoft.Dynamics.CRM.morerecords and @Microsoft.Dynamics.CRM.fetchxmlpagingcookie annotations', and the MS sample decides with TryGetPropertyValue (absent means done). rg for 'Prefer|include-annotations' under src/elspeth/plugins finds no Dataverse hit, so no request carries the Prefer header. Against a real Dataverse, every FetchXML load therefore yields its first page and then raises a non-retryable protocol_violation. The source's except DataverseClientError branch (sources/dataverse.py:1096-1108) records the error and re-raises, so the source load fails. Even if the Prefer header were sent, the final page of every query would still raise. The unit tests mock 'morerecords': False on the last page (test_dataverse_client.py:882-915), and test_missing_morerecords_crashes_fetchxml_pagination (line 980) treats absence as an anomaly, so the tests cover the wrong protocol. Expected behaviour: send the Prefer include-annotations header on FetchXML requests, and treat an absent morerecords as end-of-results (or false), per the vendor contract. Keep the contradiction check for morerecords=true with no cookie.
Independent verifier (CONFIRMED): Code: clients/dataverse.py:316-329 get_auth_headers sends only Authorization/Accept/OData-*Version. get_page (763) and paginate_fetchxml (877) pass no extra_headers, and `grep -rn 'Prefer|include-annotations' src/elspeth/plugins` has no hits. paginate_fetchxml:883-894 raises protocol_violation when more_records is None. MS docs (https://learn.microsoft.com/en-us/power-apps/developer/data-platform/fetchxml/page-results, Web API tab) say the annotations are returned only with `Prefer: odata.include-annotations="Microsoft.Dynamics.CRM.fetchxmlpagingcookie,Microsoft.Dynamics.CRM.morerecords"` (or "*"), and that 'On the final page, the response doesn't include the @Microsoft.Dynamics.CRM.morerecords and @Microsoft.Dynamics.CRM.fetchxmlpagingcookie annotations'. The MS sample decides with TryGetPropertyValue, so an absent annotation means done. Repro (.claude/lanes/20261111-plugins-review/scratch-C/repro_client.py: real DataverseClient, httpx.MockTransport, DNS pinning stubbed) used the doc's final-page shape {value:[...]} with no annotations. It yielded the page and then raised DataverseClientError(protocol_violation 'FetchXML response missing ...morerecords'). Prefer header captured on the request: None. So every FetchXML load fails, single-page result sets included. sources/dataverse.py:1096-1108 records the error and re-raises. Tests encode the wrong contract: test_dataverse_client.py:980 test_missing_morerecords_crashes_fetchxml_pagination, and mocks put morerecords:false on the last page.
Verifier repro scripts (gitignored, read-only reference): .claude/lanes/20261111-plugins-review/scratch-*/ in /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta

FINDING #72 [P1] FetchXML paging cookie is injected as the wrapper element, decoded once, instead of the inner pagingcookie attribute decoded twice
File: src/elspeth/plugins/infrastructure/clients/dataverse.py
Sweep evidence: Location: dataverse.py:914-921. The client does `decoded_cookie = urllib.parse.unquote(page.paging_cookie); root.set('paging-cookie', decoded_cookie)`. Per Microsoft's Web API docs (page-results, read during this review), the annotation value is an XML wrapper element, e.g. `<cookie pagenumber="2" pagingcookie="%253ccookie%2520page%253d%25221%2522%253e..." istracking="False" />`. The client must parse that element, take its `pagingcookie` attribute, and URL-decode it twice to get `<cookie page="1"><contactid last=... first=.../></cookie>`. The MS sample does exactly that: XElement.Parse, then Attribute("pagingcookie"), then UrlDecode(UrlDecode(...)). This code instead sends the whole wrapper, decoded once, as paging-cookie, which yields `<cookie pagenumber="2" pagingcookie="%3ccookie%20page..." istracking="False" />`. Dataverse will reject that as an invalid cookie or ignore it and fall back to simple paging, which is capped at 50,000 records and degrades as the row count grows. This sits behind the morerecords defect above, so it shows up as soon as that one is fixed. The tests (test_dataverse_client.py:882-950) build the cookie as `urllib.parse.quote("<cookie page='1'/>")`, a format Dataverse never emits, so they pass against the wrong shape. Expected behaviour: parse the annotation as XML with a Tier-3 parse failure raised as DataverseClientError, require the `pagingcookie` attribute, unquote it twice, and set the result on the fetch element.
Independent verifier (CONFIRMED): Code: clients/dataverse.py:914-921 does `root.set('paging-cookie', urllib.parse.unquote(page.paging_cookie))` on the raw annotation value. Per https://learn.microsoft.com/en-us/power-apps/developer/data-platform/fetchxml/page-results, the annotation is an XML element `<cookie pagenumber="2" pagingcookie="%253ccookie..." istracking="False" />`. The client must take its `pagingcookie` attribute and URL-decode it twice; the doc steps say so and the sample does XElement.Parse -> Attribute("pagingcookie") -> UrlDecode(UrlDecode(..)). Repro fed the doc-shaped annotation with morerecords:true. The page-2 FetchXML sent was `<fetch paging-cookie="&lt;cookie pagenumber=&quot;2&quot; pagingcookie=&quot;%3ccookie%20page%3d%221%22%3e...&quot; istracking=&quot;False&quot; /&gt;" page="2">`: the wrapper element, decoded once, not `<cookie page="1"><contactid .../></cookie>`. I cannot show live server behaviour (reject vs fall back to simple paging, capped at 50,000 per the same doc), but the request is plainly not the documented cookie. Tests (test_dataverse_client.py:884, 948, 965) use `quote("<cookie page='1'/>")`, a shape Dataverse does not emit. This is masked today by #71: it raises only once more_records parsing gets past the first page.
Verifier repro scripts (gitignored, read-only reference): .claude/lanes/20261111-plugins-review/scratch-*/ in /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta

## Files a correct fix must change

- `src/elspeth/plugins/infrastructure/clients/dataverse.py`

## Test files the lane must add or change

- `tests/unit/plugins/infrastructure/clients/test_dataverse_fetchxml_paging.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/infrastructure/clients/test_dataverse_fetchxml_paging.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-02-p1-071-072-dataverse-fetchxml-paging/report.md`; the worker returns one line.
