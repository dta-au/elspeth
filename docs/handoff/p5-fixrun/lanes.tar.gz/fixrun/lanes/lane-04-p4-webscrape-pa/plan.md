# lane-04-p4-webscrape-pa — Plugin review P4 #130, #131, #153, #157, #164 (web_scrape helpers and Power Automate client)

Ticket `p4-webscrape-pa` · run `p4` · branch `lane/p4-webscrape-pa` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

Plugin review 2026-11-11, P4 findings #130, #131, #153, #157, #164 (web_scrape helpers and Power Automate client). Read each finding in full in /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/p4/plugins-review.md (headings '### #N [P4, ...]'). FIRST re-verify each finding against your branch HEAD: earlier P1-P3 lanes and the AWS review lanes have landed, so a finding may already be fixed or its line numbers moved. If a finding is already fixed, record 'already fixed' with the commit/evidence in report.md and skip it (no test needed); if it is a design question with no clear fix, record it under 'Maintainer decisions' instead of inventing policy. Method per remaining finding: systematic debugging + TDD: a test in the lane test file that FAILS AT AN ASSERTION on the current code, commit the test, then the fix, then the next finding. To assert a new symbol exists use `importlib.util.find_spec(...)` or `'name' in vars(obj)` / `'name' in Cls.model_fields` — NEVER hasattr/getattr in tests (the whole-tree gate tests/unit/test_no_hasattr_branching.py fails on any unreviewed hasattr in tests; read CONTRIBUTING.md § Whole-tree gates before coding). Gates before handing back: re-pin every touched plugin's source_file_hash with scripts.cicd.plugin_hash.compute_source_file_hash(Path(...)) and grep docs/architecture/dag/scenario-corpus/v1/manifest.yaml for the old token; `python scripts/check_contracts.py` (convert to owned types rather than adding soft mappings; --write-census only for an inherited-contract site); `ELSPETH_JUDGE_METADATA_SIGNATURE_VERIFY_MODE=shape-only-when-key-missing .venv/bin/elspeth-lints check --rules plugin_contract.component_type,plugin_contract.options_metadata,plugin_contract.plugin_hashes --root src/elspeth` with PYTHONPATH=$PWD:$PWD/src:$PWD/elspeth-lints/src; ruff check + ruff format --check + mypy on touched files; tests/unit/test_no_hasattr_branching.py; and the module test files for every touched source file (-n 3 max). Rules: no # noqa / # type: ignore / allowlist widening; no git stash; never touch judge signatures (list rotated signed tier_model fingerprints in report.md for operator re-sign); no CHANGELOG edits; Python is the worktree .venv (3.14); keep it P4-sized — no refactors beyond the finding. report.md must include per finding: status (fixed / already fixed / decision needed), RED evidence, fix summary, COMPAT/behaviour change, a one-line CHANGELOG entry, and re-pinned hashes. If any file in your expected-files list ends up unchanged (finding already fixed or deferred as a decision), list it on a line starting 'UNTOUCHED:' near the top of report.md with the reason.

## Files a correct fix must change

- `src/elspeth/plugins/infrastructure/clients/power_automate.py`
- `src/elspeth/plugins/transforms/web_scrape_json_extraction.py`
- `src/elspeth/plugins/transforms/web_scrape_fingerprint.py`
- `src/elspeth/plugins/transforms/web_scrape_auth.py`

## Test files the lane must add or change

- `tests/unit/plugins/test_p4_webscrape_pa_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
/home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.venv/bin/python -m pytest tests/unit/plugins/test_p4_webscrape_pa_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-04-p4-webscrape-pa/report.md`; the worker returns one line.
