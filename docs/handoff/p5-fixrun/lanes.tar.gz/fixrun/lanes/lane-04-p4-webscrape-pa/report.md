lane-04-p4-webscrape-pa: fixed #130 #153 #157 #164 (test b50b3b6f RED with 17 assertion failures, fix f4835c1e GREEN 22/22); #131 deferred as a maintainer decision because it needs a capability-close lifecycle in the contract and executor; plugin hashes unchanged; no tier_model signatures rotated.

(Written by orchestrator from the lane's hand-back; the subagent's report.md write was refused.)

Branch `lane/p4-webscrape-pa`, base 4ebe6d6b. Commits: b50b3b6f (test only), f4835c1e (fix only).

UNTOUCHED: none. All four expected source files changed. power_automate.py carries only #130; #131 is deferred.

## Per finding

### #130 Archived SAS verify reports a missing key as authentication_failed: FIXED
- RED: `assert 'authentication_failed' == 'fingerprint_key_required'`.
- Fix: `_require_fingerprint_key()` runs before `_resolve_credential()` in the ArchivedPowerAutomateSASAuth branch, matching the live SAS path and the archived SP path.
- COMPAT: a VERIFY run of an archived SAS source with no ELSPETH_FINGERPRINT_KEY fails with `fingerprint_key_required` instead of `authentication_failed`, still before DNS and preflight.
- CHANGELOG: Power Automate: an archived SAS VERIFY run with no fingerprint key now reports `fingerprint_key_required` instead of a misleading `authentication_failed`.

### #131 OAuth sink builds a new credential and token per POST: DECISION NEEDED (not changed)
- `_PowerAutomateHTTPPost.post_json` still creates a new PowerAutomateOperationClient per request.
- Deferred because a bound capability is never told when its attempt ends: SinkEffectHTTPPost (contracts/sink_effect_http.py) has no close hook; `bind` is documented as credential-free; the executor (engine/executors/sink_effects.py `_member_attempt_context`) ends an attempt only by clearing `active`. Reusing a credential/token would hold a secret with no teardown or expiry check.
- Options: (a) add a close/context lifecycle to SinkEffectHTTPPost, called by the executor on revoke, reusing one operation client per attempt; (b) cache only the admitted token plus `expires_on` per bound capability, no explicit teardown. The per-request `before_send` guard stays in both.

### #153 JSON array null elements fail the record: FIXED
- RED: 5 parametrized cases, e.g. `assert 'refused: JSON record column contains a non-scalar value' == [{'name': 'x'}]`.
- Fix: `_selected_values` drops null elements before the `multiple`/`max_values` checks; a null element counts as absent like a selected top-level null. Non-null non-scalar elements are still refused (control test).
- COMPAT: `first` returns the first non-null value; `one` counts only non-null values; `all` omits nulls; an all-null array gives None for first/one and [] for all; provenance `selected_count` counts only non-null; a `required` column whose array holds only nulls still fails; a page that used to fail now extracts.
- CHANGELOG: web_scrape JSON records: null elements inside a selected array are now treated as absent (like a top-level null) instead of failing the page.

### #157 compute_fingerprint silently treats unknown modes as 'full': FIXED
- RED: `test_157_unknown_fingerprint_mode_is_refused[contents|structure||FULL]` failed with `assert False`.
- Fix: `mode` typed `Literal["content","full"]`; any other value raises ValueError; unreachable "structure"/NotImplementedError branch removed. The one caller (web_scrape.py, Literal-typed config) is unchanged.
- COMPAT: none for admitted values; "content"/"full" hashes byte-identical (control test).
- CHANGELOG: web_scrape: `compute_fingerprint` now refuses an unknown fingerprint mode instead of silently hashing as "full".

### #164 API-key header denylist omits hop-by-hop/proxy headers; basic accepts no-colon credential: FIXED
- RED: 6 header cases and the basic case failed with `assert False`.
- Fix (web_scrape_auth.py): keep-alive, proxy-authenticate, proxy-connection, forwarded added to `_RESERVED_HEADERS`; `_RESERVED_HEADER_PREFIXES = ("x-forwarded-",)` checked case-insensitively; `header()` refuses a basic credential with no ":" (RFC 7617). Not shared with `web_scrape_request_headers._FORBIDDEN_NAMES` (outside the lane; its 4-name allowlist already excludes these).
- COMPAT: api_key header_names Keep-Alive, Proxy-Authenticate, Proxy-Connection, Forwarded, X-Forwarded-* now fail config validation; a basic secret without ":" raises ValueError (secret not echoed) when the header is built, instead of an opaque server 401.
- CHANGELOG: web_scrape auth: API-key header names now exclude hop-by-hop/proxy headers (Keep-Alive, Proxy-*, Forwarded, X-Forwarded-*), and basic credentials must be `user:password`.

## Gates (lane-reported)
- Lane test before fix: exit=1, 17 failed / 5 passed, all AssertionError. After fix: exit=0, 22 passed.
- Module tests (test_web_scrape*.py, test_power_automate_{client,sink,source}.py, test_no_hasattr_branching.py, lane test, -n 3): exit=0, 539 passed.
- tests/unit/core/test_config.py + tests/unit/web/composer/test_state.py: exit=0, 367 passed.
- tests/unit/elspeth_lints/test_masquerade_gate.py: exit=0, 243 passed / 1 skipped.
- ruff, ruff format, mypy on 5 touched files: clean. check_contracts: exit=0. elspeth-lints plugin_contract.{component_type,options_metadata,plugin_hashes}: exit=0. branch-safety: FAIL=0 WARN=0.

## Hashes
None re-pinned: touched files are helper/client modules with no source_file_hash; the plugin pins still match (sinks/power_automate.py sha256:760d8ed428da2285, sources/power_automate.py sha256:d3d5582f9968f4f5, transforms/web_scrape.py sha256:ef6e828ace325e3c).

## Tier-model signatures
None rotated.

## Caveats
Full suite not run by the lane (orchestrator verify runs it).
