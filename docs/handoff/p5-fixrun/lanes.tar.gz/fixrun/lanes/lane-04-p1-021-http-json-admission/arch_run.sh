#!/bin/bash
cd /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/worktrees/lane-p1-021-http-json-admission
export PYTHONPATH=/home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/worktrees/lane-p1-021-http-json-admission/src:/home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/worktrees/lane-p1-021-http-json-admission/elspeth-lints/src
.venv/bin/python -m pytest tests/integration/core/dag tests/unit/architecture -n 2 -v -rf -p no:cacheprovider > /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/lanes/lane-04-p1-021-http-json-admission/g_arch314v.log 2>&1
echo "arch=$?" > /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/lanes/lane-04-p1-021-http-json-admission/g_arch314v.done
