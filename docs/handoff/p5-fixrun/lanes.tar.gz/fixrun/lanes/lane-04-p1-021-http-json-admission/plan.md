# lane-04-p1-021-http-json-admission — #21 GENERIC HTTP JSON parsing admits overflow floats and deep nesting that the audit writer cannot canonicalize; the call raises ValueError/RecursionError with no audit record

Ticket `p1-021-http-json-admission` · run `p1` · branch `lane/p1-021-http-json-admission` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

FINDING #21 [P1] GENERIC HTTP JSON parsing admits overflow floats and deep nesting that the audit writer cannot canonicalize; the call raises ValueError/RecursionError with no audit record
File: src/elspeth/plugins/infrastructure/clients/http.py
Sweep evidence: _parse_response_body (http.py:424-434), GENERIC branch, calls contracts.json_parser.parse_json_strict. That parser rejects the NaN/Infinity literals but has no parse_float hook and no depth bound. So a remote body like {"x": 1e999} parses to float('inf'), and an array nested about 498 levels deep (about 1 KB) parses without error. In both cases the body goes into HTTPCallResponse without the canonical check that the POWER_AUTOMATE_V1 branch applies: _policy_json_body uses finite_float plus check_json_depth(max_depth=64) (http.py:180-205), and _build_response_payload calls canonical_json (http.py:935-940).

What happens next:
- request_ssrf_safe (used by web_scrape, blob_fetch and azure_search): the success-path self._record_call at http.py:2060 reaches the recorder's stable_hash/canonical_json (core/landscape/execution/calls.py:334-342). That raises ValueError('Cannot canonicalize non-finite float: inf'). For the deep body, _build_response_payload itself raises RecursionError inside the try. The except handler at http.py:1982-1983 then calls _build_response_payload again, raises again, and nothing is recorded.
- _execute_request (post/get, used by openrouter, gateway, content_safety, prompt_shield and doc-intel): _build_response_payload and _record_and_emit run outside the try (http.py:1561, 1585), so it fails the same way.

Result: a request that was actually sent leaves no Landscape Call row, which breaks the 'every external call is recorded' invariant. A Tier-3 response also escapes as a bare ValueError/RecursionError instead of an httpx error. Callers catch only httpx and SSRF exception types (web_scrape.py:1945-1967, blob_fetch.py:720-741, openrouter.py:437-464), so any remote server can crash the transform rather than having the row routed to on_error.

Expected behaviour: apply the same bounded-depth, finite-float, canonical-admissible check in the GENERIC branch and record a _json_parse_failed sentinel, as POWER_AUTOMATE_V1 already does. Then the call is recorded as SUCCESS/ERROR with sanitized evidence, and callers keep getting a routable result.

Verification:
- parse_json_strict('{"x": 1e999}') returns ({'x': inf}, None). canonical_json({'x': inf}) raises ValueError.
- Probe script /tmp/claude-0/-home-user-elspeth/35e9058a-baa7-5887-beaa-b37b81fdf62f/scratchpad/inf_probe.py drives get_ssrf_safe with a patched httpx.Client and a recorder double that hashes like the real recorder. Body 1e999 gives 'RAISED ValueError ... recorded 0'. Control body 1.5 gives 'OK recorded 1'. A 900-deep array gives 'RAISED RecursionError recorded 0'. A 40-deep control gives 'OK recorded 1'.
- Bisection: depth 498 is the first that fails stable_hash(HTTPCallResponse(...).to_dict()).
- rg finds no test under tests/ that exercises 1e999 or overflow in the HTTP client or web_scrape/blob_fetch/llm tests.
Independent verifier (CONFIRMED): http.py:424-434 GENERIC branch uses parse_json_strict (contracts/json_parser.py:29-35: parse_constant only, no parse_float hook, no depth bound); only POWER_AUTOMATE_V1 goes through _policy_json_body (http.py:180-205) and the canonical_json admission in _build_response_payload (http.py:931-940, guarded by `if deadline is not None`, which is set only for POWER_AUTOMATE_V1). Recorder hashes response via stable_hash/canonical_json in core/landscape/execution/calls.py:331-342 before any insert, and base._record_call (clients/base.py:155-230) does not catch. Ran .claude/lanes/20261111-plugins-review/scratch-D/inf_probe.py (get_ssrf_safe): 1e999 -> 'RAISED ValueError Cannot canonicalize non-finite float: inf ... recorded 0'; 1.5 -> 'OK recorded 1'; 900-deep array -> 'RAISED RecursionError recorded 0'; 40-deep -> 'OK recorded 1'. Ran .claude/lanes/20261111-plugins-review/scratch-D/inf_probe_post.py (post/_execute_request path, client constructed under the httpx.Client patch): 1e999 -> ValueError recorded 0; deep -> RecursionError recorded 0; 1.5 -> OK recorded 1 SUCCESS. web_scrape.py:1945-1967 catches only httpx/SSRF types, so the ValueError/RecursionError escapes the transform. No escape found.
Verifier repro scripts (gitignored, read-only reference): .claude/lanes/20261111-plugins-review/scratch-*/ in /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta

## Files a correct fix must change

- `src/elspeth/plugins/infrastructure/clients/http.py`

## Test files the lane must add or change

- `tests/unit/plugins/infrastructure/clients/test_http_json_canonical_admission.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/infrastructure/clients/test_http_json_canonical_admission.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-04-p1-021-http-json-admission/report.md`; the worker returns one line.
