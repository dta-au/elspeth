FIXED (arch/DAG gate unconfirmed): #21 GENERIC HTTP JSON now gets a depth-64 bound, finite-float and canonical_json admission and records a _json_parse_failed sentinel (shared helper contracts.json_parser.parse_json_bounded). Lane commits 62a11ffc (test, RED 14 failed at assertions) and 9a964e68 (fix, GREEN 20 passed) on 21e74acc, Python 3.14.6.

## Root cause
src/elspeth/plugins/infrastructure/clients/http.py `_parse_response_body`, GENERIC branch (base lines 424-434), parsed JSON with `contracts.json_parser.parse_json_strict`. That parser has no parse_float hook and no canonical-domain check, and on base it bounds depth only at sys.getrecursionlimit(). Three kinds of body were admitted: `1e999`, which becomes inf; a 900-deep array; and integers outside ±(2**53-1). `core/landscape/execution/calls.py` runs `stable_hash` on the response before any insert, and it raised ValueError, RecursionError or IntegerDomainError. So no Call row was written, and the exception escaped through both post()/_execute_request and get_ssrf_safe/request_ssrf_safe. The POWER_AUTOMATE_V1 branch was already guarded by `_policy_json_body` and `canonical_json`.

## Fix
- `src/elspeth/contracts/json_parser.py`: new shared helper `parse_json_bounded(text, *, max_depth) -> (parsed, error)`. It runs check_json_depth before decoding, then rejects duplicate keys, NaN/Infinity and overflow floats (parse_float hook). It does not check the canonical integer domain, because contracts cannot import core. Callers that hash the result must still run canonical_json. **Later lanes can reuse this helper.**
- `http.py`: the GENERIC branch now uses `parse_json_bounded(response.text, max_depth=GENERIC_JSON_MAX_DEPTH)`. The new constant is 64, the same as PA and MAX_JSON_DEPTH. It then requires `canonical_json(parsed)` and catches (ValueError, UnicodeError), as the PA branch does. Any refusal produces the existing sentinel `{_json_parse_failed, _error, _raw_text[:10000]}`, so the call is recorded and the client returns normally. The unused `parse_json_strict` import was removed. The PA branch is unchanged.
- Compatibility: some GENERIC bodies are now recorded as the sentinel instead of the parsed body: those nested deeper than 64, those with overflow floats, and those with integers outside ±(2**53-1). The real recorder could never record any of these, so no working audit record is lost.
- The existing pin `tests/unit/plugins/clients/test_http_power_automate_policy.py::test_generic_unsafe_integer_parsing_is_unchanged` pinned the defect. Its recorder fake does not hash, and 2**53 fails stable_hash (measured). It is rewritten as `test_generic_unsafe_integer_is_recorded_as_parse_failure`. Typing in the new test was also tidied: cast(CallRecorder) and `__exit__ -> None`.

## Rebase
- The lane was first rebased onto c198cee8; the only conflict was json_parser imports, which now keep both `math` and `sys`.
- After the hub rebuilt the base, I ran `git rebase --onto claude/compassionate-brahmagupta-o0nhlw c198cee8`. It was clean. `git log base..HEAD` shows only 62a11ffc and 9a964e68.
- The base's own recursion-limit depth check in parse_json_strict is kept. The venv is 3.14.6, and elspeth/elspeth_lints `__file__` were verified inside the worktree.

## Evidence (21e74acc, Python 3.14.6)
- RED: detached temp worktree at 62a11ffc, test file only, `-n 0`. Result: exit=1, 14 failed, 6 passed. Every failure is an AssertionError, for example "Tier-3 body escaped the client unrecorded as ValueError: Cannot canonicalize non-finite float: inf", "... as RecursionError ...", "... as IntegerDomainError ..." and "contracts.json_parser must export parse_json_bounded". The 6 controls passed. Log: red314.log.
- GREEN: HEAD 9a964e68, exit=0, 20 passed (green314.log).
- The same RED/GREEN result was also measured on 1a7ff0e6 (3.13) and on c198cee8 (3.14).

## Gates (HEAD 9a964e68, 3.14)
- ruff check src/ tests/: exit 0
- ruff format --check src/ tests/: exit 0
- scripts/check_contracts.py: exit 0 (census unchanged)
- mypy on the 3 touched src/test files: exit 0
- pytest -n 2 over the clients dirs, test_power_automate.py and every test file referencing AuditedHTTPClient, _json_parse_failed or json_parser: exit 0, 3417 passed
- test_masquerade_gate.py: exit 0. No getattr/hasattr was added; the tests use vars(module).
- `tests/integration/core/dag tests/unit/architecture -n 2`: **NOT CONFIRMED.**
  - Three runs, two of them on the earlier bases, were killed by the tool's 2 h background cap at 44-92% under host load ~16 on 4 CPUs. The run on 21e74acc showed 8 'F' marks without names. The same early failure appeared at ~15% on 1a7ff0e6 and on c198cee8 as well.
  - Reasons to think these failures are not caused by this fix: http.py and json_parser.py carry no source_file_hash pin, and grep finds no reference to them in tests/unit/architecture, tests/integration/core/dag or the scenario manifest. The hub also says tests/unit/cicd is red on 21e74acc for reasons outside this lane.
  - A detached verbose re-run is in progress: script arch_run.sh, log g_arch314v.log, exit code in g_arch314v.done (all in this lane dir). **The hub must name those failures and compare them against 21e74acc before merging.**
- Tier-model keyless scan (on 1a7ff0e6): one new R6 finding at http.py `except (ValueError, UnicodeError) as canonical_error:` in `_parse_response_body`. It mirrors the existing unallowlisted PA line, and the error is turned into a recorded sentinel, not swallowed. It is left for adjudication. Allowlist ast_paths for http.py are unchanged: the AuditedHTTPClient body index was measured equal before and after.
- No signature edits and no suppressions.

## Left alone
Other Tier-3 parse_json_strict callers still lack the same admission: retrieval/azure_search.py:482, dataverse.py:623, transforms/azure/base.py:542, document_intelligence.py:733 and llm/pricing.py:22. Callers that re-parse response.text themselves are also unchanged. All of these can adopt parse_json_bounded + canonical_json. Nothing was pushed.

## Addendum after handback
The detached verbose arch/DAG re-run (g_arch314v.log) had 0 FAILED lines at 55% (2026-11-11T12:15:53Z). The run continues; the exit code will be in g_arch314v.done.
