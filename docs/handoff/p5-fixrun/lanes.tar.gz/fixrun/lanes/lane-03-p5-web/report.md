lane-03-p5-web: #5 fingerprint_mode 'full' hashes the extracted content plus each page's status, final URL (persisted form), raw Content-Type and raw-body SHA-256 ('content' unchanged); one httpx-exact predicate in core/security/web.py makes every SSRF/origin helper refuse C0+DEL as malformed_url even with empty origins (web_scrape, blob_fetch, Dataverse request+nextLink, browser, links, pagination). RED 53 failed at assertions on base; GREEN 61 passed; commits 0c9fb487 4ec0edfa fb45df0f 55eef5bf; ruff/mypy/contracts/plugin lints 0; no tier-model fingerprints rotated.

(Written by orchestrator from the lane's hand-back; the harness refused the lane's report write.)

CHANGELOG:
- Fixed: web_scrape fingerprint_mode 'full' now covers the exact extracted content plus each page's HTTP status, final URL, Content-Type and raw-body hash (previously it hashed only the extracted content) (#5).
- Fixed: the shared SSRF and origin URL checks refuse C0 and DEL characters as malformed_url for every caller, even with no allowed origins configured; such URLs previously crashed the run with an uncaught httpx.InvalidURL (blob_fetch) or were admitted (Dataverse).

COMPAT:
- Every existing 'full' fingerprint value changes: the first run after upgrade reports every page as changed. 'content' unchanged.
- compute_fingerprint(..., "full") without response context raises ValueError.
- validate_allowed_http_origin: TypeError for non-str URL and control-character refusal now apply even with no origins configured; a control-character refusal is reported as malformed_url instead of origin_not_allowed.
- Hash: WebScrapeTransform sha256:ef6e828ace325e3c -> sha256:88de403a6a8fcdb5 (blob_fetch unchanged).

Unresolved: Power Automate / retrieval / Azure Search inherit via the shared helpers but have no caller-specific test; control char inside a redirect Location not separately tested (httpx.URL() at http.py ~2318 runs before validation).
