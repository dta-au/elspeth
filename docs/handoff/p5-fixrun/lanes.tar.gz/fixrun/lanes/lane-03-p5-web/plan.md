# lane-03-p5-web — #5 web_scrape fingerprint_mode 'full' must hash the full fetch response context it claims (fix behaviour, not description); shared SSRF/origin URL helpers refuse DEL and C0 control characters

Ticket `p5-web` · run `p5` · branch `lane/p5-web` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

Maintainer ruling 2026-11-14: fix behaviour. #5 was 'fixed' by rewording the description; make 'full' do what its name says (decide the exact covered context from the finding text and document it), keep 'content' unchanged. Second item: core/security/web.py validate_url_for_ssrf and validate_allowed_http_origin still admit DEL, and with empty origins admit all control characters (web_scrape fixed only its own path, see lane-05-p1-002 report). Refuse C0+DEL exactly like the web_scrape predicate (httpx's), for every caller; find and test every caller. Findings: .claude/lanes/fixrun/p4/plugins-review.md #5; .claude/lanes/fixrun/lanes/lane-05-p1-002-webscrape-control-char-url/report.md.

## Files a correct fix must change

- `src/elspeth/plugins/transforms/web_scrape_fingerprint.py`
- `src/elspeth/core/security/web.py`

## Test files the lane must add or change

- `tests/unit/plugins/test_p5_web_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/test_p5_web_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-03-p5-web/report.md`; the worker returns one line.
