lane-06-p3-batch: all 10 P3 batch findings (#20, #99, #107, #108, #113, #115, #117, #118, #119, #140) fixed on lane/p3-batch (HEAD 66a09392), 20 commits test-then-fix; lane tests 30 fail/3 controls pass on base, 33/33 at HEAD; one mixin.py tier-model allowlist entry needs operator re-sign.

(Written by orchestrator from the lane's hand-back; report.md write was refused to the subagent.)

## Fixes
- #20 composer hints advertise the 4096-row flush cap on batch_outlier_annotator, batch_rank, batch_paired_preference, batch_drift_compare (config-time trigger.count validator left for maintainer).
- #99 batch_stats sum: int beyond 2^53-1, OverflowError and non-finite float sums -> recorded float_overflow error, operation `sum` (existing mean-overflow tests re-pinned to `sum`).
- #107/#115/#117 shared ConfiguredScalarLabel (StrictStr|StrictInt|StrictFloat|StrictBool) + require_matchable_configured_label in _scalar_buckets.py; blank strings and non-finite floats refused; knob goldens regenerated. experiment_compare baseline no longer string-only.
- #108 paired_preference 95% CI uses Student t at n-1 df (exact bisection, cached); n=3 pin ±0.3395 -> ±0.7452.
- #113 classifier positive_label type mismatch -> validation_failed/positive_label_type_mismatch (types only, no values); config StrictStr|StrictInt|StrictBool.
- #140 data-quality distinct count O(n) via scalar_bucket_key set.
- #118 mixin `_raise_orphaned_late_failure`: Tier-1 re-raised; others -> FrameworkBugError naming the timed-out row's token_id/state_id.
- #119 OutputPort.fail_pending (ports.py, Null/Collector impls, SharedBatchAdapter.fail_pending in engine/batch_adapter.py); release-loop crash delivered to waiters.

## Evidence (lane-reported)
- Static: ruff check/format, check_contracts, mypy (13 files), plugin_hashes lint all exit 0.
- Chunks: lane+adjacent 189 passed; gA 416 passed; gC 194 passed; gB 1 failed (dag_recovery_partial_terminal timeout, also fails on base under load); gD 2 failed (rag template worker readiness timeouts, pass serially); gE killed at 1700s timeout.
- Keyless trust-tier scan diff: only the mixin `_complete_ticket` R5 allowlist fingerprint churn (operator re-sign).

## Left alone
- batch_experiment_compare.py:424-425 still z=1.96 (different statistic).
- batch_stats mean-overflow branch now effectively unreachable for int input; kept.
- Full suite not run by lane.
