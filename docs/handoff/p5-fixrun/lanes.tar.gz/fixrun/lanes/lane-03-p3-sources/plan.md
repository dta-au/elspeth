# lane-03-p3-sources — #11 [P3 (raised as P2), bug] aws_s3 CSV source accepts a blank first line as an empty header; a blank-only object yields zero rows with no audit record; #42 [P3, bug] JSONL source drops valid lines before and after a single undecodable code unit for UTF-16/32, contradicting its 'subsequent valid lines still processed' contract; #43 [P3, enhancement] JSON source does not tolerate a UTF-8 BOM: a BOM-prefixed JSON array file is quarantined whole (JSONL loses line 1), unlike CSV which strips it; #51 [P3, bug] blob_csv_expand accepts delimiters that csv.reader rejects, so the error surfaces at row time instead of config time; #52 [P3, enhancement] max_blob_bytes is checked only after the whole blob is read into memory; retrieve_bounded is not used; #137 [P3 (raised as P2), bug] text source: a decode error mid-file in a non-ASCII-compatible encoding drops the valid lines before it and records the wrong line number

Ticket `p3-sources` · run `p3` · branch `lane/p3-sources` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

This lane fixes 6 findings; fix each one (one test commit + one fix commit PER finding).
Every finding names the files where the sweep located it; touch only what each fix needs.

FINDING #11 [P3 (raised as P2), bug] aws_s3 CSV source accepts a blank first line as an empty header; a blank-only object yields zero rows with no audit record

`src/elspeth/plugins/sources/aws_s3_source.py`

_load_csv reads the header with a bare next(reader) (aws_s3_source.py:1141). csv.reader yields [] for a blank line, and resolve_field_names(raw_headers=[]) accepts it, so headers=[]. Measured: b'\nid\n1\n' quarantines every data row with 'CSV parse error: expected 0 fields, got 1', when the header 'id' should be found. b'\n\n' and b'\r\n' yield zero rows and zero record_validation_error calls, but b'' quarantines with 'empty file contains no header row'. A blank-only object therefore 'succeeds' silently with no rows. The sibling csv_source skips blank records before the header via next_nonblank_record() (csv_source.py:382) and records the empty-file case. The S3 data loop already skips blank records (1212-1213), so the header path is the inconsistent one. Expected: skip blank records before the header, and if none remains, take the existing 'empty file contains no header row' file-error path.

**Verifier (CONFIRMED):** Read aws_s3_source.py:1139-1158: header read is a bare next(reader) with no blank skip; data loop skips blanks at :1212-1213. Repro .claude/lanes/20261111-plugins-review/scratch-B/repro_s3.py: b'\nid\n1\n' -> two quarantines 'CSV parse error: expected 0 fields, got 1' (header 'id' treated as a data row); b'\n\n' and b'\r\n' -> zero rows and zero validation errors; b'' -> file-error 'empty file contains no header row'. Sibling csv_source.py:354-383 uses next_nonblank_record() for the header. Real inconsistency; impact is narrow (blank-led objects), the first case is at least visible via quarantine, so P3.

FINDING #42 [P3, bug] JSONL source drops valid lines before and after a single undecodable code unit for UTF-16/32, contradicting its 'subsequent valid lines still processed' contract

`src/elspeth/plugins/sources/json_source.py`

_load_jsonl (json_source.py:306-363) relies on errors='surrogateescape' to isolate bad bytes per line. For UTF-16/32 that handler cannot repair every error (for example a lone surrogate), so the TextIOWrapper raises UnicodeDecodeError while decoding a whole buffered chunk. The outer handler at 350-363 then records one parse error at line_num+1 and ends the generator. Verified: a UTF-16 JSONL file with valid line 1, a lone 0xDC00 code unit, then valid lines 2-4 yields only one quarantined row {'file_path', '__line_number__': 1}. Valid line 1, which comes before the corruption, is also lost, along with every line after it. The reported line number is wrong, and the run completes with zero valid rows and no record of how many lines were skipped. The docstring (301-305) promises that subsequent valid lines are still processed. The existing test (test_json_source.py:1247) covers only truncation at end of file. Expected: decode incrementally per line (read bytes, split on the encoded newline, decode each line) so one bad line is quarantined and the rest are read. Failing that, record that the remainder of the file was abandoned and report the correct position.

FINDING #43 [P3, enhancement] JSON source does not tolerate a UTF-8 BOM: a BOM-prefixed JSON array file is quarantined whole (JSONL loses line 1), unlike CSV which strips it

`src/elspeth/plugins/sources/json_source.py`

With the default encoding='utf-8' (line 101), json.load/json.loads reject a leading U+FEFF ('Unexpected UTF-8 BOM'). Verified: a '﻿[{"id": 1}]' file yields a single file-level quarantine and zero rows (line 376 path). A BOM-prefixed JSONL file quarantines line 1 and keeps the rest (line 333 path). Windows tooling commonly writes such files (PowerShell 5 Out-File / Set-Content -Encoding UTF8). The CSV sibling handles a BOM by stripping it during header normalization (field_normalization: normalize_field_name('﻿id') == 'id', test_field_normalization.py:70-73). rg 'utf-8-sig|ufeff|BOM' over plugins/sources/json_source.py and its tests finds no BOM handling or test. Expected: default to or accept 'utf-8-sig' semantics for UTF-8 input, stripping a leading BOM, so a valid file is not wholly quarantined.

FINDING #51 [P3, bug] blob_csv_expand accepts delimiters that csv.reader rejects, so the error surfaces at row time instead of config time

`src/elspeth/plugins/transforms/blob_csv_expand.py`

blob_csv_expand.py:109-114 `_validate_delimiter` checks only `len(value) == 1`. Python's csv module also rejects '"' (the default quotechar), '\n' and '\r'. `_parse_csv` (line 708) builds `csv.reader(stream, delimiter=..., strict=True)` outside every try/except, so the ValueError escapes `process()` as an uncaught plugin exception on the first row rather than being refused when config loads. Verification: in the worktree venv, `BlobCSVExpandConfig.from_dict({'schema':{'mode':'observed'},'source':'field','text_field':'content','delimiter':'"'})` is accepted. Constructing `BlobCSVExpand` with that config also succeeds. Calling `_parse_csv('a,b\n1,2\n', base_fields=frozenset())` then raises `ValueError: bad delimiter or quotechar value`; '\n' raises `ValueError: bad delimiter value`. The fix is to reject these characters in the validator, or to build a probe `csv.reader` there, so that validate_transform_config and the engine path both refuse the config. The csv source has the same validator (src/elspeth/plugins/sources/csv_source.py:67-71), so the fix should be shared. No test under tests/unit/plugins/transforms/test_blob_csv_expand.py covers delimiter validation; rg finds 'delimiter' in a blob_csv_expand test path only in the golden knob schema.

FINDING #52 [P3, enhancement] max_blob_bytes is checked only after the whole blob is read into memory; retrieve_bounded is not used

`src/elspeth/plugins/transforms/blob_csv_expand.py`

blob_csv_expand.py:613 calls `self._payload_store.retrieve(blob_ref)` and only afterwards, at lines 638-648, compares `len(body)` with `max_blob_bytes`. The option is described as the 'Maximum payload size accepted from the blob store', but it does not limit memory or I/O: a multi-GB blob is read in full, and integrity-hashed, before it is refused. `PayloadStore.retrieve_bounded(content_hash, *, max_bytes)` exists for this case (src/elspeth/contracts/payload_store.py:76-83: it 'must stop reading after max_bytes + 1 bytes' and keeps retrieve()'s missing/corrupt exception behaviour), and web_scrape.py:1294 and several engine paths already use it. Expected: call `retrieve_bounded(blob_ref, max_bytes=self._max_blob_bytes)` and route `None` as blob_too_large, with an exact size only when known. The same retrieve-then-measure pattern is in blob_json_expand.py:714, blob_text_expand.py:391 and pdf_rasterize.py:593.

FINDING #137 [P3 (raised as P2), bug] text source: a decode error mid-file in a non-ASCII-compatible encoding drops the valid lines before it and records the wrong line number

`src/elspeth/plugins/sources/text_source.py`

text_source.py:164-209. The file is opened with errors="surrogateescape". That only rescues ASCII-compatible codecs. For utf-16/utf-32 an illegal code unit raises UnicodeDecodeError while TextIOWrapper decodes a whole read-ahead chunk (about 8KB). The handler at 200-209 then sets __line_number__ = line_num + 1 and source_row_index = line_num, but line_num counts lines already yielded, not the line that failed. Valid lines in the same chunk before the bad bytes are never yielded and are never audited. Every line after the bad bytes is also lost, and nothing records how many. Reproduced against the real plugin with make_context: content "a\nb\n" + b"\x00\xd8" + "c\nd\ne\n" in utf-16-le gives exactly one quarantined row, {'__line_number__': 1, source_row_index 0}. Rows a and b (valid, before the corruption) and c, d, e never appear in any form, and the reported line 1 is wrong (the corruption is on line 3). The only test, test_truncated_utf16_decode_error_uses_next_source_row_index, truncates at end of file, where the final-chunk decode has already yielded earlier lines, so it does not exercise this. The csv source sibling (csv_source.py:247-258) avoids inventing a line number for file-level decode failures ('Don't fabricate'). Expected: no invented __line_number__/source_row_index when the failing line is unknown, plus an audited record that the rest of the file was abandoned. Alternatively, decode line-by-line from bytes so preceding lines are not lost.

**Verifier (CONFIRMED):** Read text_source.py:164-209: errors='surrogateescape' cannot rescue utf-16 surrogate errors; handler uses line_num+1 of lines already yielded. Repro .claude/lanes/20261111-plugins-review/scratch-B/test_scratch_decode.py: 'a\nb\n' + b'\x00\xd8' + 'c\nd\ne\n' in utf-16-le -> exactly one quarantined row {'__line_number__': 1}, source_row_index 0; lines a, b (valid, before corruption) and c, d, e never appear and nothing records the abandonment. Same chunked-decode mechanism as #80. Only reachable with non-ASCII-compatible encodings (utf-16/32), so P3.

## Files a correct fix must change

- `src/elspeth/plugins/sources/json_source.py`

## Test files the lane must add or change

- `tests/unit/plugins/sources/test_sources_p3_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/sources/test_sources_p3_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-03-p3-sources/report.md`; the worker returns one line.
