lane-03-p3-sources: all 6 findings (#11, #42, #43, #51, #52, #137) fixed test-then-fix on lane/p3-sources (12 commits, HEAD f60cb687, base 1ee11f2e); 12 lane tests fail at assertions on base, pass at HEAD.

(Written by orchestrator from the lane's hand-back; the subagent's report.md write was refused.)

## Fixes
- #11 aws_s3 CSV skips blank records before header discovery; blank-only object -> existing empty-file error.
- #42 json_source registers codec error handler BYTE_ESCAPE_ERRORS ("elspeth.source_byte_escape"); undecodable UTF-16/32 JSONL line quarantined alone with true __line_number__ / __raw_bytes_hex__.
- #43 JSON source reads utf-8 as utf-8-sig (leading BOM accepted; mid-file U+FEFF still data).
- #51 shared validate_csv_delimiter() in infrastructure/config_base.py (csv.reader strict probe); only blob_csv_expand uses it — other source/sink delimiter validators left (re-pin churn), finding's "shared" ask half done.
- #52 blob_csv_expand reads with retrieve_bounded; blob_too_large without body_size (COMPAT).
- #137 text_source uses BYTE_ESCAPE_ERRORS; per-line quarantine.

## Re-pins
- AWSS3Source f203696d50207e25; JSONSource c299bae1329a63c2 (manifest token + EXPECTED_CASE_REGISTRY_SHA256 68e95dc0…); BlobCSVExpand ca4a5b4f566b7fd7; TextSource 1010c5ab7ec5d18f.
- Merge risk: registry SHA / JSONSource token conflicts with other lanes -> re-capture on merged tree.

## Evidence (lane-reported)
- RED 12 failed (all AssertionError) on git archive of 1ee11f2e; GREEN 12 passed; modules 660 passed; corpus contract 459 passed.
- ruff/format/check_contracts/mypy 0; fencing_inventory pinned==live (283), no writer added.
- Keyless trust-tier corpus comparison NOT run (host memory) — hub/operator to check.

## Compatibility
- UTF-16/32 undecodable lines quarantined per line; __raw_bytes_hex__ holds true codec bytes.
- BYTE_ESCAPE_ERRORS registered process-wide on json_source import (namespaced).
