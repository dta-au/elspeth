# lane-05-p2-124-147-llm-tracing — #124 [P2, bug] azure_ai tracing configures process-global Azure Monitor and then fails on an undeclared dependency; a later run with a conflicting content-recording policy is silently accepted; #147 [P2, security] Tracing privacy flags are not type-checked: the string "false" turns content recording ON

Ticket `p2-124-147-llm-tracing` · run `p2` · branch `lane/p2-124-147-llm-tracing` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

This lane fixes 2 findings; fix each one (one test commit + one fix commit PER finding).
The listed files are where the sweep located each defect; a finding may need no change in some of them.

FINDING #124 [P2, bug] azure_ai tracing configures process-global Azure Monitor and then fails on an undeclared dependency; a later run with a conflicting content-recording policy is silently accepted

`src/elspeth/plugins/transforms/llm/providers/azure.py`

In _configure_azure_monitor (azure.py:399-448), configure_azure_monitor(...) runs at line 423 and only then is azure.ai.inference.tracing.AIInferenceInstrumentor imported (line 436), raising ImportError if absent. azure-ai-inference is not declared in any pyproject extra: rg over pyproject.toml shows only azure-monitor-opentelemetry and the exporter in [azure] and [all]. It is also not installed in the project venv: site-packages has azure_monitor_opentelemetry but no azure_ai_inference. So on a standard elspeth[azure] install, any azure_ai tracing config wires the process-global App Insights exporter, then raises out of on_start (callers: transform.py:1877, sources/llm/source.py:326). The exporter stays live, _azure_monitor_configured stays False, and the next attempt in the same process calls configure_azure_monitor again. Separately, once the flag is True, a later call with a different connection_string or enable_content_recording (for example a second plugin, or a later run in a long-lived web worker) logs a warning and returns True (lines 410-414). The comment at 428-434 calls enable_content_recording policy-bearing and says the code fails closed, yet a request to disable content recording is silently overridden by an earlier enable. tracing.py:64-65 documents 'first one wins', but that does not cover a policy conflict. The instrumentor also instruments the azure-ai-inference SDK, while this provider calls openai.AzureOpenAI, so the policy is applied to a client the provider does not use. That last point is plausible but I did not verify it at runtime, because the package is not installed. Expected: check the dependency before any process-global side effect, declare it in the azure extra (or drop the instrumentor path), and refuse a second configuration whose connection_string or enable_content_recording differs from the active one. Tests in tests/unit/plugins/llm/test_p1_bug_fixes.py inject a recording instrumentor, so the import-ordering failure and the conflicting-policy case are not exercised.

**Verifier (CONFIRMED):** Repro scratch-F/r124.py patches configure_azure_monitor to a recorder and calls providers/azure.py::_configure_azure_monitor twice with a valid azure_ai config. Each call invokes configure_azure_monitor (call count 1, then 2) and then raises ImportError, and _azure_monitor_configured stays False. The process-global exporter is set up before the dependency check (azure.py:423 vs 435-443). '.venv/bin/python -c "import azure.ai.inference"' gives ModuleNotFoundError. grep finds no azure-ai-inference in pyproject.toml or uv.lock. The [azure] extra (pyproject.toml:147-153) declares only azure-monitor-opentelemetry plus the exporter. With the flag set True, a second config with a different connection_string and enable_content_recording=True logs a warning and returns True (azure.py:409-414): the conflicting policy is silently accepted. Not verified at runtime: whether AIInferenceInstrumentor affects the openai.AzureOpenAI client. By design it instruments the azure-ai-inference SDK, so it plausibly does not.

FINDING #147 [P2, security] Tracing privacy flags are not type-checked: the string "false" turns content recording ON

`src/elspeth/plugins/transforms/llm/tracing.py`

tracing.py:77-86 and 118-147: AzureAITracingConfig / LangfuseTracingConfig are plain dataclasses, and parse_tracing_config (:177-183) passes the untyped `tracing: dict[str, Any]` straight into them. Nothing checks the types of enable_content_recording, enable_live_metrics or tracing_enabled. The ${VAR} expansion in core/config.py:2491 (_expand_env_string) always returns str, so `enable_content_recording: ${RECORD_PROMPTS:-false}` becomes the string 'false'. providers/azure.py:445 passes that straight to AIInferenceInstrumentor().instrument(enable_content_recording=config.enable_content_recording), and the string is truthy, so full prompts and responses (row content/PII) go to Application Insights even though the operator asked for false. The default is already True (:79). Verified: parse_tracing_config({'provider':'azure_ai','connection_string':'x','enable_content_recording':'false'}) returns enable_content_recording='false' with no error, and the same holds for Langfuse tracing_enabled='false'. connection_string, public_key and secret_key are also only checked for None, so '' or a non-str value is accepted. Expected: refuse any non-bool policy flag and any empty or non-str credential at construction, fail-closed, as is already done for host at :136. tests/unit/plugins/llm/test_tracing_config.py has no string-bool case.

**Verifier (CONFIRMED):** Repro scratch-F/r124.py. parse_tracing_config({'provider':'azure_ai','connection_string':'x','enable_content_recording':'false'}).enable_content_recording == 'false' (a truthy str), and connection_string='' is accepted. For Langfuse with host set, tracing_enabled='false' is kept as 'false' (bool('false') is True) and goes straight to Langfuse(tracing_enabled=...) at langfuse.py:294. tracing.py:77-86 and 118-147 are plain dataclasses that type-check only host (:136), and parse_tracing_config (:173-183) splats untyped dict values. core/config.py:2491-2508 _expand_env_string returns str, so ${VAR:-false} yields 'false'. No pydantic validation was found upstream: transform.py:1544-1545 notes that tracing is dict[str, Any]. Mitigation: the azure_ai path currently cannot reach instrument() on a standard install (see #124 ImportError). The Langfuse path is live.

## Files a correct fix must change

- `src/elspeth/plugins/transforms/llm/tracing.py`
- `src/elspeth/plugins/transforms/llm/providers/azure.py`

## Test files the lane must add or change

- `tests/unit/plugins/llm/test_tracing_p2_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/llm/test_tracing_p2_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-05-p2-124-147-llm-tracing/report.md`; the worker returns one line.
