DONE: #124 and #147 fixed on lane/p2-124-147-llm-tracing (e6577272 test#124, 244b145f fix#124, b06510fb test#147, eba03611 fix#147). The lane test went from failing to passing: 34 passed.

(The hub wrote this from lane-05's hand-back, because the harness refused the lane's own report write. Its logs are in this lane dir.)

## #124
**Root cause.** In azure.py `_configure_azure_monitor`:
- It configured process-global Azure Monitor, and only after that imported AIInferenceInstrumentor. If that import failed, the exporter was left live and the guard flag stayed unset.
- A later call with a conflicting config only logged a warning and returned True.

**Fix.**
- The instrumentor is imported first.
- The applied config is stored in `_active_azure_monitor_config`. A call with an identical config is idempotent. A call that differs in connection_string, enable_content_recording or enable_live_metrics raises ValueError, naming the fields without echoing their values.
- `test_transform.py::test_real_sdk_typeerror_propagates` now injects the fake instrumentor.

**RED:** 4 failed:
- "process-global Azure Monitor was configured before the dependency check"
- 3 × DID NOT RAISE ValueError

**GREEN:** 4 passed.

## #147
**Root cause.** The tracing dataclasses did no type checks, so the string "false" was truthy and enabled content recording and Langfuse tracing.

**Fix.** `__post_init__` now calls two checks:
- `_require_bool`, which requires `type is bool` for the three flags.
- `_require_credential`, which requires a non-blank str for connection_string, public_key and secret_key.

**RED:** 30 × DID NOT RAISE.
**GREEN:** 34 passed.

## Gates
- ruff 0
- format 0
- mypy on the touched files 0
- check_contracts 0
- related LLM and tracing tests at -n 2: 1184 passed
- keyless lints on azure.py and tracing.py: the same 4 findings before and after (R9 at azure.py:274, R6 at azure.py:382, and 2 stale allowlist entries, all present on base)

No re-pins were needed: no source_file_hash lives in the edited files.

## Open choices for the maintainer
1. **azure-ai-inference.** It is still undeclared in the `[azure]` extra, so azure_ai tracing still raises ImportError in on_start, though it now has no side effect. The options are to declare the dependency, drop the instrumentor path, or apply the content policy another way. Note that the provider uses openai.AzureOpenAI, not the azure-ai-inference SDK.
2. **`instrument()` failure.** If `instrument()` raises after configure succeeds, the exporter is still left live, as it is on base.
3. **Second policy in one process.** A second plugin or run in the same process with a different policy now fails instead of silently inheriting the first policy.
