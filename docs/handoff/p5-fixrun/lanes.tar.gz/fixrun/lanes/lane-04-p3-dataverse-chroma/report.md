DONE: lane-04-p3-dataverse-chroma fixed all 9 findings (#48 #49 #75 #76 #82 #85 #92 #93 #94) test-then-fix on lane/p3-dataverse-chroma (HEAD 1c9b6a61, 19 commits incl. fencing re-pin 283->284 / 9a8cb7c5…); 3 fencing tests OOM-unverified on the lane host.

(Written by orchestrator from the lane's hand-back; the subagent's report.md write was refused.)

## Fixes
- #48 Dataverse source select entries validated as logical names; top ge=1. Existing "<literal>" accept case removed (now invalid).
- #49 FetchXML must have exactly one named <entity> under <fetch> — config-time PluginConfigError (two entities now refused too). Two source tests moved from load-time RuntimeError to construction-time PluginConfigError.
- #75 Chroma runtime_preflight / deferred init failure records an ERROR operation call (+verify_call in VERIFY) via _record_operation_error; search() init failure via _record_error.
- #76 DataverseClientError.retry_after typed field; Retry-After delta-seconds and HTTP-date parsed. Nothing consumes it yet (maintainer design call).
- #82 Upsert alternate-key values OData-escape ' as ''. Other unsupported alt-key chars left.
- #85 Dataverse sink lookups whose key is not a field_mapping key refused at config (COMPAT: previously silently ignored).
- #92 Chroma sink on_start refuses an existing collection whose hnsw:space != distance_function.
- #93 Chroma composer hint now says bad id/document diverts per row.
- #94 Chroma upsert ValueError diverts the row (like DataverseSink); _ChromaPayloadRejection removed.

## Re-pins
- source_file_hash: sources/dataverse c84e1f8a147d4255, sinks/dataverse 902733490be9e3cd, chroma_sink 90d3261584bd70d4.
- Fencing _EXPECTED_CALL_COUNT 284, caller SHA 9a8cb7c5… (arrival: ChromaSearchProvider._record_operation_error -> record_operation_call#1).

## Evidence (lane-reported)
- RED on git archive of 10d56017: 24 failed (all assertions) / 7 controls passed; GREEN 31 passed.
- ruff/format/check_contracts/mypy exit 0; module suites all green except one rag fd-leak load flake (passes -n 0).
- Unverified on lane host (OOM): fencing test_required_work_reserve_admission_on_actual_sources, test_required_work_reserve_rejects_protected_instance_formal_recovery, test_no_mutation_alias_wrapper_dynamic_or_raw_write_escape_exists — verify suite covers them.
- Keyless trust-tier scan not run (memory): verify-time/operator check needed.

## Left alone
- Chroma hint mentions on_duplicate skip/error but prepare_effect accepts only overwrite (adjacent, not #93).
