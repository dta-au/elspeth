# lane-04-p3-dataverse-chroma — #48 [P3, bug] Dataverse select entries are not validated as identifiers, so '#' or '&' can silently drop or override $filter/$top; #49 [P3, bug] FetchXML without a named <entity> passes config validation and crashes at load with RuntimeError; #75 [P3 (raised as P2), bug] Chroma runtime_preflight leaves no audit record when the readiness count fails, unlike its Azure Search sibling; #76 [P3, enhancement] Dataverse 429 Retry-After is parsed and then discarded, so throttling backoff ignores the server's value; #82 [P3 (raised as P2), bug] Dataverse sink upsert URL does not OData-escape single quotes in alternate-key values; #85 [P3, bug] Dataverse lookups whose key is not in field_mapping are accepted and silently ignored; #92 [P3, bug] distance_function is silently ignored when the collection already exists; the sibling retrieval provider refuses the mismatch; #93 [P3, bug] Composer hint says a non-string ID or document aborts the whole batch, but the code diverts that row; #94 [P3, architecture] _ChromaPayloadRejection claims an error handler distinguishes it, but nothing catches it and rejected rows are never diverted

Ticket `p3-dataverse-chroma` · run `p3` · branch `lane/p3-dataverse-chroma` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

This lane fixes 9 findings; fix each one (one test commit + one fix commit PER finding).
Every finding names the files where the sweep located it; touch only what each fix needs.

FINDING #48 [P3, bug] Dataverse select entries are not validated as identifiers, so '#' or '&' can silently drop or override $filter/$top

`src/elspeth/plugins/sources/dataverse.py`

_build_query_url (dataverse.py:600-602) joins `select` into `$select=` without encoding, with the comment 'Column names are Dataverse identifiers — safe characters'. Nothing enforces that. validate_select_not_placeholder (lines 202-214) only strips whitespace and rejects operator placeholders, whereas `entity` and `entity_set_name` are held to strict identifier regexes (lines 70-97). With a select entry such as `fullname#x`, the built URL becomes `.../contacts?$select=fullname#x&$filter=...&$top=25`. urlsplit treats everything after `#` as a fragment. core/security/web.py:545-550 keeps the fragment on the connection path, and the HTTP client never sends fragments, so the configured $filter and $top are silently dropped and the source reads the whole table. A select entry such as `fullname&$filter=...` instead injects or overrides query options. The composer LLM can author `select`, so this is a realistic gap in config validation. A related gap: `top` (line 147) has no `ge=1` bound, so `top: 0` or a negative value only fails at run time with an HTTP 400. Expected behaviour: validate each select entry with _validate_dataverse_logical_name (lookup columns such as `_x_value` still match `^[a-z_][a-z0-9_]*$`), and bound top >= 1. Verification: read the validators and the URL builder, traced connection_url in core/security/web.py:476-483 and 545-550, and found that the tests (test_dataverse_source.py:553-565, 1111-1146) cover only placeholder and plain identifier cases.

FINDING #49 [P3, bug] FetchXML without a named <entity> passes config validation and crashes at load with RuntimeError

`src/elspeth/plugins/sources/dataverse.py`

validate_fetch_xml_syntax (dataverse.py:255-275) validates the entity name only `if entity_elem is not None and "name" in entity_elem.attrib`. FetchXML with no <entity> element, or an <entity> without a name, therefore passes config and composer validation. _load_rows (lines 893-899) then raises RuntimeError('FetchXML is missing <entity> element ...') or ('... missing name attribute'). That happens at run time, after on_start has already built the credential and client. The same function says broken FetchXML 'can never produce valid results' and should fail at config time. The tests pin the late failure: test_dataverse_source.py:1799-1823 expect RuntimeError from load(). Expected behaviour: the config validator should require exactly one <entity name=...> under <fetch> and raise ValueError, which becomes a PluginConfigError, so the error reaches validation and the composer before a run starts. Then _load_rows can treat a missing entity as an internal invariant violation.

FINDING #75 [P3 (raised as P2), bug] Chroma runtime_preflight leaves no audit record when the readiness count fails, unlike its Azure Search sibling

`src/elspeth/plugins/infrastructure/clients/retrieval/chroma.py`

Location: chroma.py:805-852. runtime_preflight allocates an operation call index (line 805) and, in VERIFY, calls admit_verify_call (843-849). It then calls _live_readiness, which performs the external count() and turns any Chroma, OS, ValueError or httpx failure into reachable=False (790-798). The `if not readiness.reachable: return readiness` at line 851 returns without record_operation_call, so the attempted external call has no ERROR row in the Landscape, and in VERIFY the admitted call never reaches verify_call. The sibling AzureSearchProvider.runtime_preflight (azure_search.py:648-722) routes its count through AuditedHTTPClient, which records success and failure alike. The same gap applies when _initialize_client() raises inside _live_readiness (line 777) or inside search() at line 273 in VERIFY mode, after the call index was allocated and admitted. Expected behaviour: record an ERROR operation call carrying the failure type and message, and run verify_call in VERIFY, before returning the unreachable result or raising.

**Verifier (CONFIRMED):** chroma.py:805-852: runtime_preflight allocates an operation call index, admits the verify call in VERIFY, then `if not readiness.reachable: return readiness` (line 851) without record_operation_call, so no Call row for the attempted count and no verify_call. Severity lowered because the failure is not invisible in the audit: the only caller, RAGRetrievalTransform.runtime_preflight (plugins/transforms/rag/transform.py:122-170), records ctx.record_readiness_check(reachable=False, message='... unreachable: <ExcType>: <msg>') and raises RetrievalNotReadyError inside track_operation (engine/orchestrator/runtime_preflight.py:80-105), which fails the operation. The run stops before any rows are processed. What remains: a call-table gap and a call-index hole, plus an asymmetry with AzureSearch, which records the failed count Call. This is an audit-completeness defect, not lost evidence.

FINDING #76 [P3, enhancement] Dataverse 429 Retry-After is parsed and then discarded, so throttling backoff ignores the server's value

`src/elspeth/plugins/infrastructure/clients/dataverse.py`

Location: dataverse.py:394-423. _classify_error parses Retry-After and clamps it into `effective`, but uses the value only in the message text. DataverseClientError has no retry_after attribute. rg for 'retry_after|Retry-After' across src/elspeth/engine, sources/dataverse.py, sinks/dataverse.py and clients/http.py returns nothing, so the engine retries on its own schedule, which may be shorter than the server asked. Dataverse service-protection limits require waiting the stated Retry-After; retrying early extends the throttle window. An HTTP-date Retry-After also silently becomes 1.0s (line 399). Expected behaviour: carry the parsed delay as a typed field on DataverseClientError so the retry path can honour it, and parse the HTTP-date form.

FINDING #82 [P3 (raised as P2), bug] Dataverse sink upsert URL does not OData-escape single quotes in alternate-key values

`src/elspeth/plugins/sinks/dataverse.py`

dataverse.py:428-431 `_build_upsert_url` builds `entity(key='<value>')` and only applies `urllib.parse.quote(key_value, safe='')`, which turns `'` into `%27`. Servers percent-decode before parsing OData, so `%27` is the same as a literal quote. A valid key such as the email `o'brien@x.com` becomes `emailaddress1='o%27brien%40x.com'`, which decodes to `'o'brien@x.com'`. That string literal ends early: Dataverse returns 400, or at worst parses a different key predicate. OData ABNF requires a quote inside a string literal to be doubled (`''`). The sibling Dataverse source tests follow that rule for operator filters (tests/unit/plugins/sources/test_dataverse_source.py:2579 uses `'O''Brien'`). The same URL is used by `reconcile_member_effect` (GET), so recovery is affected too. The 400 carries no `row_data_error` category (see the related finding), so it does not divert the row. Instead the whole effect raises and a valid row can never be written. Expected: run `key_value.replace("'", "''")` before percent-encoding. Verification: ran `urllib.parse.quote("o'brien@x.com", safe='')` and got `o%27brien%40x.com`. An rg of tests/ for `%27`, `O'Brien` and `''` in the dataverse sink tests finds no apostrophe-key test. The `_build_upsert_url` tests (test_dataverse_sink.py:659-684) cover only `/`, `(`, `)` and `=`.

**Verifier (CONFIRMED):** sinks/dataverse.py:420-431 _build_upsert_url only does urllib.parse.quote(key_value, safe=''). Ran it: "o'brien@x.com" -> contacts(emailaddress1='o%27brien%40x.com'), which percent-decodes to contacts(emailaddress1='o'brien@x.com'), an unbalanced OData string literal. OData v4 URL conventions (ABNF SQUOTE-in-string = SQUOTE SQUOTE) require the quote to be doubled. The only key guards (sinks/dataverse.py:501-521) check str type, non-blank and uniqueness; nothing rejects or escapes apostrophes, and the sink tests have no apostrophe key ('%27'/O'Brien grep empty). The same URL feeds reconcile_member_effect's GET. I did not observe the exact server outcome live. MS doc https://learn.microsoft.com/en-us/power-apps/developer/data-platform/webapi/retrieve-table-row#alternate-keys-with-special-character-values separately lists / < > * % & : \\ ? + as unsupported in key segments, so the bug class is broader than the quote. Effect: a 400 with no row_data_error category (see #83) raises and aborts the effect rather than diverting the row. It fails loudly, not silently, so I rate it P3.

FINDING #85 [P3, bug] Dataverse lookups whose key is not in field_mapping are accepted and silently ignored

`src/elspeth/plugins/sinks/dataverse.py`

`lookups` is keyed by pipeline field (lines 173-176), but `_map_row` (lines 444-475) only walks `field_mapping` and applies a lookup only when `pipeline_field in self._lookups`. `validate_no_outbound_key_collisions` checks bind-key collisions but never checks that each lookup key is also a `field_mapping` key. A config such as `field_mapping: {email: emailaddress1}, lookups: {account_id: {target_entity: accounts, target_field: parentcustomerid}}` validates, and the lookup is never written, with no error. The binding is silently dropped from every upsert. `config_named_input_columns` also leaves out `account_id`, so nothing flags it. Expected: a model validator that rejects lookup keys missing from `field_mapping`, or that treats lookup keys as their own input columns. Verification: `DataverseSinkConfig.from_dict({... 'field_mapping': {'email': 'emailaddress1'}, 'alternate_key': 'emailaddress1', 'lookups': {'account_id': {...}}, 'schema': {'mode': 'observed'}})` succeeded in this worktree (elspeth.__file__ resolved to the worktree) and returned the lookup unchanged.

FINDING #92 [P3, bug] distance_function is silently ignored when the collection already exists; the sibling retrieval provider refuses the mismatch

`src/elspeth/plugins/sinks/chroma_sink.py`

At chroma_sink.py:354-357, on_start calls get_or_create_collection(metadata={'hnsw:space': distance_function}). I ran a probe against chromadb 1.5.5: get_or_create_collection('tst', metadata={'hnsw:space':'l2'}) on a collection created with 'cosine' returns the existing collection, which is still 'cosine', and raises nothing. So an operator who sets distance_function: l2 writes into a cosine index with no warning, and nothing records that the config was not applied. The read side handles this: ChromaSearchProvider._initialize_client (plugins/infrastructure/clients/retrieval/chroma.py:230-240) parses the collection's actual hnsw:space with _collection_distance_space and raises a non-retryable RetrievalError on a mismatch. Expected: after get_or_create, the sink reads collection.metadata['hnsw:space'] and fails at on_start on a mismatch, reusing the same parser for symmetry. The sink tests mention distance_function only in the config fixture (tests/unit/plugins/sinks/test_chroma_sink.py:48); nothing covers a mismatch.

FINDING #93 [P3, bug] Composer hint says a non-string ID or document aborts the whole batch, but the code diverts that row

`src/elspeth/plugins/sinks/chroma_sink.py`

The composer_hints at chroma_sink.py:281 tell the planner: 'a present-yet-non-string id or document is an upstream type error that aborts the whole batch.' The code does the opposite. Line 380 raises ValueError for a non-string id or document. Lines 430-434 catch it, and prepare_effect diverts that member individually (line 519). tests/unit/engine/test_chroma_member_effect_diversion.py:132-160 asserts exactly this for {'text': 123}: prepared_disposition 'diverted', and its valid siblings land. This is LLM-facing teaching text that misdescribes how the sink fails, so the planner may add needless upstream type-coerce steps or reason wrongly about quarantine. The hint should say that a non-string or missing id/document diverts that row. Verified with rg (the phrase occurs only at line 281) and by reading the diversion test.

FINDING #94 [P3, architecture] _ChromaPayloadRejection claims an error handler distinguishes it, but nothing catches it and rejected rows are never diverted

`src/elspeth/plugins/sinks/chroma_sink.py`

The class docstring at chroma_sink.py:68-75 says the wrapper exists 'so the error handler can distinguish "Chroma rejected our data" (Tier 3) from "bug in our code"'. rg -n '_ChromaPayloadRejection' over src/ finds only the definition and the raise at line 623. No handler exists, so the wrapped error propagates exactly as the bare ValueError would. The only distinction made is in the exception type name. The sibling DataverseSink.commit_member_effect (dataverse.py:657-679) does what this docstring promises: it classifies a row-attributable, non-retryable rejection, calls _divert_row, and returns a SinkEffectCommitResult with that ordinal diverted. Chroma has no such path, so any payload Chroma rejects after preparation fails the effect instead of diverting the row. An example is a metadata_fields entry named 'chroma:document': my probe got ValueError 'Expected metadata to not contain the reserved key chroma:document'. The docstring is false as written. Either implement row diversion for payload rejections, matching Dataverse, or correct the docstring and drop the wrapper. Related: the empty-ID InvalidArgumentError finding.

## Files a correct fix must change

- `src/elspeth/plugins/sinks/chroma_sink.py`
- `src/elspeth/plugins/sinks/dataverse.py`

## Test files the lane must add or change

- `tests/unit/plugins/test_dataverse_chroma_p3_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/test_dataverse_chroma_p3_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-04-p3-dataverse-chroma/report.md`; the worker returns one line.
