# lane-09-p3-web-scrape — #5 [P3, bug] fingerprint_mode 'full' is described as covering the full fetch response context but hashes only the extracted content; #152 [P3, bug] JSONRecordColumn.path defaults to [], which fails on every record; #160 [P3, bug] resolve_discovered_href changes the query of the link it emits (form re-encoding by fingerprint_url); #161 [P3, security] Discovered-link admission accepts session/state/cursor capability query keys that the sibling Link-header redactor treats as secret; #163 [P3, enhancement] Authenticated web_scrape config passes validation and then fails every row at runtime

Ticket `p3-web-scrape` · run `p3` · branch `lane/p3-web-scrape` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

This lane fixes 5 findings; fix each one (one test commit + one fix commit PER finding).
Every finding names the files where the sweep located it; touch only what each fix needs.

FINDING #5 [P3, bug] fingerprint_mode 'full' is described as covering the full fetch response context but hashes only the extracted content

`src/elspeth/plugins/transforms/web_scrape.py`

web_scrape.py:347-350 declares fingerprint_mode with the description 'Whether fingerprints cover processed content only or the full fetch response context.' This description is the authoring contract the composer LLM and operators read. The implementation (web_scrape.py:1662 -> web_scrape_fingerprint.py:35-41) differs only in skipping normalize_for_fingerprint: 'full' is SHA-256 of the same extracted content string without whitespace normalization. It covers no status, final URL, headers, content type or raw body. An operator who picks 'full' expecting a change of fetch_status, redirect target or content type to show up in the fingerprint gets no such detection. Expected: either describe the mode honestly (for example 'un-normalized content') or make 'full' include the response context it promises. Verification: read compute_fingerprint. rg over docs shows docs/reference/web-scrape-transform.md:20 lists only 'content | full' with no semantics, so the field description is the only authoritative contract.

FINDING #152 [P3, bug] JSONRecordColumn.path defaults to [], which fails on every record

`src/elspeth/plugins/transforms/web_scrape_json_extraction.py`

web_scrape_json_extraction.py:38: `path: JSONPath = Field(default_factory=list)`. With an empty path, _select (:133-146) returns the record itself. The record is always a dict (enforced at :212), so _scalar_text (:149-158) always raises 'non-scalar value'. A column that omits path, an easy omission for an operator or the composer (who might expect path to default to [field]), passes config validation and then fails every row as a row error. Verified: JSONRecordsConfig(field='r', records_path=['results'], columns=[{'field':'name'}]) validates, and extracting '{"results":[{"name":"a"}]}' raises ValueError('JSON record column contains a non-scalar value'). Expected: make path required with min_length=1 (or default it to [field]) so the error appears at config time.

FINDING #160 [P3, bug] resolve_discovered_href changes the query of the link it emits (form re-encoding by fingerprint_url)

`src/elspeth/plugins/transforms/web_scrape_links.py`

web_scrape_links.py:66 returns `safe_url = fingerprint_url(candidate)`. fingerprint_url (clients/fingerprinting.py:347,380) always runs parse_qsl and then urlencode on any non-empty query, even after lines 62-64 have already refused every sensitive parameter, so nothing needs fingerprinting. As a result the URL written to the row (the one the downstream row-URL fetch requests) is not the href the page contains. Measured by running resolve_discovered_href with base https://reg.example.gov/s: '/d?flag' -> '/d?flag=', '/d?a=1;b=2' -> '/d?a=1%3Bb%3D2' (the ';' and '=' are now escaped, so the server sees one parameter where the page had two), '/d?ids=1,2' -> '/d?ids=1%2C2', '/d?q=100%' -> '/d?q=100%25'. Servers that tell a bare flag from an empty value, or that split on ';', get a different request from the one the page linked to. Expected: once the sensitive-parameter refusal has passed, emit the original query unchanged. The code only needs to strip userinfo and the fragment, or it could assert fingerprint_url(candidate) == candidate the way safe_link_header_for_audit does at fingerprinting.py:94. Tests: tests/unit/plugins/transforms/test_web_scrape_links.py has no case with a query that has no '=' or has ';' or ',' in it.

FINDING #161 [P3, security] Discovered-link admission accepts session/state/cursor capability query keys that the sibling Link-header redactor treats as secret

`src/elspeth/plugins/transforms/web_scrape_links.py`

web_scrape_links.py:62-64 refuses a discovered link only when is_sensitive_query_param(name) is true. The words it checks (fingerprinting.py:48-64) include sid but not session, state, cursor, continuation, next_token or page_token. The sibling persistence-safety boundary safe_link_header_for_audit (fingerprinting.py:76,102) lists exactly those keys as _LINK_CAPABILITY_QUERY_KEYS and redacts any link that carries one before it is written to the audit trail. Measured: resolve_discovered_href('/d?session=ABCDEF123', ...) returns 'https://reg.example.gov/d?session=ABCDEF123', and '/d?state=xyz&code=abc' passes unchanged, so a session id or OAuth state/code found in scraped HTML is written as plain text into row data and the audit trail. This breaks the function's own stated purpose ('fail this link instead of persisting a navigable secret'). Expected: one shared definition of capability-bearing query keys, at least session (and probably code/state), used by both the Link-header path and the href path. Pagination keys (cursor/page_token) need a deliberate decision, because href pagination may need them; page_token is already refused through the 'token' word. No test in test_web_scrape_links.py covers these keys.

FINDING #163 [P3, enhancement] Authenticated web_scrape config passes validation and then fails every row at runtime

`src/elspeth/plugins/transforms/web_scrape_auth.py`

WebScrapeAuthConfig is a fully admitted config surface: validated origin binding, header construction at web_scrape.py:938 and an origin cross-check at web_scrape.py:459-468. But web_scrape.py:1188-1193 sends every row to TransformResult.error('authenticated web_scrape is unavailable until response evidence is secret safe') whenever auth is set. The field description at web_scrape.py:369 calls the field 'Reserved'. So a pipeline (or a composer proposal) that sets auth passes graph validation and then fails or quarantines every row at run time, a fail-late result for something already known when the config is parsed. Expected: refuse auth at config validation (or in on_start) with the same message, so that pre-run validation reports the reservation and runs do not process rows that are certain to fail.

## Files a correct fix must change

- `src/elspeth/plugins/transforms/web_scrape_links.py`

## Test files the lane must add or change

- `tests/unit/plugins/transforms/test_web_scrape_p3_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/transforms/test_web_scrape_p3_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-09-p3-web-scrape/report.md`; the worker returns one line.
