DONE: lane-09-p3-web-scrape fixed all 5 findings (#160, #161, #152, #5, #163) test-then-fix on lane/p3-web-scrape (10 commits, HEAD 557fd369, base 1ee11f2e); lane file 20/20, each RED at an assertion first.

(Written by orchestrator from the lane's hand-back; the subagent's report.md write was refused.)

## Fixes
- #160 resolve_discovered_href returns the validated candidate (query no longer re-encoded); sensitive-param check also splits on ';'.
- #161 shared fingerprinting._CAPABILITY_QUERY_KEYS + public is_capability_query_param used by both Link-header and href paths; href path now refuses cursor/continuation/next_token/page_token/session/state. `code` NOT added (maintainer call).
- #152 JSONRecordColumn.path required, min_length=1 (COMPAT: column without path now refused).
- #5 fingerprint_mode description made honest (content-only hashing); 'full' semantics unchanged (design change left to maintainer).
- #163 WebScrapeConfig refuses `auth` at config time with the existing reservation message (COMPAT: YAML with auth fails validation instead of every row). process() guard kept. docs/reference/web-scrape-transform.md one sentence updated.

## Re-pins
- WebScrapeTransform source_file_hash -> sha256:ef6e828ace325e3c (not in scenario manifest). Knob golden transform__web_scrape.json updated.

## Evidence (lane-reported)
- ruff/format/check_contracts/mypy 0; web_scrape* + fingerprinting 452 passed; adjacent 400 + 525 passed.
- No fencing change. architecture/dag trees left to hub verify (rule I).
