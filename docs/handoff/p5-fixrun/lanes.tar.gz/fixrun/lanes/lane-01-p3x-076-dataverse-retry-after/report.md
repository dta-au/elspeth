DONE: lane-01-p3x-076 #76 Dataverse Retry-After is now honoured on every request path (client wait loop bounded by a 300s throttle budget + shutdown event; source records each throttled call with retry_wait_ms; sink evidence names waits): test 0e4d52e8 + fix 34a06925 on lane/p3x-076-dataverse-retry-after, RED 13/13 assertion failures on base, GREEN 13 passed, module suites 1041 passed.

(report.md write under lanes/lane-01-p3x-076-dataverse-retry-after/ was refused by the harness; this is the fallback path.)

## Root cause
- `src/elspeth/plugins/infrastructure/clients/dataverse.py` `_classify_error` (base ~517-546) parsed Retry-After into `DataverseClientError.retry_after`, but nothing read it. The client sent every request exactly once (`_execute_request`).
- There was no retry path to feed:
  - `engine/retry.py` `RetryManager` wraps only transforms (`processor.py`) and transform runtime preflight (`engine/orchestrator/runtime_preflight.py`).
  - A source `load()` error fails the run.
  - A sink `commit_member_effect` error is marked `response_lost` by `engine/executors/sink_effects.py:_commit_member` (~1052) and re-raised, with no in-process retry.
  - So the ticket's "engine retries on its own schedule" was wrong: a throttled 429/503 simply failed the run.
- The fix is therefore a bounded wait-and-resend loop in the client, which sees every Dataverse request. The source and sink change too, for audit observability and the shutdown signal.

## Fix (34a06925)
Client:
- `DataverseClient(..., throttle_wait_budget_seconds=300.0, shutdown_event=None, on_throttle=None)`.
- `_send_with_throttle_retry(send)` wraps `get_page`, `upsert`, `paginate_odata` (each hop; url and pinned IP are bound per hop) and `paginate_fetchxml`. `_execute_request` stays a single attempt.
- It acts only on a retryable 429/503. The wait is `max(backoff, retry_after)`; backoff starts at 1s and doubles up to `retry_after_cap`.
- Waits for one request share the budget. A wait that does not fit is never slept: the client raises the original error if no wait has happened yet, otherwise a still-retryable "throttle wait budget … exhausted" error carrying `throttle_waits`. A set shutdown event ends a wait the same way.
- 503 now carries its parsed Retry-After.
- A 429 whose Retry-After is above the 60s cap stays non-retryable and is not waited.
- Other errors are unchanged.
- `throttle_waits` is new on both `DataverseClientError` and `DataversePageResponse` (default `()`).
- `on_throttle(error, wait)` runs after the wait and before the re-send. A wait cut short by shutdown is then recorded only once, by the caller's existing error path; this matters in VERIFY.

Source:
- Passes `shutdown_event` (from `on_start`) and `on_throttle=self._record_throttled_call` in both the LIVE and VERIFY client constructions.
- `_record_throttled_call` records each waited-out throttled call through the existing `_record_page_call` (ERROR, status 429/503, new `error.retry_wait_ms`).
- No new `ctx.record_call` site: `test_landscape_production_caller_set_is_frozen` passes unchanged, so no fencing re-pin.

Sink:
- Passes `shutdown_event`.
- A committed member's evidence gets `throttle_wait_ms` when its PATCH was throttled first.
- An exhausted budget raises a retryable error, which still does not divert the row.

Re-pins and test adjustments:
- `source_file_hash`: sources/dataverse c84e1f8a147d4255 -> d95b4c4ee2aedc4c; sinks/dataverse 902733490be9e3cd -> aab91c78c0486f2b. A strict equality check prints `True True`.
- Neither hash is in the scenario-corpus manifest (a grep found the old hex only in the class attributes).
- The `test_dataverse_client.py` `client` fixture now sets budget 0, so its single-response classification tests still pin the classified raise.
- The p3 sweep "non-429 carries None" case moves from 503 to 500.
- A first split duplicated a `dict[str, Any]` param and failed `check_contracts` (census 2668 -> 2669). I restructured so the census is back to 2668, with no census edit.

## Tests (0e4d52e8): tests/unit/plugins/infrastructure/clients/test_dataverse_retry_after.py, 13 tests
- Client:
  - 429 waits Retry-After, then re-sends
  - 503 honoured, and its classification carries retry_after
  - a 429 with no header still backs off at least 1s
  - a wait over the budget raises retryable with no sleep
  - the budget is spent across waits
  - observer runs after the wait and before the re-send
  - PATCH upsert is honoured
  - a 500 is not retried in the client
  - shutdown stops the wait with no observer call
- Source (end-to-end with a real client and MockTransport): the throttled call is recorded as ERROR with retry_wait_ms=3000, followed by SUCCESS, SUCCESS.
- Sink: the committed member's evidence has `throttle_wait_ms` [2000], and `on_start` passes the shutdown_event.
- The test commit was amended before the fix commit and never published:
  - two expectations compared frozen containers;
  - the observer order changed to after-wait, for the reason above.

## Evidence
- RED: the base src (`git archive` of the test commit, extracted to `.claude/lanes/fixrun/lanes/lane-01-p3x-076-dataverse-retry-after/basetree`) ran the brief's test command. Exit was 1 with 13 failed, all at `E AssertionError: DataverseClient has no throttle-wait budget`.
- GREEN: the worktree run exited 0 with `13 passed`.

Gates (worktree, Py 3.14.6, PYTHONPATH=src:elspeth-lints/src):

| Gate | Result |
|---|---|
| `ruff check src/ tests/` | exit 0 |
| `ruff format --check src/ tests/` | exit 0 |
| `check_contracts.py` | exit 0 |
| `mypy` on the 3 touched src files | exit 0 |
| Module tests at `-n 2` | exit 0, 1041 passed |
| `branch-safety-check --intent commit` | FAIL=0 WARN=0 |
| Keyless `elspeth-lints check --rules all --root src/elspeth` | exit 1, finding set identical to base |

- The module test run covered: dataverse client, fetchxml paging, source, sink, p2 and p3 sweeps, integration dataverse_statistics, test_plugin_hash, test_plugin_contract_rules, test_dag_scenario_corpus_contract, and the frozen fencing caller-set test.
- The lint comparison normalised paths and line numbers; both trees produced 3796 lines and `diff` was empty. No signature churn.

## Left alone / caveats
- I did not run the full suite or the whole architecture/dag trees (host rule I). The hub suite covers them.
- The budget is not exposed as plugin config, to avoid config-contract churn. Exposing it is a follow-up decision.
- No in-client retry for 500/502/504 or timeouts; the ticket covers 429/503 only.
- Reconcile still maps a final error to UNKNOWN.
- The sink still records no per-HTTP call, so its throttled PATCHes are visible only through the evidence, or through `throttle_waits` and the message on the raised error.
- The sink-effect lease is 5 min with a background heartbeat thread, so a 300s wait inside commit should be covered. I reasoned this from the code and did not measure it.

## COMPAT
- A Dataverse source or sink that receives a retryable 429/503 now waits and re-sends instead of failing at once. That is up to 300s of throttle waits per request, cancellable on shutdown. A 429 whose Retry-After exceeds 60s still fails immediately.
- The client, error and page types gain defaulted or keyword members only.
- Audit changes are additive:
  - the source records one extra ERROR call per waited-out throttle, with `retry_wait_ms`, so call indexes for that page shift;
  - sink commit evidence may carry `throttle_wait_ms`.
- The `source_file_hash` change for the Dataverse source and sink shows in node audit records.
- A LIVE run that was throttled, verified later without throttling, will show differing call sequences. That is inherent to verifying against a live service.

## CHANGELOG
- Dataverse source and sink now honour the server's Retry-After on 429/503 throttling: the client waits at least Retry-After (exponential backoff floor, 300s total throttle-wait budget per request, cancellable on shutdown) and re-sends, instead of failing the run. Each waited-out throttled call is recorded with its `retry_wait_ms`, and sink commit evidence names the waits (#76).
