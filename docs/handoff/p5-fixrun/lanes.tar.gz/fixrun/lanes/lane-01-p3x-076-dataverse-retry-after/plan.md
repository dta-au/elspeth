# lane-01-p3x-076-dataverse-retry-after — #76 [P3] Dataverse: consume DataverseClientError.retry_after (Retry-After) in the source and sink retry paths

Ticket `p3x-076-dataverse-retry-after` · run `p3x` · branch `lane/p3x-076-dataverse-retry-after` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

Maintainer ruling 2026-11-12: finish #76. Lane p3-dataverse-chroma (landed 20584836) added a typed DataverseClientError.retry_after parsed from Retry-After (delta-seconds and HTTP-date) but nothing consumes it. Make every Dataverse retry path (source paging/preflight and sink upsert/reconcile, plus any shared client retry loop or engine retry classification it feeds) honour retry_after for 429/503: wait at least retry_after before the next attempt, bounded by the existing retry/deadline budgets (never sleep past a row/operation deadline; if retry_after exceeds the remaining budget, fail as retryable/exhausted rather than oversleeping). Audit: the wait used must be observable in the recorded call/error context where the existing retry path records attempts. Test first, one test commit + one fix commit.

## Files a correct fix must change

- `src/elspeth/plugins/infrastructure/clients/dataverse.py`

## Test files the lane must add or change

- `tests/unit/plugins/infrastructure/clients/test_dataverse_retry_after.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/infrastructure/clients/test_dataverse_retry_after.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-01-p3x-076-dataverse-retry-after/report.md`; the worker returns one line.
