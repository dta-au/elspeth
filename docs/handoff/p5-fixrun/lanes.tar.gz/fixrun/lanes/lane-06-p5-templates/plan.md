# lane-06-p5-templates — #7 create_sandboxed_environment defaults to value_free=True; operator-only diagnostic contexts opt in to raw diagnostics explicitly

Ticket `p5-templates` · run `p5` · branch `lane/p5-templates` · base `claude/compassionate-brahmagupta-o0nhlw`

## Goal

Maintainer ruling 2026-11-14 (option b): value-free by default. The earlier fix (lane-03-p4-infra-sinks #7) forced value-free only when the context carries a TemplateRow; flip the default and make each operator-only caller opt in explicitly (find every caller; each opt-in must be a context where no row data can reach the template). Keep the row-carrying guard. Finding: plugins-review.md #7.

## Files a correct fix must change

- `src/elspeth/plugins/infrastructure/templates.py`

## Test files the lane must add or change

- `tests/unit/plugins/test_p5_templates_sweep.py`

## Test command (must be RED before the fix, GREEN after)

```
.venv/bin/python -m pytest tests/unit/plugins/test_p5_templates_sweep.py -n 0 -q -p no:cacheprovider
```

## Full suite (must pass on the merged tree)

```
bash /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/suite.sh
```

## Definition of done

1. The failing test is committed FIRST and `verify` proves it fails on the base without the fix.
2. The fix is committed; the test command exits 0 on the merged tree.
3. The full suite exits 0 on the merged tree.
4. Findings are written to `.claude/lanes/fixrun/lanes/lane-06-p5-templates/report.md`; the worker returns one line.
