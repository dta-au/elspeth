lane-06-p5-templates: #7 create_sandboxed_environment defaults to value_free=True; only the azure_blob runtime blob-path render (run_id+timestamp context) opts in to raw diagnostics; TemplateRow guard kept; sibling fix: the worker's output-bound error survives value-free renders. RED c857650e (2 failed at assertions; 6th test RED proved by temporarily removing the fix), fix 6b6057a0, 6 passed; ruff/mypy/contracts/plugin lints 0; no tier-model rotations. Hash AzureBlobSink 8c5310c3821b716f -> 55ea6b3b439e9eaa.

(Written by orchestrator from the lane's hand-back; the harness refused the lane's report write.)

CHANGELOG:
- Templates: sandboxed template environments report render failures value-free by default; a caller whose context can never carry row data must opt in to raw diagnostics with value_free=False (only the Azure Blob sink's blob path does). The output-size bound keeps its message in value-free renders (#7).

COMPAT:
- Breaking (internal API): create_sandboxed_environment() with no argument now raises TemplateError with value-free text instead of raw jinja UndefinedError/SecurityError/TemplateSyntaxError/TemplateRuntimeError. No shipped plugin renders through the default; Azure Blob sink keeps raw diagnostics via explicit opt-in.
- Oversized value-free render output now reads "Rendered template exceeds 4194304 UTF-8 bytes" instead of "message withheld".
- Hash: AzureBlobSink sha256:55ea6b3b439e9eaa.

Gates: module run -n 2 under memory pressure: 2 real failures fixed, 8 others pass serially; final -n 2 re-run (infrastructure, azure_blob_sink, sweeps) 3133 passed exit 0. Note: RED commit has 5 tests; 6th test arrived with the fix (verify's RED is measured on the RED commit's tests).
