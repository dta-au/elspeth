#!/usr/bin/env bash
# Bounded per-lane suite for the 20261111 plugin fix run (run in the tree under test).
# Widened 2026-11-12 after the integrator's full suite found 17 failures in
# tests/invariants, integration/pipeline, unit/contracts and unit/web/composer;
# the top-level whole-tree gates tests/unit/test_*.py added 2026-11-13 after the
# integrator's gate caught a hasattr probe (test_no_hasattr_branching).
# tests/unit/web/catalog and plugin_policy added 2026-11-14 after the integrator found the
# knob_schema golden red at a80751aa (a new plugin config option; this selection missed it).
# The full `pytest tests/` gate runs at tier checkpoints, not per lane (4 CPUs, ~160 lanes).
# The base (21e74acc) is itself red under host load: 29 failures recorded in
# baseline-314-failures.txt. Per AGENTS.md, a failure is credited to the change only if
# it also fails when re-run serially (-n 0); everything else is reported, not hidden.
set -u
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONPATH="$PWD/src:$PWD/elspeth-lints/src"
PY=.venv/bin/python
LOG="$(mktemp -p "$HERE" suite-run.XXXXXX.log)"
rc=0
step() { echo "=== $*"; "$@"; local r=$?; echo "=== exit=$r :: $*"; [ $r -ne 0 ] && rc=1; return 0; }
step $PY -m ruff check src/ tests/ scripts/ elspeth-lints/src/
step $PY -m ruff format --check src/ tests/ scripts/ elspeth-lints/src/
step $PY scripts/check_contracts.py
step $PY -m mypy src/ elspeth-lints/src/   # CI's exact mypy scope
# Memory guard (2026-11-14): fix lanes share the 15 GB box; wait for >= 5 GB available
# (up to 60 min) so this run is not OOM-killed (exit 137) mid-suite.
for _ in $(seq 60); do [ "$(free -m | awk '/^Mem:/{print $7}')" -ge 5000 ] && break; sleep 60; done
echo "=== pytest (log: $LOG) avail_mb=$(free -m | awk '/^Mem:/{print $7}')"
$PY -m pytest -n 3 -q -rfE -p no:cacheprovider \
  tests/unit/plugins tests/integration/plugins tests/integration/core/dag tests/unit/architecture \
  tests/invariants tests/integration/pipeline tests/unit/contracts tests/unit/web/composer \
  tests/unit/web/catalog tests/unit/web/plugin_policy \
  tests/unit/test_*.py \
  tests/unit/web/test_sessions_composer_attribute_contracts.py \
  tests/unit/elspeth_lints/test_masquerade_gate.py \
  tests/unit/scripts \
  "tests/unit/engine/test_executors.py::TestReRaiseGuardPattern" > "$LOG" 2>&1
prc=$?
tail -3 "$LOG"
echo "=== pytest exit=$prc"
if [ $prc -ne 0 ]; then
  mapfile -t failed < <(grep -E '^(FAILED|ERROR) ' "$LOG" | sed -E 's/^(FAILED|ERROR) //; s/ - .*//' | sort -u)
  if [ ${#failed[@]} -eq 0 ]; then
    echo "=== pytest failed with no FAILED/ERROR ids (collection/internal error)"; rc=1
  else
    # One process per id: a single serial process over the whole set was OOM-killed
    # (exit 137) at ~2 GB on this 15 GB host while lane agents ran (p2fu, 2026-11-12).
    echo "=== re-running ${#failed[@]} failed ids serially (-n 0, one process per id)"
    src=0
    : > "$LOG.serial"
    for id in "${failed[@]}"; do
      $PY -m pytest -n 0 -q -rfE -p no:cacheprovider "$id" > "$LOG.one" 2>&1
      r=$?
      echo "rc=$r $id" >> "$LOG.serial"
      if [ $r -ne 0 ]; then src=1; tail -30 "$LOG.one" >> "$LOG.serial"; fi
    done
    rm -f "$LOG.one"
    grep -E '^rc=[^0]' "$LOG.serial" || echo "(all ${#failed[@]} passed serially)"
    echo "=== serial rerun exit=$src"
    [ $src -ne 0 ] && rc=1
  fi
fi
echo "SUITE rc=$rc"
exit $rc
