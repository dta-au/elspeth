import sys, traceback
from pathlib import Path
from elspeth.plugins.sources.json_source import JSONSource
from tests.unit.plugins.test_json_csv_p2_sweep import _landscape_ctx
d = Path(sys.argv[1]); d.mkdir(parents=True, exist_ok=True)
deep = '{"a": ' * 1500 + '1' + '}' * 1500
for fmt, content in [("jsonl", '{"id": 1}\n{"x": ' + deep + '}\n{"id": 2}\n'), ("json", '[{"id": 1}, {"x": ' + deep + '}]')]:
    p = d / f"data.{fmt}"; p.write_text(content)
    try:
        rows = list(JSONSource({"path": str(p), "format": fmt, "on_validation_failure": "quarantine", "schema": {"mode": "observed"}}).load(_landscape_ctx()))
        print(fmt, "OK", [(r.is_quarantined, r.quarantine_error[:80] if r.is_quarantined else None) for r in rows])
    except BaseException as e:
        print(fmt, "CRASH", type(e).__name__, str(e)[:150]); traceback.print_exc(limit=-4)
