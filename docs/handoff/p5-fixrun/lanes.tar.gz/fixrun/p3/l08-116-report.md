# L08 — Finding #116: drop upstream multi-query legacy overwrite precedence

Worktree: `.claude/worktrees/compassionate-brahmagupta/.claude/worktrees/lane-p3-llm-core` (branch `lane/p3-llm-core`, not pushed)
Interpreter: worktree `.venv/bin/python` 3.14.6; `elspeth.__file__` resolves inside the worktree (verified, and branch-safety-check `provenance` PASS).

## Commits
- `a81edd3e` test(plugins): upstream multi-query must refuse suffixes colliding with its own operational fields
  - Red run: 11 failed, 1 passed (the non-colliding control) — every failure at `assert isinstance(raised, PluginConfigError)` (got `None`). Log: `l08-116-red.log`.
- `8c96452a` fix(plugins): drop upstream multi-query legacy overwrite precedence

## The fix
`unique_query_generated_fields` (multi_query.py) is now the contract for EVERY multi-query config (upstream and ordered, any stem). It first refuses any structured name equal to any query's `<query>_<response_field>`, `..._usage`, `..._model`, using the single-prompt wording family:
`Generated output field collision: query 'quality' output field suffix 'llm_response' publishes 'quality_llm_response', which collides with the transform's own response/operational fields; choose another suffix or structured_output_prefix, or rename response_field`
Raised inside `LLMConfig` validation -> `PluginConfigError` via `from_dict`.

## What was removed (legacy-only code)
- `LLMConfig._validate_cross_query_rules` (base.py): `if any(spec.structured_output_prefix is not None ...)` opt-in — check now unconditional; docstring updated.
- `web/composer/state.py` `_validate_multi_query_generated_input_requirements`: the same opt-in condition (mirror of the plugin check; kept in parity).
- `_llm_created_output_fields` (`llm/__init__.py`): "operational values overwrite extracted values ... same precedence" docstring and the `if name not in operational_names` filter.
- `_llm_generated_output_fields` (`llm/__init__.py`): "operational-field precedence" docstring and the same filter.
- `unique_query_generated_fields` docstring "Upstream mode opts in when any query explicitly overrides".
- Teaching / description text describing the opt-in ("Any non-null override requires unique final generated names ..."): `QueryDefinition.structured_output_prefix` description (multi_query.py), LLMTransform composer guidance (transform.py), planner_authoring_aids.py, `docs/guides/ordered-llm-queries.md` ("Null preserves upstream mode's legacy overwrite rules"). Catalog goldens `tests/golden/web/catalog/{knob_schema,policy_view}/transform__llm.json` updated to the new strings (6 replacements).
- Tests pinning legacy behaviour, replaced by refusal tests:
  - `test_structured_output_prefix.py::test_upstream_default_keeps_legacy_operational_precedence` -> `test_upstream_default_refuses_operational_collision`
  - `test_transform.py::test_multi_query_operational_fields_keep_emission_precedence` -> `test_multi_query_operational_collision_is_refused`
  - `test_transform.py::test_multi_query_overlapping_generated_fields_follow_query_order` -> `test_multi_query_cross_query_operational_overlap_is_refused_in_either_order`
  - `test_transform.py::test_operational_collision_output_admission_matches_the_emitted_type` deleted (it typed the overwritten collision; config is now refused before that check)
  - `test_state_multi_query_contract.py::test_upstream_override_collision_refusal_matches_plugin_without_changing_legacy` -> `test_upstream_collision_refusal_matches_plugin_for_every_stem` (both stems now refuse, composer message == plugin message)
  - Renamed `test_explicit_same_prefix_activates_collision_refusal_for_default_named_other_queries` -> `test_explicit_same_prefix_collides_with_default_named_other_query`; param id `legacy-none` -> `default-stem`; module docstring.
- New tests: `test_llm_core_p3_sweep.py::TestFinding116UpstreamOperationalSuffixCollision` (10 within-query cases incl. custom response_field, prefix omitted/explicit null; 1 cross-query `a`/`a_b` case; 1 non-colliding control).

## CHANGELOG / COMPAT notes
- BREAKING (config): a multi-query LLM transform in upstream mode whose query output suffix publishes a name equal to any query's raw-response field or its `_usage`/`_model` field (e.g. suffix `llm_response`, `llm_response_usage`, `llm_response_model` under the default query-name stem, or a cross-query `a` suffix `b_llm_response` vs query `a_b`) is now refused at config time (`PluginConfigError`, "collides with the transform's own response/operational fields"). Previously accepted, with the extracted value silently overwritten by the raw reply / usage / model. Fix: choose another suffix, set `structured_output_prefix`, or rename `response_field`. No persisted data affected; existing Composer graphs carrying such a config will fail validation (0.8.7 does not require Composer graph compatibility).
- Behavioural note: previously-accepted configs produced rows where the colliding structured value was lost; there is nothing to migrate.

## Hash
- `LLMTransform.source_file_hash`: `sha256:239240ed0e8901b7` -> `sha256:3c60f14ba869b372` (recomputed after write: stable). `git grep 239240ed` before the change found only transform.py — no scenario-corpus manifest or other pin referenced it.

## Gates (exit codes; logs in this directory)
- ruff check (9 touched .py): 0; ruff format --check: 0
- mypy (6 touched src files): 0
- `python -m scripts.check_contracts`: 0 (`l08-116-contracts.log`)
- lane command `pytest tests/unit/plugins/llm/test_llm_core_p3_sweep.py -n 0`: 0 — 29 passed
- `pytest tests/unit/plugins/llm -n 2`: 0 — 3146 passed (`l08-116-llm.log`)
- adjacent: composer multi-query contract + sources/llm + transforms/llm + integration/plugins/llm: 0 — 311 passed; goldens/teaching-text/plugin_hash/pipeline_planner/validation_guidance etc.: 0 — 1045 passed; allowlist loader/planner aids/prompts/prompt cache/policy view/catalog service/dag corpus contract: 0 — 804 passed, 1 xfailed
- keyless `elspeth-lints check --rules all --root src/elspeth`: exit 1 both before (base tree a81edd3e via temporary detached worktree, since removed) and after; normalized finding sets (root path, line:col, allow_hits index) identical (diff exit 0, 3786 lines each). Unnormalized diff did show differences (paths), so the diff instrument does detect changes. No allowlist or signature touched.
- Full `pytest tests/` NOT run (host rule I). Change reaches shared config validation for the llm plugin and composer stage-one validation; recommend it be covered by the lane's full-suite gate.

## Left in place / decisions for the maintainer
1. Row-entry strictness still keyed on the old opt-in: `transform.py` sets `self._strict_generated_fields` (refuse rows that already carry a field, or an original-name alias, equal to a generated name -> `field_collision` row error) only when `query_input_mode == ordered or any(structured_output_prefix is not None)`. In default-stem upstream mode an input row carrying e.g. `quality_score` is still silently overwritten (as single-prompt mode overwrites an incoming `llm_response`). Making it unconditional would turn chained same-named multi-query nodes into per-row errors at runtime — a runtime behaviour change beyond the config-time fix, so not done. This is the last vestige of the "override opts in" flag.
2. `resolve_queries` positional-variable guard (`_POSITIONAL_VAR_PATTERN`, "legacy positional `{{ input_N }}`" migration hint): appears redundant with `LLMConfig._validate_template_variable_bindings` (which rejects bare `input_N`), but it is a refusal, not a compat path, and the composer path calls `resolve_queries` directly; kept.

## Legacy / compatibility code noticed elsewhere (not touched)
- `src/elspeth/plugins/transforms/llm/model_catalog.py` — whole module is a "Compatibility re-export" of `elspeth.plugins.llm.model_catalog` (including private `_bundled_openrouter_slice*`, `_read_openrouter_catalog`). ~30 importers: cli.py (x2), web/app.py, web/composer/{planner_authoring_aids,tools/generation,provider_gateway}.py, web/_aws_ecs_acceptance/bedrock.py, docstrings in web/execution/service.py, engine/orchestrator/run_lifecycle.py, core/landscape/run_lifecycle_repository.py, and many tests (incl. tests/unit/plugins/llm/test_model_catalog.py which imports it with `# noqa: F401` subprocess strings, test_cli_orchestrator_teardown.py patch target). Removing it means repointing all importers.
- `src/elspeth/web/composer/state.py` — only the opt-in line was changed; no other legacy noticed in the touched function.
