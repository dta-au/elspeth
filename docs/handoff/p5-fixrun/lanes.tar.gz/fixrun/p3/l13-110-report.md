# Lane 13 / finding #110: type_coerce blank string -> bool False removed

Worktree: .claude/worktrees/compassionate-brahmagupta/.claude/worktrees/lane-p3-misc-transforms (branch lane/p3-misc-transforms)
Interpreter: worktree .venv/bin/python 3.14.6; PYTHONPATH=$PWD/src:$PWD/elspeth-lints/src;
elspeth.__file__ and elspeth_lints.__file__ were both confirmed to be inside the worktree.

## Commits
- d2dcac51 test(plugins): type_coerce must not read a blank string as bool False
  - Adds a "Finding #110" section to tests/unit/plugins/transforms/test_misc_transforms_p3_sweep.py
    (TestCoerceToBoolBlankString). It checks that '', ' ', '   ', '\t' and '\n' raise CoercionError with
    failure == "not_boolean_string" and target_type == "bool". That is the same failure mode as an
    unrecognised string such as "maybe". Two negative controls cover "maybe" -> not_boolean_string and
    the remaining real false spellings, which still coerce.
  - RED before the fix: 5 failed with `Failed: DID NOT RAISE CoercionError` at pytest.raises; the 2 controls passed (exit=1).
- 1b98b3c2 fix(plugins): type_coerce no longer reads a blank string as bool False
  - src/elspeth/plugins/transforms/type_coerce.py: removes "" from _BOOL_FALSE_STRINGS and updates the docstring.
    The function had no other blank or whitespace special case. Whitespace-only strings used to reach False
    only because `.strip()` reduced them to "" and "" was in the false set.
  - tests/unit/plugins/transforms/test_type_coerce.py: removes the two pinning assertions:
    "" in test_string_false_set, and `coerce_to_bool("  ") is False  # whitespace-only = empty = false`
    in test_string_with_whitespace. The rest of both tests is unchanged.
  - Re-pins TypeCoerce.source_file_hash.

Failure-mode choice: blank now raises `not_boolean_string`, the same as any unrecognised string, as the brief specified.
The int and float arms raise the more specific `empty_string`. If the operator prefers to match those siblings,
it is a one-line follow-up: an `if not normalized: raise CoercionError(failure="empty_string", ...)` in the str arm.
I did not make that change.

## What broke ("see what breaks")
Nothing. The callers were inventoried with grep:
- Production: the only caller of coerce_to_bool is the `_COERCION_FUNCS["bool"]` dispatch in
  src/elspeth/plugins/transforms/type_coerce.py, used by TypeCoerce.process. No source, CSV parser, config
  parser or other plugin imports it, and nothing else references _BOOL_FALSE_STRINGS.
  - Behaviour change, by design: a `type_coerce` conversion `to: bool` on a field whose value is ''
    or whitespace-only now raises CoercionError(not_boolean_string). The row routes to the transform's
    on_error instead of carrying False downstream. The int and float arms already behaved this way for blanks.
- Examples: examples/transform_pipeline/settings.yaml converts in_stock to bool. Its input.csv has no blank
  in_stock cells (true/yes/1/false/no), so it is unaffected. examples/reference_join uses type_coerce, but
  not for bool.
- Docs: no doc outside the source docstring promised ''->False. The grep covered docs/, src/ and
  examples/ for the bool string sets.
- Tests: the run covered every test file that references TypeCoerce/type_coerce/coerce_to_bool in the plugin,
  pipeline, engine, invariant, property and e2e layers, plus the files that run examples/transform_pipeline.
  The composer/web/dag files only use type_coerce as a config shape and do not coerce values, so they were not run.
  Command (-n 2): test_type_coerce.py, test_misc_transforms_p3_sweep.py, test_type_coerce_output_metadata.py,
  test_forward_invariant_probes.py, test_value_transform_contract_metadata.py, test_reference_join.py,
  test_core_catalogue_metadata.py, test_catalog_reference_content.py, test_validation_path_agreement.py,
  test_output_contract_admits_created_fields.py, integration/plugins/test_type_coerce_declared_metadata.py,
  test_type_coerce_value_transform_pipeline.py, test_state_engine_plugin_lifecycle_matrix.py,
  integration/pipeline/{test_output_declaration_routing,test_multi_source_isolation,test_replay_downstream_discards,
  test_field_name_spelling_rule,test_declared_input_miss}.py, integration/cli/test_instantiate_plugins_value_source.py,
  unit/engine/test_executors.py, invariants/{test_output_guarantees_preserve_abstention,test_declared_field_spelling_surfaces}.py,
  property/engine/test_processor_properties.py, property/audit/test_terminal_states.py, e2e/audit/test_full_lineage.py
  -> exit=0, 1167 passed (log: l13-110-callers.log).

Classification: the only breakage was (a), the two assertions that pinned the old behaviour, and they were removed.
There was no (b): no production caller relied on ''->False.

## COMPAT note for CHANGELOG
type_coerce: a `to: bool` conversion no longer maps an empty or whitespace-only string to `false`. Such values
now fail the conversion ("string is not a valid boolean string") and route the row to the transform's
`on_error`, consistent with `to: int` / `to: float`. Pipelines whose bool columns contain blank cells
must handle those rows on the error path or fill them upstream explicitly. The recognised false spellings
(false/0/no/n/off, case-insensitive, trimmed) are unchanged.

## Hashes
- TypeCoerce.source_file_hash: sha256:c9f7641c7d34f48c -> sha256:09861e25cfae3f30. Computed twice before
  the pin and once after, and stable each time.
- grep across src/tests/docs/scripts/config/examples found no other pin of the old hash (only the
  plugin's own line).
- Negative control: restoring the old pin made `plugin_contract.plugin_hashes` exit 1 with
  "PH3 ... TypeCoerce: stale source_file_hash". With the new pin it exits 0.

## Gate exit codes
- ruff check (3 touched files): 0
- ruff format --check: 0
- mypy src/elspeth/plugins/transforms/type_coerce.py: 0 (Success: no issues found)
- elspeth_lints check --rules plugin_contract.component_type,plugin_contract.plugin_hashes --root src/elspeth: 0
- lane test command (test_misc_transforms_p3_sweep.py -n 0): 0, 65 passed
- caller sweep above: 0, 1167 passed
- scripts/branch-safety-check.sh --intent commit before each commit: FAIL=0 WARN=0
Not run: full suite, testcontainer, the trust-tier keyless scan (the change only drops a set member,
so it adds no new branches or getattrs).

Logs are in this directory as l13-110-*.log. Nothing was pushed.
