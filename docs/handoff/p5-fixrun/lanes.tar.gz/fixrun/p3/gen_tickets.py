import json, re
rep = open("docs/audit/20261111-plugins-review.md").read()
secs = {}
for m in re.finditer(r"^### #(\d+) (.*?)(?=^### |^## |\Z)", rep, re.S | re.M):
    secs[int(m.group(1))] = "FINDING #" + m.group(1) + " " + m.group(2).strip()
P = "src/elspeth/plugins/"; T = "tests/unit/plugins/"
lanes = [
 ("p3-file-sinks", [14,25,26,27,41,79], [P+"sinks/csv_sink.py"], T+"sinks/test_file_sinks_p3_sweep.py"),
 ("p3-cloud-blob", [19,28,29,64,65,66,150], [P+"sinks/aws_s3_sink.py", P+"sinks/azure_blob_sink.py"], T+"sinks/test_cloud_blob_p3_sweep.py"),
 ("p3-sources", [11,42,43,51,52,137], [P+"sources/json_source.py"], T+"sources/test_sources_p3_sweep.py"),
 ("p3-dataverse-chroma", [48,49,75,76,82,85,92,93,94], [P+"sinks/chroma_sink.py", P+"sinks/dataverse.py"], T+"test_dataverse_chroma_p3_sweep.py"),
 ("p3-blob-rasterize", [55,56,69,70,81,95,132,156,162], [P+"transforms/blob_json_expand.py", P+"transforms/pdf_rasterize.py"], T+"transforms/test_blob_rasterize_p3_sweep.py"),
 ("p3-batch", [20,99,107,108,113,115,117,118,119,140], [P+"transforms/batch_paired_preference.py", P+"infrastructure/batching/mixin.py"], T+"transforms/test_batch_p3_sweep.py"),
 ("p3-llm-providers", [62,63,97,123,125,128,133], [P+"transforms/llm/providers/gateway.py"], T+"llm/test_llm_providers_p3_sweep.py"),
 ("p3-llm-core", [32,45,116,139,148,151], [P+"transforms/llm/transform.py"], T+"llm/test_llm_core_p3_sweep.py"),
 ("p3-web-scrape", [5,152,160,161,163], [P+"transforms/web_scrape_links.py"], T+"transforms/test_web_scrape_p3_sweep.py"),
 ("p3-cloud-transforms", [30,35,36,50,61,98,114,134,144], [P+"transforms/aws/textract_result.py"], T+"transforms/test_cloud_transforms_p3_sweep.py"),
 ("p3-clients", [13,22,23,86,141], [P+"infrastructure/clients/http.py"], T+"infrastructure/test_clients_p3_sweep.py"),
 ("p3-infrastructure", [0,6,100,104,126,129,149], [P+"infrastructure/manager.py"], T+"infrastructure/test_infrastructure_p3_sweep.py"),
 ("p3-misc-transforms", [58,77,78,96,106,109,110,142], [P+"transforms/type_coerce.py", P+"transforms/keyword_filter.py"], T+"transforms/test_misc_transforms_p3_sweep.py"),
]
out = []; seen = []
for t, ids, files, tf in lanes:
    for i in ids: assert i in secs, i
    seen += ids
    out.append({"ticket": t,
      "title": "; ".join(secs[i].split("\n")[0].replace("FINDING ", "") for i in ids),
      "description": "This lane fixes " + str(len(ids)) + " findings; fix each one (one test commit + one fix commit PER finding).\n"
        "Every finding names the files where the sweep located it; touch only what each fix needs.\n\n" + "\n\n".join(secs[i] for i in ids),
      "files": files, "test_files": [tf],
      "test_command": f".venv/bin/python -m pytest {tf} -n 0 -q -p no:cacheprovider"})
p3 = sorted(int(l.split("\t")[0][1:]) for l in open(".claude/lanes/fixrun/p3-index.txt") if l.startswith("#"))
assert sorted(seen) == p3, sorted(set(p3) ^ set(seen))
assert len(seen) == len(set(seen))
json.dump(out, open(".claude/lanes/fixrun/tickets-p3.json", "w"), indent=1)
print(len(out), "lanes,", len(seen), "findings")
