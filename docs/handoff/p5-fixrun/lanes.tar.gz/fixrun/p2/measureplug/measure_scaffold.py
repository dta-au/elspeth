import sys
def pytest_collection_modifyitems(items):
    m = sys.modules.get("tests.unit.web.composer.test_pipeline_planner") or next(
        mod for name, mod in sys.modules.items() if name.endswith("test_pipeline_planner"))
    m._FIXED_SCAFFOLDING_MAX_CANONICAL_BYTES = 0
