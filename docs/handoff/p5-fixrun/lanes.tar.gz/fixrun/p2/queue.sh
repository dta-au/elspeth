#!/usr/bin/env bash
# Wait for the running drive.sh to exit; if it ended ALL DONE, drive the queued P3 lanes serially.
cd /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta
LOG=.claude/lanes/fixrun/p2/drive.log
while pgrep -f "lanes/fixrun/p2/drive.sh" >/dev/null; do sleep 60; done
tail -1 $LOG | grep -q "ALL DONE" || { echo "$(date -Is) QUEUE not started: previous driver did not finish ALL DONE" >> $LOG; exit 1; }
echo "$(date -Is) QUEUE start P3 serial" >> $LOG
exec bash .claude/lanes/fixrun/p2/drive.sh lane-05-p3-blob-rasterize lane-04-p3-dataverse-chroma lane-02-p3-cloud-blob lane-01-p3-file-sinks lane-07-p3-llm-providers lane-09-p3-web-scrape lane-03-p3-sources lane-10-p3-cloud-transforms lane-11-p3-clients lane-08-p3-llm-core lane-12-p3-infrastructure lane-13-p3-misc-transforms
