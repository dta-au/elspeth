#!/usr/bin/env bash
# Serial verify -> merge -> branch-safety -> push for the P2 lanes. Stops at the first lane that is not verified.
set -u
cd /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta
L=.claude/lanes/fixrun; LM=".agents/skills/lane-manager/lane_manager.py"; LOG=$L/p2/drive.log
B=claude/compassionate-brahmagupta-o0nhlw
for lane in "$@"; do
  # pytest basetemps from earlier suites filled the disk (2026-11-13 textract run):
  # clear them when no pytest is running, and stop if free space is under 8 GiB.
  pgrep -x pytest >/dev/null || ps -eo args | grep -q "[p]ython -m pytest" || rm -rf /tmp/pytest-of-root
  free_kb=$(df --output=avail / | tail -1); [ "$free_kb" -lt 8388608 ] && { echo "STOP low-disk ${free_kb}KB $lane" >> $LOG; exit 1; }
  echo "$(date -Is) VERIFY $lane df_avail_kb=$free_kb" >> $LOG
  python3 $LM verify --lanes-dir $L/lanes --lane $lane --suite-timeout 14000 > $L/p2/verify-$lane.log 2>&1
  v=$?; echo "$(date -Is) verify exit=$v $lane" >> $LOG
  [ $v -ne 0 ] && { echo "STOP not-verified $lane" >> $LOG; exit 1; }
  python3 $LM merge --lanes-dir $L/lanes --lane $lane > $L/p2/merge-$lane.log 2>&1 || { echo "STOP merge-failed $lane" >> $LOG; exit 1; }
  bash scripts/branch-safety-check.sh --intent push --base origin/$B > $L/p2/bsc-$lane.log 2>&1 || { echo "STOP bsc-failed $lane" >> $LOG; exit 1; }
  ok=1; for d in 0 2 4 8 16; do sleep $d; git push origin $B >> $LOG 2>&1 && { ok=0; break; }; done
  [ $ok -ne 0 ] && { echo "STOP push-failed $lane" >> $LOG; exit 1; }
  echo "$(date -Is) LANDED $lane $(git rev-parse --short HEAD)" >> $LOG
done
echo "$(date -Is) ALL DONE" >> $LOG
