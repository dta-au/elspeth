#!/bin/bash
cd /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/worktrees/lane-p2fu-json-source-depth
L=/home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/p2
mapfile -t ids < $L/p2fu-failed-ids.txt
PYTHONPATH=/home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/worktrees/lane-p2fu-json-source-depth/src:/home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/worktrees/lane-p2fu-json-source-depth/elspeth-lints/src /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/worktrees/lane-p2fu-json-source-depth/.venv/bin/python -m pytest -n 0 -q -rfE -p no:cacheprovider "${ids[@]}" > $L/p2fu-rerun.log 2>&1
echo "exit=$?" > $L/p2fu-rerun.exit
