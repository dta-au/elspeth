#!/usr/bin/env bash
# Start the remaining P4 lanes after the current drive.sh run ends with ALL DONE (not on STOP).
cd /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta
F=.claude/lanes/fixrun/p2/drive.log
n=$(grep -cE "ALL DONE|STOP" $F)
until [ $(grep -cE "ALL DONE|STOP" $F) -gt $n ]; do sleep 60; done
if tail -1 $F | grep -q "ALL DONE"; then
  echo "$(date -Is) CHAIN starting P4 lanes" >> $F
  exec bash .claude/lanes/fixrun/p2/drive.sh lane-01-p4-llm lane-02-p4-batch-json lane-05-p4-safety-aws lane-03-p4-infra-sinks
fi
echo "$(date -Is) CHAIN not started (previous run stopped)" >> $F
