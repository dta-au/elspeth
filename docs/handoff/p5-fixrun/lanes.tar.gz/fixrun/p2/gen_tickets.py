import json, re, sys
rep = open("docs/audit/20261111-plugins-review.md").read()
secs = {}
for m in re.finditer(r"^### #(\d+) (.*?)(?=^### |^## |\Z)", rep, re.S | re.M):
    secs[int(m.group(1))] = "FINDING #" + m.group(1) + " " + m.group(2).strip()
P = "src/elspeth/plugins/"
lanes = [
 ("p2-003-004-155-webscrape", [3,4,155], [P+"transforms/web_scrape.py", P+"transforms/web_scrape_pagination.py"], "tests/unit/plugins/transforms/test_web_scrape_p2_sweep.py"),
 ("p2-009-010-aws-s3-source", [9,10], [P+"sources/aws_s3_source.py"], "tests/unit/plugins/sources/test_aws_s3_source_p2_sweep.py"),
 ("p2-018-068-112-138-deep-nesting", [18,68,112,138], [P+"sources/azure_blob_source.py", P+"transforms/blob_json_expand.py", P+"infrastructure/schema_factory.py", P+"transforms/llm/validation.py"], "tests/unit/plugins/test_deep_nesting_p2_sweep.py"),
 ("p2-024-044-llm-replay-timeout", [24,44], [P+"infrastructure/clients/llm.py", P+"transforms/llm/transform.py"], "tests/unit/plugins/llm/test_llm_p2_sweep.py"),
 ("p2-124-147-llm-tracing", [124,147], [P+"transforms/llm/tracing.py", P+"transforms/llm/providers/azure.py"], "tests/unit/plugins/llm/test_tracing_p2_sweep.py"),
 ("p2-040-080-103-json-csv", [40,80,103], [P+"sources/json_source.py", P+"sources/csv_source.py", P+"sinks/json_sink.py"], "tests/unit/plugins/test_json_csv_p2_sweep.py"),
 ("p2-047-074-083-084-dataverse", [47,74,83,84], [P+"sources/dataverse.py", P+"infrastructure/clients/dataverse.py", P+"sinks/dataverse.py"], "tests/unit/plugins/test_dataverse_p2_sweep.py"),
 ("p2-060-067-122-transforms", [60,67,122], [P+"transforms/reference_join.py", P+"transforms/field_mapper.py", P+"transforms/batch_replicate.py"], "tests/unit/plugins/transforms/test_transforms_p2_sweep.py"),
 ("p2-090-091-chroma-sink", [90,91], [P+"sinks/chroma_sink.py"], "tests/unit/plugins/sinks/test_chroma_sink_p2_sweep.py"),
]
out = []; seen = []
for t, ids, files, tf in lanes:
    for i in ids: assert i in secs, i
    seen += ids
    out.append({"ticket": t,
      "title": "; ".join(secs[i].split("\n")[0].replace("FINDING ", "") for i in ids),
      "description": "This lane fixes " + str(len(ids)) + " findings; fix each one (one test commit + one fix commit PER finding).\n"
        "The listed files are where the sweep located each defect; a finding may need no change in some of them.\n\n" + "\n\n".join(secs[i] for i in ids),
      "files": files, "test_files": [tf],
      "test_command": f".venv/bin/python -m pytest {tf} -n 0 -q -p no:cacheprovider"})
expected = [3,4,9,10,18,24,40,44,47,60,67,68,74,80,83,84,90,91,103,112,122,124,138,147,155]
assert sorted(seen) == expected, sorted(set(expected) ^ set(seen))
json.dump(out, open(".claude/lanes/fixrun/tickets-p2.json", "w"), indent=1)
print(len(out), "lanes,", len(seen), "findings")
