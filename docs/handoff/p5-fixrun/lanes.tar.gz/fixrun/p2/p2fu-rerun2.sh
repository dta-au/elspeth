#!/bin/bash
cd /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/worktrees/lane-p2fu-json-source-depth
L=/home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/p2
: > $L/p2fu-rerun2.log
tail -n +21 $L/p2fu-failed-ids.txt | while read id; do
  PYTHONPATH=/home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/worktrees/lane-p2fu-json-source-depth/src:/home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/worktrees/lane-p2fu-json-source-depth/elspeth-lints/src /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/worktrees/lane-p2fu-json-source-depth/.venv/bin/python -m pytest -n 0 -q -p no:cacheprovider "$id" > $L/p2fu-one.log 2>&1
  rc=$?; echo "rc=$rc $id" >> $L/p2fu-rerun2.log
  [ $rc -ne 0 ] && tail -30 $L/p2fu-one.log >> $L/p2fu-rerun2.log
done
echo done > $L/p2fu-rerun2.exit
