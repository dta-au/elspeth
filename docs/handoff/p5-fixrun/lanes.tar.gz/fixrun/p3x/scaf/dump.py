import sys, pytest
out = sys.argv[1]
class P:
    def pytest_collection_finish(self, session):
        import tests.unit.web.composer.test_pipeline_planner as m
        orig = m.canonical_json
        best = {"s": ""}
        def wrap(x):
            s = orig(x)
            if isinstance(x, dict) and "tools" in x and "messages" in x and len(s) > len(best["s"]):
                best["s"] = s
                open(out, "w").write(s)
            return s
        m.canonical_json = wrap
sys.exit(pytest.main(["-n","0","-q","-p","no:cacheprovider","tests/unit/web/composer/test_pipeline_planner.py::test_initial_request_declares_supplied_information_and_keeps_discovery_available[small]"], plugins=[P()]))
