#!/usr/bin/env bash
# After the P3 serial driver ends ALL DONE, verify/merge/push the p3x lanes.
cd /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta
LOG=.claude/lanes/fixrun/p2/drive.log
while pgrep -f "lanes/fixrun/p2/drive.sh" >/dev/null; do sleep 60; done
tail -1 $LOG | grep -q "ALL DONE" || { echo "$(date -Is) P3X QUEUE not started: previous driver did not finish ALL DONE" >> $LOG; exit 1; }
echo "$(date -Is) QUEUE start P3X" >> $LOG
exec bash .claude/lanes/fixrun/p2/drive.sh lane-01-p3x-076-dataverse-retry-after
