#!/usr/bin/env bash
# After the in-flight lane (web-scrape) reports LANDED or STOP, stop the driver and
# restart it with the integrator-fix lane first, then the remaining lanes.
cd /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta
LOG=.claude/lanes/fixrun/p2/drive.log
DRV=12741
n=$(grep -cE "LANDED|STOP|ALL DONE" $LOG)
until [ $(grep -cE "LANDED|STOP|ALL DONE" $LOG) -gt $n ]; do sleep 30; done
if kill -0 $DRV 2>/dev/null; then
  pg=$(ps -o pgid= -p $DRV | tr -d ' ')
  kill -TERM -- -$pg 2>/dev/null
  sleep 10
fi
rest="lane-03-p3-sources lane-10-p3-cloud-transforms lane-11-p3-clients lane-08-p3-llm-core lane-12-p3-infrastructure lane-13-p3-misc-transforms lane-01-p3x-076-dataverse-retry-after"
grep -q "LANDED lane-09-p3-web-scrape" $LOG || rest="lane-09-p3-web-scrape $rest"
echo "$(date -Is) REORDER: fix lane first, then: $rest" >> $LOG
exec bash .claude/lanes/fixrun/p2/drive.sh lane-01-p3fix-integrator-17 $rest
