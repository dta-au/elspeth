import io
from elspeth.plugins.sources.aws_s3_source import _BoundedDecodedLineIterator, _RecordLimitExceeded
s=io.TextIOWrapper(io.BytesIO(b'abc\r\nd\r\n'),encoding='utf-8',newline='')
it=_BoundedDecodedLineIterator(s,3); n=0
while True:
    try:
        l=next(it, None); it.finish_record()
    except _RecordLimitExceeded:
        it.skip_rest_of_line(); n+=1; print(n,"EXCEEDED"); continue
    if l is None: break
    n+=1; print(n, repr(l))
