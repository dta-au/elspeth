from elspeth.plugins.transforms.azure.content_safety import AzureContentSafetyConfig
from elspeth.plugins.sources.azure_blob_source import AzureBlobSourceConfig
from elspeth.plugins.infrastructure.clients.retrieval.azure_search import AzureSearchProviderConfig
from elspeth.plugins.transforms.llm.providers.openrouter import *  # noqa
import elspeth.plugins.transforms.llm.providers.gateway as gw, elspeth.plugins.transforms.llm.providers.openrouter as orr
for M in (AzureSearchProviderConfig,):
    print("SEARCH", "SENTINELKEY" in repr(M(endpoint="https://x.search.windows.net", index="i", api_key="SENTINELKEY")))
for M,kw in ((AzureContentSafetyConfig, dict(endpoint="https://x.cognitiveservices.azure.com", api_key="SENTINELKEY", fields=["a"], thresholds={"hate":2,"violence":2,"sexual":2,"self_harm":2}, schema={"mode":"observed"})),
             (AzureBlobSourceConfig, dict(connection_string="DefaultEndpointsProtocol=https;AccountKey=SENTINELKEY", container="c", blob_path="p.csv", format="csv", schema={"mode":"observed"}, on_validation_failure="discard"))):
    try:
        m=M.model_validate(kw); print(M.__name__, "SENTINELKEY" in repr(m), "SENTINELKEY" in str(m))
    except Exception as e: print(M.__name__, "construct failed", str(e)[:300])
for mod in (gw, orr):
    for n in dir(mod):
        o=getattr(mod,n)
        if isinstance(o,type) and hasattr(o,"model_fields") and "api_key" in o.model_fields: print(mod.__name__, n, "repr=",o.model_fields["api_key"].repr)
