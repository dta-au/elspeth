from elspeth.plugins.transforms.azure.content_safety import AzureContentSafetyConfig
from elspeth.plugins.transforms.azure.content_understanding import AzureContentUnderstandingConfig
for M in (AzureContentSafetyConfig, AzureContentUnderstandingConfig):
    try:
        M.from_dict({"endpoint":"https://x.cognitiveservices.azure.com","api_key":"SENTINELKEY","schema":{"mode":"observed"},"bogus":1})
    except Exception as e:
        print(M.__name__, "msg-leak:", "SENTINELKEY" in str(e), "cause-leak:", "SENTINELKEY" in str(e.__cause__))
