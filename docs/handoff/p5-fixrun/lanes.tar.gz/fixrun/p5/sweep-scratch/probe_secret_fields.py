import re, typing
from pydantic import BaseModel, SecretStr
from elspeth.plugins.infrastructure.discovery import discover_all_plugins
SECRETISH = re.compile(r"(api_key|apikey|secret|password|passwd|connection_string|sas_token|access_key|session_token|bearer|^token$|_token$|credential|private_key|trigger_url)", re.I)
NOTSECRET = re.compile(r"(_env$|_ref$|_name$|_field|max_|_fingerprint|_id$|auth_mode|_mode$|token_)", re.I)
seen=set()
def models_in(ann):
    out=[]
    origin=typing.get_origin(ann)
    if origin is None:
        if isinstance(ann,type) and issubclass(ann,BaseModel): out.append(ann)
        return out
    for a in typing.get_args(ann): out+=models_in(a)
    return out
def walk(M, path, plugin):
    if (M,path) in seen: return
    seen.add((M,path))
    for name,f in M.model_fields.items():
        if SECRETISH.search(name) and not NOTSECRET.search(name):
            ann=f.annotation
            is_secret = "SecretStr" in repr(ann) or "Secret" in repr(ann)
            print(f"{plugin:28s} {M.__module__}.{M.__name__}.{name}: repr={f.repr} type={ann!r} secretstr={is_secret}")
        for sub in models_in(f.annotation):
            walk(sub, path+"."+name, plugin)
plugins=discover_all_plugins()
for kind, classes in plugins.items():
    for c in classes:
        cm=getattr(c,"config_model",None)
        if cm is None: continue
        walk(cm, "", f"{kind}:{c.name}")
