import httpx
from elspeth.core.security.web import validate_url_for_ssrf, validate_allowed_http_origin, parse_http_origin, SSRFBlockedError
for u in ["https://8.8.8.8/a\n", "https://8.8.8.8/a\x7f", "https://8.8.8.8/a\x01", "https://8.8.8.8/ok"]:
    try:
        r = validate_url_for_ssrf(u); res="ssrf-ADMIT"
        try: httpx.Request("GET", r.connection_url); res+=" httpx-ok"
        except Exception as e: res+=f" httpx-{type(e).__name__}"
    except SSRFBlockedError as e: res="ssrf-reject"
    try: validate_allowed_http_origin(u, (parse_http_origin("https://8.8.8.8"),)); o="origin-ADMIT"
    except SSRFBlockedError: o="origin-reject"
    print(repr(u), res, o)
