from unittest.mock import MagicMock
from elspeth.plugins.sources.csv_source import CSVSource
from elspeth.plugins.sources.text_source import TextSource
from elspeth.plugins.sources.json_source import JSONSource
import json
for label, mk in [
 ("csv", lambda: CSVSource({"path":"/home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/p5/sweep-scratch/bom.csv","schema":{"mode":"observed"},"on_validation_failure":"discard"})),
 ("text", lambda: TextSource({"path":"/home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/p5/sweep-scratch/bom.txt","column":"line","schema":{"mode":"observed"},"on_validation_failure":"discard"})),
 ("jsonl(control)", lambda: JSONSource({"path":"/home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/p5/sweep-scratch/bom.jsonl","format":"jsonl","schema":{"mode":"observed"},"on_validation_failure":"discard"})),
]:
    try:
        rows=list(mk().load(MagicMock()))
        print(label, [ (r.row if hasattr(r,'row') else r) for r in rows][:2])
    except Exception as e: print(label,"ERR",type(e).__name__,e)
try: json.loads(b'\xef\xbb\xbf{"a":1}'.decode("utf-8"))
except Exception as e: print("blob_json_expand-style decode+loads:", e)
