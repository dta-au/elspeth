import copy, sys
sys.path.insert(0, ".claude/lanes/fixrun/p5/sweep-scratch")
from literal_probe import literal_values, baseline, validate
from elspeth.plugins.infrastructure.discovery import discover_all_plugins
for kind, classes in discover_all_plugins().items():
    for c in classes:
        cm=getattr(c,"config_model",None)
        if cm is None: continue
        base,how=baseline(c)
        if base is None or validate(cm,base): continue
        try: c(copy.deepcopy(base))
        except Exception as e:
            print(f"BASEINIT-FAIL {kind}:{c.name}: {type(e).__name__} {str(e)[:100]}"); continue
        for fname,f in cm.model_fields.items():
            key=f.alias or fname
            for v in literal_values(f.annotation):
                cfg=copy.deepcopy(base); cfg[key]=v
                if validate(cm,cfg): continue
                try: c(cfg)
                except Exception as e: print(f"INIT-REJECT {kind}:{c.name}.{key}={v!r}: {type(e).__name__}: {str(e)[:200]}")
