import sys; sys.path.insert(0, ".claude/lanes/fixrun/p5/sweep-scratch")
from literal_probe import baseline, validate
from elspeth.plugins.infrastructure.discovery import discover_all_plugins
d=discover_all_plugins(); print({k:len(v) for k,v in d.items()})
n=0
for k,cs in d.items():
    for c in cs:
        b,h=baseline(c)
        if b is not None and not validate(c.config_model,b): n+=1
print("valid baselines",n)
import copy
ok=0; fail=[]
for k,cs in d.items():
    for c in cs:
        b,h=baseline(c)
        if b is None or validate(c.config_model,b): continue
        try: c(copy.deepcopy(b)); ok+=1
        except Exception as e: fail.append((c.name,type(e).__name__))
print("init ok",ok,"fail",fail)
