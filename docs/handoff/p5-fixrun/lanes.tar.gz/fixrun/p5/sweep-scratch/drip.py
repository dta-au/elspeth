import socket, threading, time, httpx
srv=socket.socket(); srv.bind(("127.0.0.1",0)); srv.listen(1); port=srv.getsockname()[1]
def serve():
    c,_=srv.accept(); c.recv(4096)
    c.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 8\r\n\r\n")
    for i in range(8): time.sleep(0.4); c.sendall(b"x")
    c.close()
threading.Thread(target=serve,daemon=True).start()
t=time.monotonic()
with httpx.Client(timeout=1.0) as cl:
    r=cl.get(f"http://127.0.0.1:{port}/")
print("body",r.content,"elapsed %.1fs with timeout=1.0"%(time.monotonic()-t))
