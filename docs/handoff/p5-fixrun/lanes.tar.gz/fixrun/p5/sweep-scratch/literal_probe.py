import typing, copy, yaml, sys
from elspeth.plugins.infrastructure.discovery import discover_all_plugins
def literal_values(ann):
    o=typing.get_origin(ann)
    if o is typing.Literal: return list(typing.get_args(ann))
    if o is typing.Annotated: return literal_values(typing.get_args(ann)[0])
    if o in (typing.Union,) or str(o)=="<class 'types.UnionType'>":
        vals=[]
        for a in typing.get_args(ann): vals+=literal_values(a)
        return vals
    return []
def baseline(c):
    try: return c.probe_config(), "probe"
    except Exception: pass
    ex=getattr(c,"example_use",None)
    if isinstance(ex,str):
        try:
            d=yaml.safe_load(ex)
            for sect in ("sources","transforms","sinks"):
                if isinstance(d,dict) and sect in d:
                    v=d[sect]
                    node = v[0] if isinstance(v,list) else next(iter(v.values()))
                    return dict(node.get("options",{})), "example"
            if isinstance(d,dict) and "options" in d: return dict(d["options"]),"example"
            if isinstance(d,dict): return d,"example-raw"
        except Exception as e: return None, f"yaml-fail {e}"
    return None,"none"
def validate(cm, cfg):
    try:
        cm.model_validate(cfg); return None
    except Exception as e: return str(e).replace("\n"," | ")[:240]
def _main():
  pass
if __name__=="__main__":
 for kind, classes in discover_all_plugins().items():
    for c in classes:
        cm=getattr(c,"config_model",None)
        if cm is None: continue
        base, how = baseline(c)
        if base is None: print(f"SKIP {kind}:{c.name} ({how})"); continue
        err=validate(cm, base)
        if err: print(f"BASEFAIL {kind}:{c.name} ({how}): {err[:160]}"); continue
        for fname,f in cm.model_fields.items():
            key = f.alias or fname
            vals = literal_values(f.annotation)
            for v in vals:
                cfg=copy.deepcopy(base); cfg[key]=v
                e=validate(cm,cfg)
                if e: print(f"REJECT {kind}:{c.name}.{key}={v!r}: {e}")
