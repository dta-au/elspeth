import csv
from unittest.mock import MagicMock
from elspeth.plugins.sources.text_source import TextSource
src = TextSource({"path":"/home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/p5/sweep-scratch/b64.txt","column":"line","encoding":"base64","schema":{"mode":"observed"},"on_validation_failure":"discard"})
try:
    print(list(src.load(MagicMock())))
except Exception as e: print("RUNTIME", type(e).__name__, e)
for d in ['"', '\n', '\r']:
    try: csv.reader([], delimiter=d, strict=True); print(repr(d),"reader ok")
    except Exception as e: print(repr(d), "reader", type(e).__name__, e)
try: b"x".decode("rot13")
except Exception as e: print("decode", type(e).__name__, e)
