import importlib
targets = [
 ("elspeth.plugins.sources.csv_source","CSVSourceConfig"),
 ("elspeth.plugins.sources.json_source","JSONSourceConfig"),
 ("elspeth.plugins.sources.text_source","TextSourceConfig"),
 ("elspeth.plugins.sources.azure_blob_source","CSVOptions"),
 ("elspeth.plugins.sources.azure_blob_source","JSONOptions"),
 ("elspeth.plugins.sources.aws_s3_source","CSVOptions"),
 ("elspeth.plugins.sources.aws_s3_source","JSONOptions"),
 ("elspeth.plugins.sinks.csv_sink","CSVSinkConfig"),
 ("elspeth.plugins.sinks.json_sink","JSONSinkConfig"),
 ("elspeth.plugins.sinks.azure_blob_sink","CSVWriteOptions"),
 ("elspeth.plugins.sinks.aws_s3_sink","CSVWriteOptions"),
 ("elspeth.plugins.sinks.document_sink","DocumentSinkConfig"),
 ("elspeth.plugins.sinks.text_sink","TextSinkConfig"),
 ("elspeth.plugins.transforms.blob_csv_expand","BlobCSVExpandConfig"),
 ("elspeth.plugins.transforms.blob_json_expand","BlobJSONExpandConfig"),
 ("elspeth.plugins.transforms.blob_text_expand","BlobTextExpandConfig"),
 ("elspeth.plugins.transforms.file_inject","FileInjectEntryConfig"),
]
for mod, cls in targets:
    C = getattr(importlib.import_module(mod), cls)
    res = []
    for name in ("_validate_encoding",):
        f = C.__dict__.get(name)
        fn = getattr(C, name, None)
        if fn is None:
            res.append("enc:no-validator(fields=%s)" % ("encoding" in C.model_fields)); continue
        for enc in ("base64","rot13","utf-16","utf-7"):
            try: fn(enc); res.append(f"{enc}:ACCEPT")
            except Exception as e: res.append(f"{enc}:reject")
    for name in ("_validate_delimiter","_reject_empty_delimiter"):
        fn = getattr(C, name, None)
        if fn is None: continue
        for d in ('"', "\n", "\r"):
            try: fn(d); res.append(f"delim{d!r}:ACCEPT")
            except Exception: res.append(f"delim{d!r}:reject")
    if "delimiter" in C.model_fields and not any(getattr(C,n,None) for n in ("_validate_delimiter","_reject_empty_delimiter")):
        res.append("delim:no-validator")
    print(f"{mod.split('.')[-1]}.{cls}: "+" ".join(res))
