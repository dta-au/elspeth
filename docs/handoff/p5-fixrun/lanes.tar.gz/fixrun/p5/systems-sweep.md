Systems sweep at b02c94dc: 11 pattern families (8 seeded, 3 new), 47 sites (33 CONFIRMED, 14 PLAUSIBLE). 21 sites are outside every lane's named scope, and 6 more depend on a lane fixing the shared helper rather than only the site it names.

Method. Every finding below came from reading the code path end to end. Where a measurement was cheap, a probe script ran it; the scripts are in `.claude/lanes/fixrun/p5/sweep-scratch/`. Each probe was checked against a known positive and a known negative before its numbers were used. Examples: `enc_probe.py` rejects `base64` and `"` on CSVSink (the fixed site) and accepts them elsewhere. `probe_secret_fields.py` reports `repr=False` on Azure DI/CU and `repr=True` on Content Safety. `dbg.py` confirms that 58 plugins constructed from a valid baseline before the Literal init probe was trusted. No source, test or config was edited.

Lane scope was read from `.claude/lanes/fixrun/p5/tickets.json`. "Lane named" means the ticket text names the site. "Lane-transitive" means the site is fixed only if the lane fixes the shared helper, as its brief says it should. "NOT COVERED" means no lane names it.

---

## F1. A config validator is weaker than the runtime that consumes the value (seed 1)

**Structural cause.** Each config model writes its own `@field_validator("encoding")` / `("delimiter")`. The CSV and codec runtime is a second, independent source of truth. A shared authority exists (`config_base.validate_csv_delimiter`), but only `blob_csv_expand` uses it. A better codec check exists in `aws_s3_source._validate_text_encoding`, but it is private. That makes **6 different encoding validators** and **4 different delimiter validators** in the tree.

**Recurrence mechanism.** A reviewer fixes the plugin in front of them by probing the runtime, as `csv_sink` now does. The siblings are separate classes, often nested `CSVOptions` / `CSVWriteOptions` / `JSONOptions` models that nothing else links to, so nothing forces them to follow.

**Single fix.** Define two annotated types in `config_base`: `TextEncoding = Annotated[str, AfterValidator(validate_text_encoding)]` and `CSVDelimiter = Annotated[str, AfterValidator(validate_csv_delimiter)]`. Each validator probes the real consumer (`csv.writer` / `csv.reader` with the dialect actually used; an incremental decoder/encoder that must produce `str` / `bytes`). Every `encoding: str` / `delimiter: str` becomes one of these types. Add a whole-tree test that walks every plugin config (including nested models) and fails on any field named `encoding` or `delimiter` that is not one of these types. `enc_probe.py` is a ready-made instrument for that test.

Measured by `enc_probe.py`: ACCEPT/reject per validator for `base64`, `rot13`, `"`, `\n`, `\r`.

| Site | Plugin | What goes wrong | Status | Lane |
|---|---|---|---|---|
| sources/csv_source.py:138-143 | csv source | delimiter `"`/`\n`/`\r` accepted; `csv.reader` raises ValueError "bad delimiter" at load | CONFIRMED | p5-io-validation (named) |
| sources/azure_blob_source.py:101-106 | azure_blob source CSV | same delimiter gap | CONFIRMED | p5-io-validation (named) |
| sources/aws_s3_source.py:93-98 | aws_s3 source CSV | same delimiter gap | CONFIRMED | p5-io-validation (named) |
| **sinks/azure_blob_sink.py:138-143** | azure_blob sink CSV | delimiter `"`/`\n` accepted; `csv.DictWriter(delimiter=...)` at :947 raises at publication | CONFIRMED | **NOT COVERED** (brief lists only source delimiters) |
| **sinks/aws_s3_sink.py:99-104** | aws_s3 sink CSV | same; `csv.writer` at :563 raises at publication | CONFIRMED | **NOT COVERED** (brief lists only source delimiters) |
| sources/json_source.py:145, sources/text_source.py:57 | json/text sources | `base64`/`rot13` accepted; `open(..., encoding='base64')` raises LookupError at load (TextSource repro: `RUNTIME LookupError 'base64' is not a text encoding`) | CONFIRMED | p5-io-validation (named) |
| sources/azure_blob_source.py:108-117, 128-137 | azure_blob CSVOptions/JSONOptions | non-text codec accepted; `bytes.decode` raises LookupError, which is not caught (only UnicodeDecodeError is) | CONFIRMED | p5-io-validation (named) |
| sinks/azure_blob_sink.py:145-154 | azure_blob sink CSV | non-text codec accepted; `codecs.getincrementalencoder('base64')().encode(str)` fails at publication | CONFIRMED | p5-io-validation (named: brief lists "text/json/aws_s3/azure_blob/document sinks") |
| **transforms/blob_csv_expand.py:115-122** | blob_csv_expand | non-text codec accepted; `body.decode(...)` at :656 raises LookupError, which the `except UnicodeDecodeError` does not catch, so the transform crashes on the first row | CONFIRMED | **At risk**: brief says "check every encoding option in src/elspeth/plugins" but names only sources/sinks |
| **transforms/blob_json_expand.py:148-155** | blob_json_expand | same; decode at :781 | CONFIRMED | **At risk** (same) |
| **transforms/blob_text_expand.py:119-126** | blob_text_expand | same; decode at :436 | CONFIRMED | **At risk** (same) |
| aws_s3_sink.py:107-119, json_sink.py:100-110, csv_sink.py:173-187, aws_s3_source.py:121-130 | (already correct) | four *different* correct implementations of the same check; drift risk | CONFIRMED | p5-io-validation ("ONE shared validator") |

Not a defect: `document_sink`/`text_sink` restrict encodings by Literal; `file_inject` delimiter is checked by parsing at config load (file_inject.py:516-524).

---

## F2. Secrets visible in repr/str (seed 2)

**Structural cause.** Each config declares its credential as a bare `str` field. Hiding it depends on a per-field `repr=False` that the author must remember. `azure_auth.AzureAuthConfig` does hide `connection_string`/`sas_token`/`client_secret` (azure_auth.py:68-80). But the Azure Blob source and sink configs **re-declare the same three fields** with defaults, so the shared model's protection is bypassed.

**Recurrence mechanism.** Nothing ties "is a credential" to the type. Reviewers fix the LLM configs they are looking at.

**Single fix.** Make every credential field `SecretStr`, as `web_scrape_auth` and `power_automate` already do, or at minimum a shared `Credential = Annotated[str, Field(repr=False)]`. Add a whole-tree test, using the walk in `probe_secret_fields.py`, that fails when a secret-named field on any plugin config (nested models included) is a plain `str` with `repr=True`. Have Azure Blob configs compose `AzureAuthConfig` instead of copying its fields.

Measured by `probe_secret_fields.py` over all discovered plugin configs, plus `repr_probe.py`, which builds the model with `SENTINELKEY` and checks `repr()` and `str()`.

| Site | Plugin | What goes wrong | Status | Lane |
|---|---|---|---|---|
| transforms/llm/providers/openrouter.py:242 | llm (openrouter) | `api_key` repr=True (probe: `OpenRouterConfig repr= True`) | CONFIRMED | p5-llm-audit (named, #128) |
| transforms/llm/providers/gateway.py:154 | llm (gateway) | `api_key` repr=True | CONFIRMED | p5-llm-audit (named, #128) |
| **sources/azure_blob_source.py (AzureBlobSourceConfig)** | azure_blob source | `connection_string`, `sas_token`, `client_secret` repr=True; `SENTINELKEY` in repr **and** str: True/True | CONFIRMED | **NOT COVERED** |
| **sinks/azure_blob_sink.py (AzureBlobSinkConfig)** | azure_blob sink | same three fields repr=True | CONFIRMED (probe) | **NOT COVERED** |
| **transforms/azure/content_safety.py (AzureContentSafetyConfig.api_key)** | azure_content_safety | repr=True; sentinel in repr and str | CONFIRMED | **NOT COVERED** |
| **transforms/azure/prompt_shield.py (AzurePromptShieldConfig.api_key)** | azure_prompt_shield | repr=True | CONFIRMED (probe) | **NOT COVERED** |
| **transforms/azure/ai_search.py (AzureAISearchConfig.api_key)** | azure_ai_search | repr=True | CONFIRMED (probe) | **NOT COVERED** |
| **infrastructure/clients/retrieval/azure_search.py:69 (AzureSearchProviderConfig.api_key)** | rag (azure_search provider) | plain `str` field; sentinel in repr: True | CONFIRMED | **NOT COVERED** |
| infrastructure/config_base.py:355-361 | all configs | `PluginConfigError` is raised `from e`, where `e` is a pydantic ValidationError that carries `input_value` (a truncated dict repr). The message itself is input-free (`include_input=False`), but a traceback that prints `__cause__` can show the first ~25 characters of a secret placed first in the dict | PLAUSIBLE (the sentinel did not appear in two tries because pydantic elided it; the leak depends on key order and length) | NOT COVERED |

---

## F3. A call is classified SUCCESS in the audit row, then rejected (seed 3)

**Structural cause.** In the AuditedLLMClient path (Azure, Bedrock and the LLM source via those providers), the client writes `CallStatus.SUCCESS` (clients/llm.py:1237-1258) **before** the provider applies its semantic verdict (empty content, azure.py:249-267; bedrock.py:306-312). OpenRouter and Gateway validate first (`_validate_*_response`, then `_record_logical_llm_success`). The AWS Textract and Guardrails clients do the same: parse, then classify, then record (textract_client.py:747-790, guardrails_client.py:770-830). The ordering is the bug: record, then classify.

**Recurrence mechanism.** "Record the call" lives in shared infrastructure and "is this response acceptable" lives in the plugin, with no seam in between.

**Single fix.** Pass a provider-supplied response classifier into the audited client, so the status written equals the classification. That is the p5-llm-audit plan.

| Site | Plugin | What goes wrong | Status | Lane |
|---|---|---|---|---|
| clients/llm.py:1237 + providers/azure.py:249-267 | llm (azure), llm source (azure) | empty completion recorded SUCCESS, then raised | CONFIRMED (traced) | p5-llm-audit (named) |
| clients/llm.py:1237 + providers/bedrock.py:306-312 | llm (bedrock), llm source | same | CONFIRMED (traced) | p5-llm-audit (named) |
| transform.py:221, sources/llm/source.py:444 (`classify_finish_reason_failure`) | llm, all providers | non-empty `finish_reason=length/content_filter` is recorded SUCCESS at call level on **every** provider, including OpenRouter/Gateway, then rejected at row level. Empty+length is ERROR on OpenRouter but would become a classified non-SUCCESS on Azure after the lane, while truncated non-empty content stays SUCCESS everywhere | PLAUSIBLE (arguably a design choice; it breaks the "call row = classification" rule the lane adopts) | **NOT COVERED** (lane is scoped to empty content) |
| clients/http.py:634, :1672, :2058 (2xx ⇒ SUCCESS) | azure_content_safety, azure_prompt_shield, azure DI/CU, azure_ai_search, dataverse | 2xx with a malformed body is recorded SUCCESS. The plugin then raises `MalformedResponseError` (azure/base.py:449) and the row errors. Contrast AWS clients, which record `malformed_response` as ERROR | PLAUSIBLE (transport-vs-logical distinction; LLMs have a logical call row, these plugins do not) | **NOT COVERED** |

---

## F4. A shared security helper is weaker than one caller's local fix (seed 4)

**Structural cause.** `validate_url_for_ssrf` / `validate_allowed_http_origin` (core/security/web.py:422-426, 494) refuse fewer characters than `httpx` does. `validate_allowed_http_origin` refuses `<32` but not DEL, and returns early when there is no allow-list. `urllib` silently strips `\t\r\n`. So a URL can pass SSRF and then either crash in httpx (`httpx.InvalidURL`, which is not an `httpx.RequestError`, so callers' handlers miss it) or be fetched in a form different from the audited row URL. Callers then add local predicates, and those diverge.

**Recurrence mechanism.** Each caller carries its own copy of "refuse control chars": `web_scrape.py:1346` (C0+DEL, correct), `web_scrape_pagination.py:98` (`<32`, misses DEL), `web_scrape_request_headers.py:53` (C0+DEL), `web_scrape_json_extraction.py:107` (C0+DEL), `blob_fetch` (none).

**Single fix.** Refuse C0+DEL (the httpx predicate) inside `validate_url_for_ssrf`, `validate_url_scheme` and `validate_allowed_http_origin`, before parsing and regardless of the allow-list. Then delete the local copies. This is p5-web's brief.

Measured by `ssrf_ctrl.py`: `https://8.8.8.8/a\x7f` → `ssrf-ADMIT httpx-InvalidURL origin-ADMIT`; `.../a\x01` → `ssrf-ADMIT httpx-InvalidURL`; `.../a\n` → `ssrf-ADMIT httpx-ok` (the newline is stripped, so the fetched URL ≠ the row URL); `.../ok` → admit (control).

| Site | Plugin | What goes wrong | Status | Lane |
|---|---|---|---|---|
| core/security/web.py:422-426, 494 | shared | admits DEL; admits all C0 when allowed_origins is empty | CONFIRMED | p5-web (named) |
| transforms/blob_fetch.py:529-578, 697-740 | blob_fetch | row URL with DEL/C0 passes SSRF; `httpx.InvalidURL` escapes the `except httpx.RequestError` at :738 and http.py:2078-2145 re-raises it, so the run crashes instead of producing a row error. `\n` in a row URL is fetched without the newline while the audit holds the original | CONFIRMED (traced; core repro) | Lane-transitive (p5-web "every caller") |
| transforms/web_scrape_pagination.py:98 | web_scrape pagination | Link-header check refuses `<32` but not DEL; `next_link_selector` hrefs (from scraped HTML) get no control-char check; both reach `validate_url_for_ssrf` → `httpx.InvalidURL` → not caught at web_scrape.py:1968-1989 | PLAUSIBLE (`fingerprint_url` at :1586 may percent-encode; not run) | Lane-transitive (p5-web), **but the local `<32` copy at :98 should be deleted, and the brief names only the core file** |
| infrastructure/clients/dataverse.py:500-523, 789 | dataverse source | a server-supplied `@odata.nextLink` with DEL passes the SSRF layers; `httpx.InvalidURL` is not an `httpx.HTTPError`, so it escapes the client's handlers and crashes the source | PLAUSIBLE (traced) | Lane-transitive (p5-web) |
| infrastructure/clients/power_automate.py:302, clients/retrieval/connection.py:73, retrieval/azure_search.py:336 | power_automate, rag | config-time URLs only (operator-supplied); same helper | PLAUSIBLE, low | Lane-transitive (p5-web) |

---

## F5. Encoding and stream-boundary bugs fixed in one source, not in its siblings (seed 5)

**Structural cause.** There is no shared external-text decoder. Each source picks its own `errors=` (strict / `surrogateescape` / `BYTE_ESCAPE_ERRORS`), its own read framing (whole-blob decode, TextIOWrapper, bounded `readline`), and its own line counter. `json_source`/`text_source` moved to `BYTE_ESCAPE_ERRORS` because `surrogateescape` cannot carry UTF-16/32 errors. The blob and S3 sources were not updated.

**Recurrence mechanism.** Fixes land in the source under review. Azure Blob and S3 re-implement CSV/JSONL loading from bytes in their own files.

**Single fix.** One `iter_decoded_lines(binary, encoding, max_record_chars)` helper in `plugins/sources/` that byte-escapes, yields `(physical_line_no, text)`, and treats CR+LF as one terminator across bounded reads. Every source and blob transform frames lines through it.

Repro (`crlf.py`, `_BoundedDecodedLineIterator` on `b'abc\r\nd\r\n'`, max 3): `1 EXCEEDED / 2 '\n' / 3 'd\r\n'`, so `d` is reported as line 3, not line 2. A UTF-16 repro of `TextIOWrapper(..., errors='surrogateescape')` on good/bad/good lines gives `ABORT` before line 1 is yielded, and whole-blob `.decode` gives `ABORT`.

| Site | Plugin | What goes wrong | Status | Lane |
|---|---|---|---|---|
| sources/aws_s3_source.py:596, 617 (`readline(limit)`) | aws_s3 JSONL | an oversized line ending between CR and LF leaves a stray `\n` that counts as a line, so every later `__line_number__`/`source_row_index` is off by one | CONFIRMED | p5-io-validation (named) |
| sources/text_source.py | text | UTF-16 chunking: **already fixed at b02c94dc** (uses `BYTE_ESCAPE_ERRORS`, text_source.py:163-166) | CONFIRMED fixed | p5-io-validation (named; probably a no-op, re-prove RED) |
| **sources/aws_s3_source.py:1303-1308 (`errors="surrogateescape"`)** | aws_s3 JSONL | UTF-16/32 lone surrogate aborts the whole 8 KB chunk: valid lines before and after it are lost and the line number is wrong (json_source #42 sibling) | CONFIRMED (codec repro + same code shape) | **NOT COVERED** |
| **sources/azure_blob_source.py:1087-1092** | azure_blob JSONL | same `surrogateescape` TextIOWrapper | CONFIRMED (repro of identical construct) | **NOT COVERED** |
| **sources/azure_blob_source.py:735** | azure_blob CSV | whole-blob `decode(errors="surrogateescape")`: for UTF-16/32 one bad code unit quarantines the entire blob and emits zero rows | CONFIRMED (repro: whole-blob decode ABORT) | **NOT COVERED** |
| sources/aws_s3_source.py:1192, :1374 | aws_s3 CSV / JSON array | strict decode stops at the first bad byte and drops the rest (documented "processing stopped"); rows are not isolated as local CSV does | PLAUSIBLE (deliberate, recorded) | NOT COVERED (consistency only) |

---

## F6 (NEW). UTF-8 BOM is stripped in some readers, not in their siblings

**Structural cause.** This is the same missing decoder authority as F5. BOM handling was added per site: json_source.py:252-256 (`utf-8-sig`), file_inject.py:256, reference_join.py:290. CSV survives only by accident, because header normalisation strips U+FEFF.

**Recurrence mechanism.** It is fixed where reported (#43 was JSON source).

**Single fix.** Put this in the F5 helper: when the codec is UTF-8, decode as `utf-8-sig`.

Measured by `bom_probe.py`: text source → `[{'line': '﻿hello'}]`; jsonl (control, fixed) → `[{'a': 1}]`; csv → `[{'id': '1', ...}]` (OK); `json.loads(bom_text)` → `Unexpected UTF-8 BOM`.

| Site | Plugin | What goes wrong | Status | Lane |
|---|---|---|---|---|
| **sources/text_source.py:166** | text | the first row's value carries a leading U+FEFF into the pipeline | CONFIRMED | **NOT COVERED** |
| **transforms/blob_json_expand.py:781** | blob_json_expand | a BOM-prefixed JSON blob is refused by `json.loads` (row error); JSONL loses line 1 | CONFIRMED (traced + loads repro) | **NOT COVERED** |
| **transforms/blob_text_expand.py:436** | blob_text_expand | the first chunk carries U+FEFF | CONFIRMED (traced) | **NOT COVERED** |
| **sources/azure_blob_source.py:1034 / 1087** | azure_blob JSON / JSONL | JSON array: whole file quarantined. JSONL: line 1 quarantined (`str.strip` does not strip U+FEFF) | CONFIRMED (traced) | **NOT COVERED** |
| sources/aws_s3_source.py:1374 (ijson over a re-encoded TextIOWrapper) / :1303 | aws_s3 JSON / JSONL | same as Azure | PLAUSIBLE (not run) | NOT COVERED |
| transforms/blob_csv_expand.py:656 | blob_csv_expand | header first name has U+FEFF; whether normalisation strips it depends on header mode (`original` mode keeps it) | PLAUSIBLE | NOT COVERED |

---

## F7. A config Literal advertises values that validation or effect admission then refuses (seed 6)

**Structural cause.** A sink's config `Literal[...]` and its `supported_effect_modes` ClassVar (base.py:2100) are two independent declarations.

**Single fix.** Derive the option's Literal from `supported_effect_modes`, or add a whole-tree test asserting `Literal values ⊆ supported_effect_modes` for each sink's mode-selecting field.

Measured by `literal_probe.py` and `literal_init_probe.py`: for every discovered plugin with a valid baseline (58/62), each Literal value was set alone and validated, then constructed. Every config-time refusal found is a cross-field dependency (e.g. `mode=append` needs `collision_policy=append_or_create`; `search_mode=semantic` needs `semantic_config`). **No Literal value was refused by `__init__`** (58/58 baselines constructed). `supported_effect_modes` per sink: azure_blob/s3/document/power_automate {write}, csv/json/text {append, write}, dataverse {upsert}, database {append}, chroma {overwrite}.

| Site | Plugin | What goes wrong | Status | Lane |
|---|---|---|---|---|
| sinks/database_sink.py:226 vs :284/:334 | database | `if_exists: 'replace'` advertised, refused | CONFIRMED | p5-db-chroma (named) |
| sinks/chroma_sink.py:113 vs :215/:521 | chroma_sink | `on_duplicate: skip/error` advertised, refused at publication | CONFIRMED | p5-db-chroma (named) |
| (all other sinks) | — | Literal ⊆ supported modes | CONFIRMED clean | — |
| sources/llm, transforms/llm | llm | not probed: `probe_config()` returns an `api_key` the top-level config forbids (BASEFAIL) | not measured | — |

---

## F8. Docs or hints describe a defect instead of fixing it (seed 7)

**Structural cause.** A limit enforced only at runtime cannot be expressed in config, so authors document it in `composer_hints`. Nothing in graph validation reads it.

**Single fix.** Give plugins a declared, structured limit (e.g. a `max_batch_rows` ClassVar) that graph validation checks against the aggregation trigger and an end-of-source flush. Hints are then generated from that limit, not hand-written.

| Site | Plugin | What goes wrong | Status | Lane |
|---|---|---|---|---|
| batch_drift_compare / batch_outlier_annotator / batch_rank / batch_paired_preference (`_MAX_BATCH_ROWS=4096`, hint "A flush over more than … fails the whole batch") | 4 batch transforms | cap only enforced at flush | CONFIRMED | p5-batch (named, #20) |
| **transforms/batch_duplicate_annotator.py:27, :193, hint :180** | batch_duplicate_annotator | same 4096 constant, a fifth copy. It requires an end-of-source window, so **any source over 4096 rows** fails the whole batch (`comparison_capacity_exceeded`), and the cap appears only in a hint. A trigger.count check cannot catch it: it needs a source-size bound or a different design | CONFIRMED (traced) | **NOT COVERED** (p5-batch names 4 files; "keep one authority for the cap value" should include this fifth constant) |
| web_scrape.py:226 "Request timeout in seconds", blob_fetch.py:93, openrouter.py:247, gateway.py:163 "Request timeout" | HTTP plugins | the description implies a total bound; the behaviour is per-socket-phase (see F9) | CONFIRMED | **NOT COVERED** |

---

## F9 (NEW, seed 8 generalised). Deadlines whose clock does not bound what the name says

**Structural cause.** `HTTPDeadline` + `DeadlineHTTPTransport` (clients/deadline.py) give an absolute exchange deadline, but http.py:1816 applies it **only** for `HTTPAuditPolicy.POWER_AUTOMATE_V1`. Every other audited HTTP call passes `timeout=` to httpx, which bounds each connect, read or write separately. A server that sends one byte just under every `timeout` seconds keeps the request alive without limit, up to `max_body_bytes`. Several plugins size their engine batch wait as "retry budget + one HTTP timeout": `azure/base.py:165-167` and `transform.py:108-116`. That arithmetic assumes the timeout is a total, so a drip-feed outlives the engine waiter, and the row then dies on a bare `TimeoutError` instead of the plugin's structured, audited result.

**Recurrence mechanism.** The absolute-deadline machinery was built for one client policy (Power Automate) and never made the default.

**Single fix.** Make `HTTPDeadline` the default for every `AuditedHTTPClient` request (redirect hops included, sharing one budget), and set row-level deadlines at accept (p5-llm-pool-deadline's model) for every batch plugin, not only LLM.

Repro (`drip.py`): `httpx.Client(timeout=1.0)` against a local server sending 8 bytes at 0.4 s intervals returns `body b'xxxxxxxx' elapsed 3.3s with timeout=1.0`.

| Site | Plugin | What goes wrong | Status | Lane |
|---|---|---|---|---|
| transforms/llm/transform.py pooled path; pooling/executor.py:571-572 | llm (pooled) | row deadline starts in the worker, not at accept | CONFIRMED | p5-llm-pool-deadline (named) |
| **infrastructure/clients/http.py:1816-1844, 1509-1517** | web_scrape, blob_fetch, llm openrouter/gateway, dataverse, azure content_safety/prompt_shield/DI/CU/ai_search | no absolute deadline outside Power Automate; a slow-drip upstream holds a worker without bound | CONFIRMED (traced + httpx repro) | **NOT COVERED** |
| **transforms/azure/base.py:165-167** | azure safety/DI/CU batch transforms | effective batch wait = capacity budget + `_AZURE_HTTP_TIMEOUT_SECONDS`, which assumes a total HTTP bound; under drip the engine waiter fires first and the row ends without its structured result | PLAUSIBLE (follows from the row above) | **NOT COVERED** |
| transforms/llm/transform.py:108-116 | llm | same arithmetic using SDK "request timeout" (openai `DEFAULT_TIMEOUT.read`, which is also per-read) | PLAUSIBLE | p5-llm-pool-deadline (adjacent; not named) |
| transforms/web_scrape.py:1567/1599 | web_scrape pagination | `max_elapsed_seconds` is checked only between pages, so one dripping page overruns it | CONFIRMED (traced) | **NOT COVERED** |
| analyze_lro.py:384/586, textract_document_analysis.py:891/1058 | azure DI/CU, textract | poll deadlines checked between polls; each poll is a per-phase HTTP/SDK call. Bounded by poll count × timeout, so minor | PLAUSIBLE, low | NOT COVERED |

---

## F10 (NEW, minor). A security feature exists on one sink and not on its siblings

**Structural cause.** CSV formula neutralisation (`neutralize_csv_formula`) is an option on `csv_sink` and is always applied by audit export. The other two CSV writers do not offer it.

| Site | Plugin | What goes wrong | Status | Lane |
|---|---|---|---|---|
| **sinks/azure_blob_sink.py:947**, **sinks/aws_s3_sink.py:563** | azure_blob / aws_s3 sinks (CSV) | no `neutralize_formulas` option; a CSV written to cloud storage and opened in Excel carries live formulas from untrusted rows | CONFIRMED (feature absent) | **NOT COVERED** (enhancement-grade) |

**Single fix.** A shared `CSVWriteOptions` model with one row-serialiser that `csv_sink`, `azure_blob_sink` and `aws_s3_sink` all use. That would also close F1's sink-delimiter gaps by construction.

---

## F11. Cross-cutting meta-pattern

Each family above is the same shape: **a capability is implemented as a per-plugin copy instead of a shared typed authority with a whole-tree test.** Encoding, delimiter, credential field, response classification, URL control-char predicate, line decoder, BOM, effect modes vs Literal, batch cap and HTTP deadline all fit it. The fix that prevents recurrence is the same each time: (1) a shared type or helper, (2) a whole-tree test that walks every plugin config or call site and fails on any field or site not using it. The probe scripts in `sweep-scratch/` (`enc_probe.py`, `probe_secret_fields.py`, `literal_probe.py`) are close to drop-in gate tests for F1, F2 and F7.

---

## Uncovered findings, ranked by severity

1. **F2: credentials in repr/str for non-LLM plugins.** AzureBlob source and sink (`connection_string`, `sas_token`, `client_secret`), azure_content_safety, azure_prompt_shield and azure_ai_search `api_key`, and RAG `AzureSearchProviderConfig.api_key`. CONFIRMED with a sentinel in repr/str. p5-llm-audit covers only OpenRouter/Gateway.
2. **F9: no absolute HTTP deadline outside Power Automate** (http.py:1816). A slow-drip upstream holds web_scrape, blob_fetch, OpenRouter/Gateway LLM, Dataverse and Azure safety/DI/CU workers without bound, and breaks the batch-wait arithmetic in azure/base.py:165 and llm/transform.py:108. CONFIRMED (httpx repro + trace).
3. **F1: cloud CSV sink delimiters.** azure_blob_sink.py:138 and aws_s3_sink.py:99 accept `"`, `\n`, `\r`, which crash at publication. CONFIRMED. p5-io-validation lists only source delimiters.
4. **F1: blob_csv/json/text_expand accept non-text codecs** (`base64`/`rot13`). The decode raises an uncaught `LookupError` on the first row. CONFIRMED. At risk because p5-io-validation names only sources/sinks.
5. **F5: Azure Blob (JSONL :1087, CSV :735) and S3 JSONL (:1303) still use `surrogateescape`.** UTF-16/32 data loses whole chunks or the whole blob, with wrong line numbers. CONFIRMED by repro of the identical construct. These are the siblings of the fixed json_source #42 / text_source.
6. **F6: UTF-8 BOM not stripped** in text_source (BOM enters row data; CONFIRMED), blob_json_expand (row refused), blob_text_expand, azure_blob JSON/JSONL (file or line 1 quarantined), and plausibly S3 JSON/JSONL and blob_csv_expand in `original` header mode.
7. **F4 (lane-transitive): blob_fetch and Dataverse crash on DEL/C0 URLs** via an uncaught `httpx.InvalidURL`. These are fixed only if p5-web changes the shared helper. Also delete the `<32`-only local check at web_scrape_pagination.py:98, which misses DEL.
8. **F3: call-level classification beyond empty content.** Non-empty `finish_reason=length/content_filter` is recorded SUCCESS on all LLM providers. 2xx-with-malformed-body is SUCCESS for Azure safety/DI/CU/ai_search/Dataverse, while the AWS clients record ERROR. PLAUSIBLE (design ruling needed).
9. **F8: batch_duplicate_annotator's 4096-row cap** is a fifth copy of the constant and lives only in a hint. Any end-of-source window over 4096 rows fails the whole batch. CONFIRMED. Not in p5-batch's four files.
10. **F8/F9: timeout descriptions** ("Request timeout in seconds") on web_scrape, blob_fetch, OpenRouter and Gateway describe a total bound that does not exist.
11. **F10: no CSV formula neutralisation** on the Azure Blob and S3 CSV sinks (enhancement).
12. **F2: chained ValidationError `__cause__`** in `config_base.from_dict` can expose a truncated secret prefix in tracebacks. PLAUSIBLE, low.
