ADDENDUM (orchestrator, P3 tier, applies to every lane — read before starting):

A. PATHS. The lanes dir in the rules above is relative to the HUB, not to you. Use absolute paths:
   lanes dir = /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/lanes
   so heartbeat with `--lanes-dir /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.claude/lanes/fixrun/lanes`
   and write report.md under that absolute dir. Begin EVERY shell command with `cd <your worktree> &&`.

B. ENVIRONMENT. The base is the 0.8.14 integration line and requires Python >=3.14. Create the venv link once:
   `ln -sfn /home/user/elspeth/.claude/worktrees/compassionate-brahmagupta/.venv .venv` in your worktree (gitignored), and
   confirm `.venv/bin/python --version` prints 3.14.x. Never use /home/user/elspeth/.venv (that is 3.13).
   Always `export PYTHONPATH=$PWD/src:$PWD/elspeth-lints/src` and confirm once that
   `.venv/bin/python -c "import elspeth;print(elspeth.__file__)"` points INTO your worktree. A bare python imports the wrong tree.
   The host has 4 CPUs shared by several lanes: never run pytest with more than `-n 2`; never run the full `pytest tests/`.

C. PROCESS. Invoke the skills `superpowers:systematic-debugging` (root cause before fix) and
   `superpowers:test-driven-development` before writing code, and follow them. Read AGENTS.md and the
   CONTRIBUTING.md section "Whole-tree gates and conventions you will hit" before writing code.
   Fix the ROOT CAUSE the finding describes, in the smallest correct change; if the right fix lives outside the
   listed file (e.g. a shared helper or contract), make it there too and say why in report.md. If you conclude the
   finding is wrong or the fix is out of scope / needs a design decision from the maintainer, STOP, commit nothing
   further, and explain in report.md (summary line starting `BLOCKED:`).

D. WHOLE-TREE GATES you will hit when editing a plugin file:
   - Plugin `source_file_hash` pins: after `ruff format`, recompute per CONTRIBUTING "Gate: plugin inventories, source
     hashes, scenario-corpus manifest, fingerprint baseline" and re-pin (class attr, docs/architecture/dag/scenario-corpus/v1/manifest.yaml,
     any resumed_full_projection_sha256, EXPECTED_CASE_REGISTRY_SHA256) in the fix commit. Check with
     `.venv/bin/python -m pytest tests/integration/core/dag tests/unit/architecture -n 2 -q`.
   - Landscape mutation-fencing pins: if you add, remove or move a call to ctx.record_validation_error / record_call /
     record_transform_error / any landscape writer, run
     `.venv/bin/python scripts/fencing_inventory.py $PWD --baseline <git archive of your base>` and re-pin
     tests/unit/architecture/test_web_landscape_mutation_fencing.py (_EXPECTED_CALL_COUNT and the digest) with a comment
     naming each arrival/departure, in the same fix commit.
   - Before your final commit run, and get green: `.venv/bin/python -m ruff check src/ tests/`,
     `.venv/bin/python -m ruff format --check src/ tests/`, `.venv/bin/python scripts/check_contracts.py`,
     `.venv/bin/python -m mypy <files you touched>`, and the existing test files for the module you changed (`-n 2`).
   - Never add `# noqa`, `# type: ignore`, or lint suppressions. Never hand-edit judge signatures; if the trust-tier
     allowlist signature churns, leave it and note it in report.md.
   - No `git stash`. No `sed`/`awk` multi-line edits. No `/home/<user>` paths in tracked files.

E. COMMITS. A lane may carry several findings. For EACH finding make exactly two commits on your lane branch, in order:
   (1) its failing test alone, (2) its fix (+ any re-pins). Put every lane test in the ONE listed test file (it may grow
   across your test commits); each finding's tests must fail at an assertion on the base and pass after its fix.
   If a finding turns out to be wrong or needs a maintainer decision, skip it (no commits for it), finish the others,
   and explain in report.md; start the summary line `PARTIAL:` listing which findings landed and which did not.
   Messages in the repo's conventional style, e.g. `test(plugins): ...` then `fix(plugins): ...`, with a body that
   names the finding (`Sweep finding #N, 20261111-plugins-review`) and states root cause + fix. End each message with:

   Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
   Claude-Session: https://claude.ai/code/session_01Szt2FzsUgYrx4HhHYEBbKd

   Run `git status --short` before each commit and stage only your own files. Do NOT push; the hub merges and pushes.

F. report.md must include: root cause (with file:line), the fix, the RED evidence (pytest failure line) and GREEN evidence,
   every gate command you ran with its exit code, and anything you deliberately left alone.

G. VERIFY GATE. The hub verifies with lane-manager: every file listed under `files` in your brief MUST appear in your
   branch diff, the ONE test file must exist, and the test command must fail at an assertion on the base and pass on your
   branch; then the hub's full suite runs on the merged tree. P3 findings are lower-severity: prefer the smallest honest
   fix, and a finding whose remedy is a design change belongs under `PARTIAL:` rather than in a speculative refactor.

H. REPORT DELIVERY. If the harness refuses your write to report.md, put the COMPLETE report (sections per F) in your
   final message instead, starting with the one summary line; the hub writes report.md from it.
