import sys; sys.path.insert(0, ".")
from unittest.mock import MagicMock
from elspeth.contracts.schema_contract import FieldContract, SchemaContract, PipelineRow
from elspeth.plugins.transforms.field_mapper import FieldMapper
def row():
    data = {"first_name": "A", "meta": {"origin": "X"}, "status": "ORIGINAL"}
    orig = {"first_name": "First Name"}
    fields = tuple(FieldContract(normalized_name=k, original_name=orig.get(k, k), python_type=object, required=False, source="inferred") for k in data)
    return PipelineRow(data=data, contract=SchemaContract(mode="OBSERVED", fields=fields, locked=True))
for mapping in ({"First Name": "first", "meta.origin": "status"}, {"First Name": "first", "meta": "status"}):
    fm = FieldMapper({"schema": {"mode": "observed"}, "mapping": mapping})
    print(mapping, "forwards_input_fields=", fm.forwards_input_fields, "passes_through_input=", getattr(fm, "passes_through_input", None))
    try:
        r = fm.process(row(), MagicMock())
        print("  ->", r.status, r.row.to_dict() if r.row is not None else r.reason)
    except Exception as e:
        print("  RAISED", type(e).__name__, str(e)[:120])
