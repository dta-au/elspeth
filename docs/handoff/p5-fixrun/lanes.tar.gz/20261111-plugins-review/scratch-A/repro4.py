import sys, types, socket
sys.path.insert(0, ".")
from unittest.mock import patch
from tests.unit.plugins.transforms.test_web_scrape_pagination import _Recorder, _PayloadStore, _LimiterRegistry, _dns
from elspeth.contracts.plugin_context import PluginContext
from elspeth.plugins.transforms.web_scrape import WebScrapeTransform, RunMode
from elspeth.testing import make_pipeline_row
from tests.fixtures.mock_audit import mock_item_audit_authority
cfg = {"schema": {"mode": "observed"}, "url_field": "url", "content_field": "content","fingerprint_field": "fingerprint", "format": "text","http": {"abuse_contact": "test@example.com", "scraping_reason": "t"}}
for mode in (None, RunMode.REPLAY, RunMode.VERIFY):
    c = PluginContext(run_id="run-123", **mock_item_audit_authority("run-123"), config={}, landscape=_Recorder(), payload_store=_PayloadStore(), rate_limit_registry=_LimiterRegistry(), state_id="state-123")
    t = WebScrapeTransform(cfg); t.on_start(c)
    if mode is not None:
        sess = types.SimpleNamespace(mode=mode, replay_ssrf_request=lambda **k: (_ for _ in ()).throw(AssertionError("reached replay")))
        object.__setattr__(c, "call_mode_session", sess) if True else None
    try:
        r = t.process(make_pipeline_row({"url": "http://[bad/x"}), c)
        print(mode, r.status, r.reason)
    except Exception as e:
        print(mode, "RAISED", type(e).__name__, e)
