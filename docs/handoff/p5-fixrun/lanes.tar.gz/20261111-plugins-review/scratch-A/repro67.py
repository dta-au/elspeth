import sys; sys.path.insert(0, ".")
import inspect
from elspeth.plugins.transforms.field_mapper import FieldMapper
from elspeth.testing import make_pipeline_row
print(inspect.signature(make_pipeline_row))
from unittest.mock import MagicMock
for mapping in ({"First Name": "first", "meta.origin": "status"}, {"meta.origin": "status"}, {"First Name": "first", "other": "status"}):
    fm = FieldMapper({"schema": {"mode": "observed"}, "mapping": mapping})
    print(mapping, "forwards_input_fields=", fm.forwards_input_fields)
    row = make_pipeline_row({"first_name": "A", "meta": {"origin": "X"}, "status": "ORIGINAL", "other": "O"})
    print("  'meta.origin' in row:", "meta.origin" in row)
    try:
        r = fm.process(row, MagicMock())
        print("  ->", r.status, r.row.to_dict() if hasattr(r.row, "to_dict") else r.row)
    except Exception as e:
        print("  RAISED", type(e).__name__, str(e)[:150])
