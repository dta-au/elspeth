import sys, socket, traceback
sys.path.insert(0, ".")
from unittest.mock import patch
import httpx, respx
from tests.unit.plugins.transforms.test_web_scrape_pagination import _Recorder, _PayloadStore, _LimiterRegistry, _dns, _IP, _transform
from elspeth.contracts.plugin_context import PluginContext
from elspeth.plugins.transforms.web_scrape import WebScrapeTransform
from elspeth.testing import make_pipeline_row
from tests.fixtures.mock_audit import mock_item_audit_authority

def ctx():
    return PluginContext(run_id="run-123", **mock_item_audit_authority("run-123"), config={}, landscape=_Recorder(),
        payload_store=_PayloadStore(), rate_limit_registry=_LimiterRegistry(), state_id="state-123")

def plain(query=None):
    cfg = {"schema": {"mode": "observed"}, "url_field": "url", "content_field": "content",
           "fingerprint_field": "fingerprint", "format": "text",
           "http": {"abuse_contact": "test@example.com", "scraping_reason": "t"}}
    if query: cfg["query"] = query
    return WebScrapeTransform(cfg)

print("=== #2 control chars, default allowed_origins")
for q in (None, {"q": "x"}):
    for u in ["https://example.com/page\n", "https://example.com/\x00", "https://example.com/\x7f", "https://example.com/a\tb"]:
        with respx.mock:
            respx.route().mock(return_value=httpx.Response(200, headers={"content-type": "text/html"}, text="hi"))
            c = ctx(); t = plain(q)
            try:
                t.on_start(c)
            except Exception as e:
                print("on_start err", e); 
            try:
                with patch("socket.getaddrinfo", _dns):
                    r = t.process(make_pipeline_row({"url": u}), c)
                print(repr(u), q, "->", r.status, getattr(r, "reason", None))
            except Exception as e:
                tb = traceback.extract_tb(e.__traceback__)
                print(repr(u), q, "-> RAISED", type(e).__module__, type(e).__name__, e, [f"{f.filename.split('/')[-1]}:{f.lineno}" for f in tb[-3:]])

print("=== #3 pagination cycle with ':' in query")
for url, link in [("https://example.com/page-1?sort=a:b", "/page-1?sort=a:b"), ("https://example.com/page-1", "/page-1")]:
    with respx.mock:
        route = respx.get(url__regex=rf"https://{_IP}(:443)?/page-1.*").mock(return_value=httpx.Response(200, headers={"content-type":"text/html"}, text=f'<p>first</p><a class="next" href="{link}">Next</a>'))
        c = ctx(); t = _transform("next_link_css"); t.on_start(c)
        with patch("socket.getaddrinfo", _dns):
            r = t.process(make_pipeline_row({"url": url}), c)
        print(url, r.status, "calls=", route.call_count, "content=", r.row["content"] if r.status=="success" else r.reason,
              r.success_reason["metadata"].get("pagination_stop_reason") if r.status=="success" else None,
              len(r.success_reason["metadata"].get("pagination_pages", [])) if r.status=="success" else None)
