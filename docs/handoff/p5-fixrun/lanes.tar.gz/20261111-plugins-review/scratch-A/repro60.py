import sys, traceback; sys.path.insert(0, ".")
from elspeth.plugins.transforms.reference_join import ReferenceJoin
from elspeth.testing import make_pipeline_row
from unittest.mock import MagicMock
from elspeth.core.canonical import stable_hash
ctx = MagicMock()
for content in ('[{"sku":"a","rate":NaN}]', '[{"sku":"a","rate":Infinity}]', '[{"sku":"a","rate":12345678901234567890}]'):
    try:
        t = ReferenceJoin({"schema": {"mode": "observed"}, "reference_content": content, "reference_format": "json",
                           "key_field": "k", "reference_key_name": "sku", "output": {"r": "ref['rate']"}})
        print(content, "LOADED")
    except Exception as e:
        print(content, "LOAD REFUSED", type(e).__name__, str(e)[:100]); continue
    try:
        r = t.process(make_pipeline_row({"k": "a"}), ctx)
        print("  process ->", r.status, r.row.to_dict() if r.row else r.reason)
        try: stable_hash(r.row.to_dict()); print("  stable_hash ok")
        except Exception as e: print("  stable_hash RAISED", type(e).__name__, str(e)[:100])
    except Exception as e:
        tb = traceback.extract_tb(e.__traceback__)
        print("  process RAISED", type(e).__name__, e, [f"{f.filename.split('/')[-1]}:{f.lineno}" for f in tb[-3:]])
