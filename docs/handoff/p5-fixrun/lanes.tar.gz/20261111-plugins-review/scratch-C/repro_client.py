import json, urllib.parse
import httpx
from elspeth.plugins.infrastructure.clients import dataverse as dv
from elspeth.core.security.web import SSRFSafeRequest

def fake_ssrf(url):
    p = urllib.parse.urlparse(url)
    port = p.port or (443 if p.scheme == "https" else 80)
    path = p.path + ("?" + p.query if p.query else "")
    return SSRFSafeRequest(original_url=url, resolved_ip="20.0.0.1", host_header=p.hostname, port=port, path=path, scheme=p.scheme, bare_hostname=p.hostname)
dv.validate_url_for_ssrf = fake_ssrf

class Tok:  token = "SECRET"
class Cred:
    def get_token(self, scope): return Tok()

sent = []
def make(handler):
    c = dv.DataverseClient(environment_url="https://myorg.crm.dynamics.com", credential=Cred(), api_version="v9.2")
    def h(req):
        sent.append((str(req.url), req.headers.get("host"), req.headers.get("authorization"), req.headers.get("prefer"), urllib.parse.unquote(req.url.query.decode() if isinstance(req.url.query, bytes) else req.url.query)))
        return handler(req)
    c._client = httpx.Client(transport=httpx.MockTransport(h), follow_redirects=False)
    return c

MS_COOKIE = "<cookie pagenumber=\"2\" pagingcookie=\"%253ccookie%2520page%253d%25221%2522%253e%253ccontactid%2520last%253d%2522%257b70BF%257d%2522%2520first%253d%2522%257b49B0%257d%2522%2520%252f%253e%253c%252fcookie%253e\" istracking=\"False\" />"

print("=== #71: single-page FetchXML, final page without morerecords (MS doc shape) ===")
c = make(lambda r: httpx.Response(200, json={"value": [{"contactid": "a"}]}))
try:
    for p in c.paginate_fetchxml("contacts", "<fetch><entity name='contact'/></fetch>"):
        print("page rows", len(p.rows))
except dv.DataverseClientError as e:
    print("RAISED", e.error_category, str(e)[:90])
print("Prefer header sent:", sent[-1][3])

print("=== #72: cookie injection from MS-shaped annotation ===")
sent.clear(); n = {"i": 0}
def h72(r):
    n["i"] += 1
    if n["i"] == 1:
        return httpx.Response(200, json={"value": [{"contactid": "a"}], "@Microsoft.Dynamics.CRM.fetchxmlpagingcookie": MS_COOKIE, "@Microsoft.Dynamics.CRM.morerecords": True})
    return httpx.Response(200, json={"value": [{"contactid": "b"}], "@Microsoft.Dynamics.CRM.morerecords": False})
c = make(h72)
list(c.paginate_fetchxml("contacts", "<fetch><entity name='contact'/></fetch>"))
print("page2 fetchXml:", sent[1][4].split("fetchXml=",1)[1][:400])

print("=== #74: nextLink to http / foreign tenant ===")
for nl in ["http://myorg.crm.dynamics.com/api/data/v9.2/contacts?$skiptoken=x", "https://attacker.crm.dynamics.com/api/data/v9.2/contacts?$skiptoken=x"]:
    sent.clear(); n = {"i": 0}
    def h74(r, nl=nl):
        n["i"] += 1
        if n["i"] == 1:
            return httpx.Response(200, json={"value": [{"x": 1}], "@odata.nextLink": nl})
        return httpx.Response(200, json={"value": [{"x": 2}]})
    c = make(h74)
    try:
        list(c.paginate_odata("https://myorg.crm.dynamics.com/api/data/v9.2/contacts"))
        print("followed:", sent[1][0], "host=", sent[1][1], "auth=", sent[1][2])
    except dv.DataverseClientError as e:
        print("RAISED", e.error_category, e)
