import sys
from tests.unit.plugins.sources.test_azure_blob_source import _make_source, _base_config
class Ctx:
    def __init__(self): self.errs=[]
    def record_validation_error(self, **kw): self.errs.append(kw)
for depth in (500, 1500, 100000):
    deep = b'['*depth + b']'*depth
    obj = b'{"id":2,"x":' + deep + b'}'
    for fmt, meth, data in (("json","_load_json_array", b'[' + obj + b']'), ("jsonl","_load_jsonl", b'{"id":1}\n' + obj + b'\n{"id":3}\n')):
        src = _make_source(_base_config(format=fmt, blob_path="d."+fmt))
        src._first_valid_row_processed = False
        ctx = Ctx()
        out=[]
        try:
            for r in getattr(src, meth)(data, ctx):
                out.append((r.is_quarantined, r.source_row_index))
            print(depth, fmt, "rows", out, "errs", [e["error"][:60] for e in ctx.errs])
        except BaseException as e:
            import traceback
            tb = traceback.extract_tb(e.__traceback__)
            print(depth, fmt, "RAISED", type(e).__name__, "after rows", out, "errs", len(ctx.errs), "at", [f"{f.filename.split('/')[-1]}:{f.lineno}" for f in tb[:4]])
