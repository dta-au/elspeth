import json
import pytest
from elspeth.contracts.plugin_context import PluginContext
from elspeth.plugins.sources.json_source import JSONSource
from tests.fixtures.landscape import make_recorder_with_run

def _ctx():
    s = make_recorder_with_run(source_plugin_name="json")
    return PluginContext(run_id=s.run_id, coordination_token=s.coordination_token, node_id=s.source_node_id, config={}, landscape=s.factory.plugin_audit_writer())

@pytest.mark.parametrize("content,data_key", [('{"wrong":[1]}', "results"), ('[{"id":1}]', "results"), ('{"a":1}', None), ('[1]', None)])
def test_link(tmp_path, content, data_key):
    p = tmp_path / "d.json"; p.write_text(content)
    cfg = {"path": str(p), "format": "json", "on_validation_failure": "quarantine", "schema": {"mode": "observed"}}
    if data_key: cfg["data_key"] = data_key
    ctx = _ctx()
    rows = list(JSONSource(cfg).load(ctx))
    q = [r for r in rows if r.is_quarantined]
    print("\nCASE", content, data_key, "quarantined", len(q), "link:", [ctx.pop_pending_quarantine_validation_error_id(r.row) for r in q], "pending_left", len(ctx._pending_quarantine_validation_errors))

def test_deep(tmp_path):
    from elspeth.contracts.plugin_context import PluginContext
    for depth in (500, 1500):
        p = tmp_path / f"d{depth}.jsonl"
        p.write_text('{"id":1}\n{"id":2,"x":' + '['*depth + ']'*depth + '}\n{"id":3}\n')
        ctx = _ctx()
        out = []
        try:
            for r in JSONSource({"path": str(p), "format": "jsonl", "on_validation_failure": "quarantine", "schema": {"mode": "observed"}}).load(ctx):
                out.append((r.is_quarantined, r.source_row_index))
            print("\nDEEP", depth, "rows", out)
        except RecursionError as e:
            print("\nDEEP", depth, "RecursionError after", out)
