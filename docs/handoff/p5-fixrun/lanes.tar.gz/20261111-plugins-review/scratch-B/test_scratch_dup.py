from tests.fixtures.landscape import make_recorder_with_run
def test_dup():
    s = make_recorder_with_run()
    tok = s.coordination_token
    f = s.factory.data_flow
    f.create_row_with_token(s.source_node_id, 0, {"id": 1}, source_row_index=0, ingest_sequence=0, coordination_token=tok)
    f.create_row_with_token(s.source_node_id, 1, {"id": 2}, source_row_index=1, ingest_sequence=1, coordination_token=tok)
    try:
        f.create_row_with_token(s.source_node_id, 2, {"error": "x"}, source_row_index=0, ingest_sequence=2, quarantined=True, coordination_token=tok)
        print("NO ERROR")
    except Exception as e:
        print("RAISED", type(e).__name__, str(e)[:300])
