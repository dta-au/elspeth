from tests.fixtures.factories import make_source_context
from elspeth.plugins.sources.csv_source import CSVSource
from elspeth.plugins.sources.text_source import TextSource

def _summ(rows):
    v = [r for r in rows if not r.is_quarantined]
    q = [(r.source_row_index, dict(r.row)) for r in rows if r.is_quarantined]
    return len(v), q

def test_csv(tmp_path):
    for nrows, bad in ((3000, 2001), (200, 151)):
        lines = ["id,val"] + [f"{i},row{i}" for i in range(1, nrows + 1)]
        data = "\n".join(lines).encode() + b"\n"
        parts = data.split(b"\n")
        parts[bad - 1] = parts[bad - 1] + b"\xff"   # physical line `bad` (1-based, header=line 1)
        p = tmp_path / f"d{nrows}.csv"; p.write_bytes(b"\n".join(parts))
        ctx = make_source_context()
        rows = list(CSVSource({"path": str(p), "on_validation_failure": "quarantine", "schema": {"mode": "observed"}}).load(ctx))
        nv, q = _summ(rows)
        print(f"\nCSV n={nrows} bad_line={bad}: valid={nv} quarantined={q}")

def test_text(tmp_path):
    p = tmp_path / "t.txt"
    p.write_bytes("a\nb\n".encode("utf-16-le") + b"\x00\xd8" + "c\nd\ne\n".encode("utf-16-le"))
    ctx = make_source_context(plugin_name="text")
    rows = list(TextSource({"path": str(p), "encoding": "utf-16-le", "column": "line", "on_validation_failure": "quarantine", "schema": {"mode": "observed"}}).load(ctx))
    print("\nTEXT", [(r.is_quarantined, r.source_row_index, dict(r.row)) for r in rows])
