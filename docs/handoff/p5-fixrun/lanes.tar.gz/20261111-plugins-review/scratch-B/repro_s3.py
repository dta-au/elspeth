import elspeth, sys
print("elspeth at", elspeth.__file__)
from tests.unit.plugins.sources.test_aws_s3_source import _source_for
def run(data, **kw):
    src, _, ctx = _source_for(data, **kw)
    try:
        rows = list(src.load(ctx))
    except BaseException as e:
        print("  RAISED", type(e).__name__, e); return
    print("  rows:", [("Q" if r.is_quarantined else "V", r.source_row_index, r.row if r.is_quarantined else dict(r.row)) for r in rows])
    print("  verrs:", [v["error"] for v in ctx.validation_errors])
print("#9")
run(b'[{"id":1},{"id":2}] garbage', format="json")
run(b'[{"id":1},{"id":2},{"id"', format="json")
run(b'{"r":[{"id":1},{"id":2}],"r":[{"id":3}]}', format="json", json_options={"data_key":"r"})
print("#10")
run(b'{"id":1}\n{"id":"' + b'x'*50 + b'"}\n{"id":3}\n{"id":4}\n', format="jsonl", max_record_chars=20)
run(b'id\n1\n' + b'x'*50 + b'\n3\n4\n', format="csv", max_record_chars=20)
print("#11")
run(b'\nid\n1\n', format="csv")
run(b'\n\n', format="csv")
run(b'\r\n', format="csv")
run(b'', format="csv")
