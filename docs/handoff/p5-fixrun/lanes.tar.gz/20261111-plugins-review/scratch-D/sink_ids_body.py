import uuid, chromadb
from datetime import timedelta
from elspeth.contracts import NodeType
from elspeth.engine.executors.sink_effects import SinkEffectCoordinator
from tests.fixtures.landscape import leader_token_for, make_factory, make_landscape_db, register_test_node
from tests.unit.engine.test_chroma_member_effect_diversion import _RecordingCollection, _make_sink, _build_request

def run(rows, collection, label, attempts=2):
    db = make_landscape_db()
    try:
        f = make_factory(db)
        r = f.run_lifecycle.begin_run(config={}, canonical_version="v1")
        src = register_test_node(f.data_flow, r.run_id, "source", node_type=NodeType.SOURCE, plugin_name="source")
        snk = register_test_node(f.data_flow, r.run_id, "sink", node_type=NodeType.SINK, plugin_name="chroma_sink")
        req = _build_request(f, r.run_id, src, snk, rows)
        sink = _make_sink(collection)
        for i in range(attempts):
            try:
                res = SinkEffectCoordinator(factory=f, worker_id="w", lease_ttl=timedelta(minutes=5), coordination_token=leader_token_for(db, r.run_id)).execute(req, sink)
                print(label, "attempt", i, "OK state", res.effect.state); break
            except Exception as e:
                print(label, "attempt", i, "->", type(e).__name__, str(e)[:120])
    finally:
        db.close()

col = chromadb.EphemeralClient().get_or_create_collection(f"e{uuid.uuid4().hex[:6]}")
run([{"doc_id": "d0", "text": "doc 0", "topic": "t"}, {"doc_id": "", "text": "doc 1", "topic": "t"}], col, "EMPTY_ID")
print("collection ids after:", col.get()["ids"])
run([{"doc_id": "d0", "text": "doc 0", "topic": "t"}, {"doc_id": "d0", "text": "doc 0b", "topic": "t"}, {"doc_id": "d2", "text": "doc 2", "topic": "t"}], _RecordingCollection(), "DUP_ID")
