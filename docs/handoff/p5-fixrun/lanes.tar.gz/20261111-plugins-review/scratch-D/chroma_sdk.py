import httpx, uuid, json, chromadb
import chromadb.api.fastapi as fa
MODE = {"m": "ok"}
CID = str(uuid.uuid4())
def handler(req):
    p = req.url.path
    if MODE["m"] == "connect": raise httpx.ConnectError("refused", request=req)
    if MODE["m"] == "timeout": raise httpx.ReadTimeout("timeout", request=req)
    if MODE["m"] == "502": return httpx.Response(502, text="<html>Bad Gateway</html>")
    if MODE["m"] == "badjson": return httpx.Response(200, text="<html>ok</html>")
    if p.endswith("/auth/identity"): return httpx.Response(200, json={"user_id": "", "tenant": "default_tenant", "databases": ["default_database"]})
    if "/collections/" in p and p.endswith("/count"): return httpx.Response(200, json=3)
    if "/collections/" in p: return httpx.Response(200, json={"id": CID, "name": "c", "configuration_json": {}, "metadata": {"hnsw:space": "cosine"}, "dimension": None, "tenant": "default_tenant", "database": "default_database", "version": 0, "log_position": 0})
    if "/databases/" in p: return httpx.Response(200, json={"id": str(uuid.uuid4()), "name": "default_database", "tenant": "default_tenant"})
    if "/tenants/" in p: return httpx.Response(200, json={"name": "default_tenant"})
    return httpx.Response(200, json={})
orig = httpx.Client
fa.httpx.Client = lambda *a, **kw: orig(*a, transport=httpx.MockTransport(handler), **kw)
c = chromadb.HttpClient(host="127.0.0.1", port=8000)
col = c.get_collection("c")
print("count ok", col.count())
for m in ["connect", "timeout", "502", "badjson"]:
    MODE["m"] = m
    try: col.count(); print(m, "no error")
    except Exception as e: print(m, "->", type(e).__module__, type(e).__name__, "chroma?", isinstance(e, chromadb.errors.ChromaError), "OSError?", isinstance(e, (OSError, ConnectionError, TimeoutError)))
