import sys, uuid, runpy
ns = runpy.run_path(".claude/lanes/20261111-plugins-review/scratch-D/chroma_sdk.py")  # leaves MODE / col
MODE, col = ns["MODE"], ns["col"]
from tests.unit.plugins.infrastructure.clients.retrieval.test_chroma import _fake_execution, _precreate_collection
from tests.fixtures.mock_audit import mock_item_audit_authority
from elspeth.plugins.infrastructure.clients.retrieval.chroma import ChromaSearchProvider, ChromaSearchProviderConfig
for m in ["connect", "timeout", "502", "badjson"]:
    name = f"v-{uuid.uuid4().hex[:8]}"; _precreate_collection(name)
    ex = _fake_execution()
    p = ChromaSearchProvider(config=ChromaSearchProviderConfig(collection=name, mode="ephemeral"), execution=ex, run_id="r")
    p._collection = col  # real chromadb HTTP Collection, transport fault injected below the SDK
    MODE["m"] = m
    try:
        p.search("q", top_k=3, min_score=0.0, **mock_item_audit_authority(), state_id="s1", token_id=None); print(m, "no error")
    except Exception as e:
        print("search", m, "->", type(e).__name__, "| allocated", ex.call_indices, "recorded", len(ex.recorded_calls))
