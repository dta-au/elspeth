import chromadb, uuid
c = chromadb.EphemeralClient(); col = c.get_or_create_collection(f"e{uuid.uuid4().hex[:6]}")
for op, f in [("upsert", lambda: col.upsert(ids=[""], documents=["d"])), ("get", lambda: col.get(ids=[""], include=["documents","metadatas"]))]:
    try: print(op, "OK", f())
    except Exception as e: print(op, "->", type(e).__name__, "ChromaError" if isinstance(e, chromadb.errors.ChromaError) else "", "ValueError" if isinstance(e, ValueError) else "", e)
