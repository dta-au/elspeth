import os, glob
from elspeth.plugins.infrastructure.rasterize.renderer import PoolRenderer
from elspeth.testing.rasterize_fakes import crashing_worker, raising_worker
from tests.unit.plugins.infrastructure.rasterize.test_renderer import _limits
if __name__ == "__main__":
    t = os.environ["TMPDIR"]
    for w in (crashing_worker, raising_worker):
        r = PoolRenderer(_limits(), worker=w)
        try:
            r.render(b"%PDF-")
        except RuntimeError as e:
            print(w.__name__, "RuntimeError", "| leaked dirs:", len(glob.glob(os.path.join(t, "elspeth-rasterize-*"))))
        finally:
            r.close()
