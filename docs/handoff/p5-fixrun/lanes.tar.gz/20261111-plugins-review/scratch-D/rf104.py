import os, sys, yaml, traceback
sys.path.insert(0, os.environ["WT"])
from tests.unit.cli.test_cli_preflight import _explicit_audit_export_settings
from elspeth.plugins.infrastructure.runtime_factory import validate_sink_effect_eligibility_from_raw_config as v
from elspeth.engine.orchestrator.preflight import SinkEffectExecutionPurpose as P
os.chdir(os.environ["CFG"])
sinks = {"pipeline": {"plugin": "csv", "options": {"path": "out.csv", "schema": {"mode": "observed"}}}, "audit": {"plugin": "json", "options": {"path": "a.json", "schema": {"mode": "observed"}}}}
cases = {
  "typo": _explicit_audit_export_settings(enabled=True, sink="audti"),
  "env_sink": _explicit_audit_export_settings(enabled=True, sink="${AUDIT_SINK}"),
  "env_enabled": _explicit_audit_export_settings(enabled="${EXPORT_ON:-true}"),
}
os.environ["AUDIT_SINK"] = "audit"
for name, exp in cases.items():
    raw = {"sinks": sinks, "landscape": {"export": exp}}
    for purpose in (P.FRESH, P.AUDIT_EXPORT):
        try:
            r = v(raw, purpose=purpose, expand_env_placeholders=True); print(name, purpose.name, "OK", sorted(r))
        except Exception as e:
            print(name, purpose.name, "->", type(e).__name__, str(e).splitlines()[0][:100])
