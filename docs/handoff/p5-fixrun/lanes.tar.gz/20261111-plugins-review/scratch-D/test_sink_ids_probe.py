import runpy
def test_probe(capsys):
    runpy.run_path(".claude/lanes/20261111-plugins-review/scratch-D/sink_ids_body.py")
