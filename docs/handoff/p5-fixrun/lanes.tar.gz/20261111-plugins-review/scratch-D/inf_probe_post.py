from unittest.mock import patch
import httpx
from elspeth.core.canonical import stable_hash
from elspeth.core.security.web import SSRFSafeRequest
from elspeth.plugins.infrastructure.clients.http import AuditedHTTPClient
from tests.fixtures.mock_audit import mock_item_audit_authority

class Rec:
    def __init__(self): self.calls = []
    def allocate_call_index(self, *a, **k): return len(self.calls)
    def record_call(self, **kw):
        rd = kw["response_data"]
        stable_hash(rd.to_dict() if rd is not None else None)  # what the real recorder does
        self.calls.append(kw)
        return object()

import sys; body = {"pos": b"{\"x\": 1e999}", "neg": b"{\"x\": 1.5}", "deep": b"[" * 900 + b"]" * 900, "deep_neg": b"[" * 40 + b"]" * 40}[sys.argv[1]]
resp = httpx.Response(200, headers={"content-type": "application/json"}, content=body,
                      request=httpx.Request("GET", "http://93.184.216.34/"))
class C:
    def __init__(self, *a, **k): pass
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def get(self, *a, **k): return resp
    def request(self, *a, **k): return resp
    def post(self, *a, **k): return resp
    def send(self, *a, **k): return resp
    def build_request(self, *a, **k): return resp.request
    def stream(self, *a, **k): raise AssertionError('stream')
    def close(self): pass
rec = Rec()
client = AuditedHTTPClient(**mock_item_audit_authority("run-1"), execution=rec, state_id="s1", run_id="run-1", telemetry_emit=lambda e: None)
sr = SSRFSafeRequest(original_url="http://example.com/", resolved_ip="93.184.216.34", host_header="example.com", port=80, path="/", scheme="http", bare_hostname="example.com")
with patch("httpx.Client", C):
    client = AuditedHTTPClient(**mock_item_audit_authority("run-1"), execution=rec, state_id="s1", run_id="run-1", telemetry_emit=lambda e: None)
    try:
        client.post("http://93.184.216.34/", json={"a": 1})
        print("OK recorded", len(rec.calls), rec.calls[-1]["status"], str(rec.calls[-1].get("error"))[:80])
    except Exception as e:
        print("RAISED", type(e).__name__, e, "recorded", len(rec.calls))
