from types import SimpleNamespace
from elspeth.contracts import CallStatus
from elspeth.contracts.chat_parts import ChatMessage
from elspeth.contracts.enums import RunMode
from elspeth.plugins.infrastructure.clients.llm import AuditedLLMClient, LLMClientError
from tests.unit.plugins.clients.test_audited_llm_client import FakeOpenAIClient, FakeExecutionRepository, mock_audit_authority

class ReplaySession:
    mode = RunMode.REPLAY
    def replay_call(self, **kw):
        return SimpleNamespace(source_call_id="src", status=CallStatus.ERROR,
            response_data={"content": "", "model": "gpt-4"},
            error_data={"type": "ContentPolicyError", "message": "LLM returned null content (likely content-filtered by provider)",
                        "retryable": False, "pricing_model": "gpt-4", "provider_cost": None,
                        "provider_cost_source": "not_available", "category": "content_policy"}, latency_ms=1.0)
c = AuditedLLMClient(**mock_audit_authority(), execution=FakeExecutionRepository(), state_id="s", run_id="r",
    telemetry_emit=lambda e: None, underlying_client=FakeOpenAIClient(exception=AssertionError("no sdk")), call_mode_session=ReplaySession())
try:
    c.chat_completion(model="gpt-4", messages=[ChatMessage(role="user", content="hi")])
except Exception as e:
    print(type(e).__name__, "is LLMClientError:", isinstance(e, LLMClientError), e)
