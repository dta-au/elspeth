import pytest
import tests.e2e.pipelines.test_csv_to_database as m

@pytest.mark.parametrize("n", [50, 2000])
def test_big(tmp_path, monkeypatch, n):
    orig = m._write_csv
    def w(path, headers, rows):
        orig(path, headers, [[str(i), f"name{i}", str(i % 100)] for i in range(n)])
    monkeypatch.setattr(m, "_write_csv", w)
    try:
        m.TestCSVToDatabase().test_csv_to_sqlite_database(tmp_path)
    except AssertionError as e:
        # row count assertion expected to differ (5 hard-coded)
        print("ASSERT", n, str(e)[:200])
        raise
