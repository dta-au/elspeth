from tests.unit.plugins.transforms.test_batch_classifier_metrics import _make_row, DYNAMIC_SCHEMA
from tests.fixtures.factories import make_context
from elspeth.plugins.transforms.batch_classifier_metrics import BatchClassifierMetrics
for pl in ("1", 1.0):
    t = BatchClassifierMetrics({"schema": DYNAMIC_SCHEMA, "actual_field": "a", "predicted_field": "p", "positive_label": pl})
    print("configured", repr(t._positive_label))
    r = t.process([_make_row({"a":1,"p":1}), _make_row({"a":1,"p":0}), _make_row({"a":0,"p":0})], make_context())
    print(r.status, tuple(r.row["labels"]), {k: r.row[k] for k in ("binary_tp","binary_fn","binary_tn","binary_fp")})
