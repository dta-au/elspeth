from elspeth.contracts.schema_contract import SchemaContract
from elspeth.testing import make_field, make_row
from tests.fixtures.factories import make_context
from elspeth.plugins.transforms.batch_replicate import BatchReplicate
from elspeth.contracts.union_merge import join_batch_contracts
def row(data, req):
    fs = tuple(make_field(k, type(v), original_name=k, required=req, source="declared") for k, v in data.items())
    return make_row(data, contract=SchemaContract(mode="FLEXIBLE", fields=fs, locked=True))
r0 = row({"x": 1, "y": "a", "copies": 1}, True)
r1 = row({"x": "hello", "copies": 1}, True)
t = BatchReplicate({"schema": {"mode": "observed"}, "copies_field": "copies"})
res = t.process([r0, r1], make_context())
print(res.status)
out = res.rows[1]
print(out.to_dict())
for f in out.contract.fields: print(" ", f.normalized_name, f.python_type.__name__, "required" if f.required else "optional")
print("join:", [(f.normalized_name, f.python_type.__name__, f.required) for f in join_batch_contracts([r0.contract, r1.contract]).fields])
