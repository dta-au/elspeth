from tests.unit.plugins.transforms.aws.test_textract_result import _geometry
from elspeth.plugins.transforms.aws import textract_result as tr
def blk(id, t, **kw):
    b = {"Id": id, "BlockType": t, "Page": 1, "Confidence": 99.0, "Geometry": _geometry()}; b.update(kw); return b
blocks = []
for i, st in enumerate(("SELECTED", "NOT_SELECTED")):
    blocks += [
        blk(f"k{i}", "KEY_VALUE_SET", EntityTypes=["KEY"], Relationships=[{"Type": "VALUE", "Ids": [f"v{i}"]}, {"Type": "CHILD", "Ids": [f"w{i}"]}]),
        blk(f"w{i}", "WORD", Text=f"Box{i}"),
        blk(f"v{i}", "KEY_VALUE_SET", EntityTypes=["VALUE"], Relationships=[{"Type": "CHILD", "Ids": [f"s{i}"]}]),
        blk(f"s{i}", "SELECTION_ELEMENT", SelectionStatus=st),
    ]
index = {b["Id"]: b for b in blocks}
for f in tr._project_forms(blocks, index):
    print(f["key"], repr(f["value"]), sorted(f))
