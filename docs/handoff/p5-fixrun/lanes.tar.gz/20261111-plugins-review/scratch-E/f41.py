from elspeth.plugins.sinks.database_sink import DatabaseSink
from elspeth.contracts.sink_effects import *
import elspeth.contracts.sink_effects as se
P = [v for k,v in vars(se).items() if k=="SinkEffectExecutionPurpose"][0]
L = {"table": "_elspeth_sink_effects","schema_version":1,"permissions":["select","insert"]}
base = {"url":"sqlite:///x.db","table":"t","schema":{"mode":"observed"}}
for name, cfg in [("no-ledger", dict(base)), ("replace", dict(base, if_exists="replace", effect_ledger=L)),
                  ("mssql", dict(base, url="mssql+pyodbc://h/db", effect_ledger=L)), ("ok", dict(base, effect_ledger=L))]:
    try:
        r = DatabaseSink._resolve_sink_effect_mode(cfg, purpose=list(P)[0]); print(name, "OK", r)
    except Exception as e: print(name, type(e).__name__, e)
