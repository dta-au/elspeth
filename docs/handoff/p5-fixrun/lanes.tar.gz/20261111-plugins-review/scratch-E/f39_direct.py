import sys, tempfile, pathlib, os
import elspeth; print(elspeth.__file__)
from tests.integration.plugins.sinks import test_database_sink_effects as t
from elspeth.plugins.sinks.database_sink import DatabaseSink
d = pathlib.Path(sys.argv[1]); d.mkdir(parents=True, exist_ok=True)
for n in (10, 200):
    db = d / f"o{n}.db"
    if db.exists(): db.unlink()
    url = f"sqlite:///{db}"
    t._provision(url)
    sink = DatabaseSink(t._config(url))
    rows = tuple({"id": i, "name": "x"*500} for i in range(n))
    try:
        plan = t._prepare(sink, rows)
        print(n, "OK")
    except Exception as e:
        print(n, type(e).__name__, e)
