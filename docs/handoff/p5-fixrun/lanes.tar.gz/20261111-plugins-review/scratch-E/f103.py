import sys, pathlib
from tests.unit.plugins.sinks import test_local_file_sink_effects as t
from elspeth.plugins.sinks.json_sink import JSONSink
d = pathlib.Path(sys.argv[1]); d.mkdir(parents=True, exist_ok=True)
p = d / "a.jsonl"; p.write_text('{"id": 0}')
cfg = {"path": str(p), "format": "jsonl", "schema": t._SCHEMA, "mode": "append", "collision_policy": "append_or_create"}
s = JSONSink(cfg)
print("validate:", s.validate_output_target())
s.commit_effect(t._prepare(s, effect_id="cc"*32, rows=[{"id": 1}]), t._CTX)
print(repr(p.read_text()))
# also: second line garbage
p.write_text('{"id": 0}\nnot json\n'); s = JSONSink(cfg)
print("validate garbage line2:", s.validate_output_target().valid)
