import json
from elspeth.plugins.transforms.blob_json_expand import BlobJSONExpand
from elspeth.testing import make_pipeline_row
from tests.fixtures.factories import make_context
def mk(fmt):
    return BlobJSONExpand({"schema": {"mode": "observed", "guaranteed_fields": ["content"]},
        "source": "field", "format": fmt, "text_field": "content", "fields": ["a"]})
for fmt, text in [("json", "["*20000), ("jsonl", "["*20000 + "\n")]:
    try:
        r = mk(fmt).process(make_pipeline_row({"content": text}), make_context())
        print(fmt, "result", r.status, str(r.reason)[:200])
    except BaseException as e:
        print(fmt, "RAISED", type(e).__name__, str(e)[:100])
# f69
text = json.dumps({"a": "x y"}, ensure_ascii=False) + "\n" + json.dumps({"a": "z\u0085w"}, ensure_ascii=False) + "\n"
print("json.loads per \\n line:", [json.loads(l) for l in text.split("\n") if l])
r = mk("jsonl").process(make_pipeline_row({"content": text}), make_context())
print("jsonl", r.status, str(r.reason)[:400], [x.to_dict() for x in (r.rows or [])] if r.status=="success" else "")
