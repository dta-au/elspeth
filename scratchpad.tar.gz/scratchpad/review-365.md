VERDICT: PASS WITH NOTES

# Review of 6df029d8 (cherry-pick of c7f3cac4) — dta-au/elspeth#365, for 0.8.14

Reviewed tree: `/home/user/elspeth/.claude/worktrees/push-tip` at `6df029d8` (read only).
All test runs and the mutation were done in a separate detached worktree
`.claude/worktrees/review-365` at the same sha; `elspeth.__file__` and
`elspeth_lints.__file__` were confirmed to resolve inside it. Logs are in
`/tmp/claude-0/-home-user-elspeth/9e76fd8a-1fdc-52cb-beb3-e049cc7b3c01/scratchpad/`.

## What was checked, and the result

| # | Question | Result | Evidence |
|---|---|---|---|
| 1 | Bypass closed? | Yes for fork, fork-of-fork, share, replay | code trace + reverted-file control + my route-level test |
| 2 | Provenance correct, no legitimate fork rejected? | Yes; two narrow fail-closed edges (notes N1, N2) | code trace, CHECK/FK read, route-level test |
| 3 | Persistence / gate integrity | Sound on SQLite; PostgreSQL by reading only | SQL read; mutation-authority gate passes and goes red on revert |
| 4 | Composer invariants | Not touched | diff is confined to the blob copy writer, a docstring, docs, tests |
| 5 | Tests fail without fix, pass with it | Yes | `r365-reverted.log` exit=1, `r365-with-fix.log` exit=0 |

### Test runs (exit codes read from the process, not a pipe)

- With the fix: `tests/unit/web/blobs/test_service.py`,
  `tests/unit/architecture/test_session_db_mutation_authority.py`,
  `tests/unit/web/sessions/test_fork*.py`,
  `tests/unit/web/execution/test_file_inject_upload_only_readiness.py`,
  `tests/unit/web/shareable_reviews` — **exit=0**, 874 passed, 1 skipped, 1 xfailed
  (`r365-with-fix.log`).
- Negative control: `src/elspeth/web/blobs/service.py` replaced with the `HEAD~1`
  version in the scratch worktree only — **exit=1**, 7 failed (`r365-reverted.log`):
  the new test fails with `assert VERBATIM is LLM_GENERATED`, both parameters of my
  route-level test fail the same way, and four mutation-authority tests fail on the
  moved pins. File restored afterwards; `git status` showed only my scratch test.
- Reviewer scratch test through the real `POST /api/sessions/{id}/fork` route
  (in-memory and file-backed SQLite) — **exit=0**, 2 passed (`r365-scratch.log`).
  It covers what the commit's own test does not: the real plan-row writer, a fork
  of a fork with the child's plan row inside the copied slice (the grandchild then
  holds 2 `session_fork` audit rows and the anchor resolves to its own), the anchor
  row being `(child session, role=audit, writer=session_fork)`, an untouched upload
  staying `VERBATIM` with a null anchor, and `archive_session` of both descendants.
- `ruff check` and `ruff format --check` on the changed files: clean. `mypy` on
  `web/blobs/service.py`: clean.
- Keyless trust-tier lint (`--rules all --root src/elspeth`), HEAD vs a `HEAD~1`
  snapshot: no finding added or removed in `web/blobs/service.py`,
  `web/composer/tools/blobs.py` or `web/sessions/fork_custody.py`;
  `trust_tier.tier_model` line count 496 on both. (The snapshot lacked `tests/`,
  so two `R_TB_TESTS_FILE_MISSING` lines appear only on the base side; that is an
  artefact of my instrument, not of the commit.)
- Whole `tests/unit/architecture` directory: did not finish; see "Limits".

## 1. Does the fix close the bypass?

Yes, for every fork path I could trace.

- **fork -> copy -> guard.** `copy_blobs_for_fork` (`web/blobs/service.py:4239-4245`)
  now passes the source row's modality and five `creating_*` values. Every
  modality reader then sees the copy as LLM-authored: the prompt-surface guard
  (`execution/_validation_materialization.py:338-356`, used at
  `execution/service.py:1314`, `:3862`, `composer/tools/blobs.py:925`, `:1005`),
  the `blob_rows` admission (`execution/service.py:4009`,
  `sessions/routes/composer/state.py:793`, `composer/tools/sources.py:1432`) and
  the invented-source stamp (`composer/tools/sources.py:348`, `:867-883`).
- **fork -> share/import.** `_check_shareable_blob`
  (`shareable_reviews/service.py:390`) refuses `created_by == "assistant"` or any
  non-`VERBATIM` modality. It already refused these copies on `created_by`; it now
  refuses on both.
- **fork of a fork.** The grandchild reads modality from the child's copy and
  anchors to its own plan row. Verified by my route-level test.
- **replay / stale-worker takeover.** The anchor is chosen by
  `(source, target, operation_id)`, so a replay under a new lease attempt computes
  the same id; the commit's test asserts `replayed == copied`.
- **`update_blob` after fork.** Modality for a rewrite is decided server-side by
  `_blob_creation_provenance` (`composer/tools/blobs.py:1354`), not inherited, and
  the rewrite records `created_by="assistant"`. Nothing in the fork path feeds it.
- **source changing between plan and copy.** The parent is under the fork fence,
  and `_verify_plan_and_quota` re-checks status, hash and size; the modality used
  is the one read in that same verified snapshot.

Remaining, as the author states: fork copies written before this change keep
`VERBATIM` (no backfill). That is a disclosed residual, not a defect of the commit.

Out of scope, not caused by this commit, and not verified end to end: the
prompt-surface guard is modality-only and `reserve_pending_output_blob` records
pipeline output as `VERBATIM` (per the docstring at
`composer/tools/blobs.py:443-450`), so the output of an `llm` node is a second
kind of model-written `VERBATIM` content. It is not a fork path. Worth a ticket
if it is not already tracked.

## 2. Is the provenance correct, and can a legitimate fork now be rejected?

- `ck_blobs_creating_llm_provenance_nullability` (`sessions/models.py:160-177`)
  requires a non-blank anchor plus all five fields for the three LLM modalities
  and five NULLs for `verbatim`. The copy inherits a row that already satisfied
  it, and `_persist_blob_content` re-checks (`service.py:1564-1568`).
- `fk_blobs_created_from_message_session` is `(created_from_message_id,
  session_id) -> chat_messages(id, session_id)`. The plan row is written in the
  staging transaction (`sessions/service.py:8611-8639`), which commits before the
  route calls `copy_blobs_for_fork` (`sessions/routes/sessions.py:1005`), so the
  key exists in the child on either dialect.
- Several `session_fork` audit rows: handled. The lookup filters on the exact
  operation identity, the same rule `_load_staged_fork_from_transaction` and
  `_settlement_fork_blob_plan` already use. Zero or two matches raise
  `AuditIntegrityError` — but the staging loader already demands exactly one
  before the copy can start, so this cannot reject a fork that would otherwise
  have succeeded.
- The lookup runs only when at least one planned source is LLM-authored
  (`service.py:4172`), so a fork with no model-written blob takes the old path
  unchanged.
- The route's `BlobForkWriteFence.operation_id` is `fence.operation_id`, the same
  value written into the plan row — confirmed by the route-level test passing.

### Notes

**N1 — Low. A fork in flight across the upgrade fails closed.**
`web/blobs/service.py:1220-1248` (`_validate_reusable_blob_row`). If a fork
copied a model-written blob with the old code (row `verbatim`, null anchor), the
worker died, and the retry runs on the new code, the reuse check raises
`Inline custody blob ... has mismatched creation_modality`. The fork fails and
is cleaned up; nothing is laundered. Found by reading; not reproduced. Worth one
line in the release notes ("retry a fork that was interrupted by the upgrade").

**N2 — Low. Copy validation is stricter than the `update_blob` writer.**
`_persist_blob_content` requires the two hashes to be lowercase SHA-256
(`service.py:350-357`, `:1549-1556`); the replacement writer
(`coordination/repository.py:2602-2620`) and the table CHECK only require
non-blank. A source row whose hash was not SHA-256-shaped would now fail the
fork where the old code copied it. I found no producer of such a value
(`create_blob` goes through the same check with the same context values), so
this is theoretical. Found by reading.

**N3 — Low. Asymmetry for assistant `VERBATIM` copies.**
`service.py:4240`. An original the composer created from the user's own words is
`VERBATIM` with a non-null `created_from_message_id`; its fork copy still gets
`None`. This is the "unchanged" behaviour the author promised, but it means the
frontend's inline-source test (`ChatPanel.tsx:209-214`, assistant + non-null
anchor) now recognises LLM-authored copies and still not assistant-verbatim
ones. No guard reads the anchor, so no security effect.

**N4 — Info. The anchor's meaning differs on a copy.**
On an original the anchor is the triggering user message; on a copy it is an
audit plan row. `sessions/models.py:2347-2358` still describes it as "the user
message". No code in `src/` joins on it or assumes a role (searched for
`c.created_from_message_id`; only the preflight snapshot and the index use it).
The comment could be updated.

**N5 — Info. Test coverage gaps, as admitted.**
No acceptance test binds a forked LLM copy as a source (`_source_authoring_options`)
or as an `llm` prompt through the tool; the share leg is tested at
`_check_shareable_blob` only; the commit's own test uses a hand-seeded plan row
rather than the fork route. My route-level scratch test closes the last of these
for review purposes but is not in the commit.

## 3. Audit / persistence integrity

- The added SELECT (`service.py:4174-4180`) is three equality predicates on
  `chat_messages(session_id, role, writer_principal)`, read-only, on the existing
  verification connection. Nothing dialect-specific. The helper receives plain
  rows after the block; no connection escapes.
- The insert is the existing `_insert_pending_blob_row` with different values.
  No schema change, no new writer.
- Mutation-authority gate: passes with the commit; the pins are line moves plus
  one re-fingerprinted read block (`_verify_plan_and_quota`,
  `3a607d21bd66351e -> 86374a2a12d20ebf`), `connection_escape=False` throughout.
  The gate goes red when the file is reverted, so it is measuring this file.
- `chat_messages` rows cannot be deleted directly (`trg_chat_messages_no_delete`),
  and the FK is `RESTRICT`; an anchored copy has the same lifecycle shape as an
  anchored original. `archive_session` on both descendants succeeded in my test.
- **Not run on PostgreSQL** (no Docker here). Judged by reading only: the commit
  adds no SQL construct that differs between the dialects, and the FK target is
  committed before the insert. The author's "never run on PostgreSQL" stands; the
  `testcontainer` job is the gate for it.

## 4. Composer invariants

The diff touches the blob copy writer, one docstring in `composer/tools/blobs.py`,
two spec documents and tests. It authors no pipeline structure, adds no provider
bypass and no tutorial branch. It changes server-side recording of provenance,
which makes existing refusals fire; that is validation, which the invariants
permit. No `getattr`, `isinstance`, `noqa` or `type: ignore` is added in `src/`.

## Limits of this review

- PostgreSQL: not run.
- Full `pytest tests/`: not run. Scope was the changed module, the fork suites,
  the share suite, the upload-only readiness suite and the mutation-authority gate.
- Whole `tests/unit/architecture` directory: **incomplete, no pass claimed.** Three attempts stalled at the same point and none exited on its own (one killed by the 30-minute tool limit, one stopped by me, one capped with `timeout 1500`, exit=124). In the verbose attempt (`r365-arch3.log`) 2000 of 2013 items reported PASSED/XFAIL/SKIPPED and 0 reported FAILED or ERROR; the worker was still inside `tests/unit/architecture/test_web_landscape_mutation_fencing.py::test_required_work_reserve_rejects_protected_instance_formal_recovery` and 13 items never reported. That file scans Landscape code this commit does not touch, and I did not measure whether it also stalls on `HEAD~1`, so I cannot say whether the stall is the environment or the tree. The one architecture file whose pins this commit edits, `test_session_db_mutation_authority.py`, completed and passed in the exit=0 run above.
- N1 and N2 were found by reading and were not reproduced.
- The scratch worktree and my scratch test were removed at the end; nothing in
  `push-tip` was edited, staged or committed.
