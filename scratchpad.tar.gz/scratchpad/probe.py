import asyncio, gc, logging, sys, io
W="/home/user/elspeth/.claude/worktrees/composer-0.8.12"
sys.path.insert(0, W+"/src")
buf = io.StringIO()
h = logging.StreamHandler(buf); logging.getLogger("asyncio").addHandler(h); logging.getLogger("asyncio").propagate=False

async def inner():
    await asyncio.sleep(0.01)
    raise ValueError("SECRET-CONTENT")

def handler(loop, ctx):
    msg = ctx.get("message","")
    exc = ctx.get("exception")
    if exc is not None and msg.endswith("exception in shielded future"):
        logging.getLogger("asyncio").error("shielded task failed after awaiter cancelled exc_class=%s", type(exc).__name__)
        return
    loop.default_exception_handler(ctx)

async def scenario(shield, install, observe):
    loop = asyncio.get_running_loop()
    if install: loop.set_exception_handler(handler)
    t = asyncio.create_task(inner())
    async def waiter():
        await shield(t)
    w = asyncio.create_task(waiter())
    await asyncio.sleep(0)
    w.cancel()
    await asyncio.sleep(0.05)
    if observe:
        t.exception()
    del t, w
    gc.collect(); await asyncio.sleep(0); gc.collect()

def run(label, shield, install, observe, uv=False):
    buf.seek(0); buf.truncate()
    if uv:
        import uvloop
        with asyncio.Runner(loop_factory=uvloop.new_event_loop) as r: r.run(scenario(shield, install, observe))
    else:
        asyncio.run(scenario(shield, install, observe))
    gc.collect()
    out = buf.getvalue()
    first = out.splitlines()[0] if out else "<nothing logged>"
    print(f"{label:55s} leak={'SECRET' in out!s:5} first={first!r}")

try:
    from elspeth.web.execution.runtime_preflight import _shield
except Exception as e:
    print("no _shield", type(e).__name__); _shield=None
print(sys.version.split()[0])
for uv in (False, True):
    tag = "uvloop" if uv else "asyncio"
    try:
        run(f"{tag} stdlib shield, default handler, unobserved", asyncio.shield, False, False, uv)
        run(f"{tag} stdlib shield, default handler, observed", asyncio.shield, False, True, uv)
        run(f"{tag} stdlib shield, custom handler, unobserved", asyncio.shield, True, False, uv)
        if _shield:
            run(f"{tag} private _shield, default handler, unobserved", _shield, False, False, uv)
            run(f"{tag} private _shield, default handler, observed", _shield, False, True, uv)
            run(f"{tag} private _shield, custom handler, unobserved", _shield, True, False, uv)
    except ImportError as e:
        print(tag, "unavailable", e)
