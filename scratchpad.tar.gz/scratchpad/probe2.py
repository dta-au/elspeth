import sys, time
sys.path.insert(0, ".")
from tests.unit.plugins.transforms.aws import test_guardrails_client as tg

# C: end-to-end unrecorded call
bad = tg.response()
bad["assessments"][0]["contentPolicy"]["filters"][0]["confidence"] = ["HIGH"]
class SDK:
    n = 0
    def apply_guardrail(self, **_k):
        SDK.n += 1
        return bad
ex = tg.FakeExecution()
try:
    tg._client(SDK(), ex, []).apply_guardrail(text="x", source="INPUT", required_filters=tg.PROMPT_FILTERS)
except Exception as e:
    print("C:", type(e).__name__, "| sdk calls:", SDK.n, "| audit records:", len(ex.calls))
# control: string-bad confidence IS recorded
bad2 = tg.response(); bad2["assessments"][0]["contentPolicy"]["filters"][0]["confidence"] = "BOGUS"
class SDK2:
    def apply_guardrail(self, **_k): return bad2
ex2 = tg.FakeExecution()
try:
    tg._client(SDK2(), ex2, []).apply_guardrail(text="x", source="INPUT", required_filters=tg.PROMPT_FILTERS)
except Exception as e:
    print("C control:", type(e).__name__, "| audit records:", len(ex2.calls))

# G: transform config accepts ARN whose region differs from region
from elspeth.plugins.transforms.aws.bedrock_prompt_shield import AWSBedrockPromptShieldConfig
from elspeth.plugins.transforms.aws.guardrail_profiles import BedrockGuardrailProfileSettings
arn = "arn:aws:bedrock:us-west-2:123456789012:guardrail/abc123"
base = {"guardrail_identifier": arn, "guardrail_version": "1", "region": "us-east-1"}
try:
    AWSBedrockPromptShieldConfig.from_dict({**base, "fields": ["p"], "schema": {"mode": "observed"}}, plugin_name="aws_bedrock_prompt_shield")
    print("G: transform config ACCEPTS mismatched ARN region")
except Exception as e: print("G: transform config rejects:", type(e).__name__)
try:
    BedrockGuardrailProfileSettings(alias="a", plugin="aws_bedrock_prompt_shield", **base)
    print("G control: profile accepts")
except Exception as e: print("G control: profile rejects:", type(e).__name__)
try:
    AWSBedrockPromptShieldConfig.from_dict({**base, "guardrail_identifier": "arn:aws-us-gov:bedrock:us-east-1:123456789012:guardrail/abc", "fields": ["p"], "schema": {"mode": "observed"}}, plugin_name="x")
    print("G: transform config ACCEPTS non-commercial partition ARN")
except Exception as e: print("G: partition rejects:", type(e).__name__)

# F: inline config bounds
from elspeth.plugins.transforms.aws.textract_inline_analysis import AWSTextractInlineAnalysisConfig
from elspeth.plugins.transforms.aws.textract_document_analysis import AWSTextractDocumentAnalysisConfig
inl = {"region": "us-east-1", "document_format": "png", "feature_types": ["FORMS"], "text_field": "t", "schema": {"mode": "observed"}}
c = AWSTextractInlineAnalysisConfig.from_dict({**inl, "max_blocks": 10**12, "max_result_bytes": 10**15, "request_timeout_seconds": 1e9, "batch_wait_timeout_seconds": 1e12}, plugin_name="x")
print("F: inline accepts", c.max_blocks, c.max_result_bytes, c.request_timeout_seconds, c.batch_wait_timeout_seconds)
doc = {"region": "us-east-1", "bucket_field": "b", "key_field": "k", "feature_types": ["FORMS"], "text_field": "t", "schema": {"mode": "observed"}}
try:
    AWSTextractDocumentAnalysisConfig.from_dict({**doc, "max_result_bytes": 10**15}, plugin_name="x"); print("F control: doc accepts")
except Exception as e: print("F control: doc analysis rejects oversize:", type(e).__name__)
c2 = AWSTextractDocumentAnalysisConfig.from_dict({**doc, "poll_interval_seconds": 1e-9, "poll_max_interval_seconds": 1e-9}, plugin_name="x")
print("F2: doc accepts poll_interval_seconds", c2.poll_interval_seconds)

# E: _project_pages scaling
from elspeth.plugins.transforms.aws import textract_result as tr
def doc_blocks(pages, lines_per_page):
    blocks = []
    for p in range(1, pages + 1):
        blocks.append({"BlockType": "PAGE", "Id": f"p{p}", "Page": p})
        for l in range(lines_per_page):
            blocks.append({"BlockType": "LINE", "Id": f"l{p}-{l}", "Page": p, "Text": "hello", "Confidence": 99.0})
    return blocks
for pages, lpp in [(100, 60), (200, 60), (400, 60)]:
    b = doc_blocks(pages, lpp)
    t0 = time.perf_counter(); tr._project_pages(b); dt = time.perf_counter() - t0
    print(f"E: pages={pages} blocks={len(b)} _project_pages={dt:.2f}s")
