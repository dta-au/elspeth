import ast, pathlib, yaml, collections, glob
SC=(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)
def is_shield(n): return isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=="shield" and isinstance(n.func.value,ast.Name) and n.func.value.id=="asyncio"
scopes={}  # file -> {qual tuple: contains_shield}
def walk(node,qual,out):
    for c in ast.iter_child_nodes(node):
        if isinstance(c,SC):
            q=qual+(c.name,); out[q]=out.get(q,False) or any(is_shield(n) for n in ast.walk(c)); walk(c,q,out)
        else: walk(c,qual,out)
for p in pathlib.Path("src/elspeth").rglob("*.py"):
    s=p.read_text()
    if "asyncio.shield(" in s:
        out={}; walk(ast.parse(s),(),out); scopes[str(p.relative_to("src/elspeth"))]=out
tot=collections.Counter(); rows=[]
for y in glob.glob("config/cicd/enforce_tier_model/*.yaml"):
    for e in (yaml.safe_load(open(y)) or {}).get("allow_hits",[]) or []:
        parts=e["key"].split(":"); f=parts[0]
        if f not in scopes: continue
        sym=tuple(parts[2:-1]); tot["entries_in_26_files"]+=1
        if not sym: tot["module_level(drift)"]+=1; rows.append(e["key"]); continue
        if sym not in scopes[f]: tot["symbol_not_found"]+=1; print("NOSYM",e["key"]); continue
        if scopes[f][sym]: tot["scope_contains_shield(drift)"]+=1; rows.append(e["key"])
        else: tot["scope_clean"]+=1
print(dict(tot)); print(*rows,sep="\n")
