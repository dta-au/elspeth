import inspect, sys
from pathlib import Path
from elspeth.plugins.infrastructure.manager import get_shared_plugin_manager
from elspeth_lints.rules.plugin_contract.plugin_hashes.rule import discover_plugin_files, extract_plugin_attributes
root = Path(sys.argv[1])
pm = get_shared_plugin_manager()
classes = pm.get_sources() + pm.get_transforms() + pm.get_sinks()
discovered = {p.resolve() for p in discover_plugin_files(root)}
scanned = set()
for p in discovered:
    for a in extract_plugin_attributes(p):
        scanned.add((p, a.class_name))
print("registry plugins:", len(classes), " discovered files:", len(discovered), " scanned classes:", len(scanned))
missing = []
for c in classes:
    f = Path(inspect.getfile(c)).resolve()
    if (f, c.__name__) not in scanned:
        missing.append((c.name, c.__name__, str(f.relative_to(root.resolve().parent.parent))))
for m in sorted(missing):
    print("NOT SCANNED:", *m)
print("missing:", len(missing))
