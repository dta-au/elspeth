import os, sys
sys.path.insert(0, ".")
os.environ["AWS_ACCESS_KEY_ID"] = "test"; os.environ["AWS_SECRET_ACCESS_KEY"] = "test"; os.environ.pop("AWS_SESSION_TOKEN", None)
from botocore.exceptions import EndpointConnectionError, SSLError
from botocore.retries.standard import ExponentialBackoff
ExponentialBackoff.delay_amount = lambda self, context: 0
from tests.fixtures.mock_audit import mock_item_audit_authority
from tests.unit.plugins.transforms.aws.test_guardrails_client import FakeExecution
from elspeth.plugins.transforms.aws import textract_client as t

for label, exc_factory in [("EndpointConnectionError", lambda url: EndpointConnectionError(endpoint_url=url)),
                           ("SSLError", lambda url: SSLError(endpoint_url=url, error="handshake"))]:
    sdk = t.build_textract_sdk_client(region="us-east-1", aws_access_key_id=None, aws_secret_access_key=None, aws_session_token=None)
    sends = []
    def fail(request, _f=exc_factory, **_k):
        sends.append(1); raise _f(request.url)
    sdk.meta.events.register("before-send.textract", fail)
    ex = FakeExecution()
    c = t.TextractInlineClient(**mock_item_audit_authority("run-1"), execution=ex, state_id="state-1", run_id="run-1",
                               telemetry_emit=lambda e: None, region="us-east-1", sdk_client=sdk, max_response_bytes=10**6, token_id="tok")
    try:
        c.analyze_document(document_bytes=b"\x89PNG\r\n\x1a\nxx", document_sha256="0"*64, document_format="png", feature_types=("FORMS",), queries=())
    except t.TextractServiceError as e:
        rec = ex.calls[0]
        print(label, "| http attempts:", len(sends), "| audited attempts:", rec["response_data"].to_dict()["attempts"],
              "| code:", e.code, "| retryable:", e.retryable)
