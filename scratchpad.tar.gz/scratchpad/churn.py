import ast, re, pathlib, yaml, collections, glob
SC=(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)
def is_shield(n): return isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=="shield" and isinstance(n.func.value,ast.Name) and n.func.value.id=="asyncio"
files={}
for p in pathlib.Path("src/elspeth").rglob("*.py"):
    s=p.read_text()
    if "asyncio.shield(" in s: files[str(p.relative_to("src/elspeth"))]=ast.parse(s)
print("files with shield:",len(files))
def resolve(mod,path):
    node=mod; scopes=[]
    for part in path.split("/"):
        m=re.fullmatch(r"(\w+)(?:\[(\d+)\])?",part)
        v=getattr(node,m.group(1))
        node=v[int(m.group(2))] if m.group(2) is not None else v
        if isinstance(node,SC): scopes.append(node)
    return node,scopes
tot=collections.Counter(); per=collections.defaultdict(lambda:[0,0,0]); unresolved=0; allentries=0; signed_all=0
for y in glob.glob("config/cicd/enforce_tier_model/*.yaml"):
    d=yaml.safe_load(open(y)) or {}
    for e in d.get("allow_hits",[]) or []:
        allentries+=1
        if e.get("judge_metadata_signature"): signed_all+=1
        f=e["key"].split(":")[0]
        if f not in files: continue
        per[f][0]+=1
        if not e.get("ast_path"): tot["in_file_unsigned/no_ast_path"]+=1; continue
        try: node,scopes=resolve(files[f],e["ast_path"])
        except Exception as ex:
            unresolved+=1; print("UNRES",f,e["ast_path"],type(ex).__name__,ex) if unresolved<6 else None; continue
        # the finding node itself may be a scope? innermost enclosing scope = last scope that is a proper ancestor or self
        inner=scopes[-1] if scopes else files[f]
        hit=any(is_shield(n) for n in ast.walk(inner))
        per[f][1]+=1
        if hit: per[f][2]+=1; tot["scope_fp_drift_certain"]+=1
        tot["signed_in_26_files"]+=1
print("total allowlist entries",allentries,"signed",signed_all,"unresolved",unresolved)
print(dict(tot))
for f,(a,b,c) in sorted(per.items()): print(f"{f}: entries={a} bound={b} scope_contains_shield={c}")
print("files with shield but zero entries:", sorted(set(files)-set(per)))
