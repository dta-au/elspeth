import ast, sys, pathlib, collections
root = pathlib.Path("src")
rows=[]; 
for p in sorted(root.rglob("*.py")):
    src=p.read_text()
    if "shield" not in src: continue
    tree=ast.parse(src)
    parents={}
    for n in ast.walk(tree):
        for c in ast.iter_child_nodes(n): parents[c]=n
    for n in ast.walk(tree):
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=="shield" and isinstance(n.func.value,ast.Name) and n.func.value.id=="asyncio":
            f=n
            chain=[]
            while f in parents:
                f=parents[f]
                if isinstance(f,(ast.FunctionDef,ast.AsyncFunctionDef)): chain.append(f)
            fn=chain[0] if chain else None
            arg=ast.unparse(n.args[0])
            body=ast.unparse(fn) if fn else ""
            observed = any(f"{arg}.{m}(" in body for m in ("result","exception"))
            loop = f"while not {arg}.done()" in body or "while True" in body
            handed = (f"({arg}" in body.replace(f"shield({arg}","")) # passed to another call
            rows.append((str(p),n.lineno,".".join(c.name for c in reversed(chain)),arg,observed,loop,handed, fn.end_lineno-fn.lineno+1 if fn else 0))
c=collections.Counter()
for r in rows:
    c[(r[4],r[5])]+=1
    print(f"{r[0]}:{r[1]} fn={r[2]} arg={r[3]} same_fn_result/exception={r[4]} drain_loop={r[5]} passed_on={r[6]}")
print(len(rows), dict(c))
print("distinct enclosing fns:", len({(r[0],r[2]) for r in rows}))
